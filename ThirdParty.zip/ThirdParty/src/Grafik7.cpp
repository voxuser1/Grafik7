/*******************************************************************************************************************
Copyright (c) 2023 Cycling '74

The code that Max generates automatically and that end users are capable of
exporting and using, and any associated documentation files (the “Software”)
is a work of authorship for which Cycling '74 is the author and owner for
copyright purposes.

This Software is dual-licensed either under the terms of the Cycling '74
License for Max-Generated Code for Export, or alternatively under the terms
of the General Public License (GPL) Version 3. You may use the Software
according to either of these licenses as it is most appropriate for your
project on a case-by-case basis (proprietary or not).

A) Cycling '74 License for Max-Generated Code for Export

A license is hereby granted, free of charge, to any person obtaining a copy
of the Software (“Licensee”) to use, copy, modify, merge, publish, and
distribute copies of the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following conditions:

The Software is licensed to Licensee for all uses that do not include the sale,
sublicensing, or commercial distribution of software that incorporates this
source code. This means that the Licensee is free to use this software for
educational, research, and prototyping purposes, to create musical or other
creative works with software that incorporates this source code, or any other
use that does not constitute selling software that makes use of this source
code. Commercial distribution also includes the packaging of free software with
other paid software, hardware, or software-provided commercial services.

For entities with UNDER $200k in annual revenue or funding, a license is hereby
granted, free of charge, for the sale, sublicensing, or commercial distribution
of software that incorporates this source code, for as long as the entity's
annual revenue remains below $200k annual revenue or funding.

For entities with OVER $200k in annual revenue or funding interested in the
sale, sublicensing, or commercial distribution of software that incorporates
this source code, please send inquiries to licensing@cycling74.com.

The above copyright notice and this license shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Please see
https://support.cycling74.com/hc/en-us/articles/10730637742483-RNBO-Export-Licensing-FAQ
for additional information

B) General Public License Version 3 (GPLv3)
Details of the GPLv3 license can be found at: https://www.gnu.org/licenses/gpl-3.0.html
*******************************************************************************************************************/

#include "RNBO_Common.h"
#include "RNBO_AudioSignal.h"

namespace RNBO {


#define trunc(x) ((Int)(x))

#if defined(__GNUC__) || defined(__clang__)
    #define RNBO_RESTRICT __restrict__
#elif defined(_MSC_VER)
    #define RNBO_RESTRICT __restrict
#endif

#define FIXEDSIZEARRAYINIT(...) { }

class Grafik7 : public PatcherInterfaceImpl {
public:

class RNBOSubpatcher_199 : public PatcherInterfaceImpl {
    
    friend class Grafik7;
    
    public:
    
    class RNBOSubpatcher_190 : public PatcherInterfaceImpl {
            
            friend class RNBOSubpatcher_199;
            friend class Grafik7;
            
            public:
            
            RNBOSubpatcher_190()
            {
            }
            
            ~RNBOSubpatcher_190()
            {
            }
            
            virtual RNBOSubpatcher_199* getPatcher() const {
                return static_cast<RNBOSubpatcher_199 *>(_parentPatcher);
            }
            
            Grafik7* getTopLevelPatcher() {
                return this->getPatcher()->getTopLevelPatcher();
            }
            
            void cancelClockEvents()
            {
            }
            
            Index getNumMidiInputPorts() const {
                return 0;
            }
            
            void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
            
            Index getNumMidiOutputPorts() const {
                return 0;
            }
            
            void process(
                const SampleValue * const* inputs,
                Index numInputs,
                SampleValue * const* outputs,
                Index numOutputs,
                Index n
            ) {
                this->vs = n;
                this->updateTime(this->getEngine()->getCurrentTime());
                SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
                const SampleValue * in1 = (numInputs >= 1 && inputs[0] ? inputs[0] : this->zeroBuffer);
                this->onepole_tilde_01_perform(in1, this->onepole_tilde_01_freqInHz, this->signals[0], n);
                this->dspexpr_02_perform(this->signals[0], this->dspexpr_02_in2, this->signals[1], n);
                this->dspexpr_01_perform(in1, this->signals[1], out1, n);
                this->stackprotect_perform(n);
                this->audioProcessSampleCount += this->vs;
            }
            
            void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
                if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
                    Index i;
            
                    for (i = 0; i < 2; i++) {
                        this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
                    }
            
                    this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
                    this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
                    this->didAllocateSignals = true;
                }
            
                const bool sampleRateChanged = sampleRate != this->sr;
                const bool maxvsChanged = maxBlockSize != this->maxvs;
                const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
            
                if (sampleRateChanged || maxvsChanged) {
                    this->vs = maxBlockSize;
                    this->maxvs = maxBlockSize;
                    this->sr = sampleRate;
                    this->invsr = 1 / sampleRate;
                }
            
                this->onepole_tilde_01_dspsetup(forceDSPSetup);
            
                if (sampleRateChanged)
                    this->onSampleRateChanged(sampleRate);
            }
            
            void setProbingTarget(MessageTag id) {
                switch (id) {
                default:
                    {
                    this->setProbingIndex(-1);
                    break;
                    }
                }
            }
            
            void setProbingIndex(ProbingIndex ) {}
            
            Index getProbingChannels(MessageTag outletId) const {
                RNBO_UNUSED(outletId);
                return 0;
            }
            
            Index getIsMuted()  {
                return this->isMuted;
            }
            
            void setIsMuted(Index v)  {
                this->isMuted = v;
            }
            
            void onSampleRateChanged(double ) {}
            
            Index getPatcherSerial() const {
                return 0;
            }
            
            void getState(PatcherStateInterface& ) {}
            
            void setState() {}
            
            void getPreset(PatcherStateInterface& ) {}
            
            void setParameterValue(ParameterIndex , ParameterValue , MillisecondTime ) {}
            
            void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValue(index, value, time);
            }
            
            void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
                this->setParameterValue(index, this->getParameterValue(index), time);
            }
            
            void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValueNormalized(index, value, time);
            }
            
            ParameterValue getParameterValue(ParameterIndex index)  {
                switch (index) {
                default:
                    {
                    return 0;
                    }
                }
            }
            
            ParameterIndex getNumSignalInParameters() const {
                return 0;
            }
            
            ParameterIndex getNumSignalOutParameters() const {
                return 0;
            }
            
            ParameterIndex getNumParameters() const {
                return 0;
            }
            
            ConstCharPointer getParameterName(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            ConstCharPointer getParameterId(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            void getParameterInfo(ParameterIndex , ParameterInfo * ) const {}
            
            void sendParameter(ParameterIndex index, bool ignoreValue) {
                this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
            }
            
            void setParameterOffset(ParameterIndex offset) {
                this->parameterOffset = offset;
            }
            
            ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
                if (steps == 1) {
                    if (normalizedValue > 0) {
                        normalizedValue = 1.;
                    }
                } else {
                    ParameterValue oneStep = (number)1. / (steps - 1);
                    ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
                    normalizedValue = numberOfSteps * oneStep;
                }
            
                return normalizedValue;
            }
            
            ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                value = (value < 0 ? 0 : (value > 1 ? 1 : value));
            
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            void scheduleParamInit(ParameterIndex index, Index order) {
                this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
            }
            
            void processClockEvent(MillisecondTime , ClockId , bool , ParameterValue ) {}
            
            void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
            
            void processOutletEvent(
                EngineLink* sender,
                OutletIndex index,
                ParameterValue value,
                MillisecondTime time
            ) {
                this->updateTime(time);
                this->processOutletAtCurrentTime(sender, index, value);
            }
            
            void processNumMessage(MessageTag , MessageTag , MillisecondTime , number ) {}
            
            void processListMessage(MessageTag , MessageTag , MillisecondTime , const list& ) {}
            
            void processBangMessage(MessageTag , MessageTag , MillisecondTime ) {}
            
            MessageTagInfo resolveTag(MessageTag tag) const {
                switch (tag) {
            
                }
            
                return nullptr;
            }
            
            DataRef* getDataRef(DataRefIndex index)  {
                switch (index) {
                default:
                    {
                    return nullptr;
                    }
                }
            }
            
            DataRefIndex getNumDataRefs() const {
                return 0;
            }
            
            void fillDataRef(DataRefIndex , DataRef& ) {}
            
            void processDataViewUpdate(DataRefIndex , MillisecondTime ) {}
            
            void initialize() {
                this->assign_defaults();
                this->setState();
            }
            
            protected:
            
            number msToSamps(MillisecondTime ms, number sampleRate) {
                return ms * sampleRate * 0.001;
            }
            
            MillisecondTime sampsToMs(SampleIndex samps) {
                return samps * (this->invsr * 1000);
            }
            
            Index getMaxBlockSize() const {
                return this->maxvs;
            }
            
            number getSampleRate() const {
                return this->sr;
            }
            
            bool hasFixedVectorSize() const {
                return false;
            }
            
            Index getNumInputChannels() const {
                return 1;
            }
            
            Index getNumOutputChannels() const {
                return 1;
            }
            
            void initializeObjects() {}
            
            void sendOutlet(OutletIndex index, ParameterValue value) {
                this->getEngine()->sendOutlet(this, index, value);
            }
            
            void startup() {}
            
            void allocateDataRefs() {}
            
            void onepole_tilde_01_perform(const Sample * x, number freqInHz, SampleValue * out1, Index n) {
                RNBO_UNUSED(freqInHz);
                auto __onepole_tilde_01_lastY = this->onepole_tilde_01_lastY;
                auto __onepole_tilde_01_b1 = this->onepole_tilde_01_b1;
                auto __onepole_tilde_01_a0 = this->onepole_tilde_01_a0;
                auto __onepole_tilde_01_needsUpdate = this->onepole_tilde_01_needsUpdate;
                auto __onepole_tilde_01_freq = this->onepole_tilde_01_freq;
                Index i;
            
                for (i = 0; i < n; i++) {
                    if (__onepole_tilde_01_freq != 20 || (bool)(__onepole_tilde_01_needsUpdate)) {
                        __onepole_tilde_01_freq = 20;
                        __onepole_tilde_01_a0 = 1 - rnbo_exp(-125.66370614359172 / this->sr);
                        __onepole_tilde_01_a0 = (__onepole_tilde_01_a0 > 0.99999 ? 0.99999 : (__onepole_tilde_01_a0 < 0.00001 ? 0.00001 : __onepole_tilde_01_a0));
                        __onepole_tilde_01_b1 = 1 - __onepole_tilde_01_a0;
                        __onepole_tilde_01_needsUpdate = false;
                    }
            
                    __onepole_tilde_01_lastY = __onepole_tilde_01_a0 * x[(Index)i] + __onepole_tilde_01_b1 * __onepole_tilde_01_lastY;
                    out1[(Index)i] = __onepole_tilde_01_lastY;
                }
            
                this->onepole_tilde_01_freq = __onepole_tilde_01_freq;
                this->onepole_tilde_01_needsUpdate = __onepole_tilde_01_needsUpdate;
                this->onepole_tilde_01_a0 = __onepole_tilde_01_a0;
                this->onepole_tilde_01_b1 = __onepole_tilde_01_b1;
                this->onepole_tilde_01_lastY = __onepole_tilde_01_lastY;
            }
            
            void dspexpr_02_perform(const Sample * in1, number in2, SampleValue * out1, Index n) {
                RNBO_UNUSED(in2);
                Index i;
            
                for (i = 0; i < n; i++) {
                    out1[(Index)i] = in1[(Index)i] * -1;//#map:_###_obj_###_:1
                }
            }
            
            void dspexpr_01_perform(const Sample * in1, const Sample * in2, SampleValue * out1, Index n) {
                Index i;
            
                for (i = 0; i < n; i++) {
                    out1[(Index)i] = in1[(Index)i] + in2[(Index)i];//#map:_###_obj_###_:1
                }
            }
            
            void stackprotect_perform(Index n) {
                RNBO_UNUSED(n);
                auto __stackprotect_count = this->stackprotect_count;
                __stackprotect_count = 0;
                this->stackprotect_count = __stackprotect_count;
            }
            
            void onepole_tilde_01_reset() {
                this->onepole_tilde_01_lastY = 0;
                this->onepole_tilde_01_a0 = 0;
                this->onepole_tilde_01_b1 = 0;
            }
            
            void onepole_tilde_01_dspsetup(bool force) {
                if ((bool)(this->onepole_tilde_01_setupDone) && (bool)(!(bool)(force)))
                    return;
            
                this->onepole_tilde_01_needsUpdate = true;
                this->onepole_tilde_01_reset();
                this->onepole_tilde_01_setupDone = true;
            }
            
            bool stackprotect_check() {
                this->stackprotect_count++;
            
                if (this->stackprotect_count > 128) {
                    console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
                    return true;
                }
            
                return false;
            }
            
            void updateTime(MillisecondTime time) {
                this->_currentTime = time;
                this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
            
                if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
                    this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
            
                if (this->sampleOffsetIntoNextAudioBuffer < 0)
                    this->sampleOffsetIntoNextAudioBuffer = 0;
            }
            
            void assign_defaults()
            {
                dspexpr_01_in1 = 0;
                dspexpr_01_in2 = 0;
                dspexpr_02_in1 = 0;
                dspexpr_02_in2 = -1;
                onepole_tilde_01_x = 0;
                onepole_tilde_01_freqInHz = 20;
                _currentTime = 0;
                audioProcessSampleCount = 0;
                sampleOffsetIntoNextAudioBuffer = 0;
                zeroBuffer = nullptr;
                dummyBuffer = nullptr;
                signals[0] = nullptr;
                signals[1] = nullptr;
                didAllocateSignals = 0;
                vs = 0;
                maxvs = 0;
                sr = 44100;
                invsr = 0.00002267573696;
                onepole_tilde_01_freq = 0;
                onepole_tilde_01_needsUpdate = false;
                onepole_tilde_01_lastY = 0;
                onepole_tilde_01_a0 = 0;
                onepole_tilde_01_b1 = 0;
                onepole_tilde_01_setupDone = false;
                stackprotect_count = 0;
                _voiceIndex = 0;
                _noteNumber = 0;
                isMuted = 1;
                parameterOffset = 0;
            }
            
            // member variables
            
                number dspexpr_01_in1;
                number dspexpr_01_in2;
                number dspexpr_02_in1;
                number dspexpr_02_in2;
                number onepole_tilde_01_x;
                number onepole_tilde_01_freqInHz;
                MillisecondTime _currentTime;
                UInt64 audioProcessSampleCount;
                SampleIndex sampleOffsetIntoNextAudioBuffer;
                signal zeroBuffer;
                signal dummyBuffer;
                SampleValue * signals[2];
                bool didAllocateSignals;
                Index vs;
                Index maxvs;
                number sr;
                number invsr;
                number onepole_tilde_01_freq;
                bool onepole_tilde_01_needsUpdate;
                number onepole_tilde_01_lastY;
                number onepole_tilde_01_a0;
                number onepole_tilde_01_b1;
                bool onepole_tilde_01_setupDone;
                number stackprotect_count;
                Index _voiceIndex;
                Int _noteNumber;
                Index isMuted;
                ParameterIndex parameterOffset;
            
    };
    
    class RNBOSubpatcher_191 : public PatcherInterfaceImpl {
            
            friend class RNBOSubpatcher_199;
            friend class Grafik7;
            
            public:
            
            RNBOSubpatcher_191()
            {
            }
            
            ~RNBOSubpatcher_191()
            {
            }
            
            virtual RNBOSubpatcher_199* getPatcher() const {
                return static_cast<RNBOSubpatcher_199 *>(_parentPatcher);
            }
            
            Grafik7* getTopLevelPatcher() {
                return this->getPatcher()->getTopLevelPatcher();
            }
            
            void cancelClockEvents()
            {
            }
            
            Index getNumMidiInputPorts() const {
                return 0;
            }
            
            void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
            
            Index getNumMidiOutputPorts() const {
                return 0;
            }
            
            void process(
                const SampleValue * const* inputs,
                Index numInputs,
                SampleValue * const* outputs,
                Index numOutputs,
                Index n
            ) {
                this->vs = n;
                this->updateTime(this->getEngine()->getCurrentTime());
                SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
                const SampleValue * in1 = (numInputs >= 1 && inputs[0] ? inputs[0] : this->zeroBuffer);
                this->onepole_tilde_02_perform(in1, this->onepole_tilde_02_freqInHz, this->signals[0], n);
                this->dspexpr_04_perform(this->signals[0], this->dspexpr_04_in2, this->signals[1], n);
                this->dspexpr_03_perform(in1, this->signals[1], out1, n);
                this->stackprotect_perform(n);
                this->audioProcessSampleCount += this->vs;
            }
            
            void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
                if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
                    Index i;
            
                    for (i = 0; i < 2; i++) {
                        this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
                    }
            
                    this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
                    this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
                    this->didAllocateSignals = true;
                }
            
                const bool sampleRateChanged = sampleRate != this->sr;
                const bool maxvsChanged = maxBlockSize != this->maxvs;
                const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
            
                if (sampleRateChanged || maxvsChanged) {
                    this->vs = maxBlockSize;
                    this->maxvs = maxBlockSize;
                    this->sr = sampleRate;
                    this->invsr = 1 / sampleRate;
                }
            
                this->onepole_tilde_02_dspsetup(forceDSPSetup);
            
                if (sampleRateChanged)
                    this->onSampleRateChanged(sampleRate);
            }
            
            void setProbingTarget(MessageTag id) {
                switch (id) {
                default:
                    {
                    this->setProbingIndex(-1);
                    break;
                    }
                }
            }
            
            void setProbingIndex(ProbingIndex ) {}
            
            Index getProbingChannels(MessageTag outletId) const {
                RNBO_UNUSED(outletId);
                return 0;
            }
            
            Index getIsMuted()  {
                return this->isMuted;
            }
            
            void setIsMuted(Index v)  {
                this->isMuted = v;
            }
            
            void onSampleRateChanged(double ) {}
            
            Index getPatcherSerial() const {
                return 0;
            }
            
            void getState(PatcherStateInterface& ) {}
            
            void setState() {}
            
            void getPreset(PatcherStateInterface& ) {}
            
            void setParameterValue(ParameterIndex , ParameterValue , MillisecondTime ) {}
            
            void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValue(index, value, time);
            }
            
            void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
                this->setParameterValue(index, this->getParameterValue(index), time);
            }
            
            void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValueNormalized(index, value, time);
            }
            
            ParameterValue getParameterValue(ParameterIndex index)  {
                switch (index) {
                default:
                    {
                    return 0;
                    }
                }
            }
            
            ParameterIndex getNumSignalInParameters() const {
                return 0;
            }
            
            ParameterIndex getNumSignalOutParameters() const {
                return 0;
            }
            
            ParameterIndex getNumParameters() const {
                return 0;
            }
            
            ConstCharPointer getParameterName(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            ConstCharPointer getParameterId(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            void getParameterInfo(ParameterIndex , ParameterInfo * ) const {}
            
            void sendParameter(ParameterIndex index, bool ignoreValue) {
                this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
            }
            
            void setParameterOffset(ParameterIndex offset) {
                this->parameterOffset = offset;
            }
            
            ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
                if (steps == 1) {
                    if (normalizedValue > 0) {
                        normalizedValue = 1.;
                    }
                } else {
                    ParameterValue oneStep = (number)1. / (steps - 1);
                    ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
                    normalizedValue = numberOfSteps * oneStep;
                }
            
                return normalizedValue;
            }
            
            ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                value = (value < 0 ? 0 : (value > 1 ? 1 : value));
            
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            void scheduleParamInit(ParameterIndex index, Index order) {
                this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
            }
            
            void processClockEvent(MillisecondTime , ClockId , bool , ParameterValue ) {}
            
            void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
            
            void processOutletEvent(
                EngineLink* sender,
                OutletIndex index,
                ParameterValue value,
                MillisecondTime time
            ) {
                this->updateTime(time);
                this->processOutletAtCurrentTime(sender, index, value);
            }
            
            void processNumMessage(MessageTag , MessageTag , MillisecondTime , number ) {}
            
            void processListMessage(MessageTag , MessageTag , MillisecondTime , const list& ) {}
            
            void processBangMessage(MessageTag , MessageTag , MillisecondTime ) {}
            
            MessageTagInfo resolveTag(MessageTag tag) const {
                switch (tag) {
            
                }
            
                return nullptr;
            }
            
            DataRef* getDataRef(DataRefIndex index)  {
                switch (index) {
                default:
                    {
                    return nullptr;
                    }
                }
            }
            
            DataRefIndex getNumDataRefs() const {
                return 0;
            }
            
            void fillDataRef(DataRefIndex , DataRef& ) {}
            
            void processDataViewUpdate(DataRefIndex , MillisecondTime ) {}
            
            void initialize() {
                this->assign_defaults();
                this->setState();
            }
            
            protected:
            
            number msToSamps(MillisecondTime ms, number sampleRate) {
                return ms * sampleRate * 0.001;
            }
            
            MillisecondTime sampsToMs(SampleIndex samps) {
                return samps * (this->invsr * 1000);
            }
            
            Index getMaxBlockSize() const {
                return this->maxvs;
            }
            
            number getSampleRate() const {
                return this->sr;
            }
            
            bool hasFixedVectorSize() const {
                return false;
            }
            
            Index getNumInputChannels() const {
                return 1;
            }
            
            Index getNumOutputChannels() const {
                return 1;
            }
            
            void initializeObjects() {}
            
            void sendOutlet(OutletIndex index, ParameterValue value) {
                this->getEngine()->sendOutlet(this, index, value);
            }
            
            void startup() {}
            
            void allocateDataRefs() {}
            
            void onepole_tilde_02_perform(const Sample * x, number freqInHz, SampleValue * out1, Index n) {
                RNBO_UNUSED(freqInHz);
                auto __onepole_tilde_02_lastY = this->onepole_tilde_02_lastY;
                auto __onepole_tilde_02_b1 = this->onepole_tilde_02_b1;
                auto __onepole_tilde_02_a0 = this->onepole_tilde_02_a0;
                auto __onepole_tilde_02_needsUpdate = this->onepole_tilde_02_needsUpdate;
                auto __onepole_tilde_02_freq = this->onepole_tilde_02_freq;
                Index i;
            
                for (i = 0; i < n; i++) {
                    if (__onepole_tilde_02_freq != 20 || (bool)(__onepole_tilde_02_needsUpdate)) {
                        __onepole_tilde_02_freq = 20;
                        __onepole_tilde_02_a0 = 1 - rnbo_exp(-125.66370614359172 / this->sr);
                        __onepole_tilde_02_a0 = (__onepole_tilde_02_a0 > 0.99999 ? 0.99999 : (__onepole_tilde_02_a0 < 0.00001 ? 0.00001 : __onepole_tilde_02_a0));
                        __onepole_tilde_02_b1 = 1 - __onepole_tilde_02_a0;
                        __onepole_tilde_02_needsUpdate = false;
                    }
            
                    __onepole_tilde_02_lastY = __onepole_tilde_02_a0 * x[(Index)i] + __onepole_tilde_02_b1 * __onepole_tilde_02_lastY;
                    out1[(Index)i] = __onepole_tilde_02_lastY;
                }
            
                this->onepole_tilde_02_freq = __onepole_tilde_02_freq;
                this->onepole_tilde_02_needsUpdate = __onepole_tilde_02_needsUpdate;
                this->onepole_tilde_02_a0 = __onepole_tilde_02_a0;
                this->onepole_tilde_02_b1 = __onepole_tilde_02_b1;
                this->onepole_tilde_02_lastY = __onepole_tilde_02_lastY;
            }
            
            void dspexpr_04_perform(const Sample * in1, number in2, SampleValue * out1, Index n) {
                RNBO_UNUSED(in2);
                Index i;
            
                for (i = 0; i < n; i++) {
                    out1[(Index)i] = in1[(Index)i] * -1;//#map:_###_obj_###_:1
                }
            }
            
            void dspexpr_03_perform(const Sample * in1, const Sample * in2, SampleValue * out1, Index n) {
                Index i;
            
                for (i = 0; i < n; i++) {
                    out1[(Index)i] = in1[(Index)i] + in2[(Index)i];//#map:_###_obj_###_:1
                }
            }
            
            void stackprotect_perform(Index n) {
                RNBO_UNUSED(n);
                auto __stackprotect_count = this->stackprotect_count;
                __stackprotect_count = 0;
                this->stackprotect_count = __stackprotect_count;
            }
            
            void onepole_tilde_02_reset() {
                this->onepole_tilde_02_lastY = 0;
                this->onepole_tilde_02_a0 = 0;
                this->onepole_tilde_02_b1 = 0;
            }
            
            void onepole_tilde_02_dspsetup(bool force) {
                if ((bool)(this->onepole_tilde_02_setupDone) && (bool)(!(bool)(force)))
                    return;
            
                this->onepole_tilde_02_needsUpdate = true;
                this->onepole_tilde_02_reset();
                this->onepole_tilde_02_setupDone = true;
            }
            
            bool stackprotect_check() {
                this->stackprotect_count++;
            
                if (this->stackprotect_count > 128) {
                    console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
                    return true;
                }
            
                return false;
            }
            
            void updateTime(MillisecondTime time) {
                this->_currentTime = time;
                this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
            
                if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
                    this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
            
                if (this->sampleOffsetIntoNextAudioBuffer < 0)
                    this->sampleOffsetIntoNextAudioBuffer = 0;
            }
            
            void assign_defaults()
            {
                dspexpr_03_in1 = 0;
                dspexpr_03_in2 = 0;
                dspexpr_04_in1 = 0;
                dspexpr_04_in2 = -1;
                onepole_tilde_02_x = 0;
                onepole_tilde_02_freqInHz = 20;
                _currentTime = 0;
                audioProcessSampleCount = 0;
                sampleOffsetIntoNextAudioBuffer = 0;
                zeroBuffer = nullptr;
                dummyBuffer = nullptr;
                signals[0] = nullptr;
                signals[1] = nullptr;
                didAllocateSignals = 0;
                vs = 0;
                maxvs = 0;
                sr = 44100;
                invsr = 0.00002267573696;
                onepole_tilde_02_freq = 0;
                onepole_tilde_02_needsUpdate = false;
                onepole_tilde_02_lastY = 0;
                onepole_tilde_02_a0 = 0;
                onepole_tilde_02_b1 = 0;
                onepole_tilde_02_setupDone = false;
                stackprotect_count = 0;
                _voiceIndex = 0;
                _noteNumber = 0;
                isMuted = 1;
                parameterOffset = 0;
            }
            
            // member variables
            
                number dspexpr_03_in1;
                number dspexpr_03_in2;
                number dspexpr_04_in1;
                number dspexpr_04_in2;
                number onepole_tilde_02_x;
                number onepole_tilde_02_freqInHz;
                MillisecondTime _currentTime;
                UInt64 audioProcessSampleCount;
                SampleIndex sampleOffsetIntoNextAudioBuffer;
                signal zeroBuffer;
                signal dummyBuffer;
                SampleValue * signals[2];
                bool didAllocateSignals;
                Index vs;
                Index maxvs;
                number sr;
                number invsr;
                number onepole_tilde_02_freq;
                bool onepole_tilde_02_needsUpdate;
                number onepole_tilde_02_lastY;
                number onepole_tilde_02_a0;
                number onepole_tilde_02_b1;
                bool onepole_tilde_02_setupDone;
                number stackprotect_count;
                Index _voiceIndex;
                Int _noteNumber;
                Index isMuted;
                ParameterIndex parameterOffset;
            
    };
    
    RNBOSubpatcher_199()
    {
    }
    
    ~RNBOSubpatcher_199()
    {
        delete this->p_01;
        delete this->p_02;
    }
    
    virtual Grafik7* getPatcher() const {
        return static_cast<Grafik7 *>(_parentPatcher);
    }
    
    Grafik7* getTopLevelPatcher() {
        return this->getPatcher()->getTopLevelPatcher();
    }
    
    void cancelClockEvents()
    {
        getEngine()->flushClockEvents(this, -62043057, false);
    }
    
    SampleIndex currentsampletime() {
        return this->audioProcessSampleCount + this->sampleOffsetIntoNextAudioBuffer;
    }
    
    number mstosamps(MillisecondTime ms) {
        return ms * this->sr * 0.001;
    }
    
    inline number safesqrt(number num) {
        return (num > 0.0 ? rnbo_sqrt(num) : 0.0);
    }
    
    Index vectorsize() const {
        return this->vs;
    }
    
    Index getNumMidiInputPorts() const {
        return 0;
    }
    
    void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
    
    Index getNumMidiOutputPorts() const {
        return 0;
    }
    
    void process(
        const SampleValue * const* inputs,
        Index numInputs,
        SampleValue * const* outputs,
        Index numOutputs,
        Index n
    ) {
        this->vs = n;
        this->updateTime(this->getEngine()->getCurrentTime());
        SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
        SampleValue * out2 = (numOutputs >= 2 && outputs[1] ? outputs[1] : this->dummyBuffer);
        const SampleValue * in1 = (numInputs >= 1 && inputs[0] ? inputs[0] : this->zeroBuffer);
        const SampleValue * in2 = (numInputs >= 2 && inputs[1] ? inputs[1] : this->zeroBuffer);
        this->p_01_perform(in1, this->signals[0], n);
        this->linetilde_01_perform(this->signals[1], n);
        this->p_02_perform(in2, this->signals[2], n);
    
        this->filtercoeff_01_perform(
            this->filtercoeff_01_frequency,
            this->filtercoeff_01_gain,
            this->filtercoeff_01_q,
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            n
        );
    
        this->biquad_tilde_02_perform(
            in2,
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            this->signals[8],
            n
        );
    
        this->dspexpr_06_perform(this->signals[2], this->signals[8], this->signals[1], out2, n);
    
        this->biquad_tilde_01_perform(
            in1,
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            this->signals[8],
            n
        );
    
        this->dspexpr_05_perform(this->signals[0], this->signals[8], this->signals[1], out1, n);
        this->stackprotect_perform(n);
        this->audioProcessSampleCount += this->vs;
    }
    
    void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
        if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
            Index i;
    
            for (i = 0; i < 9; i++) {
                this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
            }
    
            this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
            this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
            this->didAllocateSignals = true;
        }
    
        const bool sampleRateChanged = sampleRate != this->sr;
        const bool maxvsChanged = maxBlockSize != this->maxvs;
        const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
    
        if (sampleRateChanged || maxvsChanged) {
            this->vs = maxBlockSize;
            this->maxvs = maxBlockSize;
            this->sr = sampleRate;
            this->invsr = 1 / sampleRate;
        }
    
        this->filtercoeff_01_dspsetup(forceDSPSetup);
        this->biquad_tilde_02_dspsetup(forceDSPSetup);
        this->biquad_tilde_01_dspsetup(forceDSPSetup);
        this->p_01->prepareToProcess(sampleRate, maxBlockSize, force);
        this->p_02->prepareToProcess(sampleRate, maxBlockSize, force);
    
        if (sampleRateChanged)
            this->onSampleRateChanged(sampleRate);
    }
    
    void setProbingTarget(MessageTag id) {
        switch (id) {
        default:
            {
            this->setProbingIndex(-1);
            break;
            }
        }
    }
    
    void setProbingIndex(ProbingIndex ) {}
    
    Index getProbingChannels(MessageTag outletId) const {
        RNBO_UNUSED(outletId);
        return 0;
    }
    
    Index getIsMuted()  {
        return this->isMuted;
    }
    
    void setIsMuted(Index v)  {
        this->isMuted = v;
    }
    
    void onSampleRateChanged(double ) {}
    
    Index getPatcherSerial() const {
        return 0;
    }
    
    void getState(PatcherStateInterface& ) {}
    
    void setState() {
        this->p_01 = new RNBOSubpatcher_190();
        this->p_01->setEngineAndPatcher(this->getEngine(), this);
        this->p_01->initialize();
        this->p_01->setParameterOffset(this->getParameterOffset(this->p_01));
        this->p_02 = new RNBOSubpatcher_191();
        this->p_02->setEngineAndPatcher(this->getEngine(), this);
        this->p_02->initialize();
        this->p_02->setParameterOffset(this->getParameterOffset(this->p_02));
    }
    
    void getPreset(PatcherStateInterface& preset) {
        this->p_01->getPreset(getSubState(getSubState(preset, "__sps"), "hipass[1]"));
        this->p_02->getPreset(getSubState(getSubState(preset, "__sps"), "hipass"));
    }
    
    void setParameterValue(ParameterIndex index, ParameterValue v, MillisecondTime time) {
        RNBO_UNUSED(v);
        this->updateTime(time);
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_01->getNumParameters())
                this->p_01->setParameterValue(index, v, time);
    
            index -= this->p_01->getNumParameters();
    
            if (index < this->p_02->getNumParameters())
                this->p_02->setParameterValue(index, v, time);
    
            break;
            }
        }
    }
    
    void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValue(index, value, time);
    }
    
    void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
        this->setParameterValue(index, this->getParameterValue(index), time);
    }
    
    void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValueNormalized(index, value, time);
    }
    
    ParameterValue getParameterValue(ParameterIndex index)  {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_01->getNumParameters())
                return this->p_01->getParameterValue(index);
    
            index -= this->p_01->getNumParameters();
    
            if (index < this->p_02->getNumParameters())
                return this->p_02->getParameterValue(index);
    
            return 0;
            }
        }
    }
    
    ParameterIndex getNumSignalInParameters() const {
        return 0;
    }
    
    ParameterIndex getNumSignalOutParameters() const {
        return 0;
    }
    
    ParameterIndex getNumParameters() const {
        return 0 + this->p_01->getNumParameters() + this->p_02->getNumParameters();
    }
    
    ConstCharPointer getParameterName(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_01->getNumParameters())
                return this->p_01->getParameterName(index);
    
            index -= this->p_01->getNumParameters();
    
            if (index < this->p_02->getNumParameters())
                return this->p_02->getParameterName(index);
    
            return "bogus";
            }
        }
    }
    
    ConstCharPointer getParameterId(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_01->getNumParameters())
                return this->p_01->getParameterId(index);
    
            index -= this->p_01->getNumParameters();
    
            if (index < this->p_02->getNumParameters())
                return this->p_02->getParameterId(index);
    
            return "bogus";
            }
        }
    }
    
    void getParameterInfo(ParameterIndex index, ParameterInfo * info) const {
        {
            switch (index) {
            default:
                {
                index -= 0;
    
                if (index < this->p_01->getNumParameters())
                    this->p_01->getParameterInfo(index, info);
    
                index -= this->p_01->getNumParameters();
    
                if (index < this->p_02->getNumParameters())
                    this->p_02->getParameterInfo(index, info);
    
                break;
                }
            }
        }
    }
    
    void sendParameter(ParameterIndex index, bool ignoreValue) {
        this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
    }
    
    ParameterIndex getParameterOffset(BaseInterface* subpatcher) const {
        if (subpatcher == this->p_01)
            return 0;
    
        if (subpatcher == this->p_02)
            return 0 + this->p_01->getNumParameters();
    
        return 0;
    }
    
    void setParameterOffset(ParameterIndex offset) {
        this->parameterOffset = offset;
    }
    
    ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
        if (steps == 1) {
            if (normalizedValue > 0) {
                normalizedValue = 1.;
            }
        } else {
            ParameterValue oneStep = (number)1. / (steps - 1);
            ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
            normalizedValue = numberOfSteps * oneStep;
        }
    
        return normalizedValue;
    }
    
    ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_01->getNumParameters())
                return this->p_01->convertToNormalizedParameterValue(index, value);
    
            index -= this->p_01->getNumParameters();
    
            if (index < this->p_02->getNumParameters())
                return this->p_02->convertToNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        value = (value < 0 ? 0 : (value > 1 ? 1 : value));
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_01->getNumParameters())
                return this->p_01->convertFromNormalizedParameterValue(index, value);
    
            index -= this->p_01->getNumParameters();
    
            if (index < this->p_02->getNumParameters())
                return this->p_02->convertFromNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_01->getNumParameters())
                return this->p_01->constrainParameterValue(index, value);
    
            index -= this->p_01->getNumParameters();
    
            if (index < this->p_02->getNumParameters())
                return this->p_02->constrainParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    void scheduleParamInit(ParameterIndex index, Index order) {
        this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
    }
    
    void processClockEvent(MillisecondTime time, ClockId index, bool hasValue, ParameterValue value) {
        RNBO_UNUSED(value);
        RNBO_UNUSED(hasValue);
        this->updateTime(time);
    
        switch (index) {
        case -62043057:
            {
            this->linetilde_01_target_bang();
            break;
            }
        }
    }
    
    void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
    
    void processOutletEvent(
        EngineLink* sender,
        OutletIndex index,
        ParameterValue value,
        MillisecondTime time
    ) {
        this->updateTime(time);
        this->processOutletAtCurrentTime(sender, index, value);
    }
    
    void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_01->processNumMessage(tag, objectId, time, payload);
        this->p_02->processNumMessage(tag, objectId, time, payload);
    }
    
    void processListMessage(
        MessageTag tag,
        MessageTag objectId,
        MillisecondTime time,
        const list& payload
    ) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_01->processListMessage(tag, objectId, time, payload);
        this->p_02->processListMessage(tag, objectId, time, payload);
    }
    
    void processBangMessage(MessageTag tag, MessageTag objectId, MillisecondTime time) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_01->processBangMessage(tag, objectId, time);
        this->p_02->processBangMessage(tag, objectId, time);
    }
    
    MessageTagInfo resolveTag(MessageTag tag) const {
        switch (tag) {
    
        }
    
        auto subpatchResult_0 = this->p_01->resolveTag(tag);
    
        if (subpatchResult_0)
            return subpatchResult_0;
    
        auto subpatchResult_1 = this->p_02->resolveTag(tag);
    
        if (subpatchResult_1)
            return subpatchResult_1;
    
        return nullptr;
    }
    
    DataRef* getDataRef(DataRefIndex index)  {
        switch (index) {
        default:
            {
            return nullptr;
            }
        }
    }
    
    DataRefIndex getNumDataRefs() const {
        return 0;
    }
    
    void fillDataRef(DataRefIndex , DataRef& ) {}
    
    void processDataViewUpdate(DataRefIndex index, MillisecondTime time) {
        this->p_01->processDataViewUpdate(index, time);
        this->p_02->processDataViewUpdate(index, time);
    }
    
    void initialize() {
        this->assign_defaults();
        this->setState();
    }
    
    protected:
    
    void eventinlet_01_out1_bang_bang() {
        this->linetilde_01_segments_bang();
    }
    
    void eventinlet_01_out1_list_set(const list& v) {
        this->linetilde_01_segments_set(v);
    }
    
    void linetilde_01_target_bang() {}
    
    number msToSamps(MillisecondTime ms, number sampleRate) {
        return ms * sampleRate * 0.001;
    }
    
    MillisecondTime sampsToMs(SampleIndex samps) {
        return samps * (this->invsr * 1000);
    }
    
    Index getMaxBlockSize() const {
        return this->maxvs;
    }
    
    number getSampleRate() const {
        return this->sr;
    }
    
    bool hasFixedVectorSize() const {
        return false;
    }
    
    Index getNumInputChannels() const {
        return 2;
    }
    
    Index getNumOutputChannels() const {
        return 2;
    }
    
    void initializeObjects() {
        this->p_01->initializeObjects();
        this->p_02->initializeObjects();
    }
    
    void sendOutlet(OutletIndex index, ParameterValue value) {
        this->getEngine()->sendOutlet(this, index, value);
    }
    
    void startup() {
        this->updateTime(this->getEngine()->getCurrentTime());
        this->p_01->startup();
        this->p_02->startup();
    }
    
    void allocateDataRefs() {
        this->p_01->allocateDataRefs();
        this->p_02->allocateDataRefs();
    }
    
    void linetilde_01_time_set(number v) {
        this->linetilde_01_time = v;
    }
    
    void linetilde_01_segments_set(const list& v) {
        this->linetilde_01_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_01_time == 0) {
                this->linetilde_01_activeRamps->length = 0;
                this->linetilde_01_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_01_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_01_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_01_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_01_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_01_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_01_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_01_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_01_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_01_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_01_activeRamps->push(lastRampValue);
                    this->linetilde_01_activeRamps->push(0);
                    this->linetilde_01_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_01_keepramp)) {
                            this->linetilde_01_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_01_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_01_activeRamps->push(destinationValue);
                    this->linetilde_01_activeRamps->push(inc);
                    this->linetilde_01_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void eventinlet_01_out1_number_set(number v) {
        {
            list converted = {v};
            this->linetilde_01_segments_set(converted);
        }
    }
    
    void linetilde_01_segments_bang() {
        list v = this->linetilde_01_segments;
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_01_time == 0) {
                this->linetilde_01_activeRamps->length = 0;
                this->linetilde_01_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_01_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_01_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_01_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_01_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_01_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_01_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_01_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_01_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_01_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_01_activeRamps->push(lastRampValue);
                    this->linetilde_01_activeRamps->push(0);
                    this->linetilde_01_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_01_keepramp)) {
                            this->linetilde_01_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_01_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_01_activeRamps->push(destinationValue);
                    this->linetilde_01_activeRamps->push(inc);
                    this->linetilde_01_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void p_01_perform(const SampleValue * in1, SampleValue * out1, Index n) {
        // subpatcher: hipass
        ConstSampleArray<1> ins = {in1};
    
        SampleArray<1> outs = {out1};
        this->p_01->process(ins, 1, outs, 1, n);
    }
    
    void linetilde_01_perform(SampleValue * out, Index n) {
        auto __linetilde_01_time = this->linetilde_01_time;
        auto __linetilde_01_keepramp = this->linetilde_01_keepramp;
        auto __linetilde_01_currentValue = this->linetilde_01_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_01_activeRamps->length)) {
            while ((bool)(this->linetilde_01_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_01_activeRamps[0];
                number inc = this->linetilde_01_activeRamps[1];
                number rampTimeInSamples = this->linetilde_01_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_01_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_01_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_01_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -62043057,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_01_keepramp))) {
                            __linetilde_01_time = 0;
                        }
                    }
                }
    
                __linetilde_01_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_01_currentValue;
            i++;
        }
    
        this->linetilde_01_currentValue = __linetilde_01_currentValue;
        this->linetilde_01_time = __linetilde_01_time;
    }
    
    void p_02_perform(const SampleValue * in1, SampleValue * out1, Index n) {
        // subpatcher: hipass
        ConstSampleArray<1> ins = {in1};
    
        SampleArray<1> outs = {out1};
        this->p_02->process(ins, 1, outs, 1, n);
    }
    
    void filtercoeff_01_perform(
        number frequency,
        number gain,
        number q,
        SampleValue * a0,
        SampleValue * a1,
        SampleValue * a2,
        SampleValue * b1,
        SampleValue * b2,
        Index n
    ) {
        RNBO_UNUSED(q);
        RNBO_UNUSED(gain);
        RNBO_UNUSED(frequency);
        auto __filtercoeff_01_activeResamp = this->filtercoeff_01_activeResamp;
        auto __filtercoeff_01_resamp_counter = this->filtercoeff_01_resamp_counter;
        auto __filtercoeff_01_K_EPSILON = this->filtercoeff_01_K_EPSILON;
    
        for (Index i = 0; i < n; i++) {
            number local_q = 2;
            number local_gain = 1;
    
            if (local_gain < 0)
                local_gain = 0;
    
            number local_frequency = 30;
    
            if (local_q < __filtercoeff_01_K_EPSILON)
                local_q = __filtercoeff_01_K_EPSILON;
    
            local_frequency = (local_frequency > this->sr * 0.5 ? this->sr * 0.5 : (local_frequency < 1 ? 1 : local_frequency));
            __filtercoeff_01_resamp_counter--;
    
            if (__filtercoeff_01_resamp_counter <= 0) {
                __filtercoeff_01_resamp_counter = __filtercoeff_01_activeResamp;
                this->filtercoeff_01_updateTerms(local_frequency, local_gain, local_q);
            }
    
            a0[(Index)i] = this->filtercoeff_01_la0;
            a1[(Index)i] = this->filtercoeff_01_la1;
            a2[(Index)i] = this->filtercoeff_01_la2;
            b1[(Index)i] = this->filtercoeff_01_lb1;
            b2[(Index)i] = this->filtercoeff_01_lb2;
        }
    
        this->filtercoeff_01_resamp_counter = __filtercoeff_01_resamp_counter;
    }
    
    void biquad_tilde_02_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_02_y2 = this->biquad_tilde_02_y2;
        auto __biquad_tilde_02_y1 = this->biquad_tilde_02_y1;
        auto __biquad_tilde_02_x2 = this->biquad_tilde_02_x2;
        auto __biquad_tilde_02_x1 = this->biquad_tilde_02_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_02_x1 * a1[(Index)i] + __biquad_tilde_02_x2 * a2[(Index)i] - (__biquad_tilde_02_y1 * b1[(Index)i] + __biquad_tilde_02_y2 * b2[(Index)i]);
            __biquad_tilde_02_x2 = __biquad_tilde_02_x1;
            __biquad_tilde_02_x1 = x[(Index)i];
            __biquad_tilde_02_y2 = __biquad_tilde_02_y1;
            __biquad_tilde_02_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_02_x1 = __biquad_tilde_02_x1;
        this->biquad_tilde_02_x2 = __biquad_tilde_02_x2;
        this->biquad_tilde_02_y1 = __biquad_tilde_02_y1;
        this->biquad_tilde_02_y2 = __biquad_tilde_02_y2;
    }
    
    void dspexpr_06_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void biquad_tilde_01_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_01_y2 = this->biquad_tilde_01_y2;
        auto __biquad_tilde_01_y1 = this->biquad_tilde_01_y1;
        auto __biquad_tilde_01_x2 = this->biquad_tilde_01_x2;
        auto __biquad_tilde_01_x1 = this->biquad_tilde_01_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_01_x1 * a1[(Index)i] + __biquad_tilde_01_x2 * a2[(Index)i] - (__biquad_tilde_01_y1 * b1[(Index)i] + __biquad_tilde_01_y2 * b2[(Index)i]);
            __biquad_tilde_01_x2 = __biquad_tilde_01_x1;
            __biquad_tilde_01_x1 = x[(Index)i];
            __biquad_tilde_01_y2 = __biquad_tilde_01_y1;
            __biquad_tilde_01_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_01_x1 = __biquad_tilde_01_x1;
        this->biquad_tilde_01_x2 = __biquad_tilde_01_x2;
        this->biquad_tilde_01_y1 = __biquad_tilde_01_y1;
        this->biquad_tilde_01_y2 = __biquad_tilde_01_y2;
    }
    
    void dspexpr_05_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void stackprotect_perform(Index n) {
        RNBO_UNUSED(n);
        auto __stackprotect_count = this->stackprotect_count;
        __stackprotect_count = 0;
        this->stackprotect_count = __stackprotect_count;
    }
    
    void biquad_tilde_01_reset() {
        this->biquad_tilde_01_x1 = 0;
        this->biquad_tilde_01_x2 = 0;
        this->biquad_tilde_01_y1 = 0;
        this->biquad_tilde_01_y2 = 0;
    }
    
    void biquad_tilde_01_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_01_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_01_reset();
        this->biquad_tilde_01_setupDone = true;
    }
    
    void biquad_tilde_02_reset() {
        this->biquad_tilde_02_x1 = 0;
        this->biquad_tilde_02_x2 = 0;
        this->biquad_tilde_02_y1 = 0;
        this->biquad_tilde_02_y2 = 0;
    }
    
    void biquad_tilde_02_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_02_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_02_reset();
        this->biquad_tilde_02_setupDone = true;
    }
    
    array<number, 5> filtercoeff_01_localop_next(number frequency, number q, number gain, number type) {
        number omega = frequency * this->filtercoeff_01_localop_twopi_over_sr;
        this->filtercoeff_01_localop_cs = rnbo_cos(omega);
        this->filtercoeff_01_localop_sn = rnbo_sin(omega);
        this->filtercoeff_01_localop_one_over_gain = (gain >= 0 ? (number)1 / gain : 0.0);
        this->filtercoeff_01_localop_one_over_q = (number)1 / q;
        this->filtercoeff_01_localop_alpha = this->filtercoeff_01_localop_sn * 0.5 * this->filtercoeff_01_localop_one_over_q;
    
        switch ((int)type) {
        case 5:
            {
            this->filtercoeff_01_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_01_localop_beta = this->safesqrt(
                (this->filtercoeff_01_localop_A * this->filtercoeff_01_localop_A + 1.) * this->filtercoeff_01_localop_one_over_q - (this->filtercoeff_01_localop_A - 1.) * (this->filtercoeff_01_localop_A - 1.)
            );
    
            this->filtercoeff_01_localop_b0 = (number)1 / (this->filtercoeff_01_localop_A + 1. + (this->filtercoeff_01_localop_A - 1.) * this->filtercoeff_01_localop_cs + this->filtercoeff_01_localop_beta * this->filtercoeff_01_localop_sn);
            break;
            }
        case 6:
            {
            this->filtercoeff_01_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_01_localop_beta = this->safesqrt(
                (this->filtercoeff_01_localop_A * this->filtercoeff_01_localop_A + 1.) * this->filtercoeff_01_localop_one_over_q - (this->filtercoeff_01_localop_A - 1.) * (this->filtercoeff_01_localop_A - 1.)
            );
    
            this->filtercoeff_01_localop_b0 = (number)1 / (this->filtercoeff_01_localop_A + 1. - (this->filtercoeff_01_localop_A - 1.) * this->filtercoeff_01_localop_cs + this->filtercoeff_01_localop_beta * this->filtercoeff_01_localop_sn);
            break;
            }
        case 4:
            {
            this->filtercoeff_01_localop_A = this->safesqrt(gain);
            this->filtercoeff_01_localop_one_over_a = (this->filtercoeff_01_localop_A == 0 ? 0 : (number)1 / this->filtercoeff_01_localop_A);
            this->filtercoeff_01_localop_b0 = (number)1 / (1. + this->filtercoeff_01_localop_alpha * this->filtercoeff_01_localop_one_over_a);
            break;
            }
        case 9:
        case 10:
        case 11:
        case 13:
        case 14:
            {
            this->filtercoeff_01_localop_b0 = (number)1 / (1. + this->filtercoeff_01_localop_alpha);
            this->filtercoeff_01_localop_b0g = (number)1 / (this->filtercoeff_01_localop_one_over_gain + this->filtercoeff_01_localop_alpha * this->filtercoeff_01_localop_one_over_gain);
            break;
            }
        default:
            {
            this->filtercoeff_01_localop_b0 = (number)1 / (1. + this->filtercoeff_01_localop_alpha);
            break;
            }
        }
    
        switch ((int)type) {
        case 0:
            {
            this->filtercoeff_01_localop_la0 = this->filtercoeff_01_localop_la2 = (1. - this->filtercoeff_01_localop_cs) * 0.5 * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la1 = (1. - this->filtercoeff_01_localop_cs) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0;
            break;
            }
        case 1:
            {
            this->filtercoeff_01_localop_la0 = this->filtercoeff_01_localop_la2 = (1. + this->filtercoeff_01_localop_cs) * 0.5 * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la1 = -(1. + this->filtercoeff_01_localop_cs) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0;
            break;
            }
        case 2:
            {
            this->filtercoeff_01_localop_la0 = this->filtercoeff_01_localop_alpha * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la1 = 0.;
            this->filtercoeff_01_localop_la2 = -this->filtercoeff_01_localop_alpha * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0;
            break;
            }
        case 7:
            {
            this->filtercoeff_01_localop_la0 = this->filtercoeff_01_localop_alpha * q * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la1 = 0.;
            this->filtercoeff_01_localop_la2 = -this->filtercoeff_01_localop_alpha * q * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0;
            break;
            }
        case 3:
            {
            this->filtercoeff_01_localop_la1 = this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la0 = this->filtercoeff_01_localop_la2 = this->filtercoeff_01_localop_b0;
            break;
            }
        case 8:
            {
            this->filtercoeff_01_localop_la1 = this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = this->filtercoeff_01_localop_la0 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la2 = 1.0;
            break;
            }
        case 4:
            {
            this->filtercoeff_01_localop_la0 = (1. + this->filtercoeff_01_localop_alpha * this->filtercoeff_01_localop_A) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la1 = this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la2 = (1. - this->filtercoeff_01_localop_alpha * this->filtercoeff_01_localop_A) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (1. - this->filtercoeff_01_localop_alpha * this->filtercoeff_01_localop_one_over_a) * this->filtercoeff_01_localop_b0;
            break;
            }
        case 5:
            {
            this->filtercoeff_01_localop_la0 = this->filtercoeff_01_localop_A * (this->filtercoeff_01_localop_A + 1. - (this->filtercoeff_01_localop_A - 1.) * this->filtercoeff_01_localop_cs + this->filtercoeff_01_localop_beta * this->filtercoeff_01_localop_sn) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la1 = 2. * this->filtercoeff_01_localop_A * (this->filtercoeff_01_localop_A - 1 - (this->filtercoeff_01_localop_A + 1) * this->filtercoeff_01_localop_cs) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la2 = this->filtercoeff_01_localop_A * (this->filtercoeff_01_localop_A + 1. - (this->filtercoeff_01_localop_A - 1.) * this->filtercoeff_01_localop_cs - this->filtercoeff_01_localop_beta * this->filtercoeff_01_localop_sn) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb1 = -2. * (this->filtercoeff_01_localop_A - 1. + (this->filtercoeff_01_localop_A + 1.) * this->filtercoeff_01_localop_cs) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (this->filtercoeff_01_localop_A + 1. + (this->filtercoeff_01_localop_A - 1.) * this->filtercoeff_01_localop_cs - this->filtercoeff_01_localop_beta * this->filtercoeff_01_localop_sn) * this->filtercoeff_01_localop_b0;
            break;
            }
        case 6:
            {
            this->filtercoeff_01_localop_la0 = this->filtercoeff_01_localop_A * (this->filtercoeff_01_localop_A + 1. + (this->filtercoeff_01_localop_A - 1.) * this->filtercoeff_01_localop_cs + this->filtercoeff_01_localop_beta * this->filtercoeff_01_localop_sn) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la1 = -2. * this->filtercoeff_01_localop_A * (this->filtercoeff_01_localop_A - 1. + (this->filtercoeff_01_localop_A + 1.) * this->filtercoeff_01_localop_cs) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la2 = this->filtercoeff_01_localop_A * (this->filtercoeff_01_localop_A + 1. + (this->filtercoeff_01_localop_A - 1.) * this->filtercoeff_01_localop_cs - this->filtercoeff_01_localop_beta * this->filtercoeff_01_localop_sn) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb1 = 2. * (this->filtercoeff_01_localop_A - 1. - (this->filtercoeff_01_localop_A + 1.) * this->filtercoeff_01_localop_cs) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (this->filtercoeff_01_localop_A + 1. - (this->filtercoeff_01_localop_A - 1.) * this->filtercoeff_01_localop_cs - this->filtercoeff_01_localop_beta * this->filtercoeff_01_localop_sn) * this->filtercoeff_01_localop_b0;
            break;
            }
        case 9:
            {
            this->filtercoeff_01_localop_b0g = (number)1 / (this->filtercoeff_01_localop_one_over_gain + this->filtercoeff_01_localop_alpha * this->filtercoeff_01_localop_one_over_gain);
            this->filtercoeff_01_localop_la0 = this->filtercoeff_01_localop_la2 = (1. - this->filtercoeff_01_localop_cs) * 0.5 * this->filtercoeff_01_localop_b0g;
            this->filtercoeff_01_localop_la1 = (1. - this->filtercoeff_01_localop_cs) * this->filtercoeff_01_localop_b0g;
            this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0;
            break;
            }
        case 10:
            {
            this->filtercoeff_01_localop_b0g = (number)1 / (this->filtercoeff_01_localop_one_over_gain + this->filtercoeff_01_localop_alpha * this->filtercoeff_01_localop_one_over_gain);
            this->filtercoeff_01_localop_la0 = this->filtercoeff_01_localop_la2 = (1. + this->filtercoeff_01_localop_cs) * 0.5 * this->filtercoeff_01_localop_b0g;
            this->filtercoeff_01_localop_la1 = -(1. + this->filtercoeff_01_localop_cs) * this->filtercoeff_01_localop_b0g;
            this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0;
            break;
            }
        case 11:
            {
            this->filtercoeff_01_localop_la0 = this->filtercoeff_01_localop_alpha * gain * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la1 = 0.;
            this->filtercoeff_01_localop_la2 = -this->filtercoeff_01_localop_alpha * gain * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0;
            break;
            }
        case 13:
            {
            this->filtercoeff_01_localop_la0 = this->filtercoeff_01_localop_alpha * gain * q * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la1 = 0.;
            this->filtercoeff_01_localop_la2 = -this->filtercoeff_01_localop_alpha * gain * q * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0;
            break;
            }
        case 12:
            {
            this->filtercoeff_01_localop_b0g = (number)1 / (this->filtercoeff_01_localop_one_over_gain + this->filtercoeff_01_localop_alpha * this->filtercoeff_01_localop_one_over_gain);
            this->filtercoeff_01_localop_la1 = this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs;
            this->filtercoeff_01_localop_lb2 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la1 *= this->filtercoeff_01_localop_b0g;
            this->filtercoeff_01_localop_lb1 *= this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_la0 = this->filtercoeff_01_localop_b0g;
            this->filtercoeff_01_localop_la2 = this->filtercoeff_01_localop_b0g;
            break;
            }
        case 14:
            {
            this->filtercoeff_01_localop_b0g = (number)1 / (this->filtercoeff_01_localop_one_over_gain + this->filtercoeff_01_localop_alpha * this->filtercoeff_01_localop_one_over_gain);
            this->filtercoeff_01_localop_la0 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0g;
            this->filtercoeff_01_localop_la1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0g;
            this->filtercoeff_01_localop_la2 = gain;
            this->filtercoeff_01_localop_lb1 = -2. * this->filtercoeff_01_localop_cs * this->filtercoeff_01_localop_b0;
            this->filtercoeff_01_localop_lb2 = (1. - this->filtercoeff_01_localop_alpha) * this->filtercoeff_01_localop_b0;
            break;
            }
        case 15:
            {
            this->filtercoeff_01_localop_la0 = 1;
            this->filtercoeff_01_localop_la1 = 0;
            this->filtercoeff_01_localop_la2 = 0;
            this->filtercoeff_01_localop_lb1 = 0;
            this->filtercoeff_01_localop_lb2 = 0;
            }
        default:
            {
            break;
            }
        }
    
        return {
            this->filtercoeff_01_localop_la0,
            this->filtercoeff_01_localop_la1,
            this->filtercoeff_01_localop_la2,
            this->filtercoeff_01_localop_lb1,
            this->filtercoeff_01_localop_lb2
        };
    }
    
    void filtercoeff_01_localop_dspsetup() {
        this->filtercoeff_01_localop_twopi_over_sr = (number)6.283185307179586 / this->sr;
    }
    
    void filtercoeff_01_localop_reset() {
        this->filtercoeff_01_localop_twopi_over_sr = 0;
        this->filtercoeff_01_localop_cs = 0;
        this->filtercoeff_01_localop_sn = 0;
        this->filtercoeff_01_localop_one_over_gain = 0;
        this->filtercoeff_01_localop_one_over_q = 0;
        this->filtercoeff_01_localop_alpha = 0;
        this->filtercoeff_01_localop_beta = 0;
        this->filtercoeff_01_localop_b0 = 0;
        this->filtercoeff_01_localop_b0g = 0;
        this->filtercoeff_01_localop_A = 0;
        this->filtercoeff_01_localop_one_over_a = 0;
        this->filtercoeff_01_localop_la0 = 0;
        this->filtercoeff_01_localop_la1 = 0;
        this->filtercoeff_01_localop_la2 = 0;
        this->filtercoeff_01_localop_lb1 = 0;
        this->filtercoeff_01_localop_lb2 = 0;
    }
    
    void filtercoeff_01_updateTerms(number local_frequency, number local_gain, number local_q) {
        if ((bool)(this->filtercoeff_01_force_update) || local_frequency != this->filtercoeff_01_last_frequency || local_q != this->filtercoeff_01_last_q || local_gain != this->filtercoeff_01_last_gain || this->filtercoeff_01_type != this->filtercoeff_01_last_type) {
            array<number, 5> tmp = this->filtercoeff_01_localop_next(local_frequency, local_q, local_gain, this->filtercoeff_01_type);
            this->filtercoeff_01_la0 = tmp[0];
            this->filtercoeff_01_la1 = tmp[1];
            this->filtercoeff_01_la2 = tmp[2];
            this->filtercoeff_01_lb1 = tmp[3];
            this->filtercoeff_01_lb2 = tmp[4];
            this->filtercoeff_01_last_frequency = local_frequency;
            this->filtercoeff_01_last_q = local_q;
            this->filtercoeff_01_last_gain = local_gain;
            this->filtercoeff_01_last_type = this->filtercoeff_01_type;
            this->filtercoeff_01_force_update = false;
        }
    }
    
    void filtercoeff_01_dspsetup(bool force) {
        if ((bool)(this->filtercoeff_01_setupDone) && (bool)(!(bool)(force)))
            return;
    
        {
            this->filtercoeff_01_activeResamp = this->vectorsize();
        }
    
        this->filtercoeff_01_resamp_counter = 0;
        this->filtercoeff_01_la0 = 0.;
        this->filtercoeff_01_la1 = 0.;
        this->filtercoeff_01_la2 = 0.;
        this->filtercoeff_01_lb1 = 0.;
        this->filtercoeff_01_lb2 = 0.;
        this->filtercoeff_01_last_frequency = -1.;
        this->filtercoeff_01_last_q = -1.;
        this->filtercoeff_01_last_gain = -1.;
        this->filtercoeff_01_last_type = this->filtercoeff_01_type;
        this->filtercoeff_01_force_update = true;
        this->filtercoeff_01_setupDone = true;
        this->filtercoeff_01_localop_dspsetup();
    }
    
    bool stackprotect_check() {
        this->stackprotect_count++;
    
        if (this->stackprotect_count > 128) {
            console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
            return true;
        }
    
        return false;
    }
    
    void updateTime(MillisecondTime time) {
        this->_currentTime = time;
        this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
    
        if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
            this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
    
        if (this->sampleOffsetIntoNextAudioBuffer < 0)
            this->sampleOffsetIntoNextAudioBuffer = 0;
    }
    
    void assign_defaults()
    {
        dspexpr_05_in1 = 0;
        dspexpr_05_in2 = 0;
        dspexpr_05_in3 = 0;
        p_01_target = 0;
        biquad_tilde_01_x = 0;
        biquad_tilde_01_a0 = 0;
        biquad_tilde_01_a1 = 0;
        biquad_tilde_01_a2 = 0;
        biquad_tilde_01_b1 = 0;
        biquad_tilde_01_b2 = 0;
        linetilde_01_time = 10;
        linetilde_01_keepramp = 1;
        p_02_target = 0;
        dspexpr_06_in1 = 0;
        dspexpr_06_in2 = 0;
        dspexpr_06_in3 = 0;
        biquad_tilde_02_x = 0;
        biquad_tilde_02_a0 = 0;
        biquad_tilde_02_a1 = 0;
        biquad_tilde_02_a2 = 0;
        biquad_tilde_02_b1 = 0;
        biquad_tilde_02_b2 = 0;
        filtercoeff_01_frequency = 30;
        filtercoeff_01_gain = 1;
        filtercoeff_01_q = 2;
        filtercoeff_01_type = 1;
        _currentTime = 0;
        audioProcessSampleCount = 0;
        sampleOffsetIntoNextAudioBuffer = 0;
        zeroBuffer = nullptr;
        dummyBuffer = nullptr;
        signals[0] = nullptr;
        signals[1] = nullptr;
        signals[2] = nullptr;
        signals[3] = nullptr;
        signals[4] = nullptr;
        signals[5] = nullptr;
        signals[6] = nullptr;
        signals[7] = nullptr;
        signals[8] = nullptr;
        didAllocateSignals = 0;
        vs = 0;
        maxvs = 0;
        sr = 44100;
        invsr = 0.00002267573696;
        biquad_tilde_01_x1 = 0;
        biquad_tilde_01_x2 = 0;
        biquad_tilde_01_y1 = 0;
        biquad_tilde_01_y2 = 0;
        biquad_tilde_01_setupDone = false;
        linetilde_01_currentValue = 0;
        biquad_tilde_02_x1 = 0;
        biquad_tilde_02_x2 = 0;
        biquad_tilde_02_y1 = 0;
        biquad_tilde_02_y2 = 0;
        biquad_tilde_02_setupDone = false;
        filtercoeff_01_K_EPSILON = 1e-9;
        filtercoeff_01_setupDone = false;
        stackprotect_count = 0;
        _voiceIndex = 0;
        _noteNumber = 0;
        isMuted = 1;
        parameterOffset = 0;
    }
    
    // member variables
    
        number dspexpr_05_in1;
        number dspexpr_05_in2;
        number dspexpr_05_in3;
        number p_01_target;
        number biquad_tilde_01_x;
        number biquad_tilde_01_a0;
        number biquad_tilde_01_a1;
        number biquad_tilde_01_a2;
        number biquad_tilde_01_b1;
        number biquad_tilde_01_b2;
        list linetilde_01_segments;
        number linetilde_01_time;
        number linetilde_01_keepramp;
        number p_02_target;
        number dspexpr_06_in1;
        number dspexpr_06_in2;
        number dspexpr_06_in3;
        number biquad_tilde_02_x;
        number biquad_tilde_02_a0;
        number biquad_tilde_02_a1;
        number biquad_tilde_02_a2;
        number biquad_tilde_02_b1;
        number biquad_tilde_02_b2;
        number filtercoeff_01_frequency;
        number filtercoeff_01_gain;
        number filtercoeff_01_q;
        Int filtercoeff_01_type;
        MillisecondTime _currentTime;
        UInt64 audioProcessSampleCount;
        SampleIndex sampleOffsetIntoNextAudioBuffer;
        signal zeroBuffer;
        signal dummyBuffer;
        SampleValue * signals[9];
        bool didAllocateSignals;
        Index vs;
        Index maxvs;
        number sr;
        number invsr;
        number biquad_tilde_01_x1;
        number biquad_tilde_01_x2;
        number biquad_tilde_01_y1;
        number biquad_tilde_01_y2;
        bool biquad_tilde_01_setupDone;
        list linetilde_01_activeRamps;
        number linetilde_01_currentValue;
        number biquad_tilde_02_x1;
        number biquad_tilde_02_x2;
        number biquad_tilde_02_y1;
        number biquad_tilde_02_y2;
        bool biquad_tilde_02_setupDone;
        number filtercoeff_01_resamp_counter;
        number filtercoeff_01_activeResamp;
        number filtercoeff_01_K_EPSILON;
        number filtercoeff_01_la0;
        number filtercoeff_01_la1;
        number filtercoeff_01_la2;
        number filtercoeff_01_lb1;
        number filtercoeff_01_lb2;
        number filtercoeff_01_last_frequency;
        number filtercoeff_01_last_q;
        number filtercoeff_01_last_gain;
        Int filtercoeff_01_last_type;
        bool filtercoeff_01_force_update;
        number filtercoeff_01_localop_twopi_over_sr;
        number filtercoeff_01_localop_cs;
        number filtercoeff_01_localop_sn;
        number filtercoeff_01_localop_one_over_gain;
        number filtercoeff_01_localop_one_over_q;
        number filtercoeff_01_localop_alpha;
        number filtercoeff_01_localop_beta;
        number filtercoeff_01_localop_b0;
        number filtercoeff_01_localop_b0g;
        number filtercoeff_01_localop_A;
        number filtercoeff_01_localop_one_over_a;
        number filtercoeff_01_localop_la0;
        number filtercoeff_01_localop_la1;
        number filtercoeff_01_localop_la2;
        number filtercoeff_01_localop_lb1;
        number filtercoeff_01_localop_lb2;
        bool filtercoeff_01_setupDone;
        number stackprotect_count;
        Index _voiceIndex;
        Int _noteNumber;
        Index isMuted;
        ParameterIndex parameterOffset;
        RNBOSubpatcher_190* p_01;
        RNBOSubpatcher_191* p_02;
    
};

class RNBOSubpatcher_200 : public PatcherInterfaceImpl {
    
    friend class Grafik7;
    
    public:
    
    RNBOSubpatcher_200()
    {
    }
    
    ~RNBOSubpatcher_200()
    {
    }
    
    virtual Grafik7* getPatcher() const {
        return static_cast<Grafik7 *>(_parentPatcher);
    }
    
    Grafik7* getTopLevelPatcher() {
        return this->getPatcher()->getTopLevelPatcher();
    }
    
    void cancelClockEvents()
    {
        getEngine()->flushClockEvents(this, -62043057, false);
    }
    
    SampleIndex currentsampletime() {
        return this->audioProcessSampleCount + this->sampleOffsetIntoNextAudioBuffer;
    }
    
    number mstosamps(MillisecondTime ms) {
        return ms * this->sr * 0.001;
    }
    
    Index getNumMidiInputPorts() const {
        return 0;
    }
    
    void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
    
    Index getNumMidiOutputPorts() const {
        return 0;
    }
    
    void process(
        const SampleValue * const* inputs,
        Index numInputs,
        SampleValue * const* outputs,
        Index numOutputs,
        Index n
    ) {
        this->vs = n;
        this->updateTime(this->getEngine()->getCurrentTime());
        SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
        SampleValue * out2 = (numOutputs >= 2 && outputs[1] ? outputs[1] : this->dummyBuffer);
        const SampleValue * in1 = (numInputs >= 1 && inputs[0] ? inputs[0] : this->zeroBuffer);
        const SampleValue * in2 = (numInputs >= 2 && inputs[1] ? inputs[1] : this->zeroBuffer);
        this->linetilde_02_perform(this->signals[0], n);
        this->dspexpr_08_perform(in2, this->signals[0], out2, n);
        this->dspexpr_07_perform(in1, this->signals[0], out1, n);
        this->stackprotect_perform(n);
        this->audioProcessSampleCount += this->vs;
    }
    
    void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
        if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
            Index i;
    
            for (i = 0; i < 1; i++) {
                this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
            }
    
            this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
            this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
            this->didAllocateSignals = true;
        }
    
        const bool sampleRateChanged = sampleRate != this->sr;
        const bool maxvsChanged = maxBlockSize != this->maxvs;
        const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
    
        if (sampleRateChanged || maxvsChanged) {
            this->vs = maxBlockSize;
            this->maxvs = maxBlockSize;
            this->sr = sampleRate;
            this->invsr = 1 / sampleRate;
        }
    
        RNBO_UNUSED(forceDSPSetup);
    
        if (sampleRateChanged)
            this->onSampleRateChanged(sampleRate);
    }
    
    void setProbingTarget(MessageTag id) {
        switch (id) {
        default:
            {
            this->setProbingIndex(-1);
            break;
            }
        }
    }
    
    void setProbingIndex(ProbingIndex ) {}
    
    Index getProbingChannels(MessageTag outletId) const {
        RNBO_UNUSED(outletId);
        return 0;
    }
    
    Index getIsMuted()  {
        return this->isMuted;
    }
    
    void setIsMuted(Index v)  {
        this->isMuted = v;
    }
    
    void onSampleRateChanged(double ) {}
    
    Index getPatcherSerial() const {
        return 0;
    }
    
    void getState(PatcherStateInterface& ) {}
    
    void setState() {}
    
    void getPreset(PatcherStateInterface& ) {}
    
    void setParameterValue(ParameterIndex , ParameterValue , MillisecondTime ) {}
    
    void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValue(index, value, time);
    }
    
    void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
        this->setParameterValue(index, this->getParameterValue(index), time);
    }
    
    void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValueNormalized(index, value, time);
    }
    
    ParameterValue getParameterValue(ParameterIndex index)  {
        switch (index) {
        default:
            {
            return 0;
            }
        }
    }
    
    ParameterIndex getNumSignalInParameters() const {
        return 0;
    }
    
    ParameterIndex getNumSignalOutParameters() const {
        return 0;
    }
    
    ParameterIndex getNumParameters() const {
        return 0;
    }
    
    ConstCharPointer getParameterName(ParameterIndex index) const {
        switch (index) {
        default:
            {
            return "bogus";
            }
        }
    }
    
    ConstCharPointer getParameterId(ParameterIndex index) const {
        switch (index) {
        default:
            {
            return "bogus";
            }
        }
    }
    
    void getParameterInfo(ParameterIndex , ParameterInfo * ) const {}
    
    void sendParameter(ParameterIndex index, bool ignoreValue) {
        this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
    }
    
    void setParameterOffset(ParameterIndex offset) {
        this->parameterOffset = offset;
    }
    
    ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
        if (steps == 1) {
            if (normalizedValue > 0) {
                normalizedValue = 1.;
            }
        } else {
            ParameterValue oneStep = (number)1. / (steps - 1);
            ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
            normalizedValue = numberOfSteps * oneStep;
        }
    
        return normalizedValue;
    }
    
    ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            return value;
            }
        }
    }
    
    ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        value = (value < 0 ? 0 : (value > 1 ? 1 : value));
    
        switch (index) {
        default:
            {
            return value;
            }
        }
    }
    
    ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            return value;
            }
        }
    }
    
    void scheduleParamInit(ParameterIndex index, Index order) {
        this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
    }
    
    void processClockEvent(MillisecondTime time, ClockId index, bool hasValue, ParameterValue value) {
        RNBO_UNUSED(value);
        RNBO_UNUSED(hasValue);
        this->updateTime(time);
    
        switch (index) {
        case -62043057:
            {
            this->linetilde_02_target_bang();
            break;
            }
        }
    }
    
    void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
    
    void processOutletEvent(
        EngineLink* sender,
        OutletIndex index,
        ParameterValue value,
        MillisecondTime time
    ) {
        this->updateTime(time);
        this->processOutletAtCurrentTime(sender, index, value);
    }
    
    void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
        this->updateTime(time);
    
        switch (tag) {
        case TAG("valin"):
            {
            if (TAG("Level~/number_obj-7") == objectId)
                this->numberobj_01_valin_set(payload);
    
            if (TAG("Level~/number_obj-5") == objectId)
                this->numberobj_02_valin_set(payload);
    
            break;
            }
        case TAG("format"):
            {
            if (TAG("Level~/number_obj-7") == objectId)
                this->numberobj_01_format_set(payload);
    
            if (TAG("Level~/number_obj-5") == objectId)
                this->numberobj_02_format_set(payload);
    
            break;
            }
        }
    }
    
    void processListMessage(MessageTag , MessageTag , MillisecondTime , const list& ) {}
    
    void processBangMessage(MessageTag , MessageTag , MillisecondTime ) {}
    
    MessageTagInfo resolveTag(MessageTag tag) const {
        switch (tag) {
        case TAG("valout"):
            {
            return "valout";
            }
        case TAG("Level~/number_obj-7"):
            {
            return "Level~/number_obj-7";
            }
        case TAG("setup"):
            {
            return "setup";
            }
        case TAG("Level~/number_obj-5"):
            {
            return "Level~/number_obj-5";
            }
        case TAG("valin"):
            {
            return "valin";
            }
        case TAG("format"):
            {
            return "format";
            }
        }
    
        return nullptr;
    }
    
    DataRef* getDataRef(DataRefIndex index)  {
        switch (index) {
        default:
            {
            return nullptr;
            }
        }
    }
    
    DataRefIndex getNumDataRefs() const {
        return 0;
    }
    
    void fillDataRef(DataRefIndex , DataRef& ) {}
    
    void processDataViewUpdate(DataRefIndex , MillisecondTime ) {}
    
    void initialize() {
        this->assign_defaults();
        this->setState();
    }
    
    protected:
    
    void numberobj_01_valin_set(number v) {
        this->numberobj_01_value_set(v);
    }
    
    void numberobj_01_format_set(number v) {
        this->numberobj_01_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void numberobj_02_valin_set(number v) {
        this->numberobj_02_value_set(v);
    }
    
    void numberobj_02_format_set(number v) {
        this->numberobj_02_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void eventinlet_02_out1_bang_bang() {
        this->numberobj_02_value_bang();
    }
    
    void eventinlet_02_out1_list_set(const list& v) {
        {
            number converted = (v->length > 0 ? v[0] : 0);
            this->numberobj_02_value_set(converted);
        }
    }
    
    void linetilde_02_target_bang() {}
    
    number msToSamps(MillisecondTime ms, number sampleRate) {
        return ms * sampleRate * 0.001;
    }
    
    MillisecondTime sampsToMs(SampleIndex samps) {
        return samps * (this->invsr * 1000);
    }
    
    Index getMaxBlockSize() const {
        return this->maxvs;
    }
    
    number getSampleRate() const {
        return this->sr;
    }
    
    bool hasFixedVectorSize() const {
        return false;
    }
    
    Index getNumInputChannels() const {
        return 2;
    }
    
    Index getNumOutputChannels() const {
        return 2;
    }
    
    void initializeObjects() {
        this->numberobj_01_init();
        this->numberobj_02_init();
    }
    
    void sendOutlet(OutletIndex index, ParameterValue value) {
        this->getEngine()->sendOutlet(this, index, value);
    }
    
    void startup() {}
    
    void allocateDataRefs() {}
    
    void linetilde_02_time_set(number v) {
        this->linetilde_02_time = v;
    }
    
    void linetilde_02_segments_set(const list& v) {
        this->linetilde_02_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_02_time == 0) {
                this->linetilde_02_activeRamps->length = 0;
                this->linetilde_02_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_02_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_02_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_02_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_02_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_02_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_02_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_02_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_02_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_02_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_02_activeRamps->push(lastRampValue);
                    this->linetilde_02_activeRamps->push(0);
                    this->linetilde_02_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_02_keepramp)) {
                            this->linetilde_02_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_02_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_02_activeRamps->push(destinationValue);
                    this->linetilde_02_activeRamps->push(inc);
                    this->linetilde_02_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_01_output_set(number v) {
        {
            list converted = {v};
            this->linetilde_02_segments_set(converted);
        }
    }
    
    void numberobj_01_value_set(number v) {
        this->numberobj_01_value_setter(v);
        v = this->numberobj_01_value;
        number localvalue = v;
    
        if (this->numberobj_01_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("Level~/number_obj-7"), localvalue, this->_currentTime);
        this->numberobj_01_output_set(localvalue);
    }
    
    void expr_01_out1_set(number v) {
        this->expr_01_out1 = v;
        this->numberobj_01_value_set(this->expr_01_out1);
    }
    
    void expr_01_in1_set(number in1) {
        this->expr_01_in1 = in1;
        this->expr_01_out1_set(rnbo_pow(10, this->expr_01_in1 * 0.05));//#map:Level~/dbtoa_obj-3:1
    }
    
    void numberobj_02_output_set(number v) {
        this->expr_01_in1_set(v);
    }
    
    void numberobj_02_value_set(number v) {
        this->numberobj_02_value_setter(v);
        v = this->numberobj_02_value;
        number localvalue = v;
    
        if (this->numberobj_02_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("Level~/number_obj-5"), localvalue, this->_currentTime);
        this->numberobj_02_output_set(localvalue);
    }
    
    void eventinlet_02_out1_number_set(number v) {
        this->numberobj_02_value_set(v);
    }
    
    void numberobj_02_value_bang() {
        number v = this->numberobj_02_value;
        number localvalue = v;
    
        if (this->numberobj_02_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("Level~/number_obj-5"), localvalue, this->_currentTime);
        this->numberobj_02_output_set(localvalue);
    }
    
    void linetilde_02_perform(SampleValue * out, Index n) {
        auto __linetilde_02_time = this->linetilde_02_time;
        auto __linetilde_02_keepramp = this->linetilde_02_keepramp;
        auto __linetilde_02_currentValue = this->linetilde_02_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_02_activeRamps->length)) {
            while ((bool)(this->linetilde_02_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_02_activeRamps[0];
                number inc = this->linetilde_02_activeRamps[1];
                number rampTimeInSamples = this->linetilde_02_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_02_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_02_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_02_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -62043057,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_02_keepramp))) {
                            __linetilde_02_time = 0;
                        }
                    }
                }
    
                __linetilde_02_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_02_currentValue;
            i++;
        }
    
        this->linetilde_02_currentValue = __linetilde_02_currentValue;
        this->linetilde_02_time = __linetilde_02_time;
    }
    
    void dspexpr_08_perform(const Sample * in1, const Sample * in2, SampleValue * out1, Index n) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] * in2[(Index)i];//#map:_###_obj_###_:1
        }
    }
    
    void dspexpr_07_perform(const Sample * in1, const Sample * in2, SampleValue * out1, Index n) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] * in2[(Index)i];//#map:_###_obj_###_:1
        }
    }
    
    void stackprotect_perform(Index n) {
        RNBO_UNUSED(n);
        auto __stackprotect_count = this->stackprotect_count;
        __stackprotect_count = 0;
        this->stackprotect_count = __stackprotect_count;
    }
    
    void numberobj_01_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_01_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_01_value = localvalue;
    }
    
    void numberobj_02_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_02_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_02_value = localvalue;
    }
    
    void numberobj_01_init() {
        this->numberobj_01_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("Level~/number_obj-7"), 1, this->_currentTime);
    }
    
    void numberobj_01_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_01_value;
    }
    
    void numberobj_01_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_01_value_set(preset["value"]);
    }
    
    void numberobj_02_init() {
        this->numberobj_02_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("Level~/number_obj-5"), 1, this->_currentTime);
    }
    
    void numberobj_02_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_02_value;
    }
    
    void numberobj_02_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_02_value_set(preset["value"]);
    }
    
    bool stackprotect_check() {
        this->stackprotect_count++;
    
        if (this->stackprotect_count > 128) {
            console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
            return true;
        }
    
        return false;
    }
    
    void updateTime(MillisecondTime time) {
        this->_currentTime = time;
        this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
    
        if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
            this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
    
        if (this->sampleOffsetIntoNextAudioBuffer < 0)
            this->sampleOffsetIntoNextAudioBuffer = 0;
    }
    
    void assign_defaults()
    {
        dspexpr_07_in1 = 0;
        dspexpr_07_in2 = 0;
        dspexpr_08_in1 = 0;
        dspexpr_08_in2 = 0;
        numberobj_01_value = 0;
        numberobj_01_value_setter(numberobj_01_value);
        numberobj_02_value = 0;
        numberobj_02_value_setter(numberobj_02_value);
        expr_01_in1 = 0;
        expr_01_out1 = 0;
        linetilde_02_time = 10;
        linetilde_02_keepramp = 1;
        _currentTime = 0;
        audioProcessSampleCount = 0;
        sampleOffsetIntoNextAudioBuffer = 0;
        zeroBuffer = nullptr;
        dummyBuffer = nullptr;
        signals[0] = nullptr;
        didAllocateSignals = 0;
        vs = 0;
        maxvs = 0;
        sr = 44100;
        invsr = 0.00002267573696;
        numberobj_01_currentFormat = 6;
        numberobj_01_lastValue = 0;
        numberobj_02_currentFormat = 6;
        numberobj_02_lastValue = 0;
        linetilde_02_currentValue = 1;
        stackprotect_count = 0;
        _voiceIndex = 0;
        _noteNumber = 0;
        isMuted = 1;
        parameterOffset = 0;
    }
    
    // member variables
    
        number dspexpr_07_in1;
        number dspexpr_07_in2;
        number dspexpr_08_in1;
        number dspexpr_08_in2;
        number numberobj_01_value;
        number numberobj_02_value;
        number expr_01_in1;
        number expr_01_out1;
        list linetilde_02_segments;
        number linetilde_02_time;
        number linetilde_02_keepramp;
        MillisecondTime _currentTime;
        UInt64 audioProcessSampleCount;
        SampleIndex sampleOffsetIntoNextAudioBuffer;
        signal zeroBuffer;
        signal dummyBuffer;
        SampleValue * signals[1];
        bool didAllocateSignals;
        Index vs;
        Index maxvs;
        number sr;
        number invsr;
        Int numberobj_01_currentFormat;
        number numberobj_01_lastValue;
        Int numberobj_02_currentFormat;
        number numberobj_02_lastValue;
        list linetilde_02_activeRamps;
        number linetilde_02_currentValue;
        number stackprotect_count;
        Index _voiceIndex;
        Int _noteNumber;
        Index isMuted;
        ParameterIndex parameterOffset;
    
};

class RNBOSubpatcher_201 : public PatcherInterfaceImpl {
    
    friend class Grafik7;
    
    public:
    
    class RNBOSubpatcher_192 : public PatcherInterfaceImpl {
            
            friend class RNBOSubpatcher_201;
            friend class Grafik7;
            
            public:
            
            RNBOSubpatcher_192()
            {
            }
            
            ~RNBOSubpatcher_192()
            {
            }
            
            virtual RNBOSubpatcher_201* getPatcher() const {
                return static_cast<RNBOSubpatcher_201 *>(_parentPatcher);
            }
            
            Grafik7* getTopLevelPatcher() {
                return this->getPatcher()->getTopLevelPatcher();
            }
            
            void cancelClockEvents()
            {
            }
            
            inline number safediv(number num, number denom) {
                return (denom == 0.0 ? 0.0 : num / denom);
            }
            
            number safepow(number base, number exponent) {
                return fixnan(rnbo_pow(base, exponent));
            }
            
            number scale(
                number x,
                number lowin,
                number hiin,
                number lowout,
                number highout,
                number pow
            ) {
                auto inscale = this->safediv(1., hiin - lowin);
                number outdiff = highout - lowout;
                number value = (x - lowin) * inscale;
            
                if (pow != 1) {
                    if (value > 0)
                        value = this->safepow(value, pow);
                    else
                        value = -this->safepow(-value, pow);
                }
            
                value = value * outdiff + lowout;
                return value;
            }
            
            Index getNumMidiInputPorts() const {
                return 0;
            }
            
            void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
            
            Index getNumMidiOutputPorts() const {
                return 0;
            }
            
            void process(
                const SampleValue * const* inputs,
                Index numInputs,
                SampleValue * const* outputs,
                Index numOutputs,
                Index n
            ) {
                RNBO_UNUSED(numOutputs);
                RNBO_UNUSED(outputs);
                RNBO_UNUSED(numInputs);
                RNBO_UNUSED(inputs);
                this->vs = n;
                this->updateTime(this->getEngine()->getCurrentTime());
                this->stackprotect_perform(n);
                this->audioProcessSampleCount += this->vs;
            }
            
            void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
                if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
                    this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
                    this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
                    this->didAllocateSignals = true;
                }
            
                const bool sampleRateChanged = sampleRate != this->sr;
                const bool maxvsChanged = maxBlockSize != this->maxvs;
                const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
            
                if (sampleRateChanged || maxvsChanged) {
                    this->vs = maxBlockSize;
                    this->maxvs = maxBlockSize;
                    this->sr = sampleRate;
                    this->invsr = 1 / sampleRate;
                }
            
                RNBO_UNUSED(forceDSPSetup);
            
                if (sampleRateChanged)
                    this->onSampleRateChanged(sampleRate);
            }
            
            void setProbingTarget(MessageTag id) {
                switch (id) {
                default:
                    {
                    this->setProbingIndex(-1);
                    break;
                    }
                }
            }
            
            void setProbingIndex(ProbingIndex ) {}
            
            Index getProbingChannels(MessageTag outletId) const {
                RNBO_UNUSED(outletId);
                return 0;
            }
            
            Index getIsMuted()  {
                return this->isMuted;
            }
            
            void setIsMuted(Index v)  {
                this->isMuted = v;
            }
            
            void onSampleRateChanged(double ) {}
            
            Index getPatcherSerial() const {
                return 0;
            }
            
            void getState(PatcherStateInterface& ) {}
            
            void setState() {}
            
            void getPreset(PatcherStateInterface& ) {}
            
            void setParameterValue(ParameterIndex , ParameterValue , MillisecondTime ) {}
            
            void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValue(index, value, time);
            }
            
            void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
                this->setParameterValue(index, this->getParameterValue(index), time);
            }
            
            void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValueNormalized(index, value, time);
            }
            
            ParameterValue getParameterValue(ParameterIndex index)  {
                switch (index) {
                default:
                    {
                    return 0;
                    }
                }
            }
            
            ParameterIndex getNumSignalInParameters() const {
                return 0;
            }
            
            ParameterIndex getNumSignalOutParameters() const {
                return 0;
            }
            
            ParameterIndex getNumParameters() const {
                return 0;
            }
            
            ConstCharPointer getParameterName(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            ConstCharPointer getParameterId(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            void getParameterInfo(ParameterIndex , ParameterInfo * ) const {}
            
            void sendParameter(ParameterIndex index, bool ignoreValue) {
                this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
            }
            
            void setParameterOffset(ParameterIndex offset) {
                this->parameterOffset = offset;
            }
            
            ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
                if (steps == 1) {
                    if (normalizedValue > 0) {
                        normalizedValue = 1.;
                    }
                } else {
                    ParameterValue oneStep = (number)1. / (steps - 1);
                    ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
                    normalizedValue = numberOfSteps * oneStep;
                }
            
                return normalizedValue;
            }
            
            ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                value = (value < 0 ? 0 : (value > 1 ? 1 : value));
            
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            void scheduleParamInit(ParameterIndex index, Index order) {
                this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
            }
            
            void processClockEvent(MillisecondTime , ClockId , bool , ParameterValue ) {}
            
            void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
            
            void processOutletEvent(
                EngineLink* sender,
                OutletIndex index,
                ParameterValue value,
                MillisecondTime time
            ) {
                this->updateTime(time);
                this->processOutletAtCurrentTime(sender, index, value);
            }
            
            void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
                this->updateTime(time);
            
                switch (tag) {
                case TAG("valin"):
                    {
                    if (TAG("100Hz~/scale/number_obj-34") == objectId)
                        this->numberobj_03_valin_set(payload);
            
                    if (TAG("100Hz~/scale/number_obj-32") == objectId)
                        this->numberobj_04_valin_set(payload);
            
                    if (TAG("100Hz~/scale/number_obj-38") == objectId)
                        this->numberobj_05_valin_set(payload);
            
                    if (TAG("100Hz~/scale/number_obj-55") == objectId)
                        this->numberobj_06_valin_set(payload);
            
                    break;
                    }
                case TAG("format"):
                    {
                    if (TAG("100Hz~/scale/number_obj-34") == objectId)
                        this->numberobj_03_format_set(payload);
            
                    if (TAG("100Hz~/scale/number_obj-32") == objectId)
                        this->numberobj_04_format_set(payload);
            
                    if (TAG("100Hz~/scale/number_obj-38") == objectId)
                        this->numberobj_05_format_set(payload);
            
                    if (TAG("100Hz~/scale/number_obj-55") == objectId)
                        this->numberobj_06_format_set(payload);
            
                    break;
                    }
                }
            }
            
            void processListMessage(MessageTag , MessageTag , MillisecondTime , const list& ) {}
            
            void processBangMessage(MessageTag , MessageTag , MillisecondTime ) {}
            
            MessageTagInfo resolveTag(MessageTag tag) const {
                switch (tag) {
                case TAG("valout"):
                    {
                    return "valout";
                    }
                case TAG("100Hz~/scale/number_obj-34"):
                    {
                    return "100Hz~/scale/number_obj-34";
                    }
                case TAG("setup"):
                    {
                    return "setup";
                    }
                case TAG("100Hz~/scale/number_obj-32"):
                    {
                    return "100Hz~/scale/number_obj-32";
                    }
                case TAG("100Hz~/scale/number_obj-38"):
                    {
                    return "100Hz~/scale/number_obj-38";
                    }
                case TAG("100Hz~/scale/number_obj-55"):
                    {
                    return "100Hz~/scale/number_obj-55";
                    }
                case TAG("valin"):
                    {
                    return "valin";
                    }
                case TAG("format"):
                    {
                    return "format";
                    }
                }
            
                return nullptr;
            }
            
            DataRef* getDataRef(DataRefIndex index)  {
                switch (index) {
                default:
                    {
                    return nullptr;
                    }
                }
            }
            
            DataRefIndex getNumDataRefs() const {
                return 0;
            }
            
            void fillDataRef(DataRefIndex , DataRef& ) {}
            
            void processDataViewUpdate(DataRefIndex , MillisecondTime ) {}
            
            void initialize() {
                this->assign_defaults();
                this->setState();
            }
            
            protected:
            
            void numberobj_03_valin_set(number v) {
                this->numberobj_03_value_set(v);
            }
            
            void numberobj_03_format_set(number v) {
                this->numberobj_03_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_04_valin_set(number v) {
                this->numberobj_04_value_set(v);
            }
            
            void numberobj_04_format_set(number v) {
                this->numberobj_04_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_05_valin_set(number v) {
                this->numberobj_05_value_set(v);
            }
            
            void numberobj_05_format_set(number v) {
                this->numberobj_05_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void eventinlet_03_out1_bang_bang() {
                this->expr_03_in1_bang();
                this->expr_02_in1_bang();
            }
            
            void eventinlet_03_out1_list_set(const list& v) {
                {
                    if (v->length > 1)
                        this->expr_03_in2_set(v[1]);
            
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_03_in1_set(converted);
                }
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_02_in1_set(converted);
                }
            }
            
            void numberobj_06_valin_set(number v) {
                this->numberobj_06_value_set(v);
            }
            
            void numberobj_06_format_set(number v) {
                this->numberobj_06_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            number msToSamps(MillisecondTime ms, number sampleRate) {
                return ms * sampleRate * 0.001;
            }
            
            MillisecondTime sampsToMs(SampleIndex samps) {
                return samps * (this->invsr * 1000);
            }
            
            Index getMaxBlockSize() const {
                return this->maxvs;
            }
            
            number getSampleRate() const {
                return this->sr;
            }
            
            bool hasFixedVectorSize() const {
                return false;
            }
            
            Index getNumInputChannels() const {
                return 0;
            }
            
            Index getNumOutputChannels() const {
                return 0;
            }
            
            void initializeObjects() {
                this->numberobj_03_init();
                this->numberobj_04_init();
                this->numberobj_05_init();
                this->numberobj_06_init();
            }
            
            void sendOutlet(OutletIndex index, ParameterValue value) {
                this->getEngine()->sendOutlet(this, index, value);
            }
            
            void startup() {}
            
            void allocateDataRefs() {}
            
            void eventoutlet_03_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_03_out3_number_set(v);
            }
            
            void numberobj_06_output_set(number v) {
                this->eventoutlet_03_in1_number_set(v);
            }
            
            void numberobj_06_value_set(number v) {
                this->numberobj_06_value_setter(v);
                v = this->numberobj_06_value;
                number localvalue = v;
            
                if (this->numberobj_06_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("100Hz~/scale/number_obj-55"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_06_output_set(localvalue);
            }
            
            void expr_03_out1_set(number v) {
                this->expr_03_out1 = v;
                this->numberobj_06_value_set(this->expr_03_out1);
            }
            
            void expr_03_in1_set(number in1) {
                this->expr_03_in1 = in1;
                this->expr_03_out1_set(this->expr_03_in1 < this->expr_03_in2);//#map:100Hz~/scale/<_obj-53:1
            }
            
            void eventoutlet_02_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_03_out2_number_set(v);
            }
            
            void numberobj_05_output_set(number v) {
                this->eventoutlet_02_in1_number_set(v);
            }
            
            void numberobj_05_value_set(number v) {
                this->numberobj_05_value_setter(v);
                v = this->numberobj_05_value;
                number localvalue = v;
            
                if (this->numberobj_05_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("100Hz~/scale/number_obj-38"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_05_output_set(localvalue);
            }
            
            void scale_02_out_set(const list& v) {
                this->scale_02_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_05_value_set(converted);
                }
            }
            
            void scale_02_input_set(const list& v) {
                this->scale_02_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_02_inlow,
                        this->scale_02_inhigh,
                        this->scale_02_outlow,
                        this->scale_02_outhigh,
                        this->scale_02_power
                    ));
                }
            
                this->scale_02_out_set(tmp);
            }
            
            void eventoutlet_01_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_03_out1_number_set(v);
            }
            
            void numberobj_03_output_set(number v) {
                this->eventoutlet_01_in1_number_set(v);
            }
            
            void numberobj_03_value_set(number v) {
                this->numberobj_03_value_setter(v);
                v = this->numberobj_03_value;
                number localvalue = v;
            
                if (this->numberobj_03_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("100Hz~/scale/number_obj-34"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_03_output_set(localvalue);
            }
            
            void scale_01_out_set(const list& v) {
                this->scale_01_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_03_value_set(converted);
                }
            }
            
            void scale_01_input_set(const list& v) {
                this->scale_01_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_01_inlow,
                        this->scale_01_inhigh,
                        this->scale_01_outlow,
                        this->scale_01_outhigh,
                        this->scale_01_power
                    ));
                }
            
                this->scale_01_out_set(tmp);
            }
            
            void numberobj_04_output_set(number v) {
                {
                    list converted = {v};
                    this->scale_02_input_set(converted);
                }
            
                {
                    list converted = {v};
                    this->scale_01_input_set(converted);
                }
            }
            
            void numberobj_04_value_set(number v) {
                this->numberobj_04_value_setter(v);
                v = this->numberobj_04_value;
                number localvalue = v;
            
                if (this->numberobj_04_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("100Hz~/scale/number_obj-32"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_04_output_set(localvalue);
            }
            
            void expr_02_out1_set(number v) {
                this->expr_02_out1 = v;
                this->numberobj_04_value_set(this->expr_02_out1);
            }
            
            void expr_02_in1_set(number in1) {
                this->expr_02_in1 = in1;
                this->expr_02_out1_set(rnbo_abs(this->expr_02_in1));//#map:100Hz~/scale/abs_obj-29:1
            }
            
            void eventinlet_03_out1_number_set(number v) {
                this->expr_03_in1_set(v);
                this->expr_02_in1_set(v);
            }
            
            void expr_03_in1_bang() {
                this->expr_03_out1_set(this->expr_03_in1 < this->expr_03_in2);//#map:100Hz~/scale/<_obj-53:1
            }
            
            void expr_02_in1_bang() {
                this->expr_02_out1_set(rnbo_abs(this->expr_02_in1));//#map:100Hz~/scale/abs_obj-29:1
            }
            
            void expr_03_in2_set(number v) {
                this->expr_03_in2 = v;
            }
            
            void stackprotect_perform(Index n) {
                RNBO_UNUSED(n);
                auto __stackprotect_count = this->stackprotect_count;
                __stackprotect_count = 0;
                this->stackprotect_count = __stackprotect_count;
            }
            
            void numberobj_03_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_03_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_03_value = localvalue;
            }
            
            void numberobj_04_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_04_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_04_value = localvalue;
            }
            
            void numberobj_05_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_05_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_05_value = localvalue;
            }
            
            void numberobj_06_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_06_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_06_value = localvalue;
            }
            
            void numberobj_03_init() {
                this->numberobj_03_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("100Hz~/scale/number_obj-34"), 1, this->_currentTime);
            }
            
            void numberobj_03_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_03_value;
            }
            
            void numberobj_03_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_03_value_set(preset["value"]);
            }
            
            void numberobj_04_init() {
                this->numberobj_04_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("100Hz~/scale/number_obj-32"), 1, this->_currentTime);
            }
            
            void numberobj_04_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_04_value;
            }
            
            void numberobj_04_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_04_value_set(preset["value"]);
            }
            
            void numberobj_05_init() {
                this->numberobj_05_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("100Hz~/scale/number_obj-38"), 1, this->_currentTime);
            }
            
            void numberobj_05_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_05_value;
            }
            
            void numberobj_05_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_05_value_set(preset["value"]);
            }
            
            void numberobj_06_init() {
                this->numberobj_06_currentFormat = 0;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("100Hz~/scale/number_obj-55"), 1, this->_currentTime);
            }
            
            void numberobj_06_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_06_value;
            }
            
            void numberobj_06_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_06_value_set(preset["value"]);
            }
            
            bool stackprotect_check() {
                this->stackprotect_count++;
            
                if (this->stackprotect_count > 128) {
                    console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
                    return true;
                }
            
                return false;
            }
            
            void updateTime(MillisecondTime time) {
                this->_currentTime = time;
                this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
            
                if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
                    this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
            
                if (this->sampleOffsetIntoNextAudioBuffer < 0)
                    this->sampleOffsetIntoNextAudioBuffer = 0;
            }
            
            void assign_defaults()
            {
                numberobj_03_value = 0;
                numberobj_03_value_setter(numberobj_03_value);
                numberobj_04_value = 0;
                numberobj_04_value_setter(numberobj_04_value);
                expr_02_in1 = 0;
                expr_02_out1 = 0;
                scale_01_inlow = 0;
                scale_01_inhigh = 12;
                scale_01_outlow = 0;
                scale_01_outhigh = 1;
                scale_01_power = 1;
                numberobj_05_value = 0;
                numberobj_05_value_setter(numberobj_05_value);
                scale_02_inlow = 0;
                scale_02_inhigh = 12;
                scale_02_outlow = 0;
                scale_02_outhigh = 1;
                scale_02_power = 0.5;
                numberobj_06_value = 0;
                numberobj_06_value_setter(numberobj_06_value);
                expr_03_in1 = 0;
                expr_03_in2 = 0;
                expr_03_out1 = 0;
                _currentTime = 0;
                audioProcessSampleCount = 0;
                sampleOffsetIntoNextAudioBuffer = 0;
                zeroBuffer = nullptr;
                dummyBuffer = nullptr;
                didAllocateSignals = 0;
                vs = 0;
                maxvs = 0;
                sr = 44100;
                invsr = 0.00002267573696;
                numberobj_03_currentFormat = 6;
                numberobj_03_lastValue = 0;
                numberobj_04_currentFormat = 6;
                numberobj_04_lastValue = 0;
                numberobj_05_currentFormat = 6;
                numberobj_05_lastValue = 0;
                numberobj_06_currentFormat = 6;
                numberobj_06_lastValue = 0;
                stackprotect_count = 0;
                _voiceIndex = 0;
                _noteNumber = 0;
                isMuted = 1;
                parameterOffset = 0;
            }
            
            // member variables
            
                number numberobj_03_value;
                number numberobj_04_value;
                number expr_02_in1;
                number expr_02_out1;
                list scale_01_input;
                number scale_01_inlow;
                number scale_01_inhigh;
                number scale_01_outlow;
                number scale_01_outhigh;
                number scale_01_power;
                list scale_01_out;
                number numberobj_05_value;
                list scale_02_input;
                number scale_02_inlow;
                number scale_02_inhigh;
                number scale_02_outlow;
                number scale_02_outhigh;
                number scale_02_power;
                list scale_02_out;
                number numberobj_06_value;
                number expr_03_in1;
                number expr_03_in2;
                number expr_03_out1;
                MillisecondTime _currentTime;
                UInt64 audioProcessSampleCount;
                SampleIndex sampleOffsetIntoNextAudioBuffer;
                signal zeroBuffer;
                signal dummyBuffer;
                bool didAllocateSignals;
                Index vs;
                Index maxvs;
                number sr;
                number invsr;
                Int numberobj_03_currentFormat;
                number numberobj_03_lastValue;
                Int numberobj_04_currentFormat;
                number numberobj_04_lastValue;
                Int numberobj_05_currentFormat;
                number numberobj_05_lastValue;
                Int numberobj_06_currentFormat;
                number numberobj_06_lastValue;
                number stackprotect_count;
                Index _voiceIndex;
                Int _noteNumber;
                Index isMuted;
                ParameterIndex parameterOffset;
            
    };
    
    RNBOSubpatcher_201()
    {
    }
    
    ~RNBOSubpatcher_201()
    {
        delete this->p_03;
    }
    
    virtual Grafik7* getPatcher() const {
        return static_cast<Grafik7 *>(_parentPatcher);
    }
    
    Grafik7* getTopLevelPatcher() {
        return this->getPatcher()->getTopLevelPatcher();
    }
    
    void cancelClockEvents()
    {
        getEngine()->flushClockEvents(this, -62043057, false);
        getEngine()->flushClockEvents(this, -1621164530, false);
    }
    
    SampleIndex currentsampletime() {
        return this->audioProcessSampleCount + this->sampleOffsetIntoNextAudioBuffer;
    }
    
    number mstosamps(MillisecondTime ms) {
        return ms * this->sr * 0.001;
    }
    
    number minimum(number x, number y) {
        return (y < x ? y : x);
    }
    
    inline number safesqrt(number num) {
        return (num > 0.0 ? rnbo_sqrt(num) : 0.0);
    }
    
    Index vectorsize() const {
        return this->vs;
    }
    
    Index getNumMidiInputPorts() const {
        return 0;
    }
    
    void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
    
    Index getNumMidiOutputPorts() const {
        return 0;
    }
    
    void process(
        const SampleValue * const* inputs,
        Index numInputs,
        SampleValue * const* outputs,
        Index numOutputs,
        Index n
    ) {
        this->vs = n;
        this->updateTime(this->getEngine()->getCurrentTime());
        SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
        SampleValue * out2 = (numOutputs >= 2 && outputs[1] ? outputs[1] : this->dummyBuffer);
        const SampleValue * in1 = (numInputs >= 1 && inputs[0] ? inputs[0] : this->zeroBuffer);
        const SampleValue * in2 = (numInputs >= 2 && inputs[1] ? inputs[1] : this->zeroBuffer);
        this->linetilde_03_perform(this->signals[0], n);
        this->linetilde_04_perform(this->signals[1], n);
    
        this->filtercoeff_02_perform(
            this->filtercoeff_02_frequency,
            this->signals[1],
            this->filtercoeff_02_q,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            n
        );
    
        this->biquad_tilde_04_perform(
            in2,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[1],
            n
        );
    
        this->biquad_tilde_03_perform(
            in1,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            n
        );
    
        this->gen_01_perform(
            this->signals[7],
            this->signals[1],
            this->gen_01_in3,
            this->gen_01_in4,
            this->gen_01_in5,
            this->signals[6],
            this->signals[5],
            n
        );
    
        this->dspexpr_09_perform(this->signals[7], this->signals[6], this->signals[0], out1, n);
        this->dspexpr_10_perform(this->signals[1], this->signals[5], this->signals[0], out2, n);
        this->p_03_perform(n);
        this->stackprotect_perform(n);
        this->audioProcessSampleCount += this->vs;
    }
    
    void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
        if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
            Index i;
    
            for (i = 0; i < 8; i++) {
                this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
            }
    
            this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
            this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
            this->didAllocateSignals = true;
        }
    
        const bool sampleRateChanged = sampleRate != this->sr;
        const bool maxvsChanged = maxBlockSize != this->maxvs;
        const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
    
        if (sampleRateChanged || maxvsChanged) {
            this->vs = maxBlockSize;
            this->maxvs = maxBlockSize;
            this->sr = sampleRate;
            this->invsr = 1 / sampleRate;
        }
    
        this->filtercoeff_02_dspsetup(forceDSPSetup);
        this->biquad_tilde_04_dspsetup(forceDSPSetup);
        this->biquad_tilde_03_dspsetup(forceDSPSetup);
        this->p_03->prepareToProcess(sampleRate, maxBlockSize, force);
    
        if (sampleRateChanged)
            this->onSampleRateChanged(sampleRate);
    }
    
    void setProbingTarget(MessageTag id) {
        switch (id) {
        default:
            {
            this->setProbingIndex(-1);
            break;
            }
        }
    }
    
    void setProbingIndex(ProbingIndex ) {}
    
    Index getProbingChannels(MessageTag outletId) const {
        RNBO_UNUSED(outletId);
        return 0;
    }
    
    Index getIsMuted()  {
        return this->isMuted;
    }
    
    void setIsMuted(Index v)  {
        this->isMuted = v;
    }
    
    void onSampleRateChanged(double ) {}
    
    Index getPatcherSerial() const {
        return 0;
    }
    
    void getState(PatcherStateInterface& ) {}
    
    void setState() {
        this->p_03 = new RNBOSubpatcher_192();
        this->p_03->setEngineAndPatcher(this->getEngine(), this);
        this->p_03->initialize();
        this->p_03->setParameterOffset(this->getParameterOffset(this->p_03));
    }
    
    void getPreset(PatcherStateInterface& preset) {
        this->p_03->getPreset(getSubState(getSubState(preset, "__sps"), "scale"));
    }
    
    void setParameterValue(ParameterIndex index, ParameterValue v, MillisecondTime time) {
        RNBO_UNUSED(v);
        this->updateTime(time);
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_03->getNumParameters())
                this->p_03->setParameterValue(index, v, time);
    
            break;
            }
        }
    }
    
    void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValue(index, value, time);
    }
    
    void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
        this->setParameterValue(index, this->getParameterValue(index), time);
    }
    
    void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValueNormalized(index, value, time);
    }
    
    ParameterValue getParameterValue(ParameterIndex index)  {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_03->getNumParameters())
                return this->p_03->getParameterValue(index);
    
            return 0;
            }
        }
    }
    
    ParameterIndex getNumSignalInParameters() const {
        return 0;
    }
    
    ParameterIndex getNumSignalOutParameters() const {
        return 0;
    }
    
    ParameterIndex getNumParameters() const {
        return 0 + this->p_03->getNumParameters();
    }
    
    ConstCharPointer getParameterName(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_03->getNumParameters())
                return this->p_03->getParameterName(index);
    
            return "bogus";
            }
        }
    }
    
    ConstCharPointer getParameterId(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_03->getNumParameters())
                return this->p_03->getParameterId(index);
    
            return "bogus";
            }
        }
    }
    
    void getParameterInfo(ParameterIndex index, ParameterInfo * info) const {
        {
            switch (index) {
            default:
                {
                index -= 0;
    
                if (index < this->p_03->getNumParameters())
                    this->p_03->getParameterInfo(index, info);
    
                break;
                }
            }
        }
    }
    
    void sendParameter(ParameterIndex index, bool ignoreValue) {
        this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
    }
    
    ParameterIndex getParameterOffset(BaseInterface* subpatcher) const {
        if (subpatcher == this->p_03)
            return 0;
    
        return 0;
    }
    
    void setParameterOffset(ParameterIndex offset) {
        this->parameterOffset = offset;
    }
    
    ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
        if (steps == 1) {
            if (normalizedValue > 0) {
                normalizedValue = 1.;
            }
        } else {
            ParameterValue oneStep = (number)1. / (steps - 1);
            ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
            normalizedValue = numberOfSteps * oneStep;
        }
    
        return normalizedValue;
    }
    
    ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_03->getNumParameters())
                return this->p_03->convertToNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        value = (value < 0 ? 0 : (value > 1 ? 1 : value));
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_03->getNumParameters())
                return this->p_03->convertFromNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_03->getNumParameters())
                return this->p_03->constrainParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    void scheduleParamInit(ParameterIndex index, Index order) {
        this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
    }
    
    void processClockEvent(MillisecondTime time, ClockId index, bool hasValue, ParameterValue value) {
        RNBO_UNUSED(value);
        RNBO_UNUSED(hasValue);
        this->updateTime(time);
    
        switch (index) {
        case -62043057:
            {
            this->linetilde_03_target_bang();
            break;
            }
        case -1621164530:
            {
            this->linetilde_04_target_bang();
            break;
            }
        }
    }
    
    void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
    
    void processOutletEvent(
        EngineLink* sender,
        OutletIndex index,
        ParameterValue value,
        MillisecondTime time
    ) {
        this->updateTime(time);
        this->processOutletAtCurrentTime(sender, index, value);
    }
    
    void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
        this->updateTime(time);
    
        switch (tag) {
        case TAG("valin"):
            {
            if (TAG("100Hz~/number_obj-3") == objectId)
                this->numberobj_07_valin_set(payload);
    
            if (TAG("100Hz~/number_obj-4") == objectId)
                this->numberobj_08_valin_set(payload);
    
            break;
            }
        case TAG("format"):
            {
            if (TAG("100Hz~/number_obj-3") == objectId)
                this->numberobj_07_format_set(payload);
    
            if (TAG("100Hz~/number_obj-4") == objectId)
                this->numberobj_08_format_set(payload);
    
            break;
            }
        }
    
        this->p_03->processNumMessage(tag, objectId, time, payload);
    }
    
    void processListMessage(
        MessageTag tag,
        MessageTag objectId,
        MillisecondTime time,
        const list& payload
    ) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_03->processListMessage(tag, objectId, time, payload);
    }
    
    void processBangMessage(MessageTag tag, MessageTag objectId, MillisecondTime time) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_03->processBangMessage(tag, objectId, time);
    }
    
    MessageTagInfo resolveTag(MessageTag tag) const {
        switch (tag) {
        case TAG("valout"):
            {
            return "valout";
            }
        case TAG("100Hz~/number_obj-3"):
            {
            return "100Hz~/number_obj-3";
            }
        case TAG("setup"):
            {
            return "setup";
            }
        case TAG("100Hz~/number_obj-4"):
            {
            return "100Hz~/number_obj-4";
            }
        case TAG("valin"):
            {
            return "valin";
            }
        case TAG("format"):
            {
            return "format";
            }
        }
    
        auto subpatchResult_0 = this->p_03->resolveTag(tag);
    
        if (subpatchResult_0)
            return subpatchResult_0;
    
        return nullptr;
    }
    
    DataRef* getDataRef(DataRefIndex index)  {
        switch (index) {
        default:
            {
            return nullptr;
            }
        }
    }
    
    DataRefIndex getNumDataRefs() const {
        return 0;
    }
    
    void fillDataRef(DataRefIndex , DataRef& ) {}
    
    void processDataViewUpdate(DataRefIndex index, MillisecondTime time) {
        this->p_03->processDataViewUpdate(index, time);
    }
    
    void initialize() {
        this->assign_defaults();
        this->setState();
    }
    
    protected:
    
    void eventinlet_04_out1_bang_bang() {
        this->linetilde_03_segments_bang();
    }
    
    void eventinlet_04_out1_list_set(const list& v) {
        this->linetilde_03_segments_set(v);
    }
    
    void eventinlet_05_out1_bang_bang() {
        this->numberobj_08_value_bang();
    }
    
    void eventinlet_05_out1_list_set(const list& v) {
        {
            number converted = (v->length > 0 ? v[0] : 0);
            this->numberobj_08_value_set(converted);
        }
    }
    
    void numberobj_07_valin_set(number v) {
        this->numberobj_07_value_set(v);
    }
    
    void numberobj_07_format_set(number v) {
        this->numberobj_07_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void numberobj_08_valin_set(number v) {
        this->numberobj_08_value_set(v);
    }
    
    void numberobj_08_format_set(number v) {
        this->numberobj_08_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void linetilde_03_target_bang() {}
    
    void linetilde_04_target_bang() {}
    
    number msToSamps(MillisecondTime ms, number sampleRate) {
        return ms * sampleRate * 0.001;
    }
    
    MillisecondTime sampsToMs(SampleIndex samps) {
        return samps * (this->invsr * 1000);
    }
    
    Index getMaxBlockSize() const {
        return this->maxvs;
    }
    
    number getSampleRate() const {
        return this->sr;
    }
    
    bool hasFixedVectorSize() const {
        return false;
    }
    
    Index getNumInputChannels() const {
        return 2;
    }
    
    Index getNumOutputChannels() const {
        return 2;
    }
    
    void initializeObjects() {
        this->gen_01_x1_l_init();
        this->gen_01_y1_l_init();
        this->gen_01_x1_r_init();
        this->gen_01_y1_r_init();
        this->numberobj_07_init();
        this->numberobj_08_init();
        this->p_03->initializeObjects();
    }
    
    void sendOutlet(OutletIndex index, ParameterValue value) {
        this->getEngine()->sendOutlet(this, index, value);
    }
    
    void startup() {
        this->updateTime(this->getEngine()->getCurrentTime());
        this->p_03->startup();
    }
    
    void allocateDataRefs() {
        this->p_03->allocateDataRefs();
    }
    
    void gen_01_in5_set(number v) {
        this->gen_01_in5 = v;
    }
    
    void p_03_out3_number_set(number v) {
        this->gen_01_in5_set(v);
    }
    
    void gen_01_in4_set(number v) {
        this->gen_01_in4 = v;
    }
    
    void p_03_out2_number_set(number v) {
        this->gen_01_in4_set(v);
    }
    
    void gen_01_in3_set(number v) {
        this->gen_01_in3 = v;
    }
    
    void p_03_out1_number_set(number v) {
        this->gen_01_in3_set(v);
    }
    
    void p_03_in1_number_set(number v) {
        this->p_03->updateTime(this->_currentTime);
        this->p_03->eventinlet_03_out1_number_set(v);
    }
    
    void linetilde_04_time_set(number v) {
        this->linetilde_04_time = v;
    }
    
    void linetilde_04_segments_set(const list& v) {
        this->linetilde_04_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_04_time == 0) {
                this->linetilde_04_activeRamps->length = 0;
                this->linetilde_04_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_04_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_04_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_04_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_04_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_04_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_04_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_04_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_04_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_04_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_04_activeRamps->push(lastRampValue);
                    this->linetilde_04_activeRamps->push(0);
                    this->linetilde_04_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_04_keepramp)) {
                            this->linetilde_04_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_04_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_04_activeRamps->push(destinationValue);
                    this->linetilde_04_activeRamps->push(inc);
                    this->linetilde_04_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_07_output_set(number v) {
        {
            list converted = {v};
            this->linetilde_04_segments_set(converted);
        }
    }
    
    void numberobj_07_value_set(number v) {
        this->numberobj_07_value_setter(v);
        v = this->numberobj_07_value;
        number localvalue = v;
    
        if (this->numberobj_07_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("100Hz~/number_obj-3"), localvalue, this->_currentTime);
        this->numberobj_07_output_set(localvalue);
    }
    
    void expr_04_out1_set(number v) {
        this->expr_04_out1 = v;
        this->numberobj_07_value_set(this->expr_04_out1);
    }
    
    void expr_04_in1_set(number in1) {
        this->expr_04_in1 = in1;
        this->expr_04_out1_set(rnbo_pow(10, this->expr_04_in1 * 0.05));//#map:100Hz~/dbtoa_obj-9:1
    }
    
    void numberobj_08_output_set(number v) {
        this->p_03_in1_number_set(v);
        this->expr_04_in1_set(v);
    }
    
    void numberobj_08_value_set(number v) {
        this->numberobj_08_value_setter(v);
        v = this->numberobj_08_value;
        number localvalue = v;
    
        if (this->numberobj_08_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("100Hz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_08_output_set(localvalue);
    }
    
    void eventinlet_05_out1_number_set(number v) {
        this->numberobj_08_value_set(v);
    }
    
    void linetilde_03_time_set(number v) {
        this->linetilde_03_time = v;
    }
    
    void linetilde_03_segments_set(const list& v) {
        this->linetilde_03_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_03_time == 0) {
                this->linetilde_03_activeRamps->length = 0;
                this->linetilde_03_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_03_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_03_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_03_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_03_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_03_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_03_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_03_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_03_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_03_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_03_activeRamps->push(lastRampValue);
                    this->linetilde_03_activeRamps->push(0);
                    this->linetilde_03_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_03_keepramp)) {
                            this->linetilde_03_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_03_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_03_activeRamps->push(destinationValue);
                    this->linetilde_03_activeRamps->push(inc);
                    this->linetilde_03_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void eventinlet_04_out1_number_set(number v) {
        {
            list converted = {v};
            this->linetilde_03_segments_set(converted);
        }
    }
    
    void linetilde_03_segments_bang() {
        list v = this->linetilde_03_segments;
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_03_time == 0) {
                this->linetilde_03_activeRamps->length = 0;
                this->linetilde_03_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_03_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_03_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_03_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_03_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_03_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_03_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_03_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_03_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_03_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_03_activeRamps->push(lastRampValue);
                    this->linetilde_03_activeRamps->push(0);
                    this->linetilde_03_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_03_keepramp)) {
                            this->linetilde_03_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_03_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_03_activeRamps->push(destinationValue);
                    this->linetilde_03_activeRamps->push(inc);
                    this->linetilde_03_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_08_value_bang() {
        number v = this->numberobj_08_value;
        number localvalue = v;
    
        if (this->numberobj_08_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("100Hz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_08_output_set(localvalue);
    }
    
    void linetilde_03_perform(SampleValue * out, Index n) {
        auto __linetilde_03_time = this->linetilde_03_time;
        auto __linetilde_03_keepramp = this->linetilde_03_keepramp;
        auto __linetilde_03_currentValue = this->linetilde_03_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_03_activeRamps->length)) {
            while ((bool)(this->linetilde_03_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_03_activeRamps[0];
                number inc = this->linetilde_03_activeRamps[1];
                number rampTimeInSamples = this->linetilde_03_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_03_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_03_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_03_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -62043057,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_03_keepramp))) {
                            __linetilde_03_time = 0;
                        }
                    }
                }
    
                __linetilde_03_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_03_currentValue;
            i++;
        }
    
        this->linetilde_03_currentValue = __linetilde_03_currentValue;
        this->linetilde_03_time = __linetilde_03_time;
    }
    
    void linetilde_04_perform(SampleValue * out, Index n) {
        auto __linetilde_04_time = this->linetilde_04_time;
        auto __linetilde_04_keepramp = this->linetilde_04_keepramp;
        auto __linetilde_04_currentValue = this->linetilde_04_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_04_activeRamps->length)) {
            while ((bool)(this->linetilde_04_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_04_activeRamps[0];
                number inc = this->linetilde_04_activeRamps[1];
                number rampTimeInSamples = this->linetilde_04_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_04_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_04_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_04_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -1621164530,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_04_keepramp))) {
                            __linetilde_04_time = 0;
                        }
                    }
                }
    
                __linetilde_04_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_04_currentValue;
            i++;
        }
    
        this->linetilde_04_currentValue = __linetilde_04_currentValue;
        this->linetilde_04_time = __linetilde_04_time;
    }
    
    void filtercoeff_02_perform(
        number frequency,
        const Sample * gain,
        number q,
        SampleValue * a0,
        SampleValue * a1,
        SampleValue * a2,
        SampleValue * b1,
        SampleValue * b2,
        Index n
    ) {
        RNBO_UNUSED(q);
        RNBO_UNUSED(frequency);
        auto __filtercoeff_02_activeResamp = this->filtercoeff_02_activeResamp;
        auto __filtercoeff_02_resamp_counter = this->filtercoeff_02_resamp_counter;
        auto __filtercoeff_02_K_EPSILON = this->filtercoeff_02_K_EPSILON;
    
        for (Index i = 0; i < n; i++) {
            number local_q = 1;
            number local_gain = gain[(Index)i];
    
            if (local_gain < 0)
                local_gain = 0;
    
            number local_frequency = 100;
    
            if (local_q < __filtercoeff_02_K_EPSILON)
                local_q = __filtercoeff_02_K_EPSILON;
    
            local_frequency = (local_frequency > this->sr * 0.5 ? this->sr * 0.5 : (local_frequency < 1 ? 1 : local_frequency));
            __filtercoeff_02_resamp_counter--;
    
            if (__filtercoeff_02_resamp_counter <= 0) {
                __filtercoeff_02_resamp_counter = __filtercoeff_02_activeResamp;
                this->filtercoeff_02_updateTerms(local_frequency, local_gain, local_q);
            }
    
            a0[(Index)i] = this->filtercoeff_02_la0;
            a1[(Index)i] = this->filtercoeff_02_la1;
            a2[(Index)i] = this->filtercoeff_02_la2;
            b1[(Index)i] = this->filtercoeff_02_lb1;
            b2[(Index)i] = this->filtercoeff_02_lb2;
        }
    
        this->filtercoeff_02_resamp_counter = __filtercoeff_02_resamp_counter;
    }
    
    void biquad_tilde_04_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_04_y2 = this->biquad_tilde_04_y2;
        auto __biquad_tilde_04_y1 = this->biquad_tilde_04_y1;
        auto __biquad_tilde_04_x2 = this->biquad_tilde_04_x2;
        auto __biquad_tilde_04_x1 = this->biquad_tilde_04_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_04_x1 * a1[(Index)i] + __biquad_tilde_04_x2 * a2[(Index)i] - (__biquad_tilde_04_y1 * b1[(Index)i] + __biquad_tilde_04_y2 * b2[(Index)i]);
            __biquad_tilde_04_x2 = __biquad_tilde_04_x1;
            __biquad_tilde_04_x1 = x[(Index)i];
            __biquad_tilde_04_y2 = __biquad_tilde_04_y1;
            __biquad_tilde_04_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_04_x1 = __biquad_tilde_04_x1;
        this->biquad_tilde_04_x2 = __biquad_tilde_04_x2;
        this->biquad_tilde_04_y1 = __biquad_tilde_04_y1;
        this->biquad_tilde_04_y2 = __biquad_tilde_04_y2;
    }
    
    void biquad_tilde_03_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_03_y2 = this->biquad_tilde_03_y2;
        auto __biquad_tilde_03_y1 = this->biquad_tilde_03_y1;
        auto __biquad_tilde_03_x2 = this->biquad_tilde_03_x2;
        auto __biquad_tilde_03_x1 = this->biquad_tilde_03_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_03_x1 * a1[(Index)i] + __biquad_tilde_03_x2 * a2[(Index)i] - (__biquad_tilde_03_y1 * b1[(Index)i] + __biquad_tilde_03_y2 * b2[(Index)i]);
            __biquad_tilde_03_x2 = __biquad_tilde_03_x1;
            __biquad_tilde_03_x1 = x[(Index)i];
            __biquad_tilde_03_y2 = __biquad_tilde_03_y1;
            __biquad_tilde_03_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_03_x1 = __biquad_tilde_03_x1;
        this->biquad_tilde_03_x2 = __biquad_tilde_03_x2;
        this->biquad_tilde_03_y1 = __biquad_tilde_03_y1;
        this->biquad_tilde_03_y2 = __biquad_tilde_03_y2;
    }
    
    void gen_01_perform(
        const Sample * in1,
        const Sample * in2,
        number in3,
        number in4,
        number in5,
        SampleValue * out1,
        SampleValue * out2,
        Index n
    ) {
        auto __gen_01_y1_r_value = this->gen_01_y1_r_value;
        auto __gen_01_x1_r_value = this->gen_01_x1_r_value;
        auto __gen_01_y1_l_value = this->gen_01_y1_l_value;
        auto __gen_01_x1_l_value = this->gen_01_x1_l_value;
        number raw_drive_2 = in3;
        number asym_in_3 = in4;
        number is_cut_4 = in5;
        auto drive_5 = this->minimum(raw_drive_2, 0.6);
        number morph_factor_6 = 0.12 + is_cut_4 * (0.3 - 0.12);
        number amount_7 = drive_5 * morph_factor_6;
        number bias_factor_8 = 0.02 + is_cut_4 * (0.04 - 0.02);
        number bias_9 = asym_in_3 * bias_factor_8;
        number dc_coeff_10 = 0.9995 + drive_5 * (0.999 - 0.9995);
        Index i;
    
        for (i = 0; i < n; i++) {
            number xin_l_0 = in1[(Index)i];
            number xin_r_1 = in2[(Index)i];
            number raw_l_11 = xin_l_0 + bias_9;
            number dirty_l_12 = rnbo_tanh(raw_l_11 * 0.6) * 1.6;
            number cubic_l_13 = dirty_l_12 * dirty_l_12 * dirty_l_12 / (number)3;
            number y_l_14 = xin_l_0 - amount_7 * cubic_l_13;
            number dc_l_15 = y_l_14 - __gen_01_x1_l_value + dc_coeff_10 * __gen_01_y1_l_value;
            __gen_01_x1_l_value = y_l_14;
            __gen_01_y1_l_value = dc_l_15;
            number raw_r_16 = xin_r_1 + bias_9;
            number dirty_r_17 = rnbo_tanh(raw_r_16 * 0.6) * 1.6;
            number cubic_r_18 = dirty_r_17 * dirty_r_17 * dirty_r_17 / (number)3;
            number y_r_19 = xin_r_1 - amount_7 * cubic_r_18;
            number dc_r_20 = y_r_19 - __gen_01_x1_r_value + dc_coeff_10 * __gen_01_y1_r_value;
            __gen_01_x1_r_value = y_r_19;
            __gen_01_y1_r_value = dc_r_20;
            number expr_1_21 = dc_l_15;
            number expr_2_22 = dc_r_20;
            out2[(Index)i] = expr_2_22;
            out1[(Index)i] = expr_1_21;
        }
    
        this->gen_01_x1_l_value = __gen_01_x1_l_value;
        this->gen_01_y1_l_value = __gen_01_y1_l_value;
        this->gen_01_x1_r_value = __gen_01_x1_r_value;
        this->gen_01_y1_r_value = __gen_01_y1_r_value;
    }
    
    void dspexpr_09_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void dspexpr_10_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void p_03_perform(Index n) {
        // subpatcher: scale
        this->p_03->process(nullptr, 0, nullptr, 0, n);
    }
    
    void stackprotect_perform(Index n) {
        RNBO_UNUSED(n);
        auto __stackprotect_count = this->stackprotect_count;
        __stackprotect_count = 0;
        this->stackprotect_count = __stackprotect_count;
    }
    
    void numberobj_07_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_07_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_07_value = localvalue;
    }
    
    void numberobj_08_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_08_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_08_value = localvalue;
    }
    
    void biquad_tilde_03_reset() {
        this->biquad_tilde_03_x1 = 0;
        this->biquad_tilde_03_x2 = 0;
        this->biquad_tilde_03_y1 = 0;
        this->biquad_tilde_03_y2 = 0;
    }
    
    void biquad_tilde_03_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_03_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_03_reset();
        this->biquad_tilde_03_setupDone = true;
    }
    
    void biquad_tilde_04_reset() {
        this->biquad_tilde_04_x1 = 0;
        this->biquad_tilde_04_x2 = 0;
        this->biquad_tilde_04_y1 = 0;
        this->biquad_tilde_04_y2 = 0;
    }
    
    void biquad_tilde_04_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_04_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_04_reset();
        this->biquad_tilde_04_setupDone = true;
    }
    
    number gen_01_x1_l_getvalue() {
        return this->gen_01_x1_l_value;
    }
    
    void gen_01_x1_l_setvalue(number val) {
        this->gen_01_x1_l_value = val;
    }
    
    void gen_01_x1_l_reset() {
        this->gen_01_x1_l_value = 0;
    }
    
    void gen_01_x1_l_init() {
        this->gen_01_x1_l_value = 0;
    }
    
    number gen_01_y1_l_getvalue() {
        return this->gen_01_y1_l_value;
    }
    
    void gen_01_y1_l_setvalue(number val) {
        this->gen_01_y1_l_value = val;
    }
    
    void gen_01_y1_l_reset() {
        this->gen_01_y1_l_value = 0;
    }
    
    void gen_01_y1_l_init() {
        this->gen_01_y1_l_value = 0;
    }
    
    number gen_01_x1_r_getvalue() {
        return this->gen_01_x1_r_value;
    }
    
    void gen_01_x1_r_setvalue(number val) {
        this->gen_01_x1_r_value = val;
    }
    
    void gen_01_x1_r_reset() {
        this->gen_01_x1_r_value = 0;
    }
    
    void gen_01_x1_r_init() {
        this->gen_01_x1_r_value = 0;
    }
    
    number gen_01_y1_r_getvalue() {
        return this->gen_01_y1_r_value;
    }
    
    void gen_01_y1_r_setvalue(number val) {
        this->gen_01_y1_r_value = val;
    }
    
    void gen_01_y1_r_reset() {
        this->gen_01_y1_r_value = 0;
    }
    
    void gen_01_y1_r_init() {
        this->gen_01_y1_r_value = 0;
    }
    
    array<number, 5> filtercoeff_02_localop_next(number frequency, number q, number gain, number type) {
        number omega = frequency * this->filtercoeff_02_localop_twopi_over_sr;
        this->filtercoeff_02_localop_cs = rnbo_cos(omega);
        this->filtercoeff_02_localop_sn = rnbo_sin(omega);
        this->filtercoeff_02_localop_one_over_gain = (gain >= 0 ? (number)1 / gain : 0.0);
        this->filtercoeff_02_localop_one_over_q = (number)1 / q;
        this->filtercoeff_02_localop_alpha = this->filtercoeff_02_localop_sn * 0.5 * this->filtercoeff_02_localop_one_over_q;
    
        switch ((int)type) {
        case 5:
            {
            this->filtercoeff_02_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_02_localop_beta = this->safesqrt(
                (this->filtercoeff_02_localop_A * this->filtercoeff_02_localop_A + 1.) * this->filtercoeff_02_localop_one_over_q - (this->filtercoeff_02_localop_A - 1.) * (this->filtercoeff_02_localop_A - 1.)
            );
    
            this->filtercoeff_02_localop_b0 = (number)1 / (this->filtercoeff_02_localop_A + 1. + (this->filtercoeff_02_localop_A - 1.) * this->filtercoeff_02_localop_cs + this->filtercoeff_02_localop_beta * this->filtercoeff_02_localop_sn);
            break;
            }
        case 6:
            {
            this->filtercoeff_02_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_02_localop_beta = this->safesqrt(
                (this->filtercoeff_02_localop_A * this->filtercoeff_02_localop_A + 1.) * this->filtercoeff_02_localop_one_over_q - (this->filtercoeff_02_localop_A - 1.) * (this->filtercoeff_02_localop_A - 1.)
            );
    
            this->filtercoeff_02_localop_b0 = (number)1 / (this->filtercoeff_02_localop_A + 1. - (this->filtercoeff_02_localop_A - 1.) * this->filtercoeff_02_localop_cs + this->filtercoeff_02_localop_beta * this->filtercoeff_02_localop_sn);
            break;
            }
        case 4:
            {
            this->filtercoeff_02_localop_A = this->safesqrt(gain);
            this->filtercoeff_02_localop_one_over_a = (this->filtercoeff_02_localop_A == 0 ? 0 : (number)1 / this->filtercoeff_02_localop_A);
            this->filtercoeff_02_localop_b0 = (number)1 / (1. + this->filtercoeff_02_localop_alpha * this->filtercoeff_02_localop_one_over_a);
            break;
            }
        case 9:
        case 10:
        case 11:
        case 13:
        case 14:
            {
            this->filtercoeff_02_localop_b0 = (number)1 / (1. + this->filtercoeff_02_localop_alpha);
            this->filtercoeff_02_localop_b0g = (number)1 / (this->filtercoeff_02_localop_one_over_gain + this->filtercoeff_02_localop_alpha * this->filtercoeff_02_localop_one_over_gain);
            break;
            }
        default:
            {
            this->filtercoeff_02_localop_b0 = (number)1 / (1. + this->filtercoeff_02_localop_alpha);
            break;
            }
        }
    
        switch ((int)type) {
        case 0:
            {
            this->filtercoeff_02_localop_la0 = this->filtercoeff_02_localop_la2 = (1. - this->filtercoeff_02_localop_cs) * 0.5 * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la1 = (1. - this->filtercoeff_02_localop_cs) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0;
            break;
            }
        case 1:
            {
            this->filtercoeff_02_localop_la0 = this->filtercoeff_02_localop_la2 = (1. + this->filtercoeff_02_localop_cs) * 0.5 * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la1 = -(1. + this->filtercoeff_02_localop_cs) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0;
            break;
            }
        case 2:
            {
            this->filtercoeff_02_localop_la0 = this->filtercoeff_02_localop_alpha * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la1 = 0.;
            this->filtercoeff_02_localop_la2 = -this->filtercoeff_02_localop_alpha * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0;
            break;
            }
        case 7:
            {
            this->filtercoeff_02_localop_la0 = this->filtercoeff_02_localop_alpha * q * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la1 = 0.;
            this->filtercoeff_02_localop_la2 = -this->filtercoeff_02_localop_alpha * q * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0;
            break;
            }
        case 3:
            {
            this->filtercoeff_02_localop_la1 = this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la0 = this->filtercoeff_02_localop_la2 = this->filtercoeff_02_localop_b0;
            break;
            }
        case 8:
            {
            this->filtercoeff_02_localop_la1 = this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = this->filtercoeff_02_localop_la0 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la2 = 1.0;
            break;
            }
        case 4:
            {
            this->filtercoeff_02_localop_la0 = (1. + this->filtercoeff_02_localop_alpha * this->filtercoeff_02_localop_A) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la1 = this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la2 = (1. - this->filtercoeff_02_localop_alpha * this->filtercoeff_02_localop_A) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (1. - this->filtercoeff_02_localop_alpha * this->filtercoeff_02_localop_one_over_a) * this->filtercoeff_02_localop_b0;
            break;
            }
        case 5:
            {
            this->filtercoeff_02_localop_la0 = this->filtercoeff_02_localop_A * (this->filtercoeff_02_localop_A + 1. - (this->filtercoeff_02_localop_A - 1.) * this->filtercoeff_02_localop_cs + this->filtercoeff_02_localop_beta * this->filtercoeff_02_localop_sn) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la1 = 2. * this->filtercoeff_02_localop_A * (this->filtercoeff_02_localop_A - 1 - (this->filtercoeff_02_localop_A + 1) * this->filtercoeff_02_localop_cs) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la2 = this->filtercoeff_02_localop_A * (this->filtercoeff_02_localop_A + 1. - (this->filtercoeff_02_localop_A - 1.) * this->filtercoeff_02_localop_cs - this->filtercoeff_02_localop_beta * this->filtercoeff_02_localop_sn) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb1 = -2. * (this->filtercoeff_02_localop_A - 1. + (this->filtercoeff_02_localop_A + 1.) * this->filtercoeff_02_localop_cs) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (this->filtercoeff_02_localop_A + 1. + (this->filtercoeff_02_localop_A - 1.) * this->filtercoeff_02_localop_cs - this->filtercoeff_02_localop_beta * this->filtercoeff_02_localop_sn) * this->filtercoeff_02_localop_b0;
            break;
            }
        case 6:
            {
            this->filtercoeff_02_localop_la0 = this->filtercoeff_02_localop_A * (this->filtercoeff_02_localop_A + 1. + (this->filtercoeff_02_localop_A - 1.) * this->filtercoeff_02_localop_cs + this->filtercoeff_02_localop_beta * this->filtercoeff_02_localop_sn) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la1 = -2. * this->filtercoeff_02_localop_A * (this->filtercoeff_02_localop_A - 1. + (this->filtercoeff_02_localop_A + 1.) * this->filtercoeff_02_localop_cs) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la2 = this->filtercoeff_02_localop_A * (this->filtercoeff_02_localop_A + 1. + (this->filtercoeff_02_localop_A - 1.) * this->filtercoeff_02_localop_cs - this->filtercoeff_02_localop_beta * this->filtercoeff_02_localop_sn) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb1 = 2. * (this->filtercoeff_02_localop_A - 1. - (this->filtercoeff_02_localop_A + 1.) * this->filtercoeff_02_localop_cs) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (this->filtercoeff_02_localop_A + 1. - (this->filtercoeff_02_localop_A - 1.) * this->filtercoeff_02_localop_cs - this->filtercoeff_02_localop_beta * this->filtercoeff_02_localop_sn) * this->filtercoeff_02_localop_b0;
            break;
            }
        case 9:
            {
            this->filtercoeff_02_localop_b0g = (number)1 / (this->filtercoeff_02_localop_one_over_gain + this->filtercoeff_02_localop_alpha * this->filtercoeff_02_localop_one_over_gain);
            this->filtercoeff_02_localop_la0 = this->filtercoeff_02_localop_la2 = (1. - this->filtercoeff_02_localop_cs) * 0.5 * this->filtercoeff_02_localop_b0g;
            this->filtercoeff_02_localop_la1 = (1. - this->filtercoeff_02_localop_cs) * this->filtercoeff_02_localop_b0g;
            this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0;
            break;
            }
        case 10:
            {
            this->filtercoeff_02_localop_b0g = (number)1 / (this->filtercoeff_02_localop_one_over_gain + this->filtercoeff_02_localop_alpha * this->filtercoeff_02_localop_one_over_gain);
            this->filtercoeff_02_localop_la0 = this->filtercoeff_02_localop_la2 = (1. + this->filtercoeff_02_localop_cs) * 0.5 * this->filtercoeff_02_localop_b0g;
            this->filtercoeff_02_localop_la1 = -(1. + this->filtercoeff_02_localop_cs) * this->filtercoeff_02_localop_b0g;
            this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0;
            break;
            }
        case 11:
            {
            this->filtercoeff_02_localop_la0 = this->filtercoeff_02_localop_alpha * gain * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la1 = 0.;
            this->filtercoeff_02_localop_la2 = -this->filtercoeff_02_localop_alpha * gain * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0;
            break;
            }
        case 13:
            {
            this->filtercoeff_02_localop_la0 = this->filtercoeff_02_localop_alpha * gain * q * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la1 = 0.;
            this->filtercoeff_02_localop_la2 = -this->filtercoeff_02_localop_alpha * gain * q * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0;
            break;
            }
        case 12:
            {
            this->filtercoeff_02_localop_b0g = (number)1 / (this->filtercoeff_02_localop_one_over_gain + this->filtercoeff_02_localop_alpha * this->filtercoeff_02_localop_one_over_gain);
            this->filtercoeff_02_localop_la1 = this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs;
            this->filtercoeff_02_localop_lb2 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la1 *= this->filtercoeff_02_localop_b0g;
            this->filtercoeff_02_localop_lb1 *= this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_la0 = this->filtercoeff_02_localop_b0g;
            this->filtercoeff_02_localop_la2 = this->filtercoeff_02_localop_b0g;
            break;
            }
        case 14:
            {
            this->filtercoeff_02_localop_b0g = (number)1 / (this->filtercoeff_02_localop_one_over_gain + this->filtercoeff_02_localop_alpha * this->filtercoeff_02_localop_one_over_gain);
            this->filtercoeff_02_localop_la0 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0g;
            this->filtercoeff_02_localop_la1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0g;
            this->filtercoeff_02_localop_la2 = gain;
            this->filtercoeff_02_localop_lb1 = -2. * this->filtercoeff_02_localop_cs * this->filtercoeff_02_localop_b0;
            this->filtercoeff_02_localop_lb2 = (1. - this->filtercoeff_02_localop_alpha) * this->filtercoeff_02_localop_b0;
            break;
            }
        case 15:
            {
            this->filtercoeff_02_localop_la0 = 1;
            this->filtercoeff_02_localop_la1 = 0;
            this->filtercoeff_02_localop_la2 = 0;
            this->filtercoeff_02_localop_lb1 = 0;
            this->filtercoeff_02_localop_lb2 = 0;
            }
        default:
            {
            break;
            }
        }
    
        return {
            this->filtercoeff_02_localop_la0,
            this->filtercoeff_02_localop_la1,
            this->filtercoeff_02_localop_la2,
            this->filtercoeff_02_localop_lb1,
            this->filtercoeff_02_localop_lb2
        };
    }
    
    void filtercoeff_02_localop_dspsetup() {
        this->filtercoeff_02_localop_twopi_over_sr = (number)6.283185307179586 / this->sr;
    }
    
    void filtercoeff_02_localop_reset() {
        this->filtercoeff_02_localop_twopi_over_sr = 0;
        this->filtercoeff_02_localop_cs = 0;
        this->filtercoeff_02_localop_sn = 0;
        this->filtercoeff_02_localop_one_over_gain = 0;
        this->filtercoeff_02_localop_one_over_q = 0;
        this->filtercoeff_02_localop_alpha = 0;
        this->filtercoeff_02_localop_beta = 0;
        this->filtercoeff_02_localop_b0 = 0;
        this->filtercoeff_02_localop_b0g = 0;
        this->filtercoeff_02_localop_A = 0;
        this->filtercoeff_02_localop_one_over_a = 0;
        this->filtercoeff_02_localop_la0 = 0;
        this->filtercoeff_02_localop_la1 = 0;
        this->filtercoeff_02_localop_la2 = 0;
        this->filtercoeff_02_localop_lb1 = 0;
        this->filtercoeff_02_localop_lb2 = 0;
    }
    
    void filtercoeff_02_updateTerms(number local_frequency, number local_gain, number local_q) {
        if ((bool)(this->filtercoeff_02_force_update) || local_frequency != this->filtercoeff_02_last_frequency || local_q != this->filtercoeff_02_last_q || local_gain != this->filtercoeff_02_last_gain || this->filtercoeff_02_type != this->filtercoeff_02_last_type) {
            array<number, 5> tmp = this->filtercoeff_02_localop_next(local_frequency, local_q, local_gain, this->filtercoeff_02_type);
            this->filtercoeff_02_la0 = tmp[0];
            this->filtercoeff_02_la1 = tmp[1];
            this->filtercoeff_02_la2 = tmp[2];
            this->filtercoeff_02_lb1 = tmp[3];
            this->filtercoeff_02_lb2 = tmp[4];
            this->filtercoeff_02_last_frequency = local_frequency;
            this->filtercoeff_02_last_q = local_q;
            this->filtercoeff_02_last_gain = local_gain;
            this->filtercoeff_02_last_type = this->filtercoeff_02_type;
            this->filtercoeff_02_force_update = false;
        }
    }
    
    void filtercoeff_02_dspsetup(bool force) {
        if ((bool)(this->filtercoeff_02_setupDone) && (bool)(!(bool)(force)))
            return;
    
        {
            this->filtercoeff_02_activeResamp = this->vectorsize();
        }
    
        this->filtercoeff_02_resamp_counter = 0;
        this->filtercoeff_02_la0 = 0.;
        this->filtercoeff_02_la1 = 0.;
        this->filtercoeff_02_la2 = 0.;
        this->filtercoeff_02_lb1 = 0.;
        this->filtercoeff_02_lb2 = 0.;
        this->filtercoeff_02_last_frequency = -1.;
        this->filtercoeff_02_last_q = -1.;
        this->filtercoeff_02_last_gain = -1.;
        this->filtercoeff_02_last_type = this->filtercoeff_02_type;
        this->filtercoeff_02_force_update = true;
        this->filtercoeff_02_setupDone = true;
        this->filtercoeff_02_localop_dspsetup();
    }
    
    void numberobj_07_init() {
        this->numberobj_07_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("100Hz~/number_obj-3"), 1, this->_currentTime);
    }
    
    void numberobj_07_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_07_value;
    }
    
    void numberobj_07_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_07_value_set(preset["value"]);
    }
    
    void numberobj_08_init() {
        this->numberobj_08_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("100Hz~/number_obj-4"), 1, this->_currentTime);
    }
    
    void numberobj_08_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_08_value;
    }
    
    void numberobj_08_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_08_value_set(preset["value"]);
    }
    
    bool stackprotect_check() {
        this->stackprotect_count++;
    
        if (this->stackprotect_count > 128) {
            console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
            return true;
        }
    
        return false;
    }
    
    void updateTime(MillisecondTime time) {
        this->_currentTime = time;
        this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
    
        if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
            this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
    
        if (this->sampleOffsetIntoNextAudioBuffer < 0)
            this->sampleOffsetIntoNextAudioBuffer = 0;
    }
    
    void assign_defaults()
    {
        dspexpr_09_in1 = 0;
        dspexpr_09_in2 = 0;
        dspexpr_09_in3 = 0;
        biquad_tilde_03_x = 0;
        biquad_tilde_03_a0 = 0;
        biquad_tilde_03_a1 = 0;
        biquad_tilde_03_a2 = 0;
        biquad_tilde_03_b1 = 0;
        biquad_tilde_03_b2 = 0;
        linetilde_03_time = 10;
        linetilde_03_keepramp = 1;
        biquad_tilde_04_x = 0;
        biquad_tilde_04_a0 = 0;
        biquad_tilde_04_a1 = 0;
        biquad_tilde_04_a2 = 0;
        biquad_tilde_04_b1 = 0;
        biquad_tilde_04_b2 = 0;
        dspexpr_10_in1 = 0;
        dspexpr_10_in2 = 0;
        dspexpr_10_in3 = 0;
        gen_01_in1 = 0;
        gen_01_in2 = 0;
        gen_01_in3 = 0;
        gen_01_in4 = 0;
        gen_01_in5 = 0;
        filtercoeff_02_frequency = 100;
        filtercoeff_02_gain = 1;
        filtercoeff_02_q = 1;
        filtercoeff_02_type = 5;
        numberobj_07_value = 0;
        numberobj_07_value_setter(numberobj_07_value);
        numberobj_08_value = 0;
        numberobj_08_value_setter(numberobj_08_value);
        expr_04_in1 = 0;
        expr_04_out1 = 0;
        linetilde_04_time = 10;
        linetilde_04_keepramp = 1;
        p_03_target = 0;
        _currentTime = 0;
        audioProcessSampleCount = 0;
        sampleOffsetIntoNextAudioBuffer = 0;
        zeroBuffer = nullptr;
        dummyBuffer = nullptr;
        signals[0] = nullptr;
        signals[1] = nullptr;
        signals[2] = nullptr;
        signals[3] = nullptr;
        signals[4] = nullptr;
        signals[5] = nullptr;
        signals[6] = nullptr;
        signals[7] = nullptr;
        didAllocateSignals = 0;
        vs = 0;
        maxvs = 0;
        sr = 44100;
        invsr = 0.00002267573696;
        biquad_tilde_03_x1 = 0;
        biquad_tilde_03_x2 = 0;
        biquad_tilde_03_y1 = 0;
        biquad_tilde_03_y2 = 0;
        biquad_tilde_03_setupDone = false;
        linetilde_03_currentValue = 0;
        biquad_tilde_04_x1 = 0;
        biquad_tilde_04_x2 = 0;
        biquad_tilde_04_y1 = 0;
        biquad_tilde_04_y2 = 0;
        biquad_tilde_04_setupDone = false;
        gen_01_x1_l_value = 0;
        gen_01_y1_l_value = 0;
        gen_01_x1_r_value = 0;
        gen_01_y1_r_value = 0;
        filtercoeff_02_K_EPSILON = 1e-9;
        filtercoeff_02_setupDone = false;
        numberobj_07_currentFormat = 6;
        numberobj_07_lastValue = 0;
        numberobj_08_currentFormat = 6;
        numberobj_08_lastValue = 0;
        linetilde_04_currentValue = 1;
        stackprotect_count = 0;
        _voiceIndex = 0;
        _noteNumber = 0;
        isMuted = 1;
        parameterOffset = 0;
    }
    
    // member variables
    
        number dspexpr_09_in1;
        number dspexpr_09_in2;
        number dspexpr_09_in3;
        number biquad_tilde_03_x;
        number biquad_tilde_03_a0;
        number biquad_tilde_03_a1;
        number biquad_tilde_03_a2;
        number biquad_tilde_03_b1;
        number biquad_tilde_03_b2;
        list linetilde_03_segments;
        number linetilde_03_time;
        number linetilde_03_keepramp;
        number biquad_tilde_04_x;
        number biquad_tilde_04_a0;
        number biquad_tilde_04_a1;
        number biquad_tilde_04_a2;
        number biquad_tilde_04_b1;
        number biquad_tilde_04_b2;
        number dspexpr_10_in1;
        number dspexpr_10_in2;
        number dspexpr_10_in3;
        number gen_01_in1;
        number gen_01_in2;
        number gen_01_in3;
        number gen_01_in4;
        number gen_01_in5;
        number filtercoeff_02_frequency;
        number filtercoeff_02_gain;
        number filtercoeff_02_q;
        Int filtercoeff_02_type;
        number numberobj_07_value;
        number numberobj_08_value;
        number expr_04_in1;
        number expr_04_out1;
        list linetilde_04_segments;
        number linetilde_04_time;
        number linetilde_04_keepramp;
        number p_03_target;
        MillisecondTime _currentTime;
        UInt64 audioProcessSampleCount;
        SampleIndex sampleOffsetIntoNextAudioBuffer;
        signal zeroBuffer;
        signal dummyBuffer;
        SampleValue * signals[8];
        bool didAllocateSignals;
        Index vs;
        Index maxvs;
        number sr;
        number invsr;
        number biquad_tilde_03_x1;
        number biquad_tilde_03_x2;
        number biquad_tilde_03_y1;
        number biquad_tilde_03_y2;
        bool biquad_tilde_03_setupDone;
        list linetilde_03_activeRamps;
        number linetilde_03_currentValue;
        number biquad_tilde_04_x1;
        number biquad_tilde_04_x2;
        number biquad_tilde_04_y1;
        number biquad_tilde_04_y2;
        bool biquad_tilde_04_setupDone;
        number gen_01_x1_l_value;
        number gen_01_y1_l_value;
        number gen_01_x1_r_value;
        number gen_01_y1_r_value;
        number filtercoeff_02_resamp_counter;
        number filtercoeff_02_activeResamp;
        number filtercoeff_02_K_EPSILON;
        number filtercoeff_02_la0;
        number filtercoeff_02_la1;
        number filtercoeff_02_la2;
        number filtercoeff_02_lb1;
        number filtercoeff_02_lb2;
        number filtercoeff_02_last_frequency;
        number filtercoeff_02_last_q;
        number filtercoeff_02_last_gain;
        Int filtercoeff_02_last_type;
        bool filtercoeff_02_force_update;
        number filtercoeff_02_localop_twopi_over_sr;
        number filtercoeff_02_localop_cs;
        number filtercoeff_02_localop_sn;
        number filtercoeff_02_localop_one_over_gain;
        number filtercoeff_02_localop_one_over_q;
        number filtercoeff_02_localop_alpha;
        number filtercoeff_02_localop_beta;
        number filtercoeff_02_localop_b0;
        number filtercoeff_02_localop_b0g;
        number filtercoeff_02_localop_A;
        number filtercoeff_02_localop_one_over_a;
        number filtercoeff_02_localop_la0;
        number filtercoeff_02_localop_la1;
        number filtercoeff_02_localop_la2;
        number filtercoeff_02_localop_lb1;
        number filtercoeff_02_localop_lb2;
        bool filtercoeff_02_setupDone;
        Int numberobj_07_currentFormat;
        number numberobj_07_lastValue;
        Int numberobj_08_currentFormat;
        number numberobj_08_lastValue;
        list linetilde_04_activeRamps;
        number linetilde_04_currentValue;
        number stackprotect_count;
        Index _voiceIndex;
        Int _noteNumber;
        Index isMuted;
        ParameterIndex parameterOffset;
        RNBOSubpatcher_192* p_03;
    
};

class RNBOSubpatcher_202 : public PatcherInterfaceImpl {
    
    friend class Grafik7;
    
    public:
    
    class RNBOSubpatcher_193 : public PatcherInterfaceImpl {
            
            friend class RNBOSubpatcher_202;
            friend class Grafik7;
            
            public:
            
            RNBOSubpatcher_193()
            {
            }
            
            ~RNBOSubpatcher_193()
            {
            }
            
            virtual RNBOSubpatcher_202* getPatcher() const {
                return static_cast<RNBOSubpatcher_202 *>(_parentPatcher);
            }
            
            Grafik7* getTopLevelPatcher() {
                return this->getPatcher()->getTopLevelPatcher();
            }
            
            void cancelClockEvents()
            {
            }
            
            inline number safediv(number num, number denom) {
                return (denom == 0.0 ? 0.0 : num / denom);
            }
            
            number safepow(number base, number exponent) {
                return fixnan(rnbo_pow(base, exponent));
            }
            
            number scale(
                number x,
                number lowin,
                number hiin,
                number lowout,
                number highout,
                number pow
            ) {
                auto inscale = this->safediv(1., hiin - lowin);
                number outdiff = highout - lowout;
                number value = (x - lowin) * inscale;
            
                if (pow != 1) {
                    if (value > 0)
                        value = this->safepow(value, pow);
                    else
                        value = -this->safepow(-value, pow);
                }
            
                value = value * outdiff + lowout;
                return value;
            }
            
            Index getNumMidiInputPorts() const {
                return 0;
            }
            
            void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
            
            Index getNumMidiOutputPorts() const {
                return 0;
            }
            
            void process(
                const SampleValue * const* inputs,
                Index numInputs,
                SampleValue * const* outputs,
                Index numOutputs,
                Index n
            ) {
                RNBO_UNUSED(numOutputs);
                RNBO_UNUSED(outputs);
                RNBO_UNUSED(numInputs);
                RNBO_UNUSED(inputs);
                this->vs = n;
                this->updateTime(this->getEngine()->getCurrentTime());
                this->stackprotect_perform(n);
                this->audioProcessSampleCount += this->vs;
            }
            
            void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
                if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
                    this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
                    this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
                    this->didAllocateSignals = true;
                }
            
                const bool sampleRateChanged = sampleRate != this->sr;
                const bool maxvsChanged = maxBlockSize != this->maxvs;
                const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
            
                if (sampleRateChanged || maxvsChanged) {
                    this->vs = maxBlockSize;
                    this->maxvs = maxBlockSize;
                    this->sr = sampleRate;
                    this->invsr = 1 / sampleRate;
                }
            
                RNBO_UNUSED(forceDSPSetup);
            
                if (sampleRateChanged)
                    this->onSampleRateChanged(sampleRate);
            }
            
            void setProbingTarget(MessageTag id) {
                switch (id) {
                default:
                    {
                    this->setProbingIndex(-1);
                    break;
                    }
                }
            }
            
            void setProbingIndex(ProbingIndex ) {}
            
            Index getProbingChannels(MessageTag outletId) const {
                RNBO_UNUSED(outletId);
                return 0;
            }
            
            Index getIsMuted()  {
                return this->isMuted;
            }
            
            void setIsMuted(Index v)  {
                this->isMuted = v;
            }
            
            void onSampleRateChanged(double ) {}
            
            Index getPatcherSerial() const {
                return 0;
            }
            
            void getState(PatcherStateInterface& ) {}
            
            void setState() {}
            
            void getPreset(PatcherStateInterface& ) {}
            
            void setParameterValue(ParameterIndex , ParameterValue , MillisecondTime ) {}
            
            void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValue(index, value, time);
            }
            
            void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
                this->setParameterValue(index, this->getParameterValue(index), time);
            }
            
            void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValueNormalized(index, value, time);
            }
            
            ParameterValue getParameterValue(ParameterIndex index)  {
                switch (index) {
                default:
                    {
                    return 0;
                    }
                }
            }
            
            ParameterIndex getNumSignalInParameters() const {
                return 0;
            }
            
            ParameterIndex getNumSignalOutParameters() const {
                return 0;
            }
            
            ParameterIndex getNumParameters() const {
                return 0;
            }
            
            ConstCharPointer getParameterName(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            ConstCharPointer getParameterId(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            void getParameterInfo(ParameterIndex , ParameterInfo * ) const {}
            
            void sendParameter(ParameterIndex index, bool ignoreValue) {
                this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
            }
            
            void setParameterOffset(ParameterIndex offset) {
                this->parameterOffset = offset;
            }
            
            ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
                if (steps == 1) {
                    if (normalizedValue > 0) {
                        normalizedValue = 1.;
                    }
                } else {
                    ParameterValue oneStep = (number)1. / (steps - 1);
                    ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
                    normalizedValue = numberOfSteps * oneStep;
                }
            
                return normalizedValue;
            }
            
            ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                value = (value < 0 ? 0 : (value > 1 ? 1 : value));
            
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            void scheduleParamInit(ParameterIndex index, Index order) {
                this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
            }
            
            void processClockEvent(MillisecondTime , ClockId , bool , ParameterValue ) {}
            
            void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
            
            void processOutletEvent(
                EngineLink* sender,
                OutletIndex index,
                ParameterValue value,
                MillisecondTime time
            ) {
                this->updateTime(time);
                this->processOutletAtCurrentTime(sender, index, value);
            }
            
            void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
                this->updateTime(time);
            
                switch (tag) {
                case TAG("valin"):
                    {
                    if (TAG("200Hz~/scale/number_obj-34") == objectId)
                        this->numberobj_09_valin_set(payload);
            
                    if (TAG("200Hz~/scale/number_obj-32") == objectId)
                        this->numberobj_10_valin_set(payload);
            
                    if (TAG("200Hz~/scale/number_obj-38") == objectId)
                        this->numberobj_11_valin_set(payload);
            
                    if (TAG("200Hz~/scale/number_obj-55") == objectId)
                        this->numberobj_12_valin_set(payload);
            
                    break;
                    }
                case TAG("format"):
                    {
                    if (TAG("200Hz~/scale/number_obj-34") == objectId)
                        this->numberobj_09_format_set(payload);
            
                    if (TAG("200Hz~/scale/number_obj-32") == objectId)
                        this->numberobj_10_format_set(payload);
            
                    if (TAG("200Hz~/scale/number_obj-38") == objectId)
                        this->numberobj_11_format_set(payload);
            
                    if (TAG("200Hz~/scale/number_obj-55") == objectId)
                        this->numberobj_12_format_set(payload);
            
                    break;
                    }
                }
            }
            
            void processListMessage(MessageTag , MessageTag , MillisecondTime , const list& ) {}
            
            void processBangMessage(MessageTag , MessageTag , MillisecondTime ) {}
            
            MessageTagInfo resolveTag(MessageTag tag) const {
                switch (tag) {
                case TAG("valout"):
                    {
                    return "valout";
                    }
                case TAG("200Hz~/scale/number_obj-34"):
                    {
                    return "200Hz~/scale/number_obj-34";
                    }
                case TAG("setup"):
                    {
                    return "setup";
                    }
                case TAG("200Hz~/scale/number_obj-32"):
                    {
                    return "200Hz~/scale/number_obj-32";
                    }
                case TAG("200Hz~/scale/number_obj-38"):
                    {
                    return "200Hz~/scale/number_obj-38";
                    }
                case TAG("200Hz~/scale/number_obj-55"):
                    {
                    return "200Hz~/scale/number_obj-55";
                    }
                case TAG("valin"):
                    {
                    return "valin";
                    }
                case TAG("format"):
                    {
                    return "format";
                    }
                }
            
                return nullptr;
            }
            
            DataRef* getDataRef(DataRefIndex index)  {
                switch (index) {
                default:
                    {
                    return nullptr;
                    }
                }
            }
            
            DataRefIndex getNumDataRefs() const {
                return 0;
            }
            
            void fillDataRef(DataRefIndex , DataRef& ) {}
            
            void processDataViewUpdate(DataRefIndex , MillisecondTime ) {}
            
            void initialize() {
                this->assign_defaults();
                this->setState();
            }
            
            protected:
            
            void numberobj_09_valin_set(number v) {
                this->numberobj_09_value_set(v);
            }
            
            void numberobj_09_format_set(number v) {
                this->numberobj_09_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_10_valin_set(number v) {
                this->numberobj_10_value_set(v);
            }
            
            void numberobj_10_format_set(number v) {
                this->numberobj_10_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_11_valin_set(number v) {
                this->numberobj_11_value_set(v);
            }
            
            void numberobj_11_format_set(number v) {
                this->numberobj_11_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_12_valin_set(number v) {
                this->numberobj_12_value_set(v);
            }
            
            void numberobj_12_format_set(number v) {
                this->numberobj_12_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            number msToSamps(MillisecondTime ms, number sampleRate) {
                return ms * sampleRate * 0.001;
            }
            
            MillisecondTime sampsToMs(SampleIndex samps) {
                return samps * (this->invsr * 1000);
            }
            
            Index getMaxBlockSize() const {
                return this->maxvs;
            }
            
            number getSampleRate() const {
                return this->sr;
            }
            
            bool hasFixedVectorSize() const {
                return false;
            }
            
            Index getNumInputChannels() const {
                return 0;
            }
            
            Index getNumOutputChannels() const {
                return 0;
            }
            
            void initializeObjects() {
                this->numberobj_09_init();
                this->numberobj_10_init();
                this->numberobj_11_init();
                this->numberobj_12_init();
            }
            
            void sendOutlet(OutletIndex index, ParameterValue value) {
                this->getEngine()->sendOutlet(this, index, value);
            }
            
            void startup() {}
            
            void allocateDataRefs() {}
            
            void eventoutlet_06_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_04_out3_number_set(v);
            }
            
            void numberobj_12_output_set(number v) {
                this->eventoutlet_06_in1_number_set(v);
            }
            
            void numberobj_12_value_set(number v) {
                this->numberobj_12_value_setter(v);
                v = this->numberobj_12_value;
                number localvalue = v;
            
                if (this->numberobj_12_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("200Hz~/scale/number_obj-55"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_12_output_set(localvalue);
            }
            
            void expr_06_out1_set(number v) {
                this->expr_06_out1 = v;
                this->numberobj_12_value_set(this->expr_06_out1);
            }
            
            void expr_06_in1_set(number in1) {
                this->expr_06_in1 = in1;
                this->expr_06_out1_set(this->expr_06_in1 < this->expr_06_in2);//#map:200Hz~/scale/<_obj-53:1
            }
            
            void eventoutlet_05_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_04_out2_number_set(v);
            }
            
            void numberobj_11_output_set(number v) {
                this->eventoutlet_05_in1_number_set(v);
            }
            
            void numberobj_11_value_set(number v) {
                this->numberobj_11_value_setter(v);
                v = this->numberobj_11_value;
                number localvalue = v;
            
                if (this->numberobj_11_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("200Hz~/scale/number_obj-38"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_11_output_set(localvalue);
            }
            
            void scale_04_out_set(const list& v) {
                this->scale_04_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_11_value_set(converted);
                }
            }
            
            void scale_04_input_set(const list& v) {
                this->scale_04_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_04_inlow,
                        this->scale_04_inhigh,
                        this->scale_04_outlow,
                        this->scale_04_outhigh,
                        this->scale_04_power
                    ));
                }
            
                this->scale_04_out_set(tmp);
            }
            
            void eventoutlet_04_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_04_out1_number_set(v);
            }
            
            void numberobj_09_output_set(number v) {
                this->eventoutlet_04_in1_number_set(v);
            }
            
            void numberobj_09_value_set(number v) {
                this->numberobj_09_value_setter(v);
                v = this->numberobj_09_value;
                number localvalue = v;
            
                if (this->numberobj_09_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("200Hz~/scale/number_obj-34"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_09_output_set(localvalue);
            }
            
            void scale_03_out_set(const list& v) {
                this->scale_03_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_09_value_set(converted);
                }
            }
            
            void scale_03_input_set(const list& v) {
                this->scale_03_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_03_inlow,
                        this->scale_03_inhigh,
                        this->scale_03_outlow,
                        this->scale_03_outhigh,
                        this->scale_03_power
                    ));
                }
            
                this->scale_03_out_set(tmp);
            }
            
            void numberobj_10_output_set(number v) {
                {
                    list converted = {v};
                    this->scale_04_input_set(converted);
                }
            
                {
                    list converted = {v};
                    this->scale_03_input_set(converted);
                }
            }
            
            void numberobj_10_value_set(number v) {
                this->numberobj_10_value_setter(v);
                v = this->numberobj_10_value;
                number localvalue = v;
            
                if (this->numberobj_10_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("200Hz~/scale/number_obj-32"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_10_output_set(localvalue);
            }
            
            void expr_05_out1_set(number v) {
                this->expr_05_out1 = v;
                this->numberobj_10_value_set(this->expr_05_out1);
            }
            
            void expr_05_in1_set(number in1) {
                this->expr_05_in1 = in1;
                this->expr_05_out1_set(rnbo_abs(this->expr_05_in1));//#map:200Hz~/scale/abs_obj-29:1
            }
            
            void eventinlet_06_out1_number_set(number v) {
                this->expr_06_in1_set(v);
                this->expr_05_in1_set(v);
            }
            
            void expr_06_in1_bang() {
                this->expr_06_out1_set(this->expr_06_in1 < this->expr_06_in2);//#map:200Hz~/scale/<_obj-53:1
            }
            
            void expr_05_in1_bang() {
                this->expr_05_out1_set(rnbo_abs(this->expr_05_in1));//#map:200Hz~/scale/abs_obj-29:1
            }
            
            void eventinlet_06_out1_bang_bang() {
                this->expr_06_in1_bang();
                this->expr_05_in1_bang();
            }
            
            void expr_06_in2_set(number v) {
                this->expr_06_in2 = v;
            }
            
            void eventinlet_06_out1_list_set(const list& v) {
                {
                    if (v->length > 1)
                        this->expr_06_in2_set(v[1]);
            
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_06_in1_set(converted);
                }
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_05_in1_set(converted);
                }
            }
            
            void stackprotect_perform(Index n) {
                RNBO_UNUSED(n);
                auto __stackprotect_count = this->stackprotect_count;
                __stackprotect_count = 0;
                this->stackprotect_count = __stackprotect_count;
            }
            
            void numberobj_09_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_09_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_09_value = localvalue;
            }
            
            void numberobj_10_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_10_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_10_value = localvalue;
            }
            
            void numberobj_11_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_11_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_11_value = localvalue;
            }
            
            void numberobj_12_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_12_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_12_value = localvalue;
            }
            
            void numberobj_09_init() {
                this->numberobj_09_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("200Hz~/scale/number_obj-34"), 1, this->_currentTime);
            }
            
            void numberobj_09_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_09_value;
            }
            
            void numberobj_09_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_09_value_set(preset["value"]);
            }
            
            void numberobj_10_init() {
                this->numberobj_10_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("200Hz~/scale/number_obj-32"), 1, this->_currentTime);
            }
            
            void numberobj_10_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_10_value;
            }
            
            void numberobj_10_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_10_value_set(preset["value"]);
            }
            
            void numberobj_11_init() {
                this->numberobj_11_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("200Hz~/scale/number_obj-38"), 1, this->_currentTime);
            }
            
            void numberobj_11_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_11_value;
            }
            
            void numberobj_11_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_11_value_set(preset["value"]);
            }
            
            void numberobj_12_init() {
                this->numberobj_12_currentFormat = 0;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("200Hz~/scale/number_obj-55"), 1, this->_currentTime);
            }
            
            void numberobj_12_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_12_value;
            }
            
            void numberobj_12_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_12_value_set(preset["value"]);
            }
            
            bool stackprotect_check() {
                this->stackprotect_count++;
            
                if (this->stackprotect_count > 128) {
                    console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
                    return true;
                }
            
                return false;
            }
            
            void updateTime(MillisecondTime time) {
                this->_currentTime = time;
                this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
            
                if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
                    this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
            
                if (this->sampleOffsetIntoNextAudioBuffer < 0)
                    this->sampleOffsetIntoNextAudioBuffer = 0;
            }
            
            void assign_defaults()
            {
                numberobj_09_value = 0;
                numberobj_09_value_setter(numberobj_09_value);
                numberobj_10_value = 0;
                numberobj_10_value_setter(numberobj_10_value);
                expr_05_in1 = 0;
                expr_05_out1 = 0;
                scale_03_inlow = 0;
                scale_03_inhigh = 12;
                scale_03_outlow = 0;
                scale_03_outhigh = 1;
                scale_03_power = 1;
                numberobj_11_value = 0;
                numberobj_11_value_setter(numberobj_11_value);
                scale_04_inlow = 0;
                scale_04_inhigh = 12;
                scale_04_outlow = 0;
                scale_04_outhigh = 1;
                scale_04_power = 0.5;
                numberobj_12_value = 0;
                numberobj_12_value_setter(numberobj_12_value);
                expr_06_in1 = 0;
                expr_06_in2 = 0;
                expr_06_out1 = 0;
                _currentTime = 0;
                audioProcessSampleCount = 0;
                sampleOffsetIntoNextAudioBuffer = 0;
                zeroBuffer = nullptr;
                dummyBuffer = nullptr;
                didAllocateSignals = 0;
                vs = 0;
                maxvs = 0;
                sr = 44100;
                invsr = 0.00002267573696;
                numberobj_09_currentFormat = 6;
                numberobj_09_lastValue = 0;
                numberobj_10_currentFormat = 6;
                numberobj_10_lastValue = 0;
                numberobj_11_currentFormat = 6;
                numberobj_11_lastValue = 0;
                numberobj_12_currentFormat = 6;
                numberobj_12_lastValue = 0;
                stackprotect_count = 0;
                _voiceIndex = 0;
                _noteNumber = 0;
                isMuted = 1;
                parameterOffset = 0;
            }
            
            // member variables
            
                number numberobj_09_value;
                number numberobj_10_value;
                number expr_05_in1;
                number expr_05_out1;
                list scale_03_input;
                number scale_03_inlow;
                number scale_03_inhigh;
                number scale_03_outlow;
                number scale_03_outhigh;
                number scale_03_power;
                list scale_03_out;
                number numberobj_11_value;
                list scale_04_input;
                number scale_04_inlow;
                number scale_04_inhigh;
                number scale_04_outlow;
                number scale_04_outhigh;
                number scale_04_power;
                list scale_04_out;
                number numberobj_12_value;
                number expr_06_in1;
                number expr_06_in2;
                number expr_06_out1;
                MillisecondTime _currentTime;
                UInt64 audioProcessSampleCount;
                SampleIndex sampleOffsetIntoNextAudioBuffer;
                signal zeroBuffer;
                signal dummyBuffer;
                bool didAllocateSignals;
                Index vs;
                Index maxvs;
                number sr;
                number invsr;
                Int numberobj_09_currentFormat;
                number numberobj_09_lastValue;
                Int numberobj_10_currentFormat;
                number numberobj_10_lastValue;
                Int numberobj_11_currentFormat;
                number numberobj_11_lastValue;
                Int numberobj_12_currentFormat;
                number numberobj_12_lastValue;
                number stackprotect_count;
                Index _voiceIndex;
                Int _noteNumber;
                Index isMuted;
                ParameterIndex parameterOffset;
            
    };
    
    RNBOSubpatcher_202()
    {
    }
    
    ~RNBOSubpatcher_202()
    {
        delete this->p_04;
    }
    
    virtual Grafik7* getPatcher() const {
        return static_cast<Grafik7 *>(_parentPatcher);
    }
    
    Grafik7* getTopLevelPatcher() {
        return this->getPatcher()->getTopLevelPatcher();
    }
    
    void cancelClockEvents()
    {
        getEngine()->flushClockEvents(this, -62043057, false);
        getEngine()->flushClockEvents(this, -1621164530, false);
    }
    
    SampleIndex currentsampletime() {
        return this->audioProcessSampleCount + this->sampleOffsetIntoNextAudioBuffer;
    }
    
    number mstosamps(MillisecondTime ms) {
        return ms * this->sr * 0.001;
    }
    
    inline number safesqrt(number num) {
        return (num > 0.0 ? rnbo_sqrt(num) : 0.0);
    }
    
    Index vectorsize() const {
        return this->vs;
    }
    
    Index getNumMidiInputPorts() const {
        return 0;
    }
    
    void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
    
    Index getNumMidiOutputPorts() const {
        return 0;
    }
    
    void process(
        const SampleValue * const* inputs,
        Index numInputs,
        SampleValue * const* outputs,
        Index numOutputs,
        Index n
    ) {
        this->vs = n;
        this->updateTime(this->getEngine()->getCurrentTime());
        SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
        SampleValue * out2 = (numOutputs >= 2 && outputs[1] ? outputs[1] : this->dummyBuffer);
        const SampleValue * in1 = (numInputs >= 1 && inputs[0] ? inputs[0] : this->zeroBuffer);
        const SampleValue * in2 = (numInputs >= 2 && inputs[1] ? inputs[1] : this->zeroBuffer);
        this->linetilde_05_perform(this->signals[0], n);
        this->linetilde_06_perform(this->signals[1], n);
    
        this->filtercoeff_03_perform(
            this->filtercoeff_03_frequency,
            this->signals[1],
            this->filtercoeff_03_q,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            n
        );
    
        this->biquad_tilde_06_perform(
            in2,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[1],
            n
        );
    
        this->biquad_tilde_05_perform(
            in1,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            n
        );
    
        this->gen_02_perform(
            this->signals[7],
            this->signals[1],
            this->gen_02_in3,
            this->gen_02_in4,
            this->gen_02_in5,
            this->signals[6],
            this->signals[5],
            n
        );
    
        this->dspexpr_11_perform(this->signals[7], this->signals[6], this->signals[0], out1, n);
        this->dspexpr_12_perform(this->signals[1], this->signals[5], this->signals[0], out2, n);
        this->p_04_perform(n);
        this->stackprotect_perform(n);
        this->audioProcessSampleCount += this->vs;
    }
    
    void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
        if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
            Index i;
    
            for (i = 0; i < 8; i++) {
                this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
            }
    
            this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
            this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
            this->didAllocateSignals = true;
        }
    
        const bool sampleRateChanged = sampleRate != this->sr;
        const bool maxvsChanged = maxBlockSize != this->maxvs;
        const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
    
        if (sampleRateChanged || maxvsChanged) {
            this->vs = maxBlockSize;
            this->maxvs = maxBlockSize;
            this->sr = sampleRate;
            this->invsr = 1 / sampleRate;
        }
    
        this->filtercoeff_03_dspsetup(forceDSPSetup);
        this->biquad_tilde_06_dspsetup(forceDSPSetup);
        this->biquad_tilde_05_dspsetup(forceDSPSetup);
        this->p_04->prepareToProcess(sampleRate, maxBlockSize, force);
    
        if (sampleRateChanged)
            this->onSampleRateChanged(sampleRate);
    }
    
    void setProbingTarget(MessageTag id) {
        switch (id) {
        default:
            {
            this->setProbingIndex(-1);
            break;
            }
        }
    }
    
    void setProbingIndex(ProbingIndex ) {}
    
    Index getProbingChannels(MessageTag outletId) const {
        RNBO_UNUSED(outletId);
        return 0;
    }
    
    Index getIsMuted()  {
        return this->isMuted;
    }
    
    void setIsMuted(Index v)  {
        this->isMuted = v;
    }
    
    void onSampleRateChanged(double ) {}
    
    Index getPatcherSerial() const {
        return 0;
    }
    
    void getState(PatcherStateInterface& ) {}
    
    void setState() {
        this->p_04 = new RNBOSubpatcher_193();
        this->p_04->setEngineAndPatcher(this->getEngine(), this);
        this->p_04->initialize();
        this->p_04->setParameterOffset(this->getParameterOffset(this->p_04));
    }
    
    void getPreset(PatcherStateInterface& preset) {
        this->p_04->getPreset(getSubState(getSubState(preset, "__sps"), "scale"));
    }
    
    void setParameterValue(ParameterIndex index, ParameterValue v, MillisecondTime time) {
        RNBO_UNUSED(v);
        this->updateTime(time);
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_04->getNumParameters())
                this->p_04->setParameterValue(index, v, time);
    
            break;
            }
        }
    }
    
    void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValue(index, value, time);
    }
    
    void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
        this->setParameterValue(index, this->getParameterValue(index), time);
    }
    
    void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValueNormalized(index, value, time);
    }
    
    ParameterValue getParameterValue(ParameterIndex index)  {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_04->getNumParameters())
                return this->p_04->getParameterValue(index);
    
            return 0;
            }
        }
    }
    
    ParameterIndex getNumSignalInParameters() const {
        return 0;
    }
    
    ParameterIndex getNumSignalOutParameters() const {
        return 0;
    }
    
    ParameterIndex getNumParameters() const {
        return 0 + this->p_04->getNumParameters();
    }
    
    ConstCharPointer getParameterName(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_04->getNumParameters())
                return this->p_04->getParameterName(index);
    
            return "bogus";
            }
        }
    }
    
    ConstCharPointer getParameterId(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_04->getNumParameters())
                return this->p_04->getParameterId(index);
    
            return "bogus";
            }
        }
    }
    
    void getParameterInfo(ParameterIndex index, ParameterInfo * info) const {
        {
            switch (index) {
            default:
                {
                index -= 0;
    
                if (index < this->p_04->getNumParameters())
                    this->p_04->getParameterInfo(index, info);
    
                break;
                }
            }
        }
    }
    
    void sendParameter(ParameterIndex index, bool ignoreValue) {
        this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
    }
    
    ParameterIndex getParameterOffset(BaseInterface* subpatcher) const {
        if (subpatcher == this->p_04)
            return 0;
    
        return 0;
    }
    
    void setParameterOffset(ParameterIndex offset) {
        this->parameterOffset = offset;
    }
    
    ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
        if (steps == 1) {
            if (normalizedValue > 0) {
                normalizedValue = 1.;
            }
        } else {
            ParameterValue oneStep = (number)1. / (steps - 1);
            ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
            normalizedValue = numberOfSteps * oneStep;
        }
    
        return normalizedValue;
    }
    
    ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_04->getNumParameters())
                return this->p_04->convertToNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        value = (value < 0 ? 0 : (value > 1 ? 1 : value));
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_04->getNumParameters())
                return this->p_04->convertFromNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_04->getNumParameters())
                return this->p_04->constrainParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    void scheduleParamInit(ParameterIndex index, Index order) {
        this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
    }
    
    void processClockEvent(MillisecondTime time, ClockId index, bool hasValue, ParameterValue value) {
        RNBO_UNUSED(value);
        RNBO_UNUSED(hasValue);
        this->updateTime(time);
    
        switch (index) {
        case -62043057:
            {
            this->linetilde_05_target_bang();
            break;
            }
        case -1621164530:
            {
            this->linetilde_06_target_bang();
            break;
            }
        }
    }
    
    void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
    
    void processOutletEvent(
        EngineLink* sender,
        OutletIndex index,
        ParameterValue value,
        MillisecondTime time
    ) {
        this->updateTime(time);
        this->processOutletAtCurrentTime(sender, index, value);
    }
    
    void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
        this->updateTime(time);
    
        switch (tag) {
        case TAG("valin"):
            {
            if (TAG("200Hz~/number_obj-3") == objectId)
                this->numberobj_13_valin_set(payload);
    
            if (TAG("200Hz~/number_obj-4") == objectId)
                this->numberobj_14_valin_set(payload);
    
            break;
            }
        case TAG("format"):
            {
            if (TAG("200Hz~/number_obj-3") == objectId)
                this->numberobj_13_format_set(payload);
    
            if (TAG("200Hz~/number_obj-4") == objectId)
                this->numberobj_14_format_set(payload);
    
            break;
            }
        }
    
        this->p_04->processNumMessage(tag, objectId, time, payload);
    }
    
    void processListMessage(
        MessageTag tag,
        MessageTag objectId,
        MillisecondTime time,
        const list& payload
    ) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_04->processListMessage(tag, objectId, time, payload);
    }
    
    void processBangMessage(MessageTag tag, MessageTag objectId, MillisecondTime time) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_04->processBangMessage(tag, objectId, time);
    }
    
    MessageTagInfo resolveTag(MessageTag tag) const {
        switch (tag) {
        case TAG("valout"):
            {
            return "valout";
            }
        case TAG("200Hz~/number_obj-3"):
            {
            return "200Hz~/number_obj-3";
            }
        case TAG("setup"):
            {
            return "setup";
            }
        case TAG("200Hz~/number_obj-4"):
            {
            return "200Hz~/number_obj-4";
            }
        case TAG("valin"):
            {
            return "valin";
            }
        case TAG("format"):
            {
            return "format";
            }
        }
    
        auto subpatchResult_0 = this->p_04->resolveTag(tag);
    
        if (subpatchResult_0)
            return subpatchResult_0;
    
        return nullptr;
    }
    
    DataRef* getDataRef(DataRefIndex index)  {
        switch (index) {
        default:
            {
            return nullptr;
            }
        }
    }
    
    DataRefIndex getNumDataRefs() const {
        return 0;
    }
    
    void fillDataRef(DataRefIndex , DataRef& ) {}
    
    void processDataViewUpdate(DataRefIndex index, MillisecondTime time) {
        this->p_04->processDataViewUpdate(index, time);
    }
    
    void initialize() {
        this->assign_defaults();
        this->setState();
    }
    
    protected:
    
    void eventinlet_07_out1_bang_bang() {
        this->linetilde_05_segments_bang();
    }
    
    void eventinlet_07_out1_list_set(const list& v) {
        this->linetilde_05_segments_set(v);
    }
    
    void eventinlet_08_out1_bang_bang() {
        this->p_04_in1_bang_bang();
        this->numberobj_14_value_bang();
    }
    
    void eventinlet_08_out1_list_set(const list& v) {
        this->p_04_in1_list_set(v);
    
        {
            number converted = (v->length > 0 ? v[0] : 0);
            this->numberobj_14_value_set(converted);
        }
    }
    
    void numberobj_13_valin_set(number v) {
        this->numberobj_13_value_set(v);
    }
    
    void numberobj_13_format_set(number v) {
        this->numberobj_13_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void numberobj_14_valin_set(number v) {
        this->numberobj_14_value_set(v);
    }
    
    void numberobj_14_format_set(number v) {
        this->numberobj_14_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void linetilde_05_target_bang() {}
    
    void linetilde_06_target_bang() {}
    
    number msToSamps(MillisecondTime ms, number sampleRate) {
        return ms * sampleRate * 0.001;
    }
    
    MillisecondTime sampsToMs(SampleIndex samps) {
        return samps * (this->invsr * 1000);
    }
    
    Index getMaxBlockSize() const {
        return this->maxvs;
    }
    
    number getSampleRate() const {
        return this->sr;
    }
    
    bool hasFixedVectorSize() const {
        return false;
    }
    
    Index getNumInputChannels() const {
        return 2;
    }
    
    Index getNumOutputChannels() const {
        return 2;
    }
    
    void initializeObjects() {
        this->gen_02_x1_l_init();
        this->gen_02_y1_l_init();
        this->gen_02_x1_r_init();
        this->gen_02_y1_r_init();
        this->numberobj_13_init();
        this->numberobj_14_init();
        this->p_04->initializeObjects();
    }
    
    void sendOutlet(OutletIndex index, ParameterValue value) {
        this->getEngine()->sendOutlet(this, index, value);
    }
    
    void startup() {
        this->updateTime(this->getEngine()->getCurrentTime());
        this->p_04->startup();
    }
    
    void allocateDataRefs() {
        this->p_04->allocateDataRefs();
    }
    
    void gen_02_in5_set(number v) {
        this->gen_02_in5 = v;
    }
    
    void p_04_out3_number_set(number v) {
        this->gen_02_in5_set(v);
    }
    
    void gen_02_in4_set(number v) {
        this->gen_02_in4 = v;
    }
    
    void p_04_out2_number_set(number v) {
        this->gen_02_in4_set(v);
    }
    
    void gen_02_in3_set(number v) {
        this->gen_02_in3 = v;
    }
    
    void p_04_out1_number_set(number v) {
        this->gen_02_in3_set(v);
    }
    
    void p_04_in1_number_set(number v) {
        this->p_04->updateTime(this->_currentTime);
        this->p_04->eventinlet_06_out1_number_set(v);
    }
    
    void linetilde_06_time_set(number v) {
        this->linetilde_06_time = v;
    }
    
    void linetilde_06_segments_set(const list& v) {
        this->linetilde_06_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_06_time == 0) {
                this->linetilde_06_activeRamps->length = 0;
                this->linetilde_06_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_06_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_06_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_06_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_06_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_06_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_06_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_06_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_06_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_06_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_06_activeRamps->push(lastRampValue);
                    this->linetilde_06_activeRamps->push(0);
                    this->linetilde_06_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_06_keepramp)) {
                            this->linetilde_06_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_06_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_06_activeRamps->push(destinationValue);
                    this->linetilde_06_activeRamps->push(inc);
                    this->linetilde_06_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_13_output_set(number v) {
        {
            list converted = {v};
            this->linetilde_06_segments_set(converted);
        }
    }
    
    void numberobj_13_value_set(number v) {
        this->numberobj_13_value_setter(v);
        v = this->numberobj_13_value;
        number localvalue = v;
    
        if (this->numberobj_13_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("200Hz~/number_obj-3"), localvalue, this->_currentTime);
        this->numberobj_13_output_set(localvalue);
    }
    
    void expr_07_out1_set(number v) {
        this->expr_07_out1 = v;
        this->numberobj_13_value_set(this->expr_07_out1);
    }
    
    void expr_07_in1_set(number in1) {
        this->expr_07_in1 = in1;
        this->expr_07_out1_set(rnbo_pow(10, this->expr_07_in1 * 0.05));//#map:200Hz~/dbtoa_obj-9:1
    }
    
    void numberobj_14_output_set(number v) {
        this->expr_07_in1_set(v);
    }
    
    void numberobj_14_value_set(number v) {
        this->numberobj_14_value_setter(v);
        v = this->numberobj_14_value;
        number localvalue = v;
    
        if (this->numberobj_14_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("200Hz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_14_output_set(localvalue);
    }
    
    void eventinlet_08_out1_number_set(number v) {
        this->p_04_in1_number_set(v);
        this->numberobj_14_value_set(v);
    }
    
    void linetilde_05_time_set(number v) {
        this->linetilde_05_time = v;
    }
    
    void linetilde_05_segments_set(const list& v) {
        this->linetilde_05_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_05_time == 0) {
                this->linetilde_05_activeRamps->length = 0;
                this->linetilde_05_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_05_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_05_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_05_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_05_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_05_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_05_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_05_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_05_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_05_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_05_activeRamps->push(lastRampValue);
                    this->linetilde_05_activeRamps->push(0);
                    this->linetilde_05_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_05_keepramp)) {
                            this->linetilde_05_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_05_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_05_activeRamps->push(destinationValue);
                    this->linetilde_05_activeRamps->push(inc);
                    this->linetilde_05_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void eventinlet_07_out1_number_set(number v) {
        {
            list converted = {v};
            this->linetilde_05_segments_set(converted);
        }
    }
    
    void linetilde_05_segments_bang() {
        list v = this->linetilde_05_segments;
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_05_time == 0) {
                this->linetilde_05_activeRamps->length = 0;
                this->linetilde_05_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_05_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_05_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_05_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_05_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_05_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_05_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_05_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_05_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_05_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_05_activeRamps->push(lastRampValue);
                    this->linetilde_05_activeRamps->push(0);
                    this->linetilde_05_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_05_keepramp)) {
                            this->linetilde_05_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_05_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_05_activeRamps->push(destinationValue);
                    this->linetilde_05_activeRamps->push(inc);
                    this->linetilde_05_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void p_04_in1_bang_bang() {
        this->p_04->updateTime(this->_currentTime);
        this->p_04->eventinlet_06_out1_bang_bang();
    }
    
    void numberobj_14_value_bang() {
        number v = this->numberobj_14_value;
        number localvalue = v;
    
        if (this->numberobj_14_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("200Hz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_14_output_set(localvalue);
    }
    
    void p_04_in1_list_set(const list& v) {
        this->p_04->updateTime(this->_currentTime);
        this->p_04->eventinlet_06_out1_list_set(v);
    }
    
    void linetilde_05_perform(SampleValue * out, Index n) {
        auto __linetilde_05_time = this->linetilde_05_time;
        auto __linetilde_05_keepramp = this->linetilde_05_keepramp;
        auto __linetilde_05_currentValue = this->linetilde_05_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_05_activeRamps->length)) {
            while ((bool)(this->linetilde_05_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_05_activeRamps[0];
                number inc = this->linetilde_05_activeRamps[1];
                number rampTimeInSamples = this->linetilde_05_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_05_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_05_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_05_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -62043057,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_05_keepramp))) {
                            __linetilde_05_time = 0;
                        }
                    }
                }
    
                __linetilde_05_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_05_currentValue;
            i++;
        }
    
        this->linetilde_05_currentValue = __linetilde_05_currentValue;
        this->linetilde_05_time = __linetilde_05_time;
    }
    
    void linetilde_06_perform(SampleValue * out, Index n) {
        auto __linetilde_06_time = this->linetilde_06_time;
        auto __linetilde_06_keepramp = this->linetilde_06_keepramp;
        auto __linetilde_06_currentValue = this->linetilde_06_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_06_activeRamps->length)) {
            while ((bool)(this->linetilde_06_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_06_activeRamps[0];
                number inc = this->linetilde_06_activeRamps[1];
                number rampTimeInSamples = this->linetilde_06_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_06_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_06_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_06_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -1621164530,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_06_keepramp))) {
                            __linetilde_06_time = 0;
                        }
                    }
                }
    
                __linetilde_06_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_06_currentValue;
            i++;
        }
    
        this->linetilde_06_currentValue = __linetilde_06_currentValue;
        this->linetilde_06_time = __linetilde_06_time;
    }
    
    void filtercoeff_03_perform(
        number frequency,
        const Sample * gain,
        number q,
        SampleValue * a0,
        SampleValue * a1,
        SampleValue * a2,
        SampleValue * b1,
        SampleValue * b2,
        Index n
    ) {
        RNBO_UNUSED(q);
        RNBO_UNUSED(frequency);
        auto __filtercoeff_03_activeResamp = this->filtercoeff_03_activeResamp;
        auto __filtercoeff_03_resamp_counter = this->filtercoeff_03_resamp_counter;
        auto __filtercoeff_03_K_EPSILON = this->filtercoeff_03_K_EPSILON;
    
        for (Index i = 0; i < n; i++) {
            number local_q = 1;
            number local_gain = gain[(Index)i];
    
            if (local_gain < 0)
                local_gain = 0;
    
            number local_frequency = 200;
    
            if (local_q < __filtercoeff_03_K_EPSILON)
                local_q = __filtercoeff_03_K_EPSILON;
    
            local_frequency = (local_frequency > this->sr * 0.5 ? this->sr * 0.5 : (local_frequency < 1 ? 1 : local_frequency));
            __filtercoeff_03_resamp_counter--;
    
            if (__filtercoeff_03_resamp_counter <= 0) {
                __filtercoeff_03_resamp_counter = __filtercoeff_03_activeResamp;
                this->filtercoeff_03_updateTerms(local_frequency, local_gain, local_q);
            }
    
            a0[(Index)i] = this->filtercoeff_03_la0;
            a1[(Index)i] = this->filtercoeff_03_la1;
            a2[(Index)i] = this->filtercoeff_03_la2;
            b1[(Index)i] = this->filtercoeff_03_lb1;
            b2[(Index)i] = this->filtercoeff_03_lb2;
        }
    
        this->filtercoeff_03_resamp_counter = __filtercoeff_03_resamp_counter;
    }
    
    void biquad_tilde_06_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_06_y2 = this->biquad_tilde_06_y2;
        auto __biquad_tilde_06_y1 = this->biquad_tilde_06_y1;
        auto __biquad_tilde_06_x2 = this->biquad_tilde_06_x2;
        auto __biquad_tilde_06_x1 = this->biquad_tilde_06_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_06_x1 * a1[(Index)i] + __biquad_tilde_06_x2 * a2[(Index)i] - (__biquad_tilde_06_y1 * b1[(Index)i] + __biquad_tilde_06_y2 * b2[(Index)i]);
            __biquad_tilde_06_x2 = __biquad_tilde_06_x1;
            __biquad_tilde_06_x1 = x[(Index)i];
            __biquad_tilde_06_y2 = __biquad_tilde_06_y1;
            __biquad_tilde_06_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_06_x1 = __biquad_tilde_06_x1;
        this->biquad_tilde_06_x2 = __biquad_tilde_06_x2;
        this->biquad_tilde_06_y1 = __biquad_tilde_06_y1;
        this->biquad_tilde_06_y2 = __biquad_tilde_06_y2;
    }
    
    void biquad_tilde_05_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_05_y2 = this->biquad_tilde_05_y2;
        auto __biquad_tilde_05_y1 = this->biquad_tilde_05_y1;
        auto __biquad_tilde_05_x2 = this->biquad_tilde_05_x2;
        auto __biquad_tilde_05_x1 = this->biquad_tilde_05_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_05_x1 * a1[(Index)i] + __biquad_tilde_05_x2 * a2[(Index)i] - (__biquad_tilde_05_y1 * b1[(Index)i] + __biquad_tilde_05_y2 * b2[(Index)i]);
            __biquad_tilde_05_x2 = __biquad_tilde_05_x1;
            __biquad_tilde_05_x1 = x[(Index)i];
            __biquad_tilde_05_y2 = __biquad_tilde_05_y1;
            __biquad_tilde_05_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_05_x1 = __biquad_tilde_05_x1;
        this->biquad_tilde_05_x2 = __biquad_tilde_05_x2;
        this->biquad_tilde_05_y1 = __biquad_tilde_05_y1;
        this->biquad_tilde_05_y2 = __biquad_tilde_05_y2;
    }
    
    void gen_02_perform(
        const Sample * in1,
        const Sample * in2,
        number in3,
        number in4,
        number in5,
        SampleValue * out1,
        SampleValue * out2,
        Index n
    ) {
        auto __gen_02_y1_r_value = this->gen_02_y1_r_value;
        auto __gen_02_x1_r_value = this->gen_02_x1_r_value;
        auto __gen_02_y1_l_value = this->gen_02_y1_l_value;
        auto __gen_02_x1_l_value = this->gen_02_x1_l_value;
        number drive_2 = in3;
        number asym_3 = in4;
        number is_cut_4 = in5;
        number morph_factor_5 = 0.18 + is_cut_4 * (0.4 - 0.18);
        number amount_6 = drive_2 * morph_factor_5;
        number bias_factor_7 = 0.04 + is_cut_4 * (0.08 - 0.04);
        number bias_8 = asym_3 * bias_factor_7;
        Index i;
    
        for (i = 0; i < n; i++) {
            number xin_l_0 = in1[(Index)i];
            number xin_r_1 = in2[(Index)i];
            number raw_l_9 = xin_l_0 + bias_8;
            number dirty_l_10 = rnbo_tanh(raw_l_9 * 0.6) * 1.6;
            number cubic_l_11 = dirty_l_10 * dirty_l_10 * dirty_l_10 / (number)3;
            number y_l_12 = xin_l_0 - amount_6 * cubic_l_11;
            number dc_l_13 = y_l_12 - __gen_02_x1_l_value + 0.9995 * __gen_02_y1_l_value;
            __gen_02_x1_l_value = y_l_12;
            __gen_02_y1_l_value = dc_l_13;
            number raw_r_14 = xin_r_1 + bias_8;
            number dirty_r_15 = rnbo_tanh(raw_r_14 * 0.6) * 1.6;
            number cubic_r_16 = dirty_r_15 * dirty_r_15 * dirty_r_15 / (number)3;
            number y_r_17 = xin_r_1 - amount_6 * cubic_r_16;
            number dc_r_18 = y_r_17 - __gen_02_x1_r_value + 0.9995 * __gen_02_y1_r_value;
            __gen_02_x1_r_value = y_r_17;
            __gen_02_y1_r_value = dc_r_18;
            number expr_1_19 = dc_l_13;
            number expr_2_20 = dc_r_18;
            out2[(Index)i] = expr_2_20;
            out1[(Index)i] = expr_1_19;
        }
    
        this->gen_02_x1_l_value = __gen_02_x1_l_value;
        this->gen_02_y1_l_value = __gen_02_y1_l_value;
        this->gen_02_x1_r_value = __gen_02_x1_r_value;
        this->gen_02_y1_r_value = __gen_02_y1_r_value;
    }
    
    void dspexpr_11_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void dspexpr_12_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void p_04_perform(Index n) {
        // subpatcher: scale
        this->p_04->process(nullptr, 0, nullptr, 0, n);
    }
    
    void stackprotect_perform(Index n) {
        RNBO_UNUSED(n);
        auto __stackprotect_count = this->stackprotect_count;
        __stackprotect_count = 0;
        this->stackprotect_count = __stackprotect_count;
    }
    
    void numberobj_13_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_13_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_13_value = localvalue;
    }
    
    void numberobj_14_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_14_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_14_value = localvalue;
    }
    
    void biquad_tilde_05_reset() {
        this->biquad_tilde_05_x1 = 0;
        this->biquad_tilde_05_x2 = 0;
        this->biquad_tilde_05_y1 = 0;
        this->biquad_tilde_05_y2 = 0;
    }
    
    void biquad_tilde_05_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_05_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_05_reset();
        this->biquad_tilde_05_setupDone = true;
    }
    
    void biquad_tilde_06_reset() {
        this->biquad_tilde_06_x1 = 0;
        this->biquad_tilde_06_x2 = 0;
        this->biquad_tilde_06_y1 = 0;
        this->biquad_tilde_06_y2 = 0;
    }
    
    void biquad_tilde_06_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_06_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_06_reset();
        this->biquad_tilde_06_setupDone = true;
    }
    
    number gen_02_x1_l_getvalue() {
        return this->gen_02_x1_l_value;
    }
    
    void gen_02_x1_l_setvalue(number val) {
        this->gen_02_x1_l_value = val;
    }
    
    void gen_02_x1_l_reset() {
        this->gen_02_x1_l_value = 0;
    }
    
    void gen_02_x1_l_init() {
        this->gen_02_x1_l_value = 0;
    }
    
    number gen_02_y1_l_getvalue() {
        return this->gen_02_y1_l_value;
    }
    
    void gen_02_y1_l_setvalue(number val) {
        this->gen_02_y1_l_value = val;
    }
    
    void gen_02_y1_l_reset() {
        this->gen_02_y1_l_value = 0;
    }
    
    void gen_02_y1_l_init() {
        this->gen_02_y1_l_value = 0;
    }
    
    number gen_02_x1_r_getvalue() {
        return this->gen_02_x1_r_value;
    }
    
    void gen_02_x1_r_setvalue(number val) {
        this->gen_02_x1_r_value = val;
    }
    
    void gen_02_x1_r_reset() {
        this->gen_02_x1_r_value = 0;
    }
    
    void gen_02_x1_r_init() {
        this->gen_02_x1_r_value = 0;
    }
    
    number gen_02_y1_r_getvalue() {
        return this->gen_02_y1_r_value;
    }
    
    void gen_02_y1_r_setvalue(number val) {
        this->gen_02_y1_r_value = val;
    }
    
    void gen_02_y1_r_reset() {
        this->gen_02_y1_r_value = 0;
    }
    
    void gen_02_y1_r_init() {
        this->gen_02_y1_r_value = 0;
    }
    
    array<number, 5> filtercoeff_03_localop_next(number frequency, number q, number gain, number type) {
        number omega = frequency * this->filtercoeff_03_localop_twopi_over_sr;
        this->filtercoeff_03_localop_cs = rnbo_cos(omega);
        this->filtercoeff_03_localop_sn = rnbo_sin(omega);
        this->filtercoeff_03_localop_one_over_gain = (gain >= 0 ? (number)1 / gain : 0.0);
        this->filtercoeff_03_localop_one_over_q = (number)1 / q;
        this->filtercoeff_03_localop_alpha = this->filtercoeff_03_localop_sn * 0.5 * this->filtercoeff_03_localop_one_over_q;
    
        switch ((int)type) {
        case 5:
            {
            this->filtercoeff_03_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_03_localop_beta = this->safesqrt(
                (this->filtercoeff_03_localop_A * this->filtercoeff_03_localop_A + 1.) * this->filtercoeff_03_localop_one_over_q - (this->filtercoeff_03_localop_A - 1.) * (this->filtercoeff_03_localop_A - 1.)
            );
    
            this->filtercoeff_03_localop_b0 = (number)1 / (this->filtercoeff_03_localop_A + 1. + (this->filtercoeff_03_localop_A - 1.) * this->filtercoeff_03_localop_cs + this->filtercoeff_03_localop_beta * this->filtercoeff_03_localop_sn);
            break;
            }
        case 6:
            {
            this->filtercoeff_03_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_03_localop_beta = this->safesqrt(
                (this->filtercoeff_03_localop_A * this->filtercoeff_03_localop_A + 1.) * this->filtercoeff_03_localop_one_over_q - (this->filtercoeff_03_localop_A - 1.) * (this->filtercoeff_03_localop_A - 1.)
            );
    
            this->filtercoeff_03_localop_b0 = (number)1 / (this->filtercoeff_03_localop_A + 1. - (this->filtercoeff_03_localop_A - 1.) * this->filtercoeff_03_localop_cs + this->filtercoeff_03_localop_beta * this->filtercoeff_03_localop_sn);
            break;
            }
        case 4:
            {
            this->filtercoeff_03_localop_A = this->safesqrt(gain);
            this->filtercoeff_03_localop_one_over_a = (this->filtercoeff_03_localop_A == 0 ? 0 : (number)1 / this->filtercoeff_03_localop_A);
            this->filtercoeff_03_localop_b0 = (number)1 / (1. + this->filtercoeff_03_localop_alpha * this->filtercoeff_03_localop_one_over_a);
            break;
            }
        case 9:
        case 10:
        case 11:
        case 13:
        case 14:
            {
            this->filtercoeff_03_localop_b0 = (number)1 / (1. + this->filtercoeff_03_localop_alpha);
            this->filtercoeff_03_localop_b0g = (number)1 / (this->filtercoeff_03_localop_one_over_gain + this->filtercoeff_03_localop_alpha * this->filtercoeff_03_localop_one_over_gain);
            break;
            }
        default:
            {
            this->filtercoeff_03_localop_b0 = (number)1 / (1. + this->filtercoeff_03_localop_alpha);
            break;
            }
        }
    
        switch ((int)type) {
        case 0:
            {
            this->filtercoeff_03_localop_la0 = this->filtercoeff_03_localop_la2 = (1. - this->filtercoeff_03_localop_cs) * 0.5 * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la1 = (1. - this->filtercoeff_03_localop_cs) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0;
            break;
            }
        case 1:
            {
            this->filtercoeff_03_localop_la0 = this->filtercoeff_03_localop_la2 = (1. + this->filtercoeff_03_localop_cs) * 0.5 * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la1 = -(1. + this->filtercoeff_03_localop_cs) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0;
            break;
            }
        case 2:
            {
            this->filtercoeff_03_localop_la0 = this->filtercoeff_03_localop_alpha * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la1 = 0.;
            this->filtercoeff_03_localop_la2 = -this->filtercoeff_03_localop_alpha * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0;
            break;
            }
        case 7:
            {
            this->filtercoeff_03_localop_la0 = this->filtercoeff_03_localop_alpha * q * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la1 = 0.;
            this->filtercoeff_03_localop_la2 = -this->filtercoeff_03_localop_alpha * q * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0;
            break;
            }
        case 3:
            {
            this->filtercoeff_03_localop_la1 = this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la0 = this->filtercoeff_03_localop_la2 = this->filtercoeff_03_localop_b0;
            break;
            }
        case 8:
            {
            this->filtercoeff_03_localop_la1 = this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = this->filtercoeff_03_localop_la0 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la2 = 1.0;
            break;
            }
        case 4:
            {
            this->filtercoeff_03_localop_la0 = (1. + this->filtercoeff_03_localop_alpha * this->filtercoeff_03_localop_A) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la1 = this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la2 = (1. - this->filtercoeff_03_localop_alpha * this->filtercoeff_03_localop_A) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (1. - this->filtercoeff_03_localop_alpha * this->filtercoeff_03_localop_one_over_a) * this->filtercoeff_03_localop_b0;
            break;
            }
        case 5:
            {
            this->filtercoeff_03_localop_la0 = this->filtercoeff_03_localop_A * (this->filtercoeff_03_localop_A + 1. - (this->filtercoeff_03_localop_A - 1.) * this->filtercoeff_03_localop_cs + this->filtercoeff_03_localop_beta * this->filtercoeff_03_localop_sn) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la1 = 2. * this->filtercoeff_03_localop_A * (this->filtercoeff_03_localop_A - 1 - (this->filtercoeff_03_localop_A + 1) * this->filtercoeff_03_localop_cs) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la2 = this->filtercoeff_03_localop_A * (this->filtercoeff_03_localop_A + 1. - (this->filtercoeff_03_localop_A - 1.) * this->filtercoeff_03_localop_cs - this->filtercoeff_03_localop_beta * this->filtercoeff_03_localop_sn) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb1 = -2. * (this->filtercoeff_03_localop_A - 1. + (this->filtercoeff_03_localop_A + 1.) * this->filtercoeff_03_localop_cs) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (this->filtercoeff_03_localop_A + 1. + (this->filtercoeff_03_localop_A - 1.) * this->filtercoeff_03_localop_cs - this->filtercoeff_03_localop_beta * this->filtercoeff_03_localop_sn) * this->filtercoeff_03_localop_b0;
            break;
            }
        case 6:
            {
            this->filtercoeff_03_localop_la0 = this->filtercoeff_03_localop_A * (this->filtercoeff_03_localop_A + 1. + (this->filtercoeff_03_localop_A - 1.) * this->filtercoeff_03_localop_cs + this->filtercoeff_03_localop_beta * this->filtercoeff_03_localop_sn) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la1 = -2. * this->filtercoeff_03_localop_A * (this->filtercoeff_03_localop_A - 1. + (this->filtercoeff_03_localop_A + 1.) * this->filtercoeff_03_localop_cs) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la2 = this->filtercoeff_03_localop_A * (this->filtercoeff_03_localop_A + 1. + (this->filtercoeff_03_localop_A - 1.) * this->filtercoeff_03_localop_cs - this->filtercoeff_03_localop_beta * this->filtercoeff_03_localop_sn) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb1 = 2. * (this->filtercoeff_03_localop_A - 1. - (this->filtercoeff_03_localop_A + 1.) * this->filtercoeff_03_localop_cs) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (this->filtercoeff_03_localop_A + 1. - (this->filtercoeff_03_localop_A - 1.) * this->filtercoeff_03_localop_cs - this->filtercoeff_03_localop_beta * this->filtercoeff_03_localop_sn) * this->filtercoeff_03_localop_b0;
            break;
            }
        case 9:
            {
            this->filtercoeff_03_localop_b0g = (number)1 / (this->filtercoeff_03_localop_one_over_gain + this->filtercoeff_03_localop_alpha * this->filtercoeff_03_localop_one_over_gain);
            this->filtercoeff_03_localop_la0 = this->filtercoeff_03_localop_la2 = (1. - this->filtercoeff_03_localop_cs) * 0.5 * this->filtercoeff_03_localop_b0g;
            this->filtercoeff_03_localop_la1 = (1. - this->filtercoeff_03_localop_cs) * this->filtercoeff_03_localop_b0g;
            this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0;
            break;
            }
        case 10:
            {
            this->filtercoeff_03_localop_b0g = (number)1 / (this->filtercoeff_03_localop_one_over_gain + this->filtercoeff_03_localop_alpha * this->filtercoeff_03_localop_one_over_gain);
            this->filtercoeff_03_localop_la0 = this->filtercoeff_03_localop_la2 = (1. + this->filtercoeff_03_localop_cs) * 0.5 * this->filtercoeff_03_localop_b0g;
            this->filtercoeff_03_localop_la1 = -(1. + this->filtercoeff_03_localop_cs) * this->filtercoeff_03_localop_b0g;
            this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0;
            break;
            }
        case 11:
            {
            this->filtercoeff_03_localop_la0 = this->filtercoeff_03_localop_alpha * gain * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la1 = 0.;
            this->filtercoeff_03_localop_la2 = -this->filtercoeff_03_localop_alpha * gain * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0;
            break;
            }
        case 13:
            {
            this->filtercoeff_03_localop_la0 = this->filtercoeff_03_localop_alpha * gain * q * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la1 = 0.;
            this->filtercoeff_03_localop_la2 = -this->filtercoeff_03_localop_alpha * gain * q * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0;
            break;
            }
        case 12:
            {
            this->filtercoeff_03_localop_b0g = (number)1 / (this->filtercoeff_03_localop_one_over_gain + this->filtercoeff_03_localop_alpha * this->filtercoeff_03_localop_one_over_gain);
            this->filtercoeff_03_localop_la1 = this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs;
            this->filtercoeff_03_localop_lb2 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la1 *= this->filtercoeff_03_localop_b0g;
            this->filtercoeff_03_localop_lb1 *= this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_la0 = this->filtercoeff_03_localop_b0g;
            this->filtercoeff_03_localop_la2 = this->filtercoeff_03_localop_b0g;
            break;
            }
        case 14:
            {
            this->filtercoeff_03_localop_b0g = (number)1 / (this->filtercoeff_03_localop_one_over_gain + this->filtercoeff_03_localop_alpha * this->filtercoeff_03_localop_one_over_gain);
            this->filtercoeff_03_localop_la0 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0g;
            this->filtercoeff_03_localop_la1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0g;
            this->filtercoeff_03_localop_la2 = gain;
            this->filtercoeff_03_localop_lb1 = -2. * this->filtercoeff_03_localop_cs * this->filtercoeff_03_localop_b0;
            this->filtercoeff_03_localop_lb2 = (1. - this->filtercoeff_03_localop_alpha) * this->filtercoeff_03_localop_b0;
            break;
            }
        case 15:
            {
            this->filtercoeff_03_localop_la0 = 1;
            this->filtercoeff_03_localop_la1 = 0;
            this->filtercoeff_03_localop_la2 = 0;
            this->filtercoeff_03_localop_lb1 = 0;
            this->filtercoeff_03_localop_lb2 = 0;
            }
        default:
            {
            break;
            }
        }
    
        return {
            this->filtercoeff_03_localop_la0,
            this->filtercoeff_03_localop_la1,
            this->filtercoeff_03_localop_la2,
            this->filtercoeff_03_localop_lb1,
            this->filtercoeff_03_localop_lb2
        };
    }
    
    void filtercoeff_03_localop_dspsetup() {
        this->filtercoeff_03_localop_twopi_over_sr = (number)6.283185307179586 / this->sr;
    }
    
    void filtercoeff_03_localop_reset() {
        this->filtercoeff_03_localop_twopi_over_sr = 0;
        this->filtercoeff_03_localop_cs = 0;
        this->filtercoeff_03_localop_sn = 0;
        this->filtercoeff_03_localop_one_over_gain = 0;
        this->filtercoeff_03_localop_one_over_q = 0;
        this->filtercoeff_03_localop_alpha = 0;
        this->filtercoeff_03_localop_beta = 0;
        this->filtercoeff_03_localop_b0 = 0;
        this->filtercoeff_03_localop_b0g = 0;
        this->filtercoeff_03_localop_A = 0;
        this->filtercoeff_03_localop_one_over_a = 0;
        this->filtercoeff_03_localop_la0 = 0;
        this->filtercoeff_03_localop_la1 = 0;
        this->filtercoeff_03_localop_la2 = 0;
        this->filtercoeff_03_localop_lb1 = 0;
        this->filtercoeff_03_localop_lb2 = 0;
    }
    
    void filtercoeff_03_updateTerms(number local_frequency, number local_gain, number local_q) {
        if ((bool)(this->filtercoeff_03_force_update) || local_frequency != this->filtercoeff_03_last_frequency || local_q != this->filtercoeff_03_last_q || local_gain != this->filtercoeff_03_last_gain || this->filtercoeff_03_type != this->filtercoeff_03_last_type) {
            array<number, 5> tmp = this->filtercoeff_03_localop_next(local_frequency, local_q, local_gain, this->filtercoeff_03_type);
            this->filtercoeff_03_la0 = tmp[0];
            this->filtercoeff_03_la1 = tmp[1];
            this->filtercoeff_03_la2 = tmp[2];
            this->filtercoeff_03_lb1 = tmp[3];
            this->filtercoeff_03_lb2 = tmp[4];
            this->filtercoeff_03_last_frequency = local_frequency;
            this->filtercoeff_03_last_q = local_q;
            this->filtercoeff_03_last_gain = local_gain;
            this->filtercoeff_03_last_type = this->filtercoeff_03_type;
            this->filtercoeff_03_force_update = false;
        }
    }
    
    void filtercoeff_03_dspsetup(bool force) {
        if ((bool)(this->filtercoeff_03_setupDone) && (bool)(!(bool)(force)))
            return;
    
        {
            this->filtercoeff_03_activeResamp = this->vectorsize();
        }
    
        this->filtercoeff_03_resamp_counter = 0;
        this->filtercoeff_03_la0 = 0.;
        this->filtercoeff_03_la1 = 0.;
        this->filtercoeff_03_la2 = 0.;
        this->filtercoeff_03_lb1 = 0.;
        this->filtercoeff_03_lb2 = 0.;
        this->filtercoeff_03_last_frequency = -1.;
        this->filtercoeff_03_last_q = -1.;
        this->filtercoeff_03_last_gain = -1.;
        this->filtercoeff_03_last_type = this->filtercoeff_03_type;
        this->filtercoeff_03_force_update = true;
        this->filtercoeff_03_setupDone = true;
        this->filtercoeff_03_localop_dspsetup();
    }
    
    void numberobj_13_init() {
        this->numberobj_13_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("200Hz~/number_obj-3"), 1, this->_currentTime);
    }
    
    void numberobj_13_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_13_value;
    }
    
    void numberobj_13_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_13_value_set(preset["value"]);
    }
    
    void numberobj_14_init() {
        this->numberobj_14_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("200Hz~/number_obj-4"), 1, this->_currentTime);
    }
    
    void numberobj_14_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_14_value;
    }
    
    void numberobj_14_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_14_value_set(preset["value"]);
    }
    
    bool stackprotect_check() {
        this->stackprotect_count++;
    
        if (this->stackprotect_count > 128) {
            console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
            return true;
        }
    
        return false;
    }
    
    void updateTime(MillisecondTime time) {
        this->_currentTime = time;
        this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
    
        if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
            this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
    
        if (this->sampleOffsetIntoNextAudioBuffer < 0)
            this->sampleOffsetIntoNextAudioBuffer = 0;
    }
    
    void assign_defaults()
    {
        dspexpr_11_in1 = 0;
        dspexpr_11_in2 = 0;
        dspexpr_11_in3 = 0;
        biquad_tilde_05_x = 0;
        biquad_tilde_05_a0 = 0;
        biquad_tilde_05_a1 = 0;
        biquad_tilde_05_a2 = 0;
        biquad_tilde_05_b1 = 0;
        biquad_tilde_05_b2 = 0;
        linetilde_05_time = 10;
        linetilde_05_keepramp = 1;
        dspexpr_12_in1 = 0;
        dspexpr_12_in2 = 0;
        dspexpr_12_in3 = 0;
        biquad_tilde_06_x = 0;
        biquad_tilde_06_a0 = 0;
        biquad_tilde_06_a1 = 0;
        biquad_tilde_06_a2 = 0;
        biquad_tilde_06_b1 = 0;
        biquad_tilde_06_b2 = 0;
        gen_02_in1 = 0;
        gen_02_in2 = 0;
        gen_02_in3 = 0;
        gen_02_in4 = 0;
        gen_02_in5 = 0;
        filtercoeff_03_frequency = 200;
        filtercoeff_03_gain = 1;
        filtercoeff_03_q = 1;
        filtercoeff_03_type = 4;
        numberobj_13_value = 0;
        numberobj_13_value_setter(numberobj_13_value);
        numberobj_14_value = 0;
        numberobj_14_value_setter(numberobj_14_value);
        expr_07_in1 = 0;
        expr_07_out1 = 0;
        linetilde_06_time = 10;
        linetilde_06_keepramp = 1;
        p_04_target = 0;
        _currentTime = 0;
        audioProcessSampleCount = 0;
        sampleOffsetIntoNextAudioBuffer = 0;
        zeroBuffer = nullptr;
        dummyBuffer = nullptr;
        signals[0] = nullptr;
        signals[1] = nullptr;
        signals[2] = nullptr;
        signals[3] = nullptr;
        signals[4] = nullptr;
        signals[5] = nullptr;
        signals[6] = nullptr;
        signals[7] = nullptr;
        didAllocateSignals = 0;
        vs = 0;
        maxvs = 0;
        sr = 44100;
        invsr = 0.00002267573696;
        biquad_tilde_05_x1 = 0;
        biquad_tilde_05_x2 = 0;
        biquad_tilde_05_y1 = 0;
        biquad_tilde_05_y2 = 0;
        biquad_tilde_05_setupDone = false;
        linetilde_05_currentValue = 0;
        biquad_tilde_06_x1 = 0;
        biquad_tilde_06_x2 = 0;
        biquad_tilde_06_y1 = 0;
        biquad_tilde_06_y2 = 0;
        biquad_tilde_06_setupDone = false;
        gen_02_x1_l_value = 0;
        gen_02_y1_l_value = 0;
        gen_02_x1_r_value = 0;
        gen_02_y1_r_value = 0;
        filtercoeff_03_K_EPSILON = 1e-9;
        filtercoeff_03_setupDone = false;
        numberobj_13_currentFormat = 6;
        numberobj_13_lastValue = 0;
        numberobj_14_currentFormat = 6;
        numberobj_14_lastValue = 0;
        linetilde_06_currentValue = 1;
        stackprotect_count = 0;
        _voiceIndex = 0;
        _noteNumber = 0;
        isMuted = 1;
        parameterOffset = 0;
    }
    
    // member variables
    
        number dspexpr_11_in1;
        number dspexpr_11_in2;
        number dspexpr_11_in3;
        number biquad_tilde_05_x;
        number biquad_tilde_05_a0;
        number biquad_tilde_05_a1;
        number biquad_tilde_05_a2;
        number biquad_tilde_05_b1;
        number biquad_tilde_05_b2;
        list linetilde_05_segments;
        number linetilde_05_time;
        number linetilde_05_keepramp;
        number dspexpr_12_in1;
        number dspexpr_12_in2;
        number dspexpr_12_in3;
        number biquad_tilde_06_x;
        number biquad_tilde_06_a0;
        number biquad_tilde_06_a1;
        number biquad_tilde_06_a2;
        number biquad_tilde_06_b1;
        number biquad_tilde_06_b2;
        number gen_02_in1;
        number gen_02_in2;
        number gen_02_in3;
        number gen_02_in4;
        number gen_02_in5;
        number filtercoeff_03_frequency;
        number filtercoeff_03_gain;
        number filtercoeff_03_q;
        Int filtercoeff_03_type;
        number numberobj_13_value;
        number numberobj_14_value;
        number expr_07_in1;
        number expr_07_out1;
        list linetilde_06_segments;
        number linetilde_06_time;
        number linetilde_06_keepramp;
        number p_04_target;
        MillisecondTime _currentTime;
        UInt64 audioProcessSampleCount;
        SampleIndex sampleOffsetIntoNextAudioBuffer;
        signal zeroBuffer;
        signal dummyBuffer;
        SampleValue * signals[8];
        bool didAllocateSignals;
        Index vs;
        Index maxvs;
        number sr;
        number invsr;
        number biquad_tilde_05_x1;
        number biquad_tilde_05_x2;
        number biquad_tilde_05_y1;
        number biquad_tilde_05_y2;
        bool biquad_tilde_05_setupDone;
        list linetilde_05_activeRamps;
        number linetilde_05_currentValue;
        number biquad_tilde_06_x1;
        number biquad_tilde_06_x2;
        number biquad_tilde_06_y1;
        number biquad_tilde_06_y2;
        bool biquad_tilde_06_setupDone;
        number gen_02_x1_l_value;
        number gen_02_y1_l_value;
        number gen_02_x1_r_value;
        number gen_02_y1_r_value;
        number filtercoeff_03_resamp_counter;
        number filtercoeff_03_activeResamp;
        number filtercoeff_03_K_EPSILON;
        number filtercoeff_03_la0;
        number filtercoeff_03_la1;
        number filtercoeff_03_la2;
        number filtercoeff_03_lb1;
        number filtercoeff_03_lb2;
        number filtercoeff_03_last_frequency;
        number filtercoeff_03_last_q;
        number filtercoeff_03_last_gain;
        Int filtercoeff_03_last_type;
        bool filtercoeff_03_force_update;
        number filtercoeff_03_localop_twopi_over_sr;
        number filtercoeff_03_localop_cs;
        number filtercoeff_03_localop_sn;
        number filtercoeff_03_localop_one_over_gain;
        number filtercoeff_03_localop_one_over_q;
        number filtercoeff_03_localop_alpha;
        number filtercoeff_03_localop_beta;
        number filtercoeff_03_localop_b0;
        number filtercoeff_03_localop_b0g;
        number filtercoeff_03_localop_A;
        number filtercoeff_03_localop_one_over_a;
        number filtercoeff_03_localop_la0;
        number filtercoeff_03_localop_la1;
        number filtercoeff_03_localop_la2;
        number filtercoeff_03_localop_lb1;
        number filtercoeff_03_localop_lb2;
        bool filtercoeff_03_setupDone;
        Int numberobj_13_currentFormat;
        number numberobj_13_lastValue;
        Int numberobj_14_currentFormat;
        number numberobj_14_lastValue;
        list linetilde_06_activeRamps;
        number linetilde_06_currentValue;
        number stackprotect_count;
        Index _voiceIndex;
        Int _noteNumber;
        Index isMuted;
        ParameterIndex parameterOffset;
        RNBOSubpatcher_193* p_04;
    
};

class RNBOSubpatcher_203 : public PatcherInterfaceImpl {
    
    friend class Grafik7;
    
    public:
    
    class RNBOSubpatcher_194 : public PatcherInterfaceImpl {
            
            friend class RNBOSubpatcher_203;
            friend class Grafik7;
            
            public:
            
            RNBOSubpatcher_194()
            {
            }
            
            ~RNBOSubpatcher_194()
            {
            }
            
            virtual RNBOSubpatcher_203* getPatcher() const {
                return static_cast<RNBOSubpatcher_203 *>(_parentPatcher);
            }
            
            Grafik7* getTopLevelPatcher() {
                return this->getPatcher()->getTopLevelPatcher();
            }
            
            void cancelClockEvents()
            {
            }
            
            inline number safediv(number num, number denom) {
                return (denom == 0.0 ? 0.0 : num / denom);
            }
            
            number safepow(number base, number exponent) {
                return fixnan(rnbo_pow(base, exponent));
            }
            
            number scale(
                number x,
                number lowin,
                number hiin,
                number lowout,
                number highout,
                number pow
            ) {
                auto inscale = this->safediv(1., hiin - lowin);
                number outdiff = highout - lowout;
                number value = (x - lowin) * inscale;
            
                if (pow != 1) {
                    if (value > 0)
                        value = this->safepow(value, pow);
                    else
                        value = -this->safepow(-value, pow);
                }
            
                value = value * outdiff + lowout;
                return value;
            }
            
            Index getNumMidiInputPorts() const {
                return 0;
            }
            
            void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
            
            Index getNumMidiOutputPorts() const {
                return 0;
            }
            
            void process(
                const SampleValue * const* inputs,
                Index numInputs,
                SampleValue * const* outputs,
                Index numOutputs,
                Index n
            ) {
                RNBO_UNUSED(numOutputs);
                RNBO_UNUSED(outputs);
                RNBO_UNUSED(numInputs);
                RNBO_UNUSED(inputs);
                this->vs = n;
                this->updateTime(this->getEngine()->getCurrentTime());
                this->stackprotect_perform(n);
                this->audioProcessSampleCount += this->vs;
            }
            
            void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
                if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
                    this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
                    this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
                    this->didAllocateSignals = true;
                }
            
                const bool sampleRateChanged = sampleRate != this->sr;
                const bool maxvsChanged = maxBlockSize != this->maxvs;
                const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
            
                if (sampleRateChanged || maxvsChanged) {
                    this->vs = maxBlockSize;
                    this->maxvs = maxBlockSize;
                    this->sr = sampleRate;
                    this->invsr = 1 / sampleRate;
                }
            
                RNBO_UNUSED(forceDSPSetup);
            
                if (sampleRateChanged)
                    this->onSampleRateChanged(sampleRate);
            }
            
            void setProbingTarget(MessageTag id) {
                switch (id) {
                default:
                    {
                    this->setProbingIndex(-1);
                    break;
                    }
                }
            }
            
            void setProbingIndex(ProbingIndex ) {}
            
            Index getProbingChannels(MessageTag outletId) const {
                RNBO_UNUSED(outletId);
                return 0;
            }
            
            Index getIsMuted()  {
                return this->isMuted;
            }
            
            void setIsMuted(Index v)  {
                this->isMuted = v;
            }
            
            void onSampleRateChanged(double ) {}
            
            Index getPatcherSerial() const {
                return 0;
            }
            
            void getState(PatcherStateInterface& ) {}
            
            void setState() {}
            
            void getPreset(PatcherStateInterface& ) {}
            
            void setParameterValue(ParameterIndex , ParameterValue , MillisecondTime ) {}
            
            void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValue(index, value, time);
            }
            
            void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
                this->setParameterValue(index, this->getParameterValue(index), time);
            }
            
            void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValueNormalized(index, value, time);
            }
            
            ParameterValue getParameterValue(ParameterIndex index)  {
                switch (index) {
                default:
                    {
                    return 0;
                    }
                }
            }
            
            ParameterIndex getNumSignalInParameters() const {
                return 0;
            }
            
            ParameterIndex getNumSignalOutParameters() const {
                return 0;
            }
            
            ParameterIndex getNumParameters() const {
                return 0;
            }
            
            ConstCharPointer getParameterName(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            ConstCharPointer getParameterId(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            void getParameterInfo(ParameterIndex , ParameterInfo * ) const {}
            
            void sendParameter(ParameterIndex index, bool ignoreValue) {
                this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
            }
            
            void setParameterOffset(ParameterIndex offset) {
                this->parameterOffset = offset;
            }
            
            ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
                if (steps == 1) {
                    if (normalizedValue > 0) {
                        normalizedValue = 1.;
                    }
                } else {
                    ParameterValue oneStep = (number)1. / (steps - 1);
                    ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
                    normalizedValue = numberOfSteps * oneStep;
                }
            
                return normalizedValue;
            }
            
            ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                value = (value < 0 ? 0 : (value > 1 ? 1 : value));
            
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            void scheduleParamInit(ParameterIndex index, Index order) {
                this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
            }
            
            void processClockEvent(MillisecondTime , ClockId , bool , ParameterValue ) {}
            
            void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
            
            void processOutletEvent(
                EngineLink* sender,
                OutletIndex index,
                ParameterValue value,
                MillisecondTime time
            ) {
                this->updateTime(time);
                this->processOutletAtCurrentTime(sender, index, value);
            }
            
            void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
                this->updateTime(time);
            
                switch (tag) {
                case TAG("valin"):
                    {
                    if (TAG("6.4kHz~/scale/number_obj-34") == objectId)
                        this->numberobj_15_valin_set(payload);
            
                    if (TAG("6.4kHz~/scale/number_obj-32") == objectId)
                        this->numberobj_16_valin_set(payload);
            
                    if (TAG("6.4kHz~/scale/number_obj-38") == objectId)
                        this->numberobj_17_valin_set(payload);
            
                    if (TAG("6.4kHz~/scale/number_obj-55") == objectId)
                        this->numberobj_18_valin_set(payload);
            
                    break;
                    }
                case TAG("format"):
                    {
                    if (TAG("6.4kHz~/scale/number_obj-34") == objectId)
                        this->numberobj_15_format_set(payload);
            
                    if (TAG("6.4kHz~/scale/number_obj-32") == objectId)
                        this->numberobj_16_format_set(payload);
            
                    if (TAG("6.4kHz~/scale/number_obj-38") == objectId)
                        this->numberobj_17_format_set(payload);
            
                    if (TAG("6.4kHz~/scale/number_obj-55") == objectId)
                        this->numberobj_18_format_set(payload);
            
                    break;
                    }
                }
            }
            
            void processListMessage(MessageTag , MessageTag , MillisecondTime , const list& ) {}
            
            void processBangMessage(MessageTag , MessageTag , MillisecondTime ) {}
            
            MessageTagInfo resolveTag(MessageTag tag) const {
                switch (tag) {
                case TAG("valout"):
                    {
                    return "valout";
                    }
                case TAG("6.4kHz~/scale/number_obj-34"):
                    {
                    return "6.4kHz~/scale/number_obj-34";
                    }
                case TAG("setup"):
                    {
                    return "setup";
                    }
                case TAG("6.4kHz~/scale/number_obj-32"):
                    {
                    return "6.4kHz~/scale/number_obj-32";
                    }
                case TAG("6.4kHz~/scale/number_obj-38"):
                    {
                    return "6.4kHz~/scale/number_obj-38";
                    }
                case TAG("6.4kHz~/scale/number_obj-55"):
                    {
                    return "6.4kHz~/scale/number_obj-55";
                    }
                case TAG("valin"):
                    {
                    return "valin";
                    }
                case TAG("format"):
                    {
                    return "format";
                    }
                }
            
                return nullptr;
            }
            
            DataRef* getDataRef(DataRefIndex index)  {
                switch (index) {
                default:
                    {
                    return nullptr;
                    }
                }
            }
            
            DataRefIndex getNumDataRefs() const {
                return 0;
            }
            
            void fillDataRef(DataRefIndex , DataRef& ) {}
            
            void processDataViewUpdate(DataRefIndex , MillisecondTime ) {}
            
            void initialize() {
                this->assign_defaults();
                this->setState();
            }
            
            protected:
            
            void numberobj_15_valin_set(number v) {
                this->numberobj_15_value_set(v);
            }
            
            void numberobj_15_format_set(number v) {
                this->numberobj_15_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_16_valin_set(number v) {
                this->numberobj_16_value_set(v);
            }
            
            void numberobj_16_format_set(number v) {
                this->numberobj_16_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_17_valin_set(number v) {
                this->numberobj_17_value_set(v);
            }
            
            void numberobj_17_format_set(number v) {
                this->numberobj_17_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void eventinlet_09_out1_bang_bang() {
                this->expr_09_in1_bang();
                this->expr_08_in1_bang();
            }
            
            void eventinlet_09_out1_list_set(const list& v) {
                {
                    if (v->length > 1)
                        this->expr_09_in2_set(v[1]);
            
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_09_in1_set(converted);
                }
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_08_in1_set(converted);
                }
            }
            
            void numberobj_18_valin_set(number v) {
                this->numberobj_18_value_set(v);
            }
            
            void numberobj_18_format_set(number v) {
                this->numberobj_18_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            number msToSamps(MillisecondTime ms, number sampleRate) {
                return ms * sampleRate * 0.001;
            }
            
            MillisecondTime sampsToMs(SampleIndex samps) {
                return samps * (this->invsr * 1000);
            }
            
            Index getMaxBlockSize() const {
                return this->maxvs;
            }
            
            number getSampleRate() const {
                return this->sr;
            }
            
            bool hasFixedVectorSize() const {
                return false;
            }
            
            Index getNumInputChannels() const {
                return 0;
            }
            
            Index getNumOutputChannels() const {
                return 0;
            }
            
            void initializeObjects() {
                this->numberobj_15_init();
                this->numberobj_16_init();
                this->numberobj_17_init();
                this->numberobj_18_init();
            }
            
            void sendOutlet(OutletIndex index, ParameterValue value) {
                this->getEngine()->sendOutlet(this, index, value);
            }
            
            void startup() {}
            
            void allocateDataRefs() {}
            
            void eventoutlet_09_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_05_out3_number_set(v);
            }
            
            void numberobj_18_output_set(number v) {
                this->eventoutlet_09_in1_number_set(v);
            }
            
            void numberobj_18_value_set(number v) {
                this->numberobj_18_value_setter(v);
                v = this->numberobj_18_value;
                number localvalue = v;
            
                if (this->numberobj_18_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("6.4kHz~/scale/number_obj-55"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_18_output_set(localvalue);
            }
            
            void expr_09_out1_set(number v) {
                this->expr_09_out1 = v;
                this->numberobj_18_value_set(this->expr_09_out1);
            }
            
            void expr_09_in1_set(number in1) {
                this->expr_09_in1 = in1;
                this->expr_09_out1_set(this->expr_09_in1 < this->expr_09_in2);//#map:6.4kHz~/scale/<_obj-53:1
            }
            
            void eventoutlet_08_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_05_out2_number_set(v);
            }
            
            void numberobj_17_output_set(number v) {
                this->eventoutlet_08_in1_number_set(v);
            }
            
            void numberobj_17_value_set(number v) {
                this->numberobj_17_value_setter(v);
                v = this->numberobj_17_value;
                number localvalue = v;
            
                if (this->numberobj_17_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("6.4kHz~/scale/number_obj-38"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_17_output_set(localvalue);
            }
            
            void scale_06_out_set(const list& v) {
                this->scale_06_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_17_value_set(converted);
                }
            }
            
            void scale_06_input_set(const list& v) {
                this->scale_06_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_06_inlow,
                        this->scale_06_inhigh,
                        this->scale_06_outlow,
                        this->scale_06_outhigh,
                        this->scale_06_power
                    ));
                }
            
                this->scale_06_out_set(tmp);
            }
            
            void eventoutlet_07_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_05_out1_number_set(v);
            }
            
            void numberobj_15_output_set(number v) {
                this->eventoutlet_07_in1_number_set(v);
            }
            
            void numberobj_15_value_set(number v) {
                this->numberobj_15_value_setter(v);
                v = this->numberobj_15_value;
                number localvalue = v;
            
                if (this->numberobj_15_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("6.4kHz~/scale/number_obj-34"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_15_output_set(localvalue);
            }
            
            void scale_05_out_set(const list& v) {
                this->scale_05_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_15_value_set(converted);
                }
            }
            
            void scale_05_input_set(const list& v) {
                this->scale_05_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_05_inlow,
                        this->scale_05_inhigh,
                        this->scale_05_outlow,
                        this->scale_05_outhigh,
                        this->scale_05_power
                    ));
                }
            
                this->scale_05_out_set(tmp);
            }
            
            void numberobj_16_output_set(number v) {
                {
                    list converted = {v};
                    this->scale_06_input_set(converted);
                }
            
                {
                    list converted = {v};
                    this->scale_05_input_set(converted);
                }
            }
            
            void numberobj_16_value_set(number v) {
                this->numberobj_16_value_setter(v);
                v = this->numberobj_16_value;
                number localvalue = v;
            
                if (this->numberobj_16_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("6.4kHz~/scale/number_obj-32"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_16_output_set(localvalue);
            }
            
            void expr_08_out1_set(number v) {
                this->expr_08_out1 = v;
                this->numberobj_16_value_set(this->expr_08_out1);
            }
            
            void expr_08_in1_set(number in1) {
                this->expr_08_in1 = in1;
                this->expr_08_out1_set(rnbo_abs(this->expr_08_in1));//#map:6.4kHz~/scale/abs_obj-29:1
            }
            
            void eventinlet_09_out1_number_set(number v) {
                this->expr_09_in1_set(v);
                this->expr_08_in1_set(v);
            }
            
            void expr_09_in1_bang() {
                this->expr_09_out1_set(this->expr_09_in1 < this->expr_09_in2);//#map:6.4kHz~/scale/<_obj-53:1
            }
            
            void expr_08_in1_bang() {
                this->expr_08_out1_set(rnbo_abs(this->expr_08_in1));//#map:6.4kHz~/scale/abs_obj-29:1
            }
            
            void expr_09_in2_set(number v) {
                this->expr_09_in2 = v;
            }
            
            void stackprotect_perform(Index n) {
                RNBO_UNUSED(n);
                auto __stackprotect_count = this->stackprotect_count;
                __stackprotect_count = 0;
                this->stackprotect_count = __stackprotect_count;
            }
            
            void numberobj_15_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_15_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_15_value = localvalue;
            }
            
            void numberobj_16_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_16_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_16_value = localvalue;
            }
            
            void numberobj_17_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_17_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_17_value = localvalue;
            }
            
            void numberobj_18_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_18_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_18_value = localvalue;
            }
            
            void numberobj_15_init() {
                this->numberobj_15_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("6.4kHz~/scale/number_obj-34"), 1, this->_currentTime);
            }
            
            void numberobj_15_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_15_value;
            }
            
            void numberobj_15_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_15_value_set(preset["value"]);
            }
            
            void numberobj_16_init() {
                this->numberobj_16_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("6.4kHz~/scale/number_obj-32"), 1, this->_currentTime);
            }
            
            void numberobj_16_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_16_value;
            }
            
            void numberobj_16_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_16_value_set(preset["value"]);
            }
            
            void numberobj_17_init() {
                this->numberobj_17_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("6.4kHz~/scale/number_obj-38"), 1, this->_currentTime);
            }
            
            void numberobj_17_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_17_value;
            }
            
            void numberobj_17_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_17_value_set(preset["value"]);
            }
            
            void numberobj_18_init() {
                this->numberobj_18_currentFormat = 0;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("6.4kHz~/scale/number_obj-55"), 1, this->_currentTime);
            }
            
            void numberobj_18_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_18_value;
            }
            
            void numberobj_18_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_18_value_set(preset["value"]);
            }
            
            bool stackprotect_check() {
                this->stackprotect_count++;
            
                if (this->stackprotect_count > 128) {
                    console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
                    return true;
                }
            
                return false;
            }
            
            void updateTime(MillisecondTime time) {
                this->_currentTime = time;
                this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
            
                if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
                    this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
            
                if (this->sampleOffsetIntoNextAudioBuffer < 0)
                    this->sampleOffsetIntoNextAudioBuffer = 0;
            }
            
            void assign_defaults()
            {
                numberobj_15_value = 0;
                numberobj_15_value_setter(numberobj_15_value);
                numberobj_16_value = 0;
                numberobj_16_value_setter(numberobj_16_value);
                expr_08_in1 = 0;
                expr_08_out1 = 0;
                scale_05_inlow = 0;
                scale_05_inhigh = 12;
                scale_05_outlow = 0;
                scale_05_outhigh = 1;
                scale_05_power = 1;
                numberobj_17_value = 0;
                numberobj_17_value_setter(numberobj_17_value);
                scale_06_inlow = 0;
                scale_06_inhigh = 12;
                scale_06_outlow = 0;
                scale_06_outhigh = 1;
                scale_06_power = 0.5;
                numberobj_18_value = 0;
                numberobj_18_value_setter(numberobj_18_value);
                expr_09_in1 = 0;
                expr_09_in2 = 0;
                expr_09_out1 = 0;
                _currentTime = 0;
                audioProcessSampleCount = 0;
                sampleOffsetIntoNextAudioBuffer = 0;
                zeroBuffer = nullptr;
                dummyBuffer = nullptr;
                didAllocateSignals = 0;
                vs = 0;
                maxvs = 0;
                sr = 44100;
                invsr = 0.00002267573696;
                numberobj_15_currentFormat = 6;
                numberobj_15_lastValue = 0;
                numberobj_16_currentFormat = 6;
                numberobj_16_lastValue = 0;
                numberobj_17_currentFormat = 6;
                numberobj_17_lastValue = 0;
                numberobj_18_currentFormat = 6;
                numberobj_18_lastValue = 0;
                stackprotect_count = 0;
                _voiceIndex = 0;
                _noteNumber = 0;
                isMuted = 1;
                parameterOffset = 0;
            }
            
            // member variables
            
                number numberobj_15_value;
                number numberobj_16_value;
                number expr_08_in1;
                number expr_08_out1;
                list scale_05_input;
                number scale_05_inlow;
                number scale_05_inhigh;
                number scale_05_outlow;
                number scale_05_outhigh;
                number scale_05_power;
                list scale_05_out;
                number numberobj_17_value;
                list scale_06_input;
                number scale_06_inlow;
                number scale_06_inhigh;
                number scale_06_outlow;
                number scale_06_outhigh;
                number scale_06_power;
                list scale_06_out;
                number numberobj_18_value;
                number expr_09_in1;
                number expr_09_in2;
                number expr_09_out1;
                MillisecondTime _currentTime;
                UInt64 audioProcessSampleCount;
                SampleIndex sampleOffsetIntoNextAudioBuffer;
                signal zeroBuffer;
                signal dummyBuffer;
                bool didAllocateSignals;
                Index vs;
                Index maxvs;
                number sr;
                number invsr;
                Int numberobj_15_currentFormat;
                number numberobj_15_lastValue;
                Int numberobj_16_currentFormat;
                number numberobj_16_lastValue;
                Int numberobj_17_currentFormat;
                number numberobj_17_lastValue;
                Int numberobj_18_currentFormat;
                number numberobj_18_lastValue;
                number stackprotect_count;
                Index _voiceIndex;
                Int _noteNumber;
                Index isMuted;
                ParameterIndex parameterOffset;
            
    };
    
    RNBOSubpatcher_203()
    {
    }
    
    ~RNBOSubpatcher_203()
    {
        delete this->p_05;
    }
    
    virtual Grafik7* getPatcher() const {
        return static_cast<Grafik7 *>(_parentPatcher);
    }
    
    Grafik7* getTopLevelPatcher() {
        return this->getPatcher()->getTopLevelPatcher();
    }
    
    void cancelClockEvents()
    {
        getEngine()->flushClockEvents(this, -62043057, false);
        getEngine()->flushClockEvents(this, -1621164530, false);
    }
    
    SampleIndex currentsampletime() {
        return this->audioProcessSampleCount + this->sampleOffsetIntoNextAudioBuffer;
    }
    
    number mstosamps(MillisecondTime ms) {
        return ms * this->sr * 0.001;
    }
    
    number minimum(number x, number y) {
        return (y < x ? y : x);
    }
    
    inline number safesqrt(number num) {
        return (num > 0.0 ? rnbo_sqrt(num) : 0.0);
    }
    
    Index vectorsize() const {
        return this->vs;
    }
    
    Index getNumMidiInputPorts() const {
        return 0;
    }
    
    void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
    
    Index getNumMidiOutputPorts() const {
        return 0;
    }
    
    void process(
        const SampleValue * const* inputs,
        Index numInputs,
        SampleValue * const* outputs,
        Index numOutputs,
        Index n
    ) {
        this->vs = n;
        this->updateTime(this->getEngine()->getCurrentTime());
        SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
        SampleValue * out2 = (numOutputs >= 2 && outputs[1] ? outputs[1] : this->dummyBuffer);
        const SampleValue * in1 = (numInputs >= 1 && inputs[0] ? inputs[0] : this->zeroBuffer);
        const SampleValue * in2 = (numInputs >= 2 && inputs[1] ? inputs[1] : this->zeroBuffer);
        this->linetilde_07_perform(this->signals[0], n);
        this->linetilde_08_perform(this->signals[1], n);
    
        this->filtercoeff_04_perform(
            this->filtercoeff_04_frequency,
            this->signals[1],
            this->filtercoeff_04_q,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            n
        );
    
        this->biquad_tilde_08_perform(
            in2,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[1],
            n
        );
    
        this->biquad_tilde_07_perform(
            in1,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            n
        );
    
        this->gen_03_perform(
            this->signals[7],
            this->signals[1],
            this->gen_03_in3,
            this->gen_03_in4,
            this->gen_03_in5,
            this->signals[6],
            this->signals[5],
            n
        );
    
        this->dspexpr_13_perform(this->signals[7], this->signals[6], this->signals[0], out1, n);
        this->dspexpr_14_perform(this->signals[1], this->signals[5], this->signals[0], out2, n);
        this->p_05_perform(n);
        this->stackprotect_perform(n);
        this->audioProcessSampleCount += this->vs;
    }
    
    void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
        if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
            Index i;
    
            for (i = 0; i < 8; i++) {
                this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
            }
    
            this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
            this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
            this->didAllocateSignals = true;
        }
    
        const bool sampleRateChanged = sampleRate != this->sr;
        const bool maxvsChanged = maxBlockSize != this->maxvs;
        const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
    
        if (sampleRateChanged || maxvsChanged) {
            this->vs = maxBlockSize;
            this->maxvs = maxBlockSize;
            this->sr = sampleRate;
            this->invsr = 1 / sampleRate;
        }
    
        this->filtercoeff_04_dspsetup(forceDSPSetup);
        this->biquad_tilde_08_dspsetup(forceDSPSetup);
        this->biquad_tilde_07_dspsetup(forceDSPSetup);
        this->p_05->prepareToProcess(sampleRate, maxBlockSize, force);
    
        if (sampleRateChanged)
            this->onSampleRateChanged(sampleRate);
    }
    
    void setProbingTarget(MessageTag id) {
        switch (id) {
        default:
            {
            this->setProbingIndex(-1);
            break;
            }
        }
    }
    
    void setProbingIndex(ProbingIndex ) {}
    
    Index getProbingChannels(MessageTag outletId) const {
        RNBO_UNUSED(outletId);
        return 0;
    }
    
    Index getIsMuted()  {
        return this->isMuted;
    }
    
    void setIsMuted(Index v)  {
        this->isMuted = v;
    }
    
    void onSampleRateChanged(double ) {}
    
    Index getPatcherSerial() const {
        return 0;
    }
    
    void getState(PatcherStateInterface& ) {}
    
    void setState() {
        this->p_05 = new RNBOSubpatcher_194();
        this->p_05->setEngineAndPatcher(this->getEngine(), this);
        this->p_05->initialize();
        this->p_05->setParameterOffset(this->getParameterOffset(this->p_05));
    }
    
    void getPreset(PatcherStateInterface& preset) {
        this->p_05->getPreset(getSubState(getSubState(preset, "__sps"), "scale"));
    }
    
    void setParameterValue(ParameterIndex index, ParameterValue v, MillisecondTime time) {
        RNBO_UNUSED(v);
        this->updateTime(time);
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_05->getNumParameters())
                this->p_05->setParameterValue(index, v, time);
    
            break;
            }
        }
    }
    
    void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValue(index, value, time);
    }
    
    void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
        this->setParameterValue(index, this->getParameterValue(index), time);
    }
    
    void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValueNormalized(index, value, time);
    }
    
    ParameterValue getParameterValue(ParameterIndex index)  {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_05->getNumParameters())
                return this->p_05->getParameterValue(index);
    
            return 0;
            }
        }
    }
    
    ParameterIndex getNumSignalInParameters() const {
        return 0;
    }
    
    ParameterIndex getNumSignalOutParameters() const {
        return 0;
    }
    
    ParameterIndex getNumParameters() const {
        return 0 + this->p_05->getNumParameters();
    }
    
    ConstCharPointer getParameterName(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_05->getNumParameters())
                return this->p_05->getParameterName(index);
    
            return "bogus";
            }
        }
    }
    
    ConstCharPointer getParameterId(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_05->getNumParameters())
                return this->p_05->getParameterId(index);
    
            return "bogus";
            }
        }
    }
    
    void getParameterInfo(ParameterIndex index, ParameterInfo * info) const {
        {
            switch (index) {
            default:
                {
                index -= 0;
    
                if (index < this->p_05->getNumParameters())
                    this->p_05->getParameterInfo(index, info);
    
                break;
                }
            }
        }
    }
    
    void sendParameter(ParameterIndex index, bool ignoreValue) {
        this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
    }
    
    ParameterIndex getParameterOffset(BaseInterface* subpatcher) const {
        if (subpatcher == this->p_05)
            return 0;
    
        return 0;
    }
    
    void setParameterOffset(ParameterIndex offset) {
        this->parameterOffset = offset;
    }
    
    ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
        if (steps == 1) {
            if (normalizedValue > 0) {
                normalizedValue = 1.;
            }
        } else {
            ParameterValue oneStep = (number)1. / (steps - 1);
            ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
            normalizedValue = numberOfSteps * oneStep;
        }
    
        return normalizedValue;
    }
    
    ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_05->getNumParameters())
                return this->p_05->convertToNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        value = (value < 0 ? 0 : (value > 1 ? 1 : value));
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_05->getNumParameters())
                return this->p_05->convertFromNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_05->getNumParameters())
                return this->p_05->constrainParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    void scheduleParamInit(ParameterIndex index, Index order) {
        this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
    }
    
    void processClockEvent(MillisecondTime time, ClockId index, bool hasValue, ParameterValue value) {
        RNBO_UNUSED(value);
        RNBO_UNUSED(hasValue);
        this->updateTime(time);
    
        switch (index) {
        case -62043057:
            {
            this->linetilde_07_target_bang();
            break;
            }
        case -1621164530:
            {
            this->linetilde_08_target_bang();
            break;
            }
        }
    }
    
    void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
    
    void processOutletEvent(
        EngineLink* sender,
        OutletIndex index,
        ParameterValue value,
        MillisecondTime time
    ) {
        this->updateTime(time);
        this->processOutletAtCurrentTime(sender, index, value);
    }
    
    void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
        this->updateTime(time);
    
        switch (tag) {
        case TAG("valin"):
            {
            if (TAG("6.4kHz~/number_obj-3") == objectId)
                this->numberobj_19_valin_set(payload);
    
            if (TAG("6.4kHz~/number_obj-4") == objectId)
                this->numberobj_20_valin_set(payload);
    
            break;
            }
        case TAG("format"):
            {
            if (TAG("6.4kHz~/number_obj-3") == objectId)
                this->numberobj_19_format_set(payload);
    
            if (TAG("6.4kHz~/number_obj-4") == objectId)
                this->numberobj_20_format_set(payload);
    
            break;
            }
        }
    
        this->p_05->processNumMessage(tag, objectId, time, payload);
    }
    
    void processListMessage(
        MessageTag tag,
        MessageTag objectId,
        MillisecondTime time,
        const list& payload
    ) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_05->processListMessage(tag, objectId, time, payload);
    }
    
    void processBangMessage(MessageTag tag, MessageTag objectId, MillisecondTime time) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_05->processBangMessage(tag, objectId, time);
    }
    
    MessageTagInfo resolveTag(MessageTag tag) const {
        switch (tag) {
        case TAG("valout"):
            {
            return "valout";
            }
        case TAG("6.4kHz~/number_obj-3"):
            {
            return "6.4kHz~/number_obj-3";
            }
        case TAG("setup"):
            {
            return "setup";
            }
        case TAG("6.4kHz~/number_obj-4"):
            {
            return "6.4kHz~/number_obj-4";
            }
        case TAG("valin"):
            {
            return "valin";
            }
        case TAG("format"):
            {
            return "format";
            }
        }
    
        auto subpatchResult_0 = this->p_05->resolveTag(tag);
    
        if (subpatchResult_0)
            return subpatchResult_0;
    
        return nullptr;
    }
    
    DataRef* getDataRef(DataRefIndex index)  {
        switch (index) {
        default:
            {
            return nullptr;
            }
        }
    }
    
    DataRefIndex getNumDataRefs() const {
        return 0;
    }
    
    void fillDataRef(DataRefIndex , DataRef& ) {}
    
    void processDataViewUpdate(DataRefIndex index, MillisecondTime time) {
        this->p_05->processDataViewUpdate(index, time);
    }
    
    void initialize() {
        this->assign_defaults();
        this->setState();
    }
    
    protected:
    
    void eventinlet_10_out1_bang_bang() {
        this->linetilde_07_segments_bang();
    }
    
    void eventinlet_10_out1_list_set(const list& v) {
        this->linetilde_07_segments_set(v);
    }
    
    void eventinlet_11_out1_bang_bang() {
        this->numberobj_20_value_bang();
    }
    
    void eventinlet_11_out1_list_set(const list& v) {
        {
            number converted = (v->length > 0 ? v[0] : 0);
            this->numberobj_20_value_set(converted);
        }
    }
    
    void numberobj_19_valin_set(number v) {
        this->numberobj_19_value_set(v);
    }
    
    void numberobj_19_format_set(number v) {
        this->numberobj_19_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void numberobj_20_valin_set(number v) {
        this->numberobj_20_value_set(v);
    }
    
    void numberobj_20_format_set(number v) {
        this->numberobj_20_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void linetilde_07_target_bang() {}
    
    void linetilde_08_target_bang() {}
    
    number msToSamps(MillisecondTime ms, number sampleRate) {
        return ms * sampleRate * 0.001;
    }
    
    MillisecondTime sampsToMs(SampleIndex samps) {
        return samps * (this->invsr * 1000);
    }
    
    Index getMaxBlockSize() const {
        return this->maxvs;
    }
    
    number getSampleRate() const {
        return this->sr;
    }
    
    bool hasFixedVectorSize() const {
        return false;
    }
    
    Index getNumInputChannels() const {
        return 2;
    }
    
    Index getNumOutputChannels() const {
        return 2;
    }
    
    void initializeObjects() {
        this->gen_03_x1_l_init();
        this->gen_03_y1_l_init();
        this->gen_03_x1_r_init();
        this->gen_03_y1_r_init();
        this->numberobj_19_init();
        this->numberobj_20_init();
        this->p_05->initializeObjects();
    }
    
    void sendOutlet(OutletIndex index, ParameterValue value) {
        this->getEngine()->sendOutlet(this, index, value);
    }
    
    void startup() {
        this->updateTime(this->getEngine()->getCurrentTime());
        this->p_05->startup();
    }
    
    void allocateDataRefs() {
        this->p_05->allocateDataRefs();
    }
    
    void gen_03_in5_set(number v) {
        this->gen_03_in5 = v;
    }
    
    void p_05_out3_number_set(number v) {
        this->gen_03_in5_set(v);
    }
    
    void gen_03_in4_set(number v) {
        this->gen_03_in4 = v;
    }
    
    void p_05_out2_number_set(number v) {
        this->gen_03_in4_set(v);
    }
    
    void gen_03_in3_set(number v) {
        this->gen_03_in3 = v;
    }
    
    void p_05_out1_number_set(number v) {
        this->gen_03_in3_set(v);
    }
    
    void p_05_in1_number_set(number v) {
        this->p_05->updateTime(this->_currentTime);
        this->p_05->eventinlet_09_out1_number_set(v);
    }
    
    void linetilde_08_time_set(number v) {
        this->linetilde_08_time = v;
    }
    
    void linetilde_08_segments_set(const list& v) {
        this->linetilde_08_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_08_time == 0) {
                this->linetilde_08_activeRamps->length = 0;
                this->linetilde_08_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_08_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_08_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_08_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_08_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_08_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_08_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_08_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_08_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_08_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_08_activeRamps->push(lastRampValue);
                    this->linetilde_08_activeRamps->push(0);
                    this->linetilde_08_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_08_keepramp)) {
                            this->linetilde_08_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_08_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_08_activeRamps->push(destinationValue);
                    this->linetilde_08_activeRamps->push(inc);
                    this->linetilde_08_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_19_output_set(number v) {
        {
            list converted = {v};
            this->linetilde_08_segments_set(converted);
        }
    }
    
    void numberobj_19_value_set(number v) {
        this->numberobj_19_value_setter(v);
        v = this->numberobj_19_value;
        number localvalue = v;
    
        if (this->numberobj_19_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("6.4kHz~/number_obj-3"), localvalue, this->_currentTime);
        this->numberobj_19_output_set(localvalue);
    }
    
    void expr_10_out1_set(number v) {
        this->expr_10_out1 = v;
        this->numberobj_19_value_set(this->expr_10_out1);
    }
    
    void expr_10_in1_set(number in1) {
        this->expr_10_in1 = in1;
        this->expr_10_out1_set(rnbo_pow(10, this->expr_10_in1 * 0.05));//#map:6.4kHz~/dbtoa_obj-9:1
    }
    
    void numberobj_20_output_set(number v) {
        this->p_05_in1_number_set(v);
        this->expr_10_in1_set(v);
    }
    
    void numberobj_20_value_set(number v) {
        this->numberobj_20_value_setter(v);
        v = this->numberobj_20_value;
        number localvalue = v;
    
        if (this->numberobj_20_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("6.4kHz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_20_output_set(localvalue);
    }
    
    void eventinlet_11_out1_number_set(number v) {
        this->numberobj_20_value_set(v);
    }
    
    void linetilde_07_time_set(number v) {
        this->linetilde_07_time = v;
    }
    
    void linetilde_07_segments_set(const list& v) {
        this->linetilde_07_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_07_time == 0) {
                this->linetilde_07_activeRamps->length = 0;
                this->linetilde_07_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_07_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_07_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_07_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_07_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_07_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_07_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_07_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_07_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_07_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_07_activeRamps->push(lastRampValue);
                    this->linetilde_07_activeRamps->push(0);
                    this->linetilde_07_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_07_keepramp)) {
                            this->linetilde_07_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_07_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_07_activeRamps->push(destinationValue);
                    this->linetilde_07_activeRamps->push(inc);
                    this->linetilde_07_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void eventinlet_10_out1_number_set(number v) {
        {
            list converted = {v};
            this->linetilde_07_segments_set(converted);
        }
    }
    
    void linetilde_07_segments_bang() {
        list v = this->linetilde_07_segments;
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_07_time == 0) {
                this->linetilde_07_activeRamps->length = 0;
                this->linetilde_07_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_07_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_07_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_07_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_07_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_07_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_07_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_07_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_07_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_07_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_07_activeRamps->push(lastRampValue);
                    this->linetilde_07_activeRamps->push(0);
                    this->linetilde_07_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_07_keepramp)) {
                            this->linetilde_07_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_07_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_07_activeRamps->push(destinationValue);
                    this->linetilde_07_activeRamps->push(inc);
                    this->linetilde_07_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_20_value_bang() {
        number v = this->numberobj_20_value;
        number localvalue = v;
    
        if (this->numberobj_20_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("6.4kHz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_20_output_set(localvalue);
    }
    
    void linetilde_07_perform(SampleValue * out, Index n) {
        auto __linetilde_07_time = this->linetilde_07_time;
        auto __linetilde_07_keepramp = this->linetilde_07_keepramp;
        auto __linetilde_07_currentValue = this->linetilde_07_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_07_activeRamps->length)) {
            while ((bool)(this->linetilde_07_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_07_activeRamps[0];
                number inc = this->linetilde_07_activeRamps[1];
                number rampTimeInSamples = this->linetilde_07_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_07_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_07_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_07_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -62043057,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_07_keepramp))) {
                            __linetilde_07_time = 0;
                        }
                    }
                }
    
                __linetilde_07_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_07_currentValue;
            i++;
        }
    
        this->linetilde_07_currentValue = __linetilde_07_currentValue;
        this->linetilde_07_time = __linetilde_07_time;
    }
    
    void linetilde_08_perform(SampleValue * out, Index n) {
        auto __linetilde_08_time = this->linetilde_08_time;
        auto __linetilde_08_keepramp = this->linetilde_08_keepramp;
        auto __linetilde_08_currentValue = this->linetilde_08_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_08_activeRamps->length)) {
            while ((bool)(this->linetilde_08_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_08_activeRamps[0];
                number inc = this->linetilde_08_activeRamps[1];
                number rampTimeInSamples = this->linetilde_08_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_08_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_08_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_08_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -1621164530,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_08_keepramp))) {
                            __linetilde_08_time = 0;
                        }
                    }
                }
    
                __linetilde_08_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_08_currentValue;
            i++;
        }
    
        this->linetilde_08_currentValue = __linetilde_08_currentValue;
        this->linetilde_08_time = __linetilde_08_time;
    }
    
    void filtercoeff_04_perform(
        number frequency,
        const Sample * gain,
        number q,
        SampleValue * a0,
        SampleValue * a1,
        SampleValue * a2,
        SampleValue * b1,
        SampleValue * b2,
        Index n
    ) {
        RNBO_UNUSED(q);
        RNBO_UNUSED(frequency);
        auto __filtercoeff_04_activeResamp = this->filtercoeff_04_activeResamp;
        auto __filtercoeff_04_resamp_counter = this->filtercoeff_04_resamp_counter;
        auto __filtercoeff_04_K_EPSILON = this->filtercoeff_04_K_EPSILON;
    
        for (Index i = 0; i < n; i++) {
            number local_q = 1;
            number local_gain = gain[(Index)i];
    
            if (local_gain < 0)
                local_gain = 0;
    
            number local_frequency = 6400;
    
            if (local_q < __filtercoeff_04_K_EPSILON)
                local_q = __filtercoeff_04_K_EPSILON;
    
            local_frequency = (local_frequency > this->sr * 0.5 ? this->sr * 0.5 : (local_frequency < 1 ? 1 : local_frequency));
            __filtercoeff_04_resamp_counter--;
    
            if (__filtercoeff_04_resamp_counter <= 0) {
                __filtercoeff_04_resamp_counter = __filtercoeff_04_activeResamp;
                this->filtercoeff_04_updateTerms(local_frequency, local_gain, local_q);
            }
    
            a0[(Index)i] = this->filtercoeff_04_la0;
            a1[(Index)i] = this->filtercoeff_04_la1;
            a2[(Index)i] = this->filtercoeff_04_la2;
            b1[(Index)i] = this->filtercoeff_04_lb1;
            b2[(Index)i] = this->filtercoeff_04_lb2;
        }
    
        this->filtercoeff_04_resamp_counter = __filtercoeff_04_resamp_counter;
    }
    
    void biquad_tilde_08_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_08_y2 = this->biquad_tilde_08_y2;
        auto __biquad_tilde_08_y1 = this->biquad_tilde_08_y1;
        auto __biquad_tilde_08_x2 = this->biquad_tilde_08_x2;
        auto __biquad_tilde_08_x1 = this->biquad_tilde_08_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_08_x1 * a1[(Index)i] + __biquad_tilde_08_x2 * a2[(Index)i] - (__biquad_tilde_08_y1 * b1[(Index)i] + __biquad_tilde_08_y2 * b2[(Index)i]);
            __biquad_tilde_08_x2 = __biquad_tilde_08_x1;
            __biquad_tilde_08_x1 = x[(Index)i];
            __biquad_tilde_08_y2 = __biquad_tilde_08_y1;
            __biquad_tilde_08_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_08_x1 = __biquad_tilde_08_x1;
        this->biquad_tilde_08_x2 = __biquad_tilde_08_x2;
        this->biquad_tilde_08_y1 = __biquad_tilde_08_y1;
        this->biquad_tilde_08_y2 = __biquad_tilde_08_y2;
    }
    
    void biquad_tilde_07_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_07_y2 = this->biquad_tilde_07_y2;
        auto __biquad_tilde_07_y1 = this->biquad_tilde_07_y1;
        auto __biquad_tilde_07_x2 = this->biquad_tilde_07_x2;
        auto __biquad_tilde_07_x1 = this->biquad_tilde_07_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_07_x1 * a1[(Index)i] + __biquad_tilde_07_x2 * a2[(Index)i] - (__biquad_tilde_07_y1 * b1[(Index)i] + __biquad_tilde_07_y2 * b2[(Index)i]);
            __biquad_tilde_07_x2 = __biquad_tilde_07_x1;
            __biquad_tilde_07_x1 = x[(Index)i];
            __biquad_tilde_07_y2 = __biquad_tilde_07_y1;
            __biquad_tilde_07_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_07_x1 = __biquad_tilde_07_x1;
        this->biquad_tilde_07_x2 = __biquad_tilde_07_x2;
        this->biquad_tilde_07_y1 = __biquad_tilde_07_y1;
        this->biquad_tilde_07_y2 = __biquad_tilde_07_y2;
    }
    
    void gen_03_perform(
        const Sample * in1,
        const Sample * in2,
        number in3,
        number in4,
        number in5,
        SampleValue * out1,
        SampleValue * out2,
        Index n
    ) {
        auto __gen_03_y1_r_value = this->gen_03_y1_r_value;
        auto __gen_03_x1_r_value = this->gen_03_x1_r_value;
        auto __gen_03_y1_l_value = this->gen_03_y1_l_value;
        auto __gen_03_x1_l_value = this->gen_03_x1_l_value;
        number raw_drive_2 = in3;
        number asym_in_3 = in4;
        number is_cut_4 = in5;
        auto drive_5 = this->minimum(raw_drive_2, 0.55);
        number morph_factor_6 = 0.1 + is_cut_4 * (0.4 - 0.1);
        number amount_7 = drive_5 * morph_factor_6;
        number bias_factor_8 = 0.02 + is_cut_4 * (0.05 - 0.02);
        number bias_9 = asym_in_3 * bias_factor_8 * drive_5;
        Index i;
    
        for (i = 0; i < n; i++) {
            number xin_l_0 = in1[(Index)i];
            number xin_r_1 = in2[(Index)i];
            number raw_l_10 = xin_l_0 + bias_9;
            number dirty_l_11 = rnbo_tanh(raw_l_10 * 0.6) * 1.6;
            number cubic_l_12 = dirty_l_11 * dirty_l_11 * dirty_l_11 / (number)3;
            number y_l_13 = xin_l_0 - amount_7 * cubic_l_12;
            number dc_l_14 = y_l_13 - __gen_03_x1_l_value + 0.9995 * __gen_03_y1_l_value;
            __gen_03_x1_l_value = y_l_13;
            __gen_03_y1_l_value = dc_l_14;
            number raw_r_15 = xin_r_1 + bias_9;
            number dirty_r_16 = rnbo_tanh(raw_r_15 * 0.6) * 1.6;
            number cubic_r_17 = dirty_r_16 * dirty_r_16 * dirty_r_16 / (number)3;
            number y_r_18 = xin_r_1 - amount_7 * cubic_r_17;
            number dc_r_19 = y_r_18 - __gen_03_x1_r_value + 0.9995 * __gen_03_y1_r_value;
            __gen_03_x1_r_value = y_r_18;
            __gen_03_y1_r_value = dc_r_19;
            number expr_1_20 = dc_l_14;
            number expr_2_21 = dc_r_19;
            out1[(Index)i] = expr_1_20;
            out2[(Index)i] = expr_2_21;
        }
    
        this->gen_03_x1_l_value = __gen_03_x1_l_value;
        this->gen_03_y1_l_value = __gen_03_y1_l_value;
        this->gen_03_x1_r_value = __gen_03_x1_r_value;
        this->gen_03_y1_r_value = __gen_03_y1_r_value;
    }
    
    void dspexpr_13_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void dspexpr_14_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void p_05_perform(Index n) {
        // subpatcher: scale
        this->p_05->process(nullptr, 0, nullptr, 0, n);
    }
    
    void stackprotect_perform(Index n) {
        RNBO_UNUSED(n);
        auto __stackprotect_count = this->stackprotect_count;
        __stackprotect_count = 0;
        this->stackprotect_count = __stackprotect_count;
    }
    
    void numberobj_19_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_19_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_19_value = localvalue;
    }
    
    void numberobj_20_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_20_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_20_value = localvalue;
    }
    
    void biquad_tilde_07_reset() {
        this->biquad_tilde_07_x1 = 0;
        this->biquad_tilde_07_x2 = 0;
        this->biquad_tilde_07_y1 = 0;
        this->biquad_tilde_07_y2 = 0;
    }
    
    void biquad_tilde_07_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_07_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_07_reset();
        this->biquad_tilde_07_setupDone = true;
    }
    
    void biquad_tilde_08_reset() {
        this->biquad_tilde_08_x1 = 0;
        this->biquad_tilde_08_x2 = 0;
        this->biquad_tilde_08_y1 = 0;
        this->biquad_tilde_08_y2 = 0;
    }
    
    void biquad_tilde_08_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_08_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_08_reset();
        this->biquad_tilde_08_setupDone = true;
    }
    
    number gen_03_x1_l_getvalue() {
        return this->gen_03_x1_l_value;
    }
    
    void gen_03_x1_l_setvalue(number val) {
        this->gen_03_x1_l_value = val;
    }
    
    void gen_03_x1_l_reset() {
        this->gen_03_x1_l_value = 0;
    }
    
    void gen_03_x1_l_init() {
        this->gen_03_x1_l_value = 0;
    }
    
    number gen_03_y1_l_getvalue() {
        return this->gen_03_y1_l_value;
    }
    
    void gen_03_y1_l_setvalue(number val) {
        this->gen_03_y1_l_value = val;
    }
    
    void gen_03_y1_l_reset() {
        this->gen_03_y1_l_value = 0;
    }
    
    void gen_03_y1_l_init() {
        this->gen_03_y1_l_value = 0;
    }
    
    number gen_03_x1_r_getvalue() {
        return this->gen_03_x1_r_value;
    }
    
    void gen_03_x1_r_setvalue(number val) {
        this->gen_03_x1_r_value = val;
    }
    
    void gen_03_x1_r_reset() {
        this->gen_03_x1_r_value = 0;
    }
    
    void gen_03_x1_r_init() {
        this->gen_03_x1_r_value = 0;
    }
    
    number gen_03_y1_r_getvalue() {
        return this->gen_03_y1_r_value;
    }
    
    void gen_03_y1_r_setvalue(number val) {
        this->gen_03_y1_r_value = val;
    }
    
    void gen_03_y1_r_reset() {
        this->gen_03_y1_r_value = 0;
    }
    
    void gen_03_y1_r_init() {
        this->gen_03_y1_r_value = 0;
    }
    
    array<number, 5> filtercoeff_04_localop_next(number frequency, number q, number gain, number type) {
        number omega = frequency * this->filtercoeff_04_localop_twopi_over_sr;
        this->filtercoeff_04_localop_cs = rnbo_cos(omega);
        this->filtercoeff_04_localop_sn = rnbo_sin(omega);
        this->filtercoeff_04_localop_one_over_gain = (gain >= 0 ? (number)1 / gain : 0.0);
        this->filtercoeff_04_localop_one_over_q = (number)1 / q;
        this->filtercoeff_04_localop_alpha = this->filtercoeff_04_localop_sn * 0.5 * this->filtercoeff_04_localop_one_over_q;
    
        switch ((int)type) {
        case 5:
            {
            this->filtercoeff_04_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_04_localop_beta = this->safesqrt(
                (this->filtercoeff_04_localop_A * this->filtercoeff_04_localop_A + 1.) * this->filtercoeff_04_localop_one_over_q - (this->filtercoeff_04_localop_A - 1.) * (this->filtercoeff_04_localop_A - 1.)
            );
    
            this->filtercoeff_04_localop_b0 = (number)1 / (this->filtercoeff_04_localop_A + 1. + (this->filtercoeff_04_localop_A - 1.) * this->filtercoeff_04_localop_cs + this->filtercoeff_04_localop_beta * this->filtercoeff_04_localop_sn);
            break;
            }
        case 6:
            {
            this->filtercoeff_04_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_04_localop_beta = this->safesqrt(
                (this->filtercoeff_04_localop_A * this->filtercoeff_04_localop_A + 1.) * this->filtercoeff_04_localop_one_over_q - (this->filtercoeff_04_localop_A - 1.) * (this->filtercoeff_04_localop_A - 1.)
            );
    
            this->filtercoeff_04_localop_b0 = (number)1 / (this->filtercoeff_04_localop_A + 1. - (this->filtercoeff_04_localop_A - 1.) * this->filtercoeff_04_localop_cs + this->filtercoeff_04_localop_beta * this->filtercoeff_04_localop_sn);
            break;
            }
        case 4:
            {
            this->filtercoeff_04_localop_A = this->safesqrt(gain);
            this->filtercoeff_04_localop_one_over_a = (this->filtercoeff_04_localop_A == 0 ? 0 : (number)1 / this->filtercoeff_04_localop_A);
            this->filtercoeff_04_localop_b0 = (number)1 / (1. + this->filtercoeff_04_localop_alpha * this->filtercoeff_04_localop_one_over_a);
            break;
            }
        case 9:
        case 10:
        case 11:
        case 13:
        case 14:
            {
            this->filtercoeff_04_localop_b0 = (number)1 / (1. + this->filtercoeff_04_localop_alpha);
            this->filtercoeff_04_localop_b0g = (number)1 / (this->filtercoeff_04_localop_one_over_gain + this->filtercoeff_04_localop_alpha * this->filtercoeff_04_localop_one_over_gain);
            break;
            }
        default:
            {
            this->filtercoeff_04_localop_b0 = (number)1 / (1. + this->filtercoeff_04_localop_alpha);
            break;
            }
        }
    
        switch ((int)type) {
        case 0:
            {
            this->filtercoeff_04_localop_la0 = this->filtercoeff_04_localop_la2 = (1. - this->filtercoeff_04_localop_cs) * 0.5 * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la1 = (1. - this->filtercoeff_04_localop_cs) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0;
            break;
            }
        case 1:
            {
            this->filtercoeff_04_localop_la0 = this->filtercoeff_04_localop_la2 = (1. + this->filtercoeff_04_localop_cs) * 0.5 * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la1 = -(1. + this->filtercoeff_04_localop_cs) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0;
            break;
            }
        case 2:
            {
            this->filtercoeff_04_localop_la0 = this->filtercoeff_04_localop_alpha * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la1 = 0.;
            this->filtercoeff_04_localop_la2 = -this->filtercoeff_04_localop_alpha * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0;
            break;
            }
        case 7:
            {
            this->filtercoeff_04_localop_la0 = this->filtercoeff_04_localop_alpha * q * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la1 = 0.;
            this->filtercoeff_04_localop_la2 = -this->filtercoeff_04_localop_alpha * q * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0;
            break;
            }
        case 3:
            {
            this->filtercoeff_04_localop_la1 = this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la0 = this->filtercoeff_04_localop_la2 = this->filtercoeff_04_localop_b0;
            break;
            }
        case 8:
            {
            this->filtercoeff_04_localop_la1 = this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = this->filtercoeff_04_localop_la0 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la2 = 1.0;
            break;
            }
        case 4:
            {
            this->filtercoeff_04_localop_la0 = (1. + this->filtercoeff_04_localop_alpha * this->filtercoeff_04_localop_A) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la1 = this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la2 = (1. - this->filtercoeff_04_localop_alpha * this->filtercoeff_04_localop_A) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (1. - this->filtercoeff_04_localop_alpha * this->filtercoeff_04_localop_one_over_a) * this->filtercoeff_04_localop_b0;
            break;
            }
        case 5:
            {
            this->filtercoeff_04_localop_la0 = this->filtercoeff_04_localop_A * (this->filtercoeff_04_localop_A + 1. - (this->filtercoeff_04_localop_A - 1.) * this->filtercoeff_04_localop_cs + this->filtercoeff_04_localop_beta * this->filtercoeff_04_localop_sn) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la1 = 2. * this->filtercoeff_04_localop_A * (this->filtercoeff_04_localop_A - 1 - (this->filtercoeff_04_localop_A + 1) * this->filtercoeff_04_localop_cs) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la2 = this->filtercoeff_04_localop_A * (this->filtercoeff_04_localop_A + 1. - (this->filtercoeff_04_localop_A - 1.) * this->filtercoeff_04_localop_cs - this->filtercoeff_04_localop_beta * this->filtercoeff_04_localop_sn) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb1 = -2. * (this->filtercoeff_04_localop_A - 1. + (this->filtercoeff_04_localop_A + 1.) * this->filtercoeff_04_localop_cs) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (this->filtercoeff_04_localop_A + 1. + (this->filtercoeff_04_localop_A - 1.) * this->filtercoeff_04_localop_cs - this->filtercoeff_04_localop_beta * this->filtercoeff_04_localop_sn) * this->filtercoeff_04_localop_b0;
            break;
            }
        case 6:
            {
            this->filtercoeff_04_localop_la0 = this->filtercoeff_04_localop_A * (this->filtercoeff_04_localop_A + 1. + (this->filtercoeff_04_localop_A - 1.) * this->filtercoeff_04_localop_cs + this->filtercoeff_04_localop_beta * this->filtercoeff_04_localop_sn) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la1 = -2. * this->filtercoeff_04_localop_A * (this->filtercoeff_04_localop_A - 1. + (this->filtercoeff_04_localop_A + 1.) * this->filtercoeff_04_localop_cs) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la2 = this->filtercoeff_04_localop_A * (this->filtercoeff_04_localop_A + 1. + (this->filtercoeff_04_localop_A - 1.) * this->filtercoeff_04_localop_cs - this->filtercoeff_04_localop_beta * this->filtercoeff_04_localop_sn) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb1 = 2. * (this->filtercoeff_04_localop_A - 1. - (this->filtercoeff_04_localop_A + 1.) * this->filtercoeff_04_localop_cs) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (this->filtercoeff_04_localop_A + 1. - (this->filtercoeff_04_localop_A - 1.) * this->filtercoeff_04_localop_cs - this->filtercoeff_04_localop_beta * this->filtercoeff_04_localop_sn) * this->filtercoeff_04_localop_b0;
            break;
            }
        case 9:
            {
            this->filtercoeff_04_localop_b0g = (number)1 / (this->filtercoeff_04_localop_one_over_gain + this->filtercoeff_04_localop_alpha * this->filtercoeff_04_localop_one_over_gain);
            this->filtercoeff_04_localop_la0 = this->filtercoeff_04_localop_la2 = (1. - this->filtercoeff_04_localop_cs) * 0.5 * this->filtercoeff_04_localop_b0g;
            this->filtercoeff_04_localop_la1 = (1. - this->filtercoeff_04_localop_cs) * this->filtercoeff_04_localop_b0g;
            this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0;
            break;
            }
        case 10:
            {
            this->filtercoeff_04_localop_b0g = (number)1 / (this->filtercoeff_04_localop_one_over_gain + this->filtercoeff_04_localop_alpha * this->filtercoeff_04_localop_one_over_gain);
            this->filtercoeff_04_localop_la0 = this->filtercoeff_04_localop_la2 = (1. + this->filtercoeff_04_localop_cs) * 0.5 * this->filtercoeff_04_localop_b0g;
            this->filtercoeff_04_localop_la1 = -(1. + this->filtercoeff_04_localop_cs) * this->filtercoeff_04_localop_b0g;
            this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0;
            break;
            }
        case 11:
            {
            this->filtercoeff_04_localop_la0 = this->filtercoeff_04_localop_alpha * gain * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la1 = 0.;
            this->filtercoeff_04_localop_la2 = -this->filtercoeff_04_localop_alpha * gain * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0;
            break;
            }
        case 13:
            {
            this->filtercoeff_04_localop_la0 = this->filtercoeff_04_localop_alpha * gain * q * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la1 = 0.;
            this->filtercoeff_04_localop_la2 = -this->filtercoeff_04_localop_alpha * gain * q * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0;
            break;
            }
        case 12:
            {
            this->filtercoeff_04_localop_b0g = (number)1 / (this->filtercoeff_04_localop_one_over_gain + this->filtercoeff_04_localop_alpha * this->filtercoeff_04_localop_one_over_gain);
            this->filtercoeff_04_localop_la1 = this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs;
            this->filtercoeff_04_localop_lb2 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la1 *= this->filtercoeff_04_localop_b0g;
            this->filtercoeff_04_localop_lb1 *= this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_la0 = this->filtercoeff_04_localop_b0g;
            this->filtercoeff_04_localop_la2 = this->filtercoeff_04_localop_b0g;
            break;
            }
        case 14:
            {
            this->filtercoeff_04_localop_b0g = (number)1 / (this->filtercoeff_04_localop_one_over_gain + this->filtercoeff_04_localop_alpha * this->filtercoeff_04_localop_one_over_gain);
            this->filtercoeff_04_localop_la0 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0g;
            this->filtercoeff_04_localop_la1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0g;
            this->filtercoeff_04_localop_la2 = gain;
            this->filtercoeff_04_localop_lb1 = -2. * this->filtercoeff_04_localop_cs * this->filtercoeff_04_localop_b0;
            this->filtercoeff_04_localop_lb2 = (1. - this->filtercoeff_04_localop_alpha) * this->filtercoeff_04_localop_b0;
            break;
            }
        case 15:
            {
            this->filtercoeff_04_localop_la0 = 1;
            this->filtercoeff_04_localop_la1 = 0;
            this->filtercoeff_04_localop_la2 = 0;
            this->filtercoeff_04_localop_lb1 = 0;
            this->filtercoeff_04_localop_lb2 = 0;
            }
        default:
            {
            break;
            }
        }
    
        return {
            this->filtercoeff_04_localop_la0,
            this->filtercoeff_04_localop_la1,
            this->filtercoeff_04_localop_la2,
            this->filtercoeff_04_localop_lb1,
            this->filtercoeff_04_localop_lb2
        };
    }
    
    void filtercoeff_04_localop_dspsetup() {
        this->filtercoeff_04_localop_twopi_over_sr = (number)6.283185307179586 / this->sr;
    }
    
    void filtercoeff_04_localop_reset() {
        this->filtercoeff_04_localop_twopi_over_sr = 0;
        this->filtercoeff_04_localop_cs = 0;
        this->filtercoeff_04_localop_sn = 0;
        this->filtercoeff_04_localop_one_over_gain = 0;
        this->filtercoeff_04_localop_one_over_q = 0;
        this->filtercoeff_04_localop_alpha = 0;
        this->filtercoeff_04_localop_beta = 0;
        this->filtercoeff_04_localop_b0 = 0;
        this->filtercoeff_04_localop_b0g = 0;
        this->filtercoeff_04_localop_A = 0;
        this->filtercoeff_04_localop_one_over_a = 0;
        this->filtercoeff_04_localop_la0 = 0;
        this->filtercoeff_04_localop_la1 = 0;
        this->filtercoeff_04_localop_la2 = 0;
        this->filtercoeff_04_localop_lb1 = 0;
        this->filtercoeff_04_localop_lb2 = 0;
    }
    
    void filtercoeff_04_updateTerms(number local_frequency, number local_gain, number local_q) {
        if ((bool)(this->filtercoeff_04_force_update) || local_frequency != this->filtercoeff_04_last_frequency || local_q != this->filtercoeff_04_last_q || local_gain != this->filtercoeff_04_last_gain || this->filtercoeff_04_type != this->filtercoeff_04_last_type) {
            array<number, 5> tmp = this->filtercoeff_04_localop_next(local_frequency, local_q, local_gain, this->filtercoeff_04_type);
            this->filtercoeff_04_la0 = tmp[0];
            this->filtercoeff_04_la1 = tmp[1];
            this->filtercoeff_04_la2 = tmp[2];
            this->filtercoeff_04_lb1 = tmp[3];
            this->filtercoeff_04_lb2 = tmp[4];
            this->filtercoeff_04_last_frequency = local_frequency;
            this->filtercoeff_04_last_q = local_q;
            this->filtercoeff_04_last_gain = local_gain;
            this->filtercoeff_04_last_type = this->filtercoeff_04_type;
            this->filtercoeff_04_force_update = false;
        }
    }
    
    void filtercoeff_04_dspsetup(bool force) {
        if ((bool)(this->filtercoeff_04_setupDone) && (bool)(!(bool)(force)))
            return;
    
        {
            this->filtercoeff_04_activeResamp = this->vectorsize();
        }
    
        this->filtercoeff_04_resamp_counter = 0;
        this->filtercoeff_04_la0 = 0.;
        this->filtercoeff_04_la1 = 0.;
        this->filtercoeff_04_la2 = 0.;
        this->filtercoeff_04_lb1 = 0.;
        this->filtercoeff_04_lb2 = 0.;
        this->filtercoeff_04_last_frequency = -1.;
        this->filtercoeff_04_last_q = -1.;
        this->filtercoeff_04_last_gain = -1.;
        this->filtercoeff_04_last_type = this->filtercoeff_04_type;
        this->filtercoeff_04_force_update = true;
        this->filtercoeff_04_setupDone = true;
        this->filtercoeff_04_localop_dspsetup();
    }
    
    void numberobj_19_init() {
        this->numberobj_19_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("6.4kHz~/number_obj-3"), 1, this->_currentTime);
    }
    
    void numberobj_19_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_19_value;
    }
    
    void numberobj_19_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_19_value_set(preset["value"]);
    }
    
    void numberobj_20_init() {
        this->numberobj_20_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("6.4kHz~/number_obj-4"), 1, this->_currentTime);
    }
    
    void numberobj_20_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_20_value;
    }
    
    void numberobj_20_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_20_value_set(preset["value"]);
    }
    
    bool stackprotect_check() {
        this->stackprotect_count++;
    
        if (this->stackprotect_count > 128) {
            console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
            return true;
        }
    
        return false;
    }
    
    void updateTime(MillisecondTime time) {
        this->_currentTime = time;
        this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
    
        if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
            this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
    
        if (this->sampleOffsetIntoNextAudioBuffer < 0)
            this->sampleOffsetIntoNextAudioBuffer = 0;
    }
    
    void assign_defaults()
    {
        dspexpr_13_in1 = 0;
        dspexpr_13_in2 = 0;
        dspexpr_13_in3 = 0;
        biquad_tilde_07_x = 0;
        biquad_tilde_07_a0 = 0;
        biquad_tilde_07_a1 = 0;
        biquad_tilde_07_a2 = 0;
        biquad_tilde_07_b1 = 0;
        biquad_tilde_07_b2 = 0;
        linetilde_07_time = 10;
        linetilde_07_keepramp = 1;
        biquad_tilde_08_x = 0;
        biquad_tilde_08_a0 = 0;
        biquad_tilde_08_a1 = 0;
        biquad_tilde_08_a2 = 0;
        biquad_tilde_08_b1 = 0;
        biquad_tilde_08_b2 = 0;
        dspexpr_14_in1 = 0;
        dspexpr_14_in2 = 0;
        dspexpr_14_in3 = 0;
        gen_03_in1 = 0;
        gen_03_in2 = 0;
        gen_03_in3 = 0;
        gen_03_in4 = 0;
        gen_03_in5 = 0;
        filtercoeff_04_frequency = 6400;
        filtercoeff_04_gain = 1;
        filtercoeff_04_q = 1;
        filtercoeff_04_type = 6;
        numberobj_19_value = 0;
        numberobj_19_value_setter(numberobj_19_value);
        numberobj_20_value = 0;
        numberobj_20_value_setter(numberobj_20_value);
        expr_10_in1 = 0;
        expr_10_out1 = 0;
        linetilde_08_time = 10;
        linetilde_08_keepramp = 1;
        p_05_target = 0;
        _currentTime = 0;
        audioProcessSampleCount = 0;
        sampleOffsetIntoNextAudioBuffer = 0;
        zeroBuffer = nullptr;
        dummyBuffer = nullptr;
        signals[0] = nullptr;
        signals[1] = nullptr;
        signals[2] = nullptr;
        signals[3] = nullptr;
        signals[4] = nullptr;
        signals[5] = nullptr;
        signals[6] = nullptr;
        signals[7] = nullptr;
        didAllocateSignals = 0;
        vs = 0;
        maxvs = 0;
        sr = 44100;
        invsr = 0.00002267573696;
        biquad_tilde_07_x1 = 0;
        biquad_tilde_07_x2 = 0;
        biquad_tilde_07_y1 = 0;
        biquad_tilde_07_y2 = 0;
        biquad_tilde_07_setupDone = false;
        linetilde_07_currentValue = 0;
        biquad_tilde_08_x1 = 0;
        biquad_tilde_08_x2 = 0;
        biquad_tilde_08_y1 = 0;
        biquad_tilde_08_y2 = 0;
        biquad_tilde_08_setupDone = false;
        gen_03_x1_l_value = 0;
        gen_03_y1_l_value = 0;
        gen_03_x1_r_value = 0;
        gen_03_y1_r_value = 0;
        filtercoeff_04_K_EPSILON = 1e-9;
        filtercoeff_04_setupDone = false;
        numberobj_19_currentFormat = 6;
        numberobj_19_lastValue = 0;
        numberobj_20_currentFormat = 6;
        numberobj_20_lastValue = 0;
        linetilde_08_currentValue = 1;
        stackprotect_count = 0;
        _voiceIndex = 0;
        _noteNumber = 0;
        isMuted = 1;
        parameterOffset = 0;
    }
    
    // member variables
    
        number dspexpr_13_in1;
        number dspexpr_13_in2;
        number dspexpr_13_in3;
        number biquad_tilde_07_x;
        number biquad_tilde_07_a0;
        number biquad_tilde_07_a1;
        number biquad_tilde_07_a2;
        number biquad_tilde_07_b1;
        number biquad_tilde_07_b2;
        list linetilde_07_segments;
        number linetilde_07_time;
        number linetilde_07_keepramp;
        number biquad_tilde_08_x;
        number biquad_tilde_08_a0;
        number biquad_tilde_08_a1;
        number biquad_tilde_08_a2;
        number biquad_tilde_08_b1;
        number biquad_tilde_08_b2;
        number dspexpr_14_in1;
        number dspexpr_14_in2;
        number dspexpr_14_in3;
        number gen_03_in1;
        number gen_03_in2;
        number gen_03_in3;
        number gen_03_in4;
        number gen_03_in5;
        number filtercoeff_04_frequency;
        number filtercoeff_04_gain;
        number filtercoeff_04_q;
        Int filtercoeff_04_type;
        number numberobj_19_value;
        number numberobj_20_value;
        number expr_10_in1;
        number expr_10_out1;
        list linetilde_08_segments;
        number linetilde_08_time;
        number linetilde_08_keepramp;
        number p_05_target;
        MillisecondTime _currentTime;
        UInt64 audioProcessSampleCount;
        SampleIndex sampleOffsetIntoNextAudioBuffer;
        signal zeroBuffer;
        signal dummyBuffer;
        SampleValue * signals[8];
        bool didAllocateSignals;
        Index vs;
        Index maxvs;
        number sr;
        number invsr;
        number biquad_tilde_07_x1;
        number biquad_tilde_07_x2;
        number biquad_tilde_07_y1;
        number biquad_tilde_07_y2;
        bool biquad_tilde_07_setupDone;
        list linetilde_07_activeRamps;
        number linetilde_07_currentValue;
        number biquad_tilde_08_x1;
        number biquad_tilde_08_x2;
        number biquad_tilde_08_y1;
        number biquad_tilde_08_y2;
        bool biquad_tilde_08_setupDone;
        number gen_03_x1_l_value;
        number gen_03_y1_l_value;
        number gen_03_x1_r_value;
        number gen_03_y1_r_value;
        number filtercoeff_04_resamp_counter;
        number filtercoeff_04_activeResamp;
        number filtercoeff_04_K_EPSILON;
        number filtercoeff_04_la0;
        number filtercoeff_04_la1;
        number filtercoeff_04_la2;
        number filtercoeff_04_lb1;
        number filtercoeff_04_lb2;
        number filtercoeff_04_last_frequency;
        number filtercoeff_04_last_q;
        number filtercoeff_04_last_gain;
        Int filtercoeff_04_last_type;
        bool filtercoeff_04_force_update;
        number filtercoeff_04_localop_twopi_over_sr;
        number filtercoeff_04_localop_cs;
        number filtercoeff_04_localop_sn;
        number filtercoeff_04_localop_one_over_gain;
        number filtercoeff_04_localop_one_over_q;
        number filtercoeff_04_localop_alpha;
        number filtercoeff_04_localop_beta;
        number filtercoeff_04_localop_b0;
        number filtercoeff_04_localop_b0g;
        number filtercoeff_04_localop_A;
        number filtercoeff_04_localop_one_over_a;
        number filtercoeff_04_localop_la0;
        number filtercoeff_04_localop_la1;
        number filtercoeff_04_localop_la2;
        number filtercoeff_04_localop_lb1;
        number filtercoeff_04_localop_lb2;
        bool filtercoeff_04_setupDone;
        Int numberobj_19_currentFormat;
        number numberobj_19_lastValue;
        Int numberobj_20_currentFormat;
        number numberobj_20_lastValue;
        list linetilde_08_activeRamps;
        number linetilde_08_currentValue;
        number stackprotect_count;
        Index _voiceIndex;
        Int _noteNumber;
        Index isMuted;
        ParameterIndex parameterOffset;
        RNBOSubpatcher_194* p_05;
    
};

class RNBOSubpatcher_204 : public PatcherInterfaceImpl {
    
    friend class Grafik7;
    
    public:
    
    class RNBOSubpatcher_195 : public PatcherInterfaceImpl {
            
            friend class RNBOSubpatcher_204;
            friend class Grafik7;
            
            public:
            
            RNBOSubpatcher_195()
            {
            }
            
            ~RNBOSubpatcher_195()
            {
            }
            
            virtual RNBOSubpatcher_204* getPatcher() const {
                return static_cast<RNBOSubpatcher_204 *>(_parentPatcher);
            }
            
            Grafik7* getTopLevelPatcher() {
                return this->getPatcher()->getTopLevelPatcher();
            }
            
            void cancelClockEvents()
            {
            }
            
            inline number safediv(number num, number denom) {
                return (denom == 0.0 ? 0.0 : num / denom);
            }
            
            number safepow(number base, number exponent) {
                return fixnan(rnbo_pow(base, exponent));
            }
            
            number scale(
                number x,
                number lowin,
                number hiin,
                number lowout,
                number highout,
                number pow
            ) {
                auto inscale = this->safediv(1., hiin - lowin);
                number outdiff = highout - lowout;
                number value = (x - lowin) * inscale;
            
                if (pow != 1) {
                    if (value > 0)
                        value = this->safepow(value, pow);
                    else
                        value = -this->safepow(-value, pow);
                }
            
                value = value * outdiff + lowout;
                return value;
            }
            
            Index getNumMidiInputPorts() const {
                return 0;
            }
            
            void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
            
            Index getNumMidiOutputPorts() const {
                return 0;
            }
            
            void process(
                const SampleValue * const* inputs,
                Index numInputs,
                SampleValue * const* outputs,
                Index numOutputs,
                Index n
            ) {
                RNBO_UNUSED(numOutputs);
                RNBO_UNUSED(outputs);
                RNBO_UNUSED(numInputs);
                RNBO_UNUSED(inputs);
                this->vs = n;
                this->updateTime(this->getEngine()->getCurrentTime());
                this->stackprotect_perform(n);
                this->audioProcessSampleCount += this->vs;
            }
            
            void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
                if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
                    this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
                    this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
                    this->didAllocateSignals = true;
                }
            
                const bool sampleRateChanged = sampleRate != this->sr;
                const bool maxvsChanged = maxBlockSize != this->maxvs;
                const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
            
                if (sampleRateChanged || maxvsChanged) {
                    this->vs = maxBlockSize;
                    this->maxvs = maxBlockSize;
                    this->sr = sampleRate;
                    this->invsr = 1 / sampleRate;
                }
            
                RNBO_UNUSED(forceDSPSetup);
            
                if (sampleRateChanged)
                    this->onSampleRateChanged(sampleRate);
            }
            
            void setProbingTarget(MessageTag id) {
                switch (id) {
                default:
                    {
                    this->setProbingIndex(-1);
                    break;
                    }
                }
            }
            
            void setProbingIndex(ProbingIndex ) {}
            
            Index getProbingChannels(MessageTag outletId) const {
                RNBO_UNUSED(outletId);
                return 0;
            }
            
            Index getIsMuted()  {
                return this->isMuted;
            }
            
            void setIsMuted(Index v)  {
                this->isMuted = v;
            }
            
            void onSampleRateChanged(double ) {}
            
            Index getPatcherSerial() const {
                return 0;
            }
            
            void getState(PatcherStateInterface& ) {}
            
            void setState() {}
            
            void getPreset(PatcherStateInterface& ) {}
            
            void setParameterValue(ParameterIndex , ParameterValue , MillisecondTime ) {}
            
            void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValue(index, value, time);
            }
            
            void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
                this->setParameterValue(index, this->getParameterValue(index), time);
            }
            
            void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValueNormalized(index, value, time);
            }
            
            ParameterValue getParameterValue(ParameterIndex index)  {
                switch (index) {
                default:
                    {
                    return 0;
                    }
                }
            }
            
            ParameterIndex getNumSignalInParameters() const {
                return 0;
            }
            
            ParameterIndex getNumSignalOutParameters() const {
                return 0;
            }
            
            ParameterIndex getNumParameters() const {
                return 0;
            }
            
            ConstCharPointer getParameterName(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            ConstCharPointer getParameterId(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            void getParameterInfo(ParameterIndex , ParameterInfo * ) const {}
            
            void sendParameter(ParameterIndex index, bool ignoreValue) {
                this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
            }
            
            void setParameterOffset(ParameterIndex offset) {
                this->parameterOffset = offset;
            }
            
            ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
                if (steps == 1) {
                    if (normalizedValue > 0) {
                        normalizedValue = 1.;
                    }
                } else {
                    ParameterValue oneStep = (number)1. / (steps - 1);
                    ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
                    normalizedValue = numberOfSteps * oneStep;
                }
            
                return normalizedValue;
            }
            
            ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                value = (value < 0 ? 0 : (value > 1 ? 1 : value));
            
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            void scheduleParamInit(ParameterIndex index, Index order) {
                this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
            }
            
            void processClockEvent(MillisecondTime , ClockId , bool , ParameterValue ) {}
            
            void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
            
            void processOutletEvent(
                EngineLink* sender,
                OutletIndex index,
                ParameterValue value,
                MillisecondTime time
            ) {
                this->updateTime(time);
                this->processOutletAtCurrentTime(sender, index, value);
            }
            
            void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
                this->updateTime(time);
            
                switch (tag) {
                case TAG("valin"):
                    {
                    if (TAG("3.2kHz~/scale/number_obj-34") == objectId)
                        this->numberobj_21_valin_set(payload);
            
                    if (TAG("3.2kHz~/scale/number_obj-32") == objectId)
                        this->numberobj_22_valin_set(payload);
            
                    if (TAG("3.2kHz~/scale/number_obj-38") == objectId)
                        this->numberobj_23_valin_set(payload);
            
                    if (TAG("3.2kHz~/scale/number_obj-55") == objectId)
                        this->numberobj_24_valin_set(payload);
            
                    break;
                    }
                case TAG("format"):
                    {
                    if (TAG("3.2kHz~/scale/number_obj-34") == objectId)
                        this->numberobj_21_format_set(payload);
            
                    if (TAG("3.2kHz~/scale/number_obj-32") == objectId)
                        this->numberobj_22_format_set(payload);
            
                    if (TAG("3.2kHz~/scale/number_obj-38") == objectId)
                        this->numberobj_23_format_set(payload);
            
                    if (TAG("3.2kHz~/scale/number_obj-55") == objectId)
                        this->numberobj_24_format_set(payload);
            
                    break;
                    }
                }
            }
            
            void processListMessage(MessageTag , MessageTag , MillisecondTime , const list& ) {}
            
            void processBangMessage(MessageTag , MessageTag , MillisecondTime ) {}
            
            MessageTagInfo resolveTag(MessageTag tag) const {
                switch (tag) {
                case TAG("valout"):
                    {
                    return "valout";
                    }
                case TAG("3.2kHz~/scale/number_obj-34"):
                    {
                    return "3.2kHz~/scale/number_obj-34";
                    }
                case TAG("setup"):
                    {
                    return "setup";
                    }
                case TAG("3.2kHz~/scale/number_obj-32"):
                    {
                    return "3.2kHz~/scale/number_obj-32";
                    }
                case TAG("3.2kHz~/scale/number_obj-38"):
                    {
                    return "3.2kHz~/scale/number_obj-38";
                    }
                case TAG("3.2kHz~/scale/number_obj-55"):
                    {
                    return "3.2kHz~/scale/number_obj-55";
                    }
                case TAG("valin"):
                    {
                    return "valin";
                    }
                case TAG("format"):
                    {
                    return "format";
                    }
                }
            
                return nullptr;
            }
            
            DataRef* getDataRef(DataRefIndex index)  {
                switch (index) {
                default:
                    {
                    return nullptr;
                    }
                }
            }
            
            DataRefIndex getNumDataRefs() const {
                return 0;
            }
            
            void fillDataRef(DataRefIndex , DataRef& ) {}
            
            void processDataViewUpdate(DataRefIndex , MillisecondTime ) {}
            
            void initialize() {
                this->assign_defaults();
                this->setState();
            }
            
            protected:
            
            void numberobj_21_valin_set(number v) {
                this->numberobj_21_value_set(v);
            }
            
            void numberobj_21_format_set(number v) {
                this->numberobj_21_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_22_valin_set(number v) {
                this->numberobj_22_value_set(v);
            }
            
            void numberobj_22_format_set(number v) {
                this->numberobj_22_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_23_valin_set(number v) {
                this->numberobj_23_value_set(v);
            }
            
            void numberobj_23_format_set(number v) {
                this->numberobj_23_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void eventinlet_12_out1_bang_bang() {
                this->expr_12_in1_bang();
                this->expr_11_in1_bang();
            }
            
            void eventinlet_12_out1_list_set(const list& v) {
                {
                    if (v->length > 1)
                        this->expr_12_in2_set(v[1]);
            
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_12_in1_set(converted);
                }
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_11_in1_set(converted);
                }
            }
            
            void numberobj_24_valin_set(number v) {
                this->numberobj_24_value_set(v);
            }
            
            void numberobj_24_format_set(number v) {
                this->numberobj_24_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            number msToSamps(MillisecondTime ms, number sampleRate) {
                return ms * sampleRate * 0.001;
            }
            
            MillisecondTime sampsToMs(SampleIndex samps) {
                return samps * (this->invsr * 1000);
            }
            
            Index getMaxBlockSize() const {
                return this->maxvs;
            }
            
            number getSampleRate() const {
                return this->sr;
            }
            
            bool hasFixedVectorSize() const {
                return false;
            }
            
            Index getNumInputChannels() const {
                return 0;
            }
            
            Index getNumOutputChannels() const {
                return 0;
            }
            
            void initializeObjects() {
                this->numberobj_21_init();
                this->numberobj_22_init();
                this->numberobj_23_init();
                this->numberobj_24_init();
            }
            
            void sendOutlet(OutletIndex index, ParameterValue value) {
                this->getEngine()->sendOutlet(this, index, value);
            }
            
            void startup() {}
            
            void allocateDataRefs() {}
            
            void eventoutlet_12_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_06_out3_number_set(v);
            }
            
            void numberobj_24_output_set(number v) {
                this->eventoutlet_12_in1_number_set(v);
            }
            
            void numberobj_24_value_set(number v) {
                this->numberobj_24_value_setter(v);
                v = this->numberobj_24_value;
                number localvalue = v;
            
                if (this->numberobj_24_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("3.2kHz~/scale/number_obj-55"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_24_output_set(localvalue);
            }
            
            void expr_12_out1_set(number v) {
                this->expr_12_out1 = v;
                this->numberobj_24_value_set(this->expr_12_out1);
            }
            
            void expr_12_in1_set(number in1) {
                this->expr_12_in1 = in1;
                this->expr_12_out1_set(this->expr_12_in1 < this->expr_12_in2);//#map:3.2kHz~/scale/<_obj-53:1
            }
            
            void eventoutlet_11_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_06_out2_number_set(v);
            }
            
            void numberobj_23_output_set(number v) {
                this->eventoutlet_11_in1_number_set(v);
            }
            
            void numberobj_23_value_set(number v) {
                this->numberobj_23_value_setter(v);
                v = this->numberobj_23_value;
                number localvalue = v;
            
                if (this->numberobj_23_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("3.2kHz~/scale/number_obj-38"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_23_output_set(localvalue);
            }
            
            void scale_08_out_set(const list& v) {
                this->scale_08_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_23_value_set(converted);
                }
            }
            
            void scale_08_input_set(const list& v) {
                this->scale_08_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_08_inlow,
                        this->scale_08_inhigh,
                        this->scale_08_outlow,
                        this->scale_08_outhigh,
                        this->scale_08_power
                    ));
                }
            
                this->scale_08_out_set(tmp);
            }
            
            void eventoutlet_10_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_06_out1_number_set(v);
            }
            
            void numberobj_21_output_set(number v) {
                this->eventoutlet_10_in1_number_set(v);
            }
            
            void numberobj_21_value_set(number v) {
                this->numberobj_21_value_setter(v);
                v = this->numberobj_21_value;
                number localvalue = v;
            
                if (this->numberobj_21_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("3.2kHz~/scale/number_obj-34"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_21_output_set(localvalue);
            }
            
            void scale_07_out_set(const list& v) {
                this->scale_07_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_21_value_set(converted);
                }
            }
            
            void scale_07_input_set(const list& v) {
                this->scale_07_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_07_inlow,
                        this->scale_07_inhigh,
                        this->scale_07_outlow,
                        this->scale_07_outhigh,
                        this->scale_07_power
                    ));
                }
            
                this->scale_07_out_set(tmp);
            }
            
            void numberobj_22_output_set(number v) {
                {
                    list converted = {v};
                    this->scale_08_input_set(converted);
                }
            
                {
                    list converted = {v};
                    this->scale_07_input_set(converted);
                }
            }
            
            void numberobj_22_value_set(number v) {
                this->numberobj_22_value_setter(v);
                v = this->numberobj_22_value;
                number localvalue = v;
            
                if (this->numberobj_22_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("3.2kHz~/scale/number_obj-32"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_22_output_set(localvalue);
            }
            
            void expr_11_out1_set(number v) {
                this->expr_11_out1 = v;
                this->numberobj_22_value_set(this->expr_11_out1);
            }
            
            void expr_11_in1_set(number in1) {
                this->expr_11_in1 = in1;
                this->expr_11_out1_set(rnbo_abs(this->expr_11_in1));//#map:3.2kHz~/scale/abs_obj-29:1
            }
            
            void eventinlet_12_out1_number_set(number v) {
                this->expr_12_in1_set(v);
                this->expr_11_in1_set(v);
            }
            
            void expr_12_in1_bang() {
                this->expr_12_out1_set(this->expr_12_in1 < this->expr_12_in2);//#map:3.2kHz~/scale/<_obj-53:1
            }
            
            void expr_11_in1_bang() {
                this->expr_11_out1_set(rnbo_abs(this->expr_11_in1));//#map:3.2kHz~/scale/abs_obj-29:1
            }
            
            void expr_12_in2_set(number v) {
                this->expr_12_in2 = v;
            }
            
            void stackprotect_perform(Index n) {
                RNBO_UNUSED(n);
                auto __stackprotect_count = this->stackprotect_count;
                __stackprotect_count = 0;
                this->stackprotect_count = __stackprotect_count;
            }
            
            void numberobj_21_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_21_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_21_value = localvalue;
            }
            
            void numberobj_22_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_22_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_22_value = localvalue;
            }
            
            void numberobj_23_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_23_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_23_value = localvalue;
            }
            
            void numberobj_24_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_24_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_24_value = localvalue;
            }
            
            void numberobj_21_init() {
                this->numberobj_21_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("3.2kHz~/scale/number_obj-34"), 1, this->_currentTime);
            }
            
            void numberobj_21_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_21_value;
            }
            
            void numberobj_21_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_21_value_set(preset["value"]);
            }
            
            void numberobj_22_init() {
                this->numberobj_22_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("3.2kHz~/scale/number_obj-32"), 1, this->_currentTime);
            }
            
            void numberobj_22_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_22_value;
            }
            
            void numberobj_22_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_22_value_set(preset["value"]);
            }
            
            void numberobj_23_init() {
                this->numberobj_23_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("3.2kHz~/scale/number_obj-38"), 1, this->_currentTime);
            }
            
            void numberobj_23_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_23_value;
            }
            
            void numberobj_23_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_23_value_set(preset["value"]);
            }
            
            void numberobj_24_init() {
                this->numberobj_24_currentFormat = 0;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("3.2kHz~/scale/number_obj-55"), 1, this->_currentTime);
            }
            
            void numberobj_24_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_24_value;
            }
            
            void numberobj_24_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_24_value_set(preset["value"]);
            }
            
            bool stackprotect_check() {
                this->stackprotect_count++;
            
                if (this->stackprotect_count > 128) {
                    console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
                    return true;
                }
            
                return false;
            }
            
            void updateTime(MillisecondTime time) {
                this->_currentTime = time;
                this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
            
                if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
                    this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
            
                if (this->sampleOffsetIntoNextAudioBuffer < 0)
                    this->sampleOffsetIntoNextAudioBuffer = 0;
            }
            
            void assign_defaults()
            {
                numberobj_21_value = 0;
                numberobj_21_value_setter(numberobj_21_value);
                numberobj_22_value = 0;
                numberobj_22_value_setter(numberobj_22_value);
                expr_11_in1 = 0;
                expr_11_out1 = 0;
                scale_07_inlow = 0;
                scale_07_inhigh = 12;
                scale_07_outlow = 0;
                scale_07_outhigh = 1;
                scale_07_power = 1;
                numberobj_23_value = 0;
                numberobj_23_value_setter(numberobj_23_value);
                scale_08_inlow = 0;
                scale_08_inhigh = 12;
                scale_08_outlow = 0;
                scale_08_outhigh = 1;
                scale_08_power = 0.5;
                numberobj_24_value = 0;
                numberobj_24_value_setter(numberobj_24_value);
                expr_12_in1 = 0;
                expr_12_in2 = 0;
                expr_12_out1 = 0;
                _currentTime = 0;
                audioProcessSampleCount = 0;
                sampleOffsetIntoNextAudioBuffer = 0;
                zeroBuffer = nullptr;
                dummyBuffer = nullptr;
                didAllocateSignals = 0;
                vs = 0;
                maxvs = 0;
                sr = 44100;
                invsr = 0.00002267573696;
                numberobj_21_currentFormat = 6;
                numberobj_21_lastValue = 0;
                numberobj_22_currentFormat = 6;
                numberobj_22_lastValue = 0;
                numberobj_23_currentFormat = 6;
                numberobj_23_lastValue = 0;
                numberobj_24_currentFormat = 6;
                numberobj_24_lastValue = 0;
                stackprotect_count = 0;
                _voiceIndex = 0;
                _noteNumber = 0;
                isMuted = 1;
                parameterOffset = 0;
            }
            
            // member variables
            
                number numberobj_21_value;
                number numberobj_22_value;
                number expr_11_in1;
                number expr_11_out1;
                list scale_07_input;
                number scale_07_inlow;
                number scale_07_inhigh;
                number scale_07_outlow;
                number scale_07_outhigh;
                number scale_07_power;
                list scale_07_out;
                number numberobj_23_value;
                list scale_08_input;
                number scale_08_inlow;
                number scale_08_inhigh;
                number scale_08_outlow;
                number scale_08_outhigh;
                number scale_08_power;
                list scale_08_out;
                number numberobj_24_value;
                number expr_12_in1;
                number expr_12_in2;
                number expr_12_out1;
                MillisecondTime _currentTime;
                UInt64 audioProcessSampleCount;
                SampleIndex sampleOffsetIntoNextAudioBuffer;
                signal zeroBuffer;
                signal dummyBuffer;
                bool didAllocateSignals;
                Index vs;
                Index maxvs;
                number sr;
                number invsr;
                Int numberobj_21_currentFormat;
                number numberobj_21_lastValue;
                Int numberobj_22_currentFormat;
                number numberobj_22_lastValue;
                Int numberobj_23_currentFormat;
                number numberobj_23_lastValue;
                Int numberobj_24_currentFormat;
                number numberobj_24_lastValue;
                number stackprotect_count;
                Index _voiceIndex;
                Int _noteNumber;
                Index isMuted;
                ParameterIndex parameterOffset;
            
    };
    
    RNBOSubpatcher_204()
    {
    }
    
    ~RNBOSubpatcher_204()
    {
        delete this->p_06;
    }
    
    virtual Grafik7* getPatcher() const {
        return static_cast<Grafik7 *>(_parentPatcher);
    }
    
    Grafik7* getTopLevelPatcher() {
        return this->getPatcher()->getTopLevelPatcher();
    }
    
    void cancelClockEvents()
    {
        getEngine()->flushClockEvents(this, -1621164530, false);
        getEngine()->flushClockEvents(this, 1114681293, false);
        getEngine()->flushClockEvents(this, -62043057, false);
    }
    
    SampleIndex currentsampletime() {
        return this->audioProcessSampleCount + this->sampleOffsetIntoNextAudioBuffer;
    }
    
    number mstosamps(MillisecondTime ms) {
        return ms * this->sr * 0.001;
    }
    
    number minimum(number x, number y) {
        return (y < x ? y : x);
    }
    
    inline number safesqrt(number num) {
        return (num > 0.0 ? rnbo_sqrt(num) : 0.0);
    }
    
    Index vectorsize() const {
        return this->vs;
    }
    
    Index getNumMidiInputPorts() const {
        return 0;
    }
    
    void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
    
    Index getNumMidiOutputPorts() const {
        return 0;
    }
    
    void process(
        const SampleValue * const* inputs,
        Index numInputs,
        SampleValue * const* outputs,
        Index numOutputs,
        Index n
    ) {
        this->vs = n;
        this->updateTime(this->getEngine()->getCurrentTime());
        SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
        SampleValue * out2 = (numOutputs >= 2 && outputs[1] ? outputs[1] : this->dummyBuffer);
        const SampleValue * in1 = (numInputs >= 1 && inputs[0] ? inputs[0] : this->zeroBuffer);
        const SampleValue * in2 = (numInputs >= 2 && inputs[1] ? inputs[1] : this->zeroBuffer);
        this->linetilde_09_perform(this->signals[0], n);
        this->linetilde_10_perform(this->signals[1], n);
        this->p_06_perform(n);
        this->linetilde_11_perform(this->signals[2], n);
    
        this->filtercoeff_05_perform(
            this->filtercoeff_05_frequency,
            this->signals[1],
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            n
        );
    
        this->biquad_tilde_10_perform(
            in2,
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            this->signals[2],
            n
        );
    
        this->biquad_tilde_09_perform(
            in1,
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            this->signals[1],
            n
        );
    
        this->gen_04_perform(
            this->signals[1],
            this->signals[2],
            this->gen_04_in3,
            this->gen_04_in4,
            this->gen_04_in5,
            this->signals[7],
            this->signals[6],
            n
        );
    
        this->dspexpr_15_perform(this->signals[1], this->signals[7], this->signals[0], out1, n);
        this->dspexpr_16_perform(this->signals[2], this->signals[6], this->signals[0], out2, n);
        this->stackprotect_perform(n);
        this->audioProcessSampleCount += this->vs;
    }
    
    void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
        if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
            Index i;
    
            for (i = 0; i < 8; i++) {
                this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
            }
    
            this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
            this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
            this->didAllocateSignals = true;
        }
    
        const bool sampleRateChanged = sampleRate != this->sr;
        const bool maxvsChanged = maxBlockSize != this->maxvs;
        const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
    
        if (sampleRateChanged || maxvsChanged) {
            this->vs = maxBlockSize;
            this->maxvs = maxBlockSize;
            this->sr = sampleRate;
            this->invsr = 1 / sampleRate;
        }
    
        this->filtercoeff_05_dspsetup(forceDSPSetup);
        this->biquad_tilde_10_dspsetup(forceDSPSetup);
        this->biquad_tilde_09_dspsetup(forceDSPSetup);
        this->p_06->prepareToProcess(sampleRate, maxBlockSize, force);
    
        if (sampleRateChanged)
            this->onSampleRateChanged(sampleRate);
    }
    
    void setProbingTarget(MessageTag id) {
        switch (id) {
        default:
            {
            this->setProbingIndex(-1);
            break;
            }
        }
    }
    
    void setProbingIndex(ProbingIndex ) {}
    
    Index getProbingChannels(MessageTag outletId) const {
        RNBO_UNUSED(outletId);
        return 0;
    }
    
    Index getIsMuted()  {
        return this->isMuted;
    }
    
    void setIsMuted(Index v)  {
        this->isMuted = v;
    }
    
    void onSampleRateChanged(double ) {}
    
    Index getPatcherSerial() const {
        return 0;
    }
    
    void getState(PatcherStateInterface& ) {}
    
    void setState() {
        this->p_06 = new RNBOSubpatcher_195();
        this->p_06->setEngineAndPatcher(this->getEngine(), this);
        this->p_06->initialize();
        this->p_06->setParameterOffset(this->getParameterOffset(this->p_06));
    }
    
    void getPreset(PatcherStateInterface& preset) {
        this->p_06->getPreset(getSubState(getSubState(preset, "__sps"), "scale"));
    }
    
    void setParameterValue(ParameterIndex index, ParameterValue v, MillisecondTime time) {
        RNBO_UNUSED(v);
        this->updateTime(time);
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_06->getNumParameters())
                this->p_06->setParameterValue(index, v, time);
    
            break;
            }
        }
    }
    
    void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValue(index, value, time);
    }
    
    void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
        this->setParameterValue(index, this->getParameterValue(index), time);
    }
    
    void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValueNormalized(index, value, time);
    }
    
    ParameterValue getParameterValue(ParameterIndex index)  {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_06->getNumParameters())
                return this->p_06->getParameterValue(index);
    
            return 0;
            }
        }
    }
    
    ParameterIndex getNumSignalInParameters() const {
        return 0;
    }
    
    ParameterIndex getNumSignalOutParameters() const {
        return 0;
    }
    
    ParameterIndex getNumParameters() const {
        return 0 + this->p_06->getNumParameters();
    }
    
    ConstCharPointer getParameterName(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_06->getNumParameters())
                return this->p_06->getParameterName(index);
    
            return "bogus";
            }
        }
    }
    
    ConstCharPointer getParameterId(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_06->getNumParameters())
                return this->p_06->getParameterId(index);
    
            return "bogus";
            }
        }
    }
    
    void getParameterInfo(ParameterIndex index, ParameterInfo * info) const {
        {
            switch (index) {
            default:
                {
                index -= 0;
    
                if (index < this->p_06->getNumParameters())
                    this->p_06->getParameterInfo(index, info);
    
                break;
                }
            }
        }
    }
    
    void sendParameter(ParameterIndex index, bool ignoreValue) {
        this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
    }
    
    ParameterIndex getParameterOffset(BaseInterface* subpatcher) const {
        if (subpatcher == this->p_06)
            return 0;
    
        return 0;
    }
    
    void setParameterOffset(ParameterIndex offset) {
        this->parameterOffset = offset;
    }
    
    ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
        if (steps == 1) {
            if (normalizedValue > 0) {
                normalizedValue = 1.;
            }
        } else {
            ParameterValue oneStep = (number)1. / (steps - 1);
            ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
            normalizedValue = numberOfSteps * oneStep;
        }
    
        return normalizedValue;
    }
    
    ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_06->getNumParameters())
                return this->p_06->convertToNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        value = (value < 0 ? 0 : (value > 1 ? 1 : value));
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_06->getNumParameters())
                return this->p_06->convertFromNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_06->getNumParameters())
                return this->p_06->constrainParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    void scheduleParamInit(ParameterIndex index, Index order) {
        this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
    }
    
    void processClockEvent(MillisecondTime time, ClockId index, bool hasValue, ParameterValue value) {
        RNBO_UNUSED(value);
        RNBO_UNUSED(hasValue);
        this->updateTime(time);
    
        switch (index) {
        case -1621164530:
            {
            this->linetilde_09_target_bang();
            break;
            }
        case 1114681293:
            {
            this->linetilde_10_target_bang();
            break;
            }
        case -62043057:
            {
            this->linetilde_11_target_bang();
            break;
            }
        }
    }
    
    void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
    
    void processOutletEvent(
        EngineLink* sender,
        OutletIndex index,
        ParameterValue value,
        MillisecondTime time
    ) {
        this->updateTime(time);
        this->processOutletAtCurrentTime(sender, index, value);
    }
    
    void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
        this->updateTime(time);
    
        switch (tag) {
        case TAG("valin"):
            {
            if (TAG("3.2kHz~/number_obj-3") == objectId)
                this->numberobj_25_valin_set(payload);
    
            if (TAG("3.2kHz~/number_obj-4") == objectId)
                this->numberobj_26_valin_set(payload);
    
            if (TAG("3.2kHz~/number_obj-8") == objectId)
                this->numberobj_27_valin_set(payload);
    
            break;
            }
        case TAG("format"):
            {
            if (TAG("3.2kHz~/number_obj-3") == objectId)
                this->numberobj_25_format_set(payload);
    
            if (TAG("3.2kHz~/number_obj-4") == objectId)
                this->numberobj_26_format_set(payload);
    
            if (TAG("3.2kHz~/number_obj-8") == objectId)
                this->numberobj_27_format_set(payload);
    
            break;
            }
        case TAG("listin"):
            {
            if (TAG("3.2kHz~/message_obj-33") == objectId)
                this->message_01_listin_number_set(payload);
    
            if (TAG("3.2kHz~/message_obj-31") == objectId)
                this->message_02_listin_number_set(payload);
    
            break;
            }
        }
    
        this->p_06->processNumMessage(tag, objectId, time, payload);
    }
    
    void processListMessage(
        MessageTag tag,
        MessageTag objectId,
        MillisecondTime time,
        const list& payload
    ) {
        this->updateTime(time);
    
        switch (tag) {
        case TAG("listin"):
            {
            if (TAG("3.2kHz~/message_obj-33") == objectId)
                this->message_01_listin_list_set(payload);
    
            if (TAG("3.2kHz~/message_obj-31") == objectId)
                this->message_02_listin_list_set(payload);
    
            break;
            }
        }
    
        this->p_06->processListMessage(tag, objectId, time, payload);
    }
    
    void processBangMessage(MessageTag tag, MessageTag objectId, MillisecondTime time) {
        this->updateTime(time);
    
        switch (tag) {
        case TAG("listin"):
            {
            if (TAG("3.2kHz~/message_obj-33") == objectId)
                this->message_01_listin_bang_bang();
    
            if (TAG("3.2kHz~/message_obj-31") == objectId)
                this->message_02_listin_bang_bang();
    
            break;
            }
        }
    
        this->p_06->processBangMessage(tag, objectId, time);
    }
    
    MessageTagInfo resolveTag(MessageTag tag) const {
        switch (tag) {
        case TAG("valout"):
            {
            return "valout";
            }
        case TAG("3.2kHz~/number_obj-3"):
            {
            return "3.2kHz~/number_obj-3";
            }
        case TAG("setup"):
            {
            return "setup";
            }
        case TAG("3.2kHz~/number_obj-4"):
            {
            return "3.2kHz~/number_obj-4";
            }
        case TAG("listout"):
            {
            return "listout";
            }
        case TAG("3.2kHz~/message_obj-33"):
            {
            return "3.2kHz~/message_obj-33";
            }
        case TAG("3.2kHz~/number_obj-8"):
            {
            return "3.2kHz~/number_obj-8";
            }
        case TAG("3.2kHz~/message_obj-31"):
            {
            return "3.2kHz~/message_obj-31";
            }
        case TAG("valin"):
            {
            return "valin";
            }
        case TAG("format"):
            {
            return "format";
            }
        case TAG("listin"):
            {
            return "listin";
            }
        }
    
        auto subpatchResult_0 = this->p_06->resolveTag(tag);
    
        if (subpatchResult_0)
            return subpatchResult_0;
    
        return nullptr;
    }
    
    DataRef* getDataRef(DataRefIndex index)  {
        switch (index) {
        default:
            {
            return nullptr;
            }
        }
    }
    
    DataRefIndex getNumDataRefs() const {
        return 0;
    }
    
    void fillDataRef(DataRefIndex , DataRef& ) {}
    
    void processDataViewUpdate(DataRefIndex index, MillisecondTime time) {
        this->p_06->processDataViewUpdate(index, time);
    }
    
    void initialize() {
        this->assign_defaults();
        this->setState();
    }
    
    protected:
    
    void eventinlet_13_out1_bang_bang() {
        this->linetilde_09_segments_bang();
    }
    
    void eventinlet_13_out1_list_set(const list& v) {
        this->linetilde_09_segments_set(v);
    }
    
    void eventinlet_14_out1_bang_bang() {
        this->numberobj_26_value_bang();
    }
    
    void eventinlet_14_out1_list_set(const list& v) {
        {
            number converted = (v->length > 0 ? v[0] : 0);
            this->numberobj_26_value_set(converted);
        }
    }
    
    void numberobj_25_valin_set(number v) {
        this->numberobj_25_value_set(v);
    }
    
    void numberobj_25_format_set(number v) {
        this->numberobj_25_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void numberobj_26_valin_set(number v) {
        this->numberobj_26_value_set(v);
    }
    
    void numberobj_26_format_set(number v) {
        this->numberobj_26_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void message_01_listin_list_set(const list& v) {
        this->message_01_set_set(v);
    }
    
    void message_01_listin_number_set(number v) {
        this->message_01_set_set(v);
    }
    
    void message_01_listin_bang_bang() {
        this->message_01_trigger_bang();
    }
    
    void numberobj_27_valin_set(number v) {
        this->numberobj_27_value_set(v);
    }
    
    void numberobj_27_format_set(number v) {
        this->numberobj_27_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void message_02_listin_list_set(const list& v) {
        this->message_02_set_set(v);
    }
    
    void message_02_listin_number_set(number v) {
        this->message_02_set_set(v);
    }
    
    void message_02_listin_bang_bang() {
        this->message_02_trigger_bang();
    }
    
    void linetilde_09_target_bang() {}
    
    void linetilde_10_target_bang() {}
    
    void linetilde_11_target_bang() {}
    
    number msToSamps(MillisecondTime ms, number sampleRate) {
        return ms * sampleRate * 0.001;
    }
    
    MillisecondTime sampsToMs(SampleIndex samps) {
        return samps * (this->invsr * 1000);
    }
    
    Index getMaxBlockSize() const {
        return this->maxvs;
    }
    
    number getSampleRate() const {
        return this->sr;
    }
    
    bool hasFixedVectorSize() const {
        return false;
    }
    
    Index getNumInputChannels() const {
        return 2;
    }
    
    Index getNumOutputChannels() const {
        return 2;
    }
    
    void initializeObjects() {
        this->gen_04_x1_l_init();
        this->gen_04_y1_l_init();
        this->gen_04_x1_r_init();
        this->gen_04_y1_r_init();
        this->numberobj_25_init();
        this->numberobj_26_init();
        this->change_01_init();
        this->message_01_init();
        this->numberobj_27_init();
        this->message_02_init();
        this->p_06->initializeObjects();
    }
    
    void sendOutlet(OutletIndex index, ParameterValue value) {
        this->getEngine()->sendOutlet(this, index, value);
    }
    
    void startup() {
        this->updateTime(this->getEngine()->getCurrentTime());
        this->p_06->startup();
    }
    
    void allocateDataRefs() {
        this->p_06->allocateDataRefs();
    }
    
    void change_01_zero_set(number ) {}
    
    void change_01_nonzero_set(number ) {}
    
    void linetilde_11_time_set(number v) {
        this->linetilde_11_time = v;
    }
    
    void linetilde_11_segments_set(const list& v) {
        this->linetilde_11_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_11_time == 0) {
                this->linetilde_11_activeRamps->length = 0;
                this->linetilde_11_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_11_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_11_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_11_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_11_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_11_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_11_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_11_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_11_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_11_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_11_activeRamps->push(lastRampValue);
                    this->linetilde_11_activeRamps->push(0);
                    this->linetilde_11_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_11_keepramp)) {
                            this->linetilde_11_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_11_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_11_activeRamps->push(destinationValue);
                    this->linetilde_11_activeRamps->push(inc);
                    this->linetilde_11_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void message_01_out_set(const list& v) {
        this->linetilde_11_segments_set(v);
    }
    
    void message_01_trigger_bang() {
        this->message_01_out_set(this->message_01_set);
    }
    
    void select_01_match1_bang() {
        this->message_01_trigger_bang();
    }
    
    void message_02_out_set(const list& v) {
        this->linetilde_11_segments_set(v);
    }
    
    void message_02_trigger_bang() {
        this->message_02_out_set(this->message_02_set);
    }
    
    void select_01_match2_bang() {
        this->message_02_trigger_bang();
    }
    
    void select_01_nomatch_number_set(number ) {}
    
    void select_01_input_number_set(number v) {
        if (v == this->select_01_test1)
            this->select_01_match1_bang();
        else if (v == this->select_01_test2)
            this->select_01_match2_bang();
        else
            this->select_01_nomatch_number_set(v);
    }
    
    void change_01_out_set(number v) {
        this->change_01_out = v;
        this->select_01_input_number_set(v);
    }
    
    void change_01_input_set(number v) {
        this->change_01_input = v;
    
        if (v != this->change_01_prev) {
            number prev = this->change_01_prev;
            this->change_01_prev = v;
    
            if (v == 0) {
                this->change_01_zero_set(1);
            } else if (this->change_01_out == 0) {
                this->change_01_nonzero_set(1);
            }
    
            {
                this->change_01_out_set(v);
            }
        } else {
            this->change_01_prev = v;
        }
    }
    
    void numberobj_27_output_set(number v) {
        this->change_01_input_set(v);
    }
    
    void numberobj_27_value_set(number v) {
        this->numberobj_27_value_setter(v);
        v = this->numberobj_27_value;
        number localvalue = v;
    
        if (this->numberobj_27_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("3.2kHz~/number_obj-8"), localvalue, this->_currentTime);
        this->numberobj_27_output_set(localvalue);
    }
    
    void expr_14_out1_set(number v) {
        this->expr_14_out1 = v;
        this->numberobj_27_value_set(this->expr_14_out1);
    }
    
    void expr_14_in1_set(number in1) {
        this->expr_14_in1 = in1;
        this->expr_14_out1_set(this->expr_14_in1 > this->expr_14_in2);//#map:3.2kHz~/>_obj-2:1
    }
    
    void gen_04_in5_set(number v) {
        this->gen_04_in5 = v;
    }
    
    void p_06_out3_number_set(number v) {
        this->gen_04_in5_set(v);
    }
    
    void gen_04_in4_set(number v) {
        this->gen_04_in4 = v;
    }
    
    void p_06_out2_number_set(number v) {
        this->gen_04_in4_set(v);
    }
    
    void gen_04_in3_set(number v) {
        this->gen_04_in3 = v;
    }
    
    void p_06_out1_number_set(number v) {
        this->gen_04_in3_set(v);
    }
    
    void p_06_in1_number_set(number v) {
        this->p_06->updateTime(this->_currentTime);
        this->p_06->eventinlet_12_out1_number_set(v);
    }
    
    void linetilde_10_time_set(number v) {
        this->linetilde_10_time = v;
    }
    
    void linetilde_10_segments_set(const list& v) {
        this->linetilde_10_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_10_time == 0) {
                this->linetilde_10_activeRamps->length = 0;
                this->linetilde_10_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_10_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_10_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_10_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_10_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_10_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_10_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_10_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_10_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_10_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_10_activeRamps->push(lastRampValue);
                    this->linetilde_10_activeRamps->push(0);
                    this->linetilde_10_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_10_keepramp)) {
                            this->linetilde_10_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_10_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_10_activeRamps->push(destinationValue);
                    this->linetilde_10_activeRamps->push(inc);
                    this->linetilde_10_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_25_output_set(number v) {
        {
            list converted = {v};
            this->linetilde_10_segments_set(converted);
        }
    }
    
    void numberobj_25_value_set(number v) {
        this->numberobj_25_value_setter(v);
        v = this->numberobj_25_value;
        number localvalue = v;
    
        if (this->numberobj_25_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("3.2kHz~/number_obj-3"), localvalue, this->_currentTime);
        this->numberobj_25_output_set(localvalue);
    }
    
    void expr_13_out1_set(number v) {
        this->expr_13_out1 = v;
        this->numberobj_25_value_set(this->expr_13_out1);
    }
    
    void expr_13_in1_set(number in1) {
        this->expr_13_in1 = in1;
        this->expr_13_out1_set(rnbo_pow(10, this->expr_13_in1 * 0.05));//#map:3.2kHz~/dbtoa_obj-9:1
    }
    
    void numberobj_26_output_set(number v) {
        this->expr_14_in1_set(v);
        this->p_06_in1_number_set(v);
        this->expr_13_in1_set(v);
    }
    
    void numberobj_26_value_set(number v) {
        this->numberobj_26_value_setter(v);
        v = this->numberobj_26_value;
        number localvalue = v;
    
        if (this->numberobj_26_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("3.2kHz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_26_output_set(localvalue);
    }
    
    void eventinlet_14_out1_number_set(number v) {
        this->numberobj_26_value_set(v);
    }
    
    void linetilde_09_time_set(number v) {
        this->linetilde_09_time = v;
    }
    
    void linetilde_09_segments_set(const list& v) {
        this->linetilde_09_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_09_time == 0) {
                this->linetilde_09_activeRamps->length = 0;
                this->linetilde_09_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_09_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_09_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_09_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_09_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_09_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_09_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_09_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_09_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_09_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_09_activeRamps->push(lastRampValue);
                    this->linetilde_09_activeRamps->push(0);
                    this->linetilde_09_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_09_keepramp)) {
                            this->linetilde_09_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_09_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_09_activeRamps->push(destinationValue);
                    this->linetilde_09_activeRamps->push(inc);
                    this->linetilde_09_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void eventinlet_13_out1_number_set(number v) {
        {
            list converted = {v};
            this->linetilde_09_segments_set(converted);
        }
    }
    
    void linetilde_09_segments_bang() {
        list v = this->linetilde_09_segments;
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_09_time == 0) {
                this->linetilde_09_activeRamps->length = 0;
                this->linetilde_09_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_09_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_09_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_09_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_09_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_09_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_09_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_09_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_09_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_09_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_09_activeRamps->push(lastRampValue);
                    this->linetilde_09_activeRamps->push(0);
                    this->linetilde_09_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_09_keepramp)) {
                            this->linetilde_09_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_09_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_09_activeRamps->push(destinationValue);
                    this->linetilde_09_activeRamps->push(inc);
                    this->linetilde_09_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_26_value_bang() {
        number v = this->numberobj_26_value;
        number localvalue = v;
    
        if (this->numberobj_26_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("3.2kHz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_26_output_set(localvalue);
    }
    
    void message_01_set_set(const list& v) {
        this->message_01_set = jsCreateListCopy(v);
        this->getEngine()->sendListMessage(TAG("listout"), TAG("3.2kHz~/message_obj-33"), v, this->_currentTime);
    }
    
    void message_02_set_set(const list& v) {
        this->message_02_set = jsCreateListCopy(v);
        this->getEngine()->sendListMessage(TAG("listout"), TAG("3.2kHz~/message_obj-31"), v, this->_currentTime);
    }
    
    void linetilde_09_perform(SampleValue * out, Index n) {
        auto __linetilde_09_time = this->linetilde_09_time;
        auto __linetilde_09_keepramp = this->linetilde_09_keepramp;
        auto __linetilde_09_currentValue = this->linetilde_09_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_09_activeRamps->length)) {
            while ((bool)(this->linetilde_09_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_09_activeRamps[0];
                number inc = this->linetilde_09_activeRamps[1];
                number rampTimeInSamples = this->linetilde_09_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_09_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_09_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_09_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -1621164530,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_09_keepramp))) {
                            __linetilde_09_time = 0;
                        }
                    }
                }
    
                __linetilde_09_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_09_currentValue;
            i++;
        }
    
        this->linetilde_09_currentValue = __linetilde_09_currentValue;
        this->linetilde_09_time = __linetilde_09_time;
    }
    
    void linetilde_10_perform(SampleValue * out, Index n) {
        auto __linetilde_10_time = this->linetilde_10_time;
        auto __linetilde_10_keepramp = this->linetilde_10_keepramp;
        auto __linetilde_10_currentValue = this->linetilde_10_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_10_activeRamps->length)) {
            while ((bool)(this->linetilde_10_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_10_activeRamps[0];
                number inc = this->linetilde_10_activeRamps[1];
                number rampTimeInSamples = this->linetilde_10_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_10_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_10_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_10_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            1114681293,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_10_keepramp))) {
                            __linetilde_10_time = 0;
                        }
                    }
                }
    
                __linetilde_10_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_10_currentValue;
            i++;
        }
    
        this->linetilde_10_currentValue = __linetilde_10_currentValue;
        this->linetilde_10_time = __linetilde_10_time;
    }
    
    void p_06_perform(Index n) {
        // subpatcher: scale
        this->p_06->process(nullptr, 0, nullptr, 0, n);
    }
    
    void linetilde_11_perform(SampleValue * out, Index n) {
        auto __linetilde_11_time = this->linetilde_11_time;
        auto __linetilde_11_keepramp = this->linetilde_11_keepramp;
        auto __linetilde_11_currentValue = this->linetilde_11_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_11_activeRamps->length)) {
            while ((bool)(this->linetilde_11_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_11_activeRamps[0];
                number inc = this->linetilde_11_activeRamps[1];
                number rampTimeInSamples = this->linetilde_11_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_11_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_11_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_11_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -62043057,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_11_keepramp))) {
                            __linetilde_11_time = 0;
                        }
                    }
                }
    
                __linetilde_11_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_11_currentValue;
            i++;
        }
    
        this->linetilde_11_currentValue = __linetilde_11_currentValue;
        this->linetilde_11_time = __linetilde_11_time;
    }
    
    void filtercoeff_05_perform(
        number frequency,
        const Sample * gain,
        const Sample * q,
        SampleValue * a0,
        SampleValue * a1,
        SampleValue * a2,
        SampleValue * b1,
        SampleValue * b2,
        Index n
    ) {
        RNBO_UNUSED(frequency);
        auto __filtercoeff_05_activeResamp = this->filtercoeff_05_activeResamp;
        auto __filtercoeff_05_resamp_counter = this->filtercoeff_05_resamp_counter;
        auto __filtercoeff_05_K_EPSILON = this->filtercoeff_05_K_EPSILON;
    
        for (Index i = 0; i < n; i++) {
            number local_q = q[(Index)i];
            number local_gain = gain[(Index)i];
    
            if (local_gain < 0)
                local_gain = 0;
    
            number local_frequency = 3200;
    
            if (local_q < __filtercoeff_05_K_EPSILON)
                local_q = __filtercoeff_05_K_EPSILON;
    
            local_frequency = (local_frequency > this->sr * 0.5 ? this->sr * 0.5 : (local_frequency < 1 ? 1 : local_frequency));
            __filtercoeff_05_resamp_counter--;
    
            if (__filtercoeff_05_resamp_counter <= 0) {
                __filtercoeff_05_resamp_counter = __filtercoeff_05_activeResamp;
                this->filtercoeff_05_updateTerms(local_frequency, local_gain, local_q);
            }
    
            a0[(Index)i] = this->filtercoeff_05_la0;
            a1[(Index)i] = this->filtercoeff_05_la1;
            a2[(Index)i] = this->filtercoeff_05_la2;
            b1[(Index)i] = this->filtercoeff_05_lb1;
            b2[(Index)i] = this->filtercoeff_05_lb2;
        }
    
        this->filtercoeff_05_resamp_counter = __filtercoeff_05_resamp_counter;
    }
    
    void biquad_tilde_10_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_10_y2 = this->biquad_tilde_10_y2;
        auto __biquad_tilde_10_y1 = this->biquad_tilde_10_y1;
        auto __biquad_tilde_10_x2 = this->biquad_tilde_10_x2;
        auto __biquad_tilde_10_x1 = this->biquad_tilde_10_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_10_x1 * a1[(Index)i] + __biquad_tilde_10_x2 * a2[(Index)i] - (__biquad_tilde_10_y1 * b1[(Index)i] + __biquad_tilde_10_y2 * b2[(Index)i]);
            __biquad_tilde_10_x2 = __biquad_tilde_10_x1;
            __biquad_tilde_10_x1 = x[(Index)i];
            __biquad_tilde_10_y2 = __biquad_tilde_10_y1;
            __biquad_tilde_10_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_10_x1 = __biquad_tilde_10_x1;
        this->biquad_tilde_10_x2 = __biquad_tilde_10_x2;
        this->biquad_tilde_10_y1 = __biquad_tilde_10_y1;
        this->biquad_tilde_10_y2 = __biquad_tilde_10_y2;
    }
    
    void biquad_tilde_09_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_09_y2 = this->biquad_tilde_09_y2;
        auto __biquad_tilde_09_y1 = this->biquad_tilde_09_y1;
        auto __biquad_tilde_09_x2 = this->biquad_tilde_09_x2;
        auto __biquad_tilde_09_x1 = this->biquad_tilde_09_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_09_x1 * a1[(Index)i] + __biquad_tilde_09_x2 * a2[(Index)i] - (__biquad_tilde_09_y1 * b1[(Index)i] + __biquad_tilde_09_y2 * b2[(Index)i]);
            __biquad_tilde_09_x2 = __biquad_tilde_09_x1;
            __biquad_tilde_09_x1 = x[(Index)i];
            __biquad_tilde_09_y2 = __biquad_tilde_09_y1;
            __biquad_tilde_09_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_09_x1 = __biquad_tilde_09_x1;
        this->biquad_tilde_09_x2 = __biquad_tilde_09_x2;
        this->biquad_tilde_09_y1 = __biquad_tilde_09_y1;
        this->biquad_tilde_09_y2 = __biquad_tilde_09_y2;
    }
    
    void gen_04_perform(
        const Sample * in1,
        const Sample * in2,
        number in3,
        number in4,
        number in5,
        SampleValue * out1,
        SampleValue * out2,
        Index n
    ) {
        auto __gen_04_y1_r_value = this->gen_04_y1_r_value;
        auto __gen_04_x1_r_value = this->gen_04_x1_r_value;
        auto __gen_04_y1_l_value = this->gen_04_y1_l_value;
        auto __gen_04_x1_l_value = this->gen_04_x1_l_value;
        number raw_drive_2 = in3;
        number asym_in_3 = in4;
        number is_cut_4 = in5;
        auto drive_5 = this->minimum(raw_drive_2, 0.75);
        number morph_factor_6 = 0.15 + is_cut_4 * (0.5 - 0.15);
        number amount_7 = drive_5 * morph_factor_6;
        number bias_factor_8 = 0.05 + is_cut_4 * (0.09 - 0.05);
        number bias_9 = asym_in_3 * bias_factor_8 * drive_5;
        Index i;
    
        for (i = 0; i < n; i++) {
            number xin_l_0 = in1[(Index)i];
            number xin_r_1 = in2[(Index)i];
            number raw_l_10 = xin_l_0 + bias_9;
            number dirty_l_11 = rnbo_tanh(raw_l_10 * 0.6) * 1.6;
            number cubic_l_12 = dirty_l_11 * dirty_l_11 * dirty_l_11 / (number)3;
            number y_l_13 = xin_l_0 - amount_7 * cubic_l_12;
            number dc_l_14 = y_l_13 - __gen_04_x1_l_value + 0.9995 * __gen_04_y1_l_value;
            __gen_04_x1_l_value = y_l_13;
            __gen_04_y1_l_value = dc_l_14;
            number raw_r_15 = xin_r_1 + bias_9;
            number dirty_r_16 = rnbo_tanh(raw_r_15 * 0.6) * 1.6;
            number cubic_r_17 = dirty_r_16 * dirty_r_16 * dirty_r_16 / (number)3;
            number y_r_18 = xin_r_1 - amount_7 * cubic_r_17;
            number dc_r_19 = y_r_18 - __gen_04_x1_r_value + 0.9995 * __gen_04_y1_r_value;
            __gen_04_x1_r_value = y_r_18;
            __gen_04_y1_r_value = dc_r_19;
            number expr_1_20 = dc_l_14;
            number expr_2_21 = dc_r_19;
            out1[(Index)i] = expr_1_20;
            out2[(Index)i] = expr_2_21;
        }
    
        this->gen_04_x1_l_value = __gen_04_x1_l_value;
        this->gen_04_y1_l_value = __gen_04_y1_l_value;
        this->gen_04_x1_r_value = __gen_04_x1_r_value;
        this->gen_04_y1_r_value = __gen_04_y1_r_value;
    }
    
    void dspexpr_15_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void dspexpr_16_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void stackprotect_perform(Index n) {
        RNBO_UNUSED(n);
        auto __stackprotect_count = this->stackprotect_count;
        __stackprotect_count = 0;
        this->stackprotect_count = __stackprotect_count;
    }
    
    void numberobj_25_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_25_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_25_value = localvalue;
    }
    
    void numberobj_26_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_26_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_26_value = localvalue;
    }
    
    void numberobj_27_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_27_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_27_value = localvalue;
    }
    
    void biquad_tilde_09_reset() {
        this->biquad_tilde_09_x1 = 0;
        this->biquad_tilde_09_x2 = 0;
        this->biquad_tilde_09_y1 = 0;
        this->biquad_tilde_09_y2 = 0;
    }
    
    void biquad_tilde_09_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_09_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_09_reset();
        this->biquad_tilde_09_setupDone = true;
    }
    
    void biquad_tilde_10_reset() {
        this->biquad_tilde_10_x1 = 0;
        this->biquad_tilde_10_x2 = 0;
        this->biquad_tilde_10_y1 = 0;
        this->biquad_tilde_10_y2 = 0;
    }
    
    void biquad_tilde_10_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_10_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_10_reset();
        this->biquad_tilde_10_setupDone = true;
    }
    
    number gen_04_x1_l_getvalue() {
        return this->gen_04_x1_l_value;
    }
    
    void gen_04_x1_l_setvalue(number val) {
        this->gen_04_x1_l_value = val;
    }
    
    void gen_04_x1_l_reset() {
        this->gen_04_x1_l_value = 0;
    }
    
    void gen_04_x1_l_init() {
        this->gen_04_x1_l_value = 0;
    }
    
    number gen_04_y1_l_getvalue() {
        return this->gen_04_y1_l_value;
    }
    
    void gen_04_y1_l_setvalue(number val) {
        this->gen_04_y1_l_value = val;
    }
    
    void gen_04_y1_l_reset() {
        this->gen_04_y1_l_value = 0;
    }
    
    void gen_04_y1_l_init() {
        this->gen_04_y1_l_value = 0;
    }
    
    number gen_04_x1_r_getvalue() {
        return this->gen_04_x1_r_value;
    }
    
    void gen_04_x1_r_setvalue(number val) {
        this->gen_04_x1_r_value = val;
    }
    
    void gen_04_x1_r_reset() {
        this->gen_04_x1_r_value = 0;
    }
    
    void gen_04_x1_r_init() {
        this->gen_04_x1_r_value = 0;
    }
    
    number gen_04_y1_r_getvalue() {
        return this->gen_04_y1_r_value;
    }
    
    void gen_04_y1_r_setvalue(number val) {
        this->gen_04_y1_r_value = val;
    }
    
    void gen_04_y1_r_reset() {
        this->gen_04_y1_r_value = 0;
    }
    
    void gen_04_y1_r_init() {
        this->gen_04_y1_r_value = 0;
    }
    
    array<number, 5> filtercoeff_05_localop_next(number frequency, number q, number gain, number type) {
        number omega = frequency * this->filtercoeff_05_localop_twopi_over_sr;
        this->filtercoeff_05_localop_cs = rnbo_cos(omega);
        this->filtercoeff_05_localop_sn = rnbo_sin(omega);
        this->filtercoeff_05_localop_one_over_gain = (gain >= 0 ? (number)1 / gain : 0.0);
        this->filtercoeff_05_localop_one_over_q = (number)1 / q;
        this->filtercoeff_05_localop_alpha = this->filtercoeff_05_localop_sn * 0.5 * this->filtercoeff_05_localop_one_over_q;
    
        switch ((int)type) {
        case 5:
            {
            this->filtercoeff_05_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_05_localop_beta = this->safesqrt(
                (this->filtercoeff_05_localop_A * this->filtercoeff_05_localop_A + 1.) * this->filtercoeff_05_localop_one_over_q - (this->filtercoeff_05_localop_A - 1.) * (this->filtercoeff_05_localop_A - 1.)
            );
    
            this->filtercoeff_05_localop_b0 = (number)1 / (this->filtercoeff_05_localop_A + 1. + (this->filtercoeff_05_localop_A - 1.) * this->filtercoeff_05_localop_cs + this->filtercoeff_05_localop_beta * this->filtercoeff_05_localop_sn);
            break;
            }
        case 6:
            {
            this->filtercoeff_05_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_05_localop_beta = this->safesqrt(
                (this->filtercoeff_05_localop_A * this->filtercoeff_05_localop_A + 1.) * this->filtercoeff_05_localop_one_over_q - (this->filtercoeff_05_localop_A - 1.) * (this->filtercoeff_05_localop_A - 1.)
            );
    
            this->filtercoeff_05_localop_b0 = (number)1 / (this->filtercoeff_05_localop_A + 1. - (this->filtercoeff_05_localop_A - 1.) * this->filtercoeff_05_localop_cs + this->filtercoeff_05_localop_beta * this->filtercoeff_05_localop_sn);
            break;
            }
        case 4:
            {
            this->filtercoeff_05_localop_A = this->safesqrt(gain);
            this->filtercoeff_05_localop_one_over_a = (this->filtercoeff_05_localop_A == 0 ? 0 : (number)1 / this->filtercoeff_05_localop_A);
            this->filtercoeff_05_localop_b0 = (number)1 / (1. + this->filtercoeff_05_localop_alpha * this->filtercoeff_05_localop_one_over_a);
            break;
            }
        case 9:
        case 10:
        case 11:
        case 13:
        case 14:
            {
            this->filtercoeff_05_localop_b0 = (number)1 / (1. + this->filtercoeff_05_localop_alpha);
            this->filtercoeff_05_localop_b0g = (number)1 / (this->filtercoeff_05_localop_one_over_gain + this->filtercoeff_05_localop_alpha * this->filtercoeff_05_localop_one_over_gain);
            break;
            }
        default:
            {
            this->filtercoeff_05_localop_b0 = (number)1 / (1. + this->filtercoeff_05_localop_alpha);
            break;
            }
        }
    
        switch ((int)type) {
        case 0:
            {
            this->filtercoeff_05_localop_la0 = this->filtercoeff_05_localop_la2 = (1. - this->filtercoeff_05_localop_cs) * 0.5 * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la1 = (1. - this->filtercoeff_05_localop_cs) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0;
            break;
            }
        case 1:
            {
            this->filtercoeff_05_localop_la0 = this->filtercoeff_05_localop_la2 = (1. + this->filtercoeff_05_localop_cs) * 0.5 * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la1 = -(1. + this->filtercoeff_05_localop_cs) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0;
            break;
            }
        case 2:
            {
            this->filtercoeff_05_localop_la0 = this->filtercoeff_05_localop_alpha * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la1 = 0.;
            this->filtercoeff_05_localop_la2 = -this->filtercoeff_05_localop_alpha * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0;
            break;
            }
        case 7:
            {
            this->filtercoeff_05_localop_la0 = this->filtercoeff_05_localop_alpha * q * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la1 = 0.;
            this->filtercoeff_05_localop_la2 = -this->filtercoeff_05_localop_alpha * q * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0;
            break;
            }
        case 3:
            {
            this->filtercoeff_05_localop_la1 = this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la0 = this->filtercoeff_05_localop_la2 = this->filtercoeff_05_localop_b0;
            break;
            }
        case 8:
            {
            this->filtercoeff_05_localop_la1 = this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = this->filtercoeff_05_localop_la0 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la2 = 1.0;
            break;
            }
        case 4:
            {
            this->filtercoeff_05_localop_la0 = (1. + this->filtercoeff_05_localop_alpha * this->filtercoeff_05_localop_A) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la1 = this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la2 = (1. - this->filtercoeff_05_localop_alpha * this->filtercoeff_05_localop_A) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (1. - this->filtercoeff_05_localop_alpha * this->filtercoeff_05_localop_one_over_a) * this->filtercoeff_05_localop_b0;
            break;
            }
        case 5:
            {
            this->filtercoeff_05_localop_la0 = this->filtercoeff_05_localop_A * (this->filtercoeff_05_localop_A + 1. - (this->filtercoeff_05_localop_A - 1.) * this->filtercoeff_05_localop_cs + this->filtercoeff_05_localop_beta * this->filtercoeff_05_localop_sn) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la1 = 2. * this->filtercoeff_05_localop_A * (this->filtercoeff_05_localop_A - 1 - (this->filtercoeff_05_localop_A + 1) * this->filtercoeff_05_localop_cs) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la2 = this->filtercoeff_05_localop_A * (this->filtercoeff_05_localop_A + 1. - (this->filtercoeff_05_localop_A - 1.) * this->filtercoeff_05_localop_cs - this->filtercoeff_05_localop_beta * this->filtercoeff_05_localop_sn) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb1 = -2. * (this->filtercoeff_05_localop_A - 1. + (this->filtercoeff_05_localop_A + 1.) * this->filtercoeff_05_localop_cs) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (this->filtercoeff_05_localop_A + 1. + (this->filtercoeff_05_localop_A - 1.) * this->filtercoeff_05_localop_cs - this->filtercoeff_05_localop_beta * this->filtercoeff_05_localop_sn) * this->filtercoeff_05_localop_b0;
            break;
            }
        case 6:
            {
            this->filtercoeff_05_localop_la0 = this->filtercoeff_05_localop_A * (this->filtercoeff_05_localop_A + 1. + (this->filtercoeff_05_localop_A - 1.) * this->filtercoeff_05_localop_cs + this->filtercoeff_05_localop_beta * this->filtercoeff_05_localop_sn) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la1 = -2. * this->filtercoeff_05_localop_A * (this->filtercoeff_05_localop_A - 1. + (this->filtercoeff_05_localop_A + 1.) * this->filtercoeff_05_localop_cs) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la2 = this->filtercoeff_05_localop_A * (this->filtercoeff_05_localop_A + 1. + (this->filtercoeff_05_localop_A - 1.) * this->filtercoeff_05_localop_cs - this->filtercoeff_05_localop_beta * this->filtercoeff_05_localop_sn) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb1 = 2. * (this->filtercoeff_05_localop_A - 1. - (this->filtercoeff_05_localop_A + 1.) * this->filtercoeff_05_localop_cs) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (this->filtercoeff_05_localop_A + 1. - (this->filtercoeff_05_localop_A - 1.) * this->filtercoeff_05_localop_cs - this->filtercoeff_05_localop_beta * this->filtercoeff_05_localop_sn) * this->filtercoeff_05_localop_b0;
            break;
            }
        case 9:
            {
            this->filtercoeff_05_localop_b0g = (number)1 / (this->filtercoeff_05_localop_one_over_gain + this->filtercoeff_05_localop_alpha * this->filtercoeff_05_localop_one_over_gain);
            this->filtercoeff_05_localop_la0 = this->filtercoeff_05_localop_la2 = (1. - this->filtercoeff_05_localop_cs) * 0.5 * this->filtercoeff_05_localop_b0g;
            this->filtercoeff_05_localop_la1 = (1. - this->filtercoeff_05_localop_cs) * this->filtercoeff_05_localop_b0g;
            this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0;
            break;
            }
        case 10:
            {
            this->filtercoeff_05_localop_b0g = (number)1 / (this->filtercoeff_05_localop_one_over_gain + this->filtercoeff_05_localop_alpha * this->filtercoeff_05_localop_one_over_gain);
            this->filtercoeff_05_localop_la0 = this->filtercoeff_05_localop_la2 = (1. + this->filtercoeff_05_localop_cs) * 0.5 * this->filtercoeff_05_localop_b0g;
            this->filtercoeff_05_localop_la1 = -(1. + this->filtercoeff_05_localop_cs) * this->filtercoeff_05_localop_b0g;
            this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0;
            break;
            }
        case 11:
            {
            this->filtercoeff_05_localop_la0 = this->filtercoeff_05_localop_alpha * gain * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la1 = 0.;
            this->filtercoeff_05_localop_la2 = -this->filtercoeff_05_localop_alpha * gain * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0;
            break;
            }
        case 13:
            {
            this->filtercoeff_05_localop_la0 = this->filtercoeff_05_localop_alpha * gain * q * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la1 = 0.;
            this->filtercoeff_05_localop_la2 = -this->filtercoeff_05_localop_alpha * gain * q * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0;
            break;
            }
        case 12:
            {
            this->filtercoeff_05_localop_b0g = (number)1 / (this->filtercoeff_05_localop_one_over_gain + this->filtercoeff_05_localop_alpha * this->filtercoeff_05_localop_one_over_gain);
            this->filtercoeff_05_localop_la1 = this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs;
            this->filtercoeff_05_localop_lb2 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la1 *= this->filtercoeff_05_localop_b0g;
            this->filtercoeff_05_localop_lb1 *= this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_la0 = this->filtercoeff_05_localop_b0g;
            this->filtercoeff_05_localop_la2 = this->filtercoeff_05_localop_b0g;
            break;
            }
        case 14:
            {
            this->filtercoeff_05_localop_b0g = (number)1 / (this->filtercoeff_05_localop_one_over_gain + this->filtercoeff_05_localop_alpha * this->filtercoeff_05_localop_one_over_gain);
            this->filtercoeff_05_localop_la0 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0g;
            this->filtercoeff_05_localop_la1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0g;
            this->filtercoeff_05_localop_la2 = gain;
            this->filtercoeff_05_localop_lb1 = -2. * this->filtercoeff_05_localop_cs * this->filtercoeff_05_localop_b0;
            this->filtercoeff_05_localop_lb2 = (1. - this->filtercoeff_05_localop_alpha) * this->filtercoeff_05_localop_b0;
            break;
            }
        case 15:
            {
            this->filtercoeff_05_localop_la0 = 1;
            this->filtercoeff_05_localop_la1 = 0;
            this->filtercoeff_05_localop_la2 = 0;
            this->filtercoeff_05_localop_lb1 = 0;
            this->filtercoeff_05_localop_lb2 = 0;
            }
        default:
            {
            break;
            }
        }
    
        return {
            this->filtercoeff_05_localop_la0,
            this->filtercoeff_05_localop_la1,
            this->filtercoeff_05_localop_la2,
            this->filtercoeff_05_localop_lb1,
            this->filtercoeff_05_localop_lb2
        };
    }
    
    void filtercoeff_05_localop_dspsetup() {
        this->filtercoeff_05_localop_twopi_over_sr = (number)6.283185307179586 / this->sr;
    }
    
    void filtercoeff_05_localop_reset() {
        this->filtercoeff_05_localop_twopi_over_sr = 0;
        this->filtercoeff_05_localop_cs = 0;
        this->filtercoeff_05_localop_sn = 0;
        this->filtercoeff_05_localop_one_over_gain = 0;
        this->filtercoeff_05_localop_one_over_q = 0;
        this->filtercoeff_05_localop_alpha = 0;
        this->filtercoeff_05_localop_beta = 0;
        this->filtercoeff_05_localop_b0 = 0;
        this->filtercoeff_05_localop_b0g = 0;
        this->filtercoeff_05_localop_A = 0;
        this->filtercoeff_05_localop_one_over_a = 0;
        this->filtercoeff_05_localop_la0 = 0;
        this->filtercoeff_05_localop_la1 = 0;
        this->filtercoeff_05_localop_la2 = 0;
        this->filtercoeff_05_localop_lb1 = 0;
        this->filtercoeff_05_localop_lb2 = 0;
    }
    
    void filtercoeff_05_updateTerms(number local_frequency, number local_gain, number local_q) {
        if ((bool)(this->filtercoeff_05_force_update) || local_frequency != this->filtercoeff_05_last_frequency || local_q != this->filtercoeff_05_last_q || local_gain != this->filtercoeff_05_last_gain || this->filtercoeff_05_type != this->filtercoeff_05_last_type) {
            array<number, 5> tmp = this->filtercoeff_05_localop_next(local_frequency, local_q, local_gain, this->filtercoeff_05_type);
            this->filtercoeff_05_la0 = tmp[0];
            this->filtercoeff_05_la1 = tmp[1];
            this->filtercoeff_05_la2 = tmp[2];
            this->filtercoeff_05_lb1 = tmp[3];
            this->filtercoeff_05_lb2 = tmp[4];
            this->filtercoeff_05_last_frequency = local_frequency;
            this->filtercoeff_05_last_q = local_q;
            this->filtercoeff_05_last_gain = local_gain;
            this->filtercoeff_05_last_type = this->filtercoeff_05_type;
            this->filtercoeff_05_force_update = false;
        }
    }
    
    void filtercoeff_05_dspsetup(bool force) {
        if ((bool)(this->filtercoeff_05_setupDone) && (bool)(!(bool)(force)))
            return;
    
        {
            this->filtercoeff_05_activeResamp = this->vectorsize();
        }
    
        this->filtercoeff_05_resamp_counter = 0;
        this->filtercoeff_05_la0 = 0.;
        this->filtercoeff_05_la1 = 0.;
        this->filtercoeff_05_la2 = 0.;
        this->filtercoeff_05_lb1 = 0.;
        this->filtercoeff_05_lb2 = 0.;
        this->filtercoeff_05_last_frequency = -1.;
        this->filtercoeff_05_last_q = -1.;
        this->filtercoeff_05_last_gain = -1.;
        this->filtercoeff_05_last_type = this->filtercoeff_05_type;
        this->filtercoeff_05_force_update = true;
        this->filtercoeff_05_setupDone = true;
        this->filtercoeff_05_localop_dspsetup();
    }
    
    void numberobj_25_init() {
        this->numberobj_25_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("3.2kHz~/number_obj-3"), 1, this->_currentTime);
    }
    
    void numberobj_25_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_25_value;
    }
    
    void numberobj_25_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_25_value_set(preset["value"]);
    }
    
    void numberobj_26_init() {
        this->numberobj_26_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("3.2kHz~/number_obj-4"), 1, this->_currentTime);
    }
    
    void numberobj_26_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_26_value;
    }
    
    void numberobj_26_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_26_value_set(preset["value"]);
    }
    
    void change_01_init() {
        this->change_01_prev = this->change_01_input;
    }
    
    void message_01_init() {
        this->message_01_set_set({0.9});
    }
    
    void numberobj_27_init() {
        this->numberobj_27_currentFormat = 0;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("3.2kHz~/number_obj-8"), 1, this->_currentTime);
    }
    
    void numberobj_27_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_27_value;
    }
    
    void numberobj_27_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_27_value_set(preset["value"]);
    }
    
    void message_02_init() {
        this->message_02_set_set({1.2});
    }
    
    bool stackprotect_check() {
        this->stackprotect_count++;
    
        if (this->stackprotect_count > 128) {
            console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
            return true;
        }
    
        return false;
    }
    
    void updateTime(MillisecondTime time) {
        this->_currentTime = time;
        this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
    
        if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
            this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
    
        if (this->sampleOffsetIntoNextAudioBuffer < 0)
            this->sampleOffsetIntoNextAudioBuffer = 0;
    }
    
    void assign_defaults()
    {
        dspexpr_15_in1 = 0;
        dspexpr_15_in2 = 0;
        dspexpr_15_in3 = 0;
        biquad_tilde_09_x = 0;
        biquad_tilde_09_a0 = 0;
        biquad_tilde_09_a1 = 0;
        biquad_tilde_09_a2 = 0;
        biquad_tilde_09_b1 = 0;
        biquad_tilde_09_b2 = 0;
        linetilde_09_time = 10;
        linetilde_09_keepramp = 1;
        biquad_tilde_10_x = 0;
        biquad_tilde_10_a0 = 0;
        biquad_tilde_10_a1 = 0;
        biquad_tilde_10_a2 = 0;
        biquad_tilde_10_b1 = 0;
        biquad_tilde_10_b2 = 0;
        dspexpr_16_in1 = 0;
        dspexpr_16_in2 = 0;
        dspexpr_16_in3 = 0;
        gen_04_in1 = 0;
        gen_04_in2 = 0;
        gen_04_in3 = 0;
        gen_04_in4 = 0;
        gen_04_in5 = 0;
        filtercoeff_05_frequency = 3200;
        filtercoeff_05_gain = 1;
        filtercoeff_05_q = 1.2;
        filtercoeff_05_type = 4;
        numberobj_25_value = 0;
        numberobj_25_value_setter(numberobj_25_value);
        numberobj_26_value = 0;
        numberobj_26_value_setter(numberobj_26_value);
        expr_13_in1 = 0;
        expr_13_out1 = 0;
        linetilde_10_time = 10;
        linetilde_10_keepramp = 1;
        p_06_target = 0;
        change_01_input = 0;
        change_01_out = 0;
        select_01_test1 = 0;
        select_01_test2 = 1;
        numberobj_27_value = 0;
        numberobj_27_value_setter(numberobj_27_value);
        expr_14_in1 = 0;
        expr_14_in2 = 0;
        expr_14_out1 = 0;
        linetilde_11_time = 10;
        linetilde_11_keepramp = 1;
        _currentTime = 0;
        audioProcessSampleCount = 0;
        sampleOffsetIntoNextAudioBuffer = 0;
        zeroBuffer = nullptr;
        dummyBuffer = nullptr;
        signals[0] = nullptr;
        signals[1] = nullptr;
        signals[2] = nullptr;
        signals[3] = nullptr;
        signals[4] = nullptr;
        signals[5] = nullptr;
        signals[6] = nullptr;
        signals[7] = nullptr;
        didAllocateSignals = 0;
        vs = 0;
        maxvs = 0;
        sr = 44100;
        invsr = 0.00002267573696;
        biquad_tilde_09_x1 = 0;
        biquad_tilde_09_x2 = 0;
        biquad_tilde_09_y1 = 0;
        biquad_tilde_09_y2 = 0;
        biquad_tilde_09_setupDone = false;
        linetilde_09_currentValue = 0;
        biquad_tilde_10_x1 = 0;
        biquad_tilde_10_x2 = 0;
        biquad_tilde_10_y1 = 0;
        biquad_tilde_10_y2 = 0;
        biquad_tilde_10_setupDone = false;
        gen_04_x1_l_value = 0;
        gen_04_y1_l_value = 0;
        gen_04_x1_r_value = 0;
        gen_04_y1_r_value = 0;
        filtercoeff_05_K_EPSILON = 1e-9;
        filtercoeff_05_setupDone = false;
        numberobj_25_currentFormat = 6;
        numberobj_25_lastValue = 0;
        numberobj_26_currentFormat = 6;
        numberobj_26_lastValue = 0;
        linetilde_10_currentValue = 1;
        numberobj_27_currentFormat = 6;
        numberobj_27_lastValue = 0;
        linetilde_11_currentValue = 1;
        stackprotect_count = 0;
        _voiceIndex = 0;
        _noteNumber = 0;
        isMuted = 1;
        parameterOffset = 0;
    }
    
    // member variables
    
        number dspexpr_15_in1;
        number dspexpr_15_in2;
        number dspexpr_15_in3;
        number biquad_tilde_09_x;
        number biquad_tilde_09_a0;
        number biquad_tilde_09_a1;
        number biquad_tilde_09_a2;
        number biquad_tilde_09_b1;
        number biquad_tilde_09_b2;
        list linetilde_09_segments;
        number linetilde_09_time;
        number linetilde_09_keepramp;
        number biquad_tilde_10_x;
        number biquad_tilde_10_a0;
        number biquad_tilde_10_a1;
        number biquad_tilde_10_a2;
        number biquad_tilde_10_b1;
        number biquad_tilde_10_b2;
        number dspexpr_16_in1;
        number dspexpr_16_in2;
        number dspexpr_16_in3;
        number gen_04_in1;
        number gen_04_in2;
        number gen_04_in3;
        number gen_04_in4;
        number gen_04_in5;
        number filtercoeff_05_frequency;
        number filtercoeff_05_gain;
        number filtercoeff_05_q;
        Int filtercoeff_05_type;
        number numberobj_25_value;
        number numberobj_26_value;
        number expr_13_in1;
        number expr_13_out1;
        list linetilde_10_segments;
        number linetilde_10_time;
        number linetilde_10_keepramp;
        number p_06_target;
        number change_01_input;
        number change_01_out;
        list message_01_set;
        number select_01_test1;
        number select_01_test2;
        number numberobj_27_value;
        number expr_14_in1;
        number expr_14_in2;
        number expr_14_out1;
        list linetilde_11_segments;
        number linetilde_11_time;
        number linetilde_11_keepramp;
        list message_02_set;
        MillisecondTime _currentTime;
        UInt64 audioProcessSampleCount;
        SampleIndex sampleOffsetIntoNextAudioBuffer;
        signal zeroBuffer;
        signal dummyBuffer;
        SampleValue * signals[8];
        bool didAllocateSignals;
        Index vs;
        Index maxvs;
        number sr;
        number invsr;
        number biquad_tilde_09_x1;
        number biquad_tilde_09_x2;
        number biquad_tilde_09_y1;
        number biquad_tilde_09_y2;
        bool biquad_tilde_09_setupDone;
        list linetilde_09_activeRamps;
        number linetilde_09_currentValue;
        number biquad_tilde_10_x1;
        number biquad_tilde_10_x2;
        number biquad_tilde_10_y1;
        number biquad_tilde_10_y2;
        bool biquad_tilde_10_setupDone;
        number gen_04_x1_l_value;
        number gen_04_y1_l_value;
        number gen_04_x1_r_value;
        number gen_04_y1_r_value;
        number filtercoeff_05_resamp_counter;
        number filtercoeff_05_activeResamp;
        number filtercoeff_05_K_EPSILON;
        number filtercoeff_05_la0;
        number filtercoeff_05_la1;
        number filtercoeff_05_la2;
        number filtercoeff_05_lb1;
        number filtercoeff_05_lb2;
        number filtercoeff_05_last_frequency;
        number filtercoeff_05_last_q;
        number filtercoeff_05_last_gain;
        Int filtercoeff_05_last_type;
        bool filtercoeff_05_force_update;
        number filtercoeff_05_localop_twopi_over_sr;
        number filtercoeff_05_localop_cs;
        number filtercoeff_05_localop_sn;
        number filtercoeff_05_localop_one_over_gain;
        number filtercoeff_05_localop_one_over_q;
        number filtercoeff_05_localop_alpha;
        number filtercoeff_05_localop_beta;
        number filtercoeff_05_localop_b0;
        number filtercoeff_05_localop_b0g;
        number filtercoeff_05_localop_A;
        number filtercoeff_05_localop_one_over_a;
        number filtercoeff_05_localop_la0;
        number filtercoeff_05_localop_la1;
        number filtercoeff_05_localop_la2;
        number filtercoeff_05_localop_lb1;
        number filtercoeff_05_localop_lb2;
        bool filtercoeff_05_setupDone;
        Int numberobj_25_currentFormat;
        number numberobj_25_lastValue;
        Int numberobj_26_currentFormat;
        number numberobj_26_lastValue;
        list linetilde_10_activeRamps;
        number linetilde_10_currentValue;
        number change_01_prev;
        Int numberobj_27_currentFormat;
        number numberobj_27_lastValue;
        list linetilde_11_activeRamps;
        number linetilde_11_currentValue;
        number stackprotect_count;
        Index _voiceIndex;
        Int _noteNumber;
        Index isMuted;
        ParameterIndex parameterOffset;
        RNBOSubpatcher_195* p_06;
    
};

class RNBOSubpatcher_205 : public PatcherInterfaceImpl {
    
    friend class Grafik7;
    
    public:
    
    class RNBOSubpatcher_196 : public PatcherInterfaceImpl {
            
            friend class RNBOSubpatcher_205;
            friend class Grafik7;
            
            public:
            
            RNBOSubpatcher_196()
            {
            }
            
            ~RNBOSubpatcher_196()
            {
            }
            
            virtual RNBOSubpatcher_205* getPatcher() const {
                return static_cast<RNBOSubpatcher_205 *>(_parentPatcher);
            }
            
            Grafik7* getTopLevelPatcher() {
                return this->getPatcher()->getTopLevelPatcher();
            }
            
            void cancelClockEvents()
            {
            }
            
            inline number safediv(number num, number denom) {
                return (denom == 0.0 ? 0.0 : num / denom);
            }
            
            number safepow(number base, number exponent) {
                return fixnan(rnbo_pow(base, exponent));
            }
            
            number scale(
                number x,
                number lowin,
                number hiin,
                number lowout,
                number highout,
                number pow
            ) {
                auto inscale = this->safediv(1., hiin - lowin);
                number outdiff = highout - lowout;
                number value = (x - lowin) * inscale;
            
                if (pow != 1) {
                    if (value > 0)
                        value = this->safepow(value, pow);
                    else
                        value = -this->safepow(-value, pow);
                }
            
                value = value * outdiff + lowout;
                return value;
            }
            
            Index getNumMidiInputPorts() const {
                return 0;
            }
            
            void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
            
            Index getNumMidiOutputPorts() const {
                return 0;
            }
            
            void process(
                const SampleValue * const* inputs,
                Index numInputs,
                SampleValue * const* outputs,
                Index numOutputs,
                Index n
            ) {
                RNBO_UNUSED(numOutputs);
                RNBO_UNUSED(outputs);
                RNBO_UNUSED(numInputs);
                RNBO_UNUSED(inputs);
                this->vs = n;
                this->updateTime(this->getEngine()->getCurrentTime());
                this->stackprotect_perform(n);
                this->audioProcessSampleCount += this->vs;
            }
            
            void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
                if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
                    this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
                    this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
                    this->didAllocateSignals = true;
                }
            
                const bool sampleRateChanged = sampleRate != this->sr;
                const bool maxvsChanged = maxBlockSize != this->maxvs;
                const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
            
                if (sampleRateChanged || maxvsChanged) {
                    this->vs = maxBlockSize;
                    this->maxvs = maxBlockSize;
                    this->sr = sampleRate;
                    this->invsr = 1 / sampleRate;
                }
            
                RNBO_UNUSED(forceDSPSetup);
            
                if (sampleRateChanged)
                    this->onSampleRateChanged(sampleRate);
            }
            
            void setProbingTarget(MessageTag id) {
                switch (id) {
                default:
                    {
                    this->setProbingIndex(-1);
                    break;
                    }
                }
            }
            
            void setProbingIndex(ProbingIndex ) {}
            
            Index getProbingChannels(MessageTag outletId) const {
                RNBO_UNUSED(outletId);
                return 0;
            }
            
            Index getIsMuted()  {
                return this->isMuted;
            }
            
            void setIsMuted(Index v)  {
                this->isMuted = v;
            }
            
            void onSampleRateChanged(double ) {}
            
            Index getPatcherSerial() const {
                return 0;
            }
            
            void getState(PatcherStateInterface& ) {}
            
            void setState() {}
            
            void getPreset(PatcherStateInterface& ) {}
            
            void setParameterValue(ParameterIndex , ParameterValue , MillisecondTime ) {}
            
            void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValue(index, value, time);
            }
            
            void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
                this->setParameterValue(index, this->getParameterValue(index), time);
            }
            
            void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValueNormalized(index, value, time);
            }
            
            ParameterValue getParameterValue(ParameterIndex index)  {
                switch (index) {
                default:
                    {
                    return 0;
                    }
                }
            }
            
            ParameterIndex getNumSignalInParameters() const {
                return 0;
            }
            
            ParameterIndex getNumSignalOutParameters() const {
                return 0;
            }
            
            ParameterIndex getNumParameters() const {
                return 0;
            }
            
            ConstCharPointer getParameterName(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            ConstCharPointer getParameterId(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            void getParameterInfo(ParameterIndex , ParameterInfo * ) const {}
            
            void sendParameter(ParameterIndex index, bool ignoreValue) {
                this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
            }
            
            void setParameterOffset(ParameterIndex offset) {
                this->parameterOffset = offset;
            }
            
            ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
                if (steps == 1) {
                    if (normalizedValue > 0) {
                        normalizedValue = 1.;
                    }
                } else {
                    ParameterValue oneStep = (number)1. / (steps - 1);
                    ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
                    normalizedValue = numberOfSteps * oneStep;
                }
            
                return normalizedValue;
            }
            
            ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                value = (value < 0 ? 0 : (value > 1 ? 1 : value));
            
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            void scheduleParamInit(ParameterIndex index, Index order) {
                this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
            }
            
            void processClockEvent(MillisecondTime , ClockId , bool , ParameterValue ) {}
            
            void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
            
            void processOutletEvent(
                EngineLink* sender,
                OutletIndex index,
                ParameterValue value,
                MillisecondTime time
            ) {
                this->updateTime(time);
                this->processOutletAtCurrentTime(sender, index, value);
            }
            
            void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
                this->updateTime(time);
            
                switch (tag) {
                case TAG("valin"):
                    {
                    if (TAG("1.6kHz~/scale/number_obj-34") == objectId)
                        this->numberobj_28_valin_set(payload);
            
                    if (TAG("1.6kHz~/scale/number_obj-32") == objectId)
                        this->numberobj_29_valin_set(payload);
            
                    if (TAG("1.6kHz~/scale/number_obj-38") == objectId)
                        this->numberobj_30_valin_set(payload);
            
                    if (TAG("1.6kHz~/scale/number_obj-55") == objectId)
                        this->numberobj_31_valin_set(payload);
            
                    break;
                    }
                case TAG("format"):
                    {
                    if (TAG("1.6kHz~/scale/number_obj-34") == objectId)
                        this->numberobj_28_format_set(payload);
            
                    if (TAG("1.6kHz~/scale/number_obj-32") == objectId)
                        this->numberobj_29_format_set(payload);
            
                    if (TAG("1.6kHz~/scale/number_obj-38") == objectId)
                        this->numberobj_30_format_set(payload);
            
                    if (TAG("1.6kHz~/scale/number_obj-55") == objectId)
                        this->numberobj_31_format_set(payload);
            
                    break;
                    }
                }
            }
            
            void processListMessage(MessageTag , MessageTag , MillisecondTime , const list& ) {}
            
            void processBangMessage(MessageTag , MessageTag , MillisecondTime ) {}
            
            MessageTagInfo resolveTag(MessageTag tag) const {
                switch (tag) {
                case TAG("valout"):
                    {
                    return "valout";
                    }
                case TAG("1.6kHz~/scale/number_obj-34"):
                    {
                    return "1.6kHz~/scale/number_obj-34";
                    }
                case TAG("setup"):
                    {
                    return "setup";
                    }
                case TAG("1.6kHz~/scale/number_obj-32"):
                    {
                    return "1.6kHz~/scale/number_obj-32";
                    }
                case TAG("1.6kHz~/scale/number_obj-38"):
                    {
                    return "1.6kHz~/scale/number_obj-38";
                    }
                case TAG("1.6kHz~/scale/number_obj-55"):
                    {
                    return "1.6kHz~/scale/number_obj-55";
                    }
                case TAG("valin"):
                    {
                    return "valin";
                    }
                case TAG("format"):
                    {
                    return "format";
                    }
                }
            
                return nullptr;
            }
            
            DataRef* getDataRef(DataRefIndex index)  {
                switch (index) {
                default:
                    {
                    return nullptr;
                    }
                }
            }
            
            DataRefIndex getNumDataRefs() const {
                return 0;
            }
            
            void fillDataRef(DataRefIndex , DataRef& ) {}
            
            void processDataViewUpdate(DataRefIndex , MillisecondTime ) {}
            
            void initialize() {
                this->assign_defaults();
                this->setState();
            }
            
            protected:
            
            void numberobj_28_valin_set(number v) {
                this->numberobj_28_value_set(v);
            }
            
            void numberobj_28_format_set(number v) {
                this->numberobj_28_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_29_valin_set(number v) {
                this->numberobj_29_value_set(v);
            }
            
            void numberobj_29_format_set(number v) {
                this->numberobj_29_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_30_valin_set(number v) {
                this->numberobj_30_value_set(v);
            }
            
            void numberobj_30_format_set(number v) {
                this->numberobj_30_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void eventinlet_15_out1_bang_bang() {
                this->expr_16_in1_bang();
                this->expr_15_in1_bang();
            }
            
            void eventinlet_15_out1_list_set(const list& v) {
                {
                    if (v->length > 1)
                        this->expr_16_in2_set(v[1]);
            
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_16_in1_set(converted);
                }
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_15_in1_set(converted);
                }
            }
            
            void numberobj_31_valin_set(number v) {
                this->numberobj_31_value_set(v);
            }
            
            void numberobj_31_format_set(number v) {
                this->numberobj_31_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            number msToSamps(MillisecondTime ms, number sampleRate) {
                return ms * sampleRate * 0.001;
            }
            
            MillisecondTime sampsToMs(SampleIndex samps) {
                return samps * (this->invsr * 1000);
            }
            
            Index getMaxBlockSize() const {
                return this->maxvs;
            }
            
            number getSampleRate() const {
                return this->sr;
            }
            
            bool hasFixedVectorSize() const {
                return false;
            }
            
            Index getNumInputChannels() const {
                return 0;
            }
            
            Index getNumOutputChannels() const {
                return 0;
            }
            
            void initializeObjects() {
                this->numberobj_28_init();
                this->numberobj_29_init();
                this->numberobj_30_init();
                this->numberobj_31_init();
            }
            
            void sendOutlet(OutletIndex index, ParameterValue value) {
                this->getEngine()->sendOutlet(this, index, value);
            }
            
            void startup() {}
            
            void allocateDataRefs() {}
            
            void eventoutlet_15_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_07_out3_number_set(v);
            }
            
            void numberobj_31_output_set(number v) {
                this->eventoutlet_15_in1_number_set(v);
            }
            
            void numberobj_31_value_set(number v) {
                this->numberobj_31_value_setter(v);
                v = this->numberobj_31_value;
                number localvalue = v;
            
                if (this->numberobj_31_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("1.6kHz~/scale/number_obj-55"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_31_output_set(localvalue);
            }
            
            void expr_16_out1_set(number v) {
                this->expr_16_out1 = v;
                this->numberobj_31_value_set(this->expr_16_out1);
            }
            
            void expr_16_in1_set(number in1) {
                this->expr_16_in1 = in1;
                this->expr_16_out1_set(this->expr_16_in1 < this->expr_16_in2);//#map:1.6kHz~/scale/<_obj-53:1
            }
            
            void eventoutlet_14_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_07_out2_number_set(v);
            }
            
            void numberobj_30_output_set(number v) {
                this->eventoutlet_14_in1_number_set(v);
            }
            
            void numberobj_30_value_set(number v) {
                this->numberobj_30_value_setter(v);
                v = this->numberobj_30_value;
                number localvalue = v;
            
                if (this->numberobj_30_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("1.6kHz~/scale/number_obj-38"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_30_output_set(localvalue);
            }
            
            void scale_10_out_set(const list& v) {
                this->scale_10_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_30_value_set(converted);
                }
            }
            
            void scale_10_input_set(const list& v) {
                this->scale_10_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_10_inlow,
                        this->scale_10_inhigh,
                        this->scale_10_outlow,
                        this->scale_10_outhigh,
                        this->scale_10_power
                    ));
                }
            
                this->scale_10_out_set(tmp);
            }
            
            void eventoutlet_13_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_07_out1_number_set(v);
            }
            
            void numberobj_28_output_set(number v) {
                this->eventoutlet_13_in1_number_set(v);
            }
            
            void numberobj_28_value_set(number v) {
                this->numberobj_28_value_setter(v);
                v = this->numberobj_28_value;
                number localvalue = v;
            
                if (this->numberobj_28_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("1.6kHz~/scale/number_obj-34"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_28_output_set(localvalue);
            }
            
            void scale_09_out_set(const list& v) {
                this->scale_09_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_28_value_set(converted);
                }
            }
            
            void scale_09_input_set(const list& v) {
                this->scale_09_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_09_inlow,
                        this->scale_09_inhigh,
                        this->scale_09_outlow,
                        this->scale_09_outhigh,
                        this->scale_09_power
                    ));
                }
            
                this->scale_09_out_set(tmp);
            }
            
            void numberobj_29_output_set(number v) {
                {
                    list converted = {v};
                    this->scale_10_input_set(converted);
                }
            
                {
                    list converted = {v};
                    this->scale_09_input_set(converted);
                }
            }
            
            void numberobj_29_value_set(number v) {
                this->numberobj_29_value_setter(v);
                v = this->numberobj_29_value;
                number localvalue = v;
            
                if (this->numberobj_29_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("1.6kHz~/scale/number_obj-32"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_29_output_set(localvalue);
            }
            
            void expr_15_out1_set(number v) {
                this->expr_15_out1 = v;
                this->numberobj_29_value_set(this->expr_15_out1);
            }
            
            void expr_15_in1_set(number in1) {
                this->expr_15_in1 = in1;
                this->expr_15_out1_set(rnbo_abs(this->expr_15_in1));//#map:1.6kHz~/scale/abs_obj-29:1
            }
            
            void eventinlet_15_out1_number_set(number v) {
                this->expr_16_in1_set(v);
                this->expr_15_in1_set(v);
            }
            
            void expr_16_in1_bang() {
                this->expr_16_out1_set(this->expr_16_in1 < this->expr_16_in2);//#map:1.6kHz~/scale/<_obj-53:1
            }
            
            void expr_15_in1_bang() {
                this->expr_15_out1_set(rnbo_abs(this->expr_15_in1));//#map:1.6kHz~/scale/abs_obj-29:1
            }
            
            void expr_16_in2_set(number v) {
                this->expr_16_in2 = v;
            }
            
            void stackprotect_perform(Index n) {
                RNBO_UNUSED(n);
                auto __stackprotect_count = this->stackprotect_count;
                __stackprotect_count = 0;
                this->stackprotect_count = __stackprotect_count;
            }
            
            void numberobj_28_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_28_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_28_value = localvalue;
            }
            
            void numberobj_29_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_29_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_29_value = localvalue;
            }
            
            void numberobj_30_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_30_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_30_value = localvalue;
            }
            
            void numberobj_31_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_31_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_31_value = localvalue;
            }
            
            void numberobj_28_init() {
                this->numberobj_28_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("1.6kHz~/scale/number_obj-34"), 1, this->_currentTime);
            }
            
            void numberobj_28_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_28_value;
            }
            
            void numberobj_28_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_28_value_set(preset["value"]);
            }
            
            void numberobj_29_init() {
                this->numberobj_29_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("1.6kHz~/scale/number_obj-32"), 1, this->_currentTime);
            }
            
            void numberobj_29_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_29_value;
            }
            
            void numberobj_29_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_29_value_set(preset["value"]);
            }
            
            void numberobj_30_init() {
                this->numberobj_30_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("1.6kHz~/scale/number_obj-38"), 1, this->_currentTime);
            }
            
            void numberobj_30_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_30_value;
            }
            
            void numberobj_30_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_30_value_set(preset["value"]);
            }
            
            void numberobj_31_init() {
                this->numberobj_31_currentFormat = 0;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("1.6kHz~/scale/number_obj-55"), 1, this->_currentTime);
            }
            
            void numberobj_31_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_31_value;
            }
            
            void numberobj_31_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_31_value_set(preset["value"]);
            }
            
            bool stackprotect_check() {
                this->stackprotect_count++;
            
                if (this->stackprotect_count > 128) {
                    console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
                    return true;
                }
            
                return false;
            }
            
            void updateTime(MillisecondTime time) {
                this->_currentTime = time;
                this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
            
                if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
                    this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
            
                if (this->sampleOffsetIntoNextAudioBuffer < 0)
                    this->sampleOffsetIntoNextAudioBuffer = 0;
            }
            
            void assign_defaults()
            {
                numberobj_28_value = 0;
                numberobj_28_value_setter(numberobj_28_value);
                numberobj_29_value = 0;
                numberobj_29_value_setter(numberobj_29_value);
                expr_15_in1 = 0;
                expr_15_out1 = 0;
                scale_09_inlow = 0;
                scale_09_inhigh = 12;
                scale_09_outlow = 0;
                scale_09_outhigh = 1;
                scale_09_power = 1;
                numberobj_30_value = 0;
                numberobj_30_value_setter(numberobj_30_value);
                scale_10_inlow = 0;
                scale_10_inhigh = 12;
                scale_10_outlow = 0;
                scale_10_outhigh = 1;
                scale_10_power = 0.5;
                numberobj_31_value = 0;
                numberobj_31_value_setter(numberobj_31_value);
                expr_16_in1 = 0;
                expr_16_in2 = 0;
                expr_16_out1 = 0;
                _currentTime = 0;
                audioProcessSampleCount = 0;
                sampleOffsetIntoNextAudioBuffer = 0;
                zeroBuffer = nullptr;
                dummyBuffer = nullptr;
                didAllocateSignals = 0;
                vs = 0;
                maxvs = 0;
                sr = 44100;
                invsr = 0.00002267573696;
                numberobj_28_currentFormat = 6;
                numberobj_28_lastValue = 0;
                numberobj_29_currentFormat = 6;
                numberobj_29_lastValue = 0;
                numberobj_30_currentFormat = 6;
                numberobj_30_lastValue = 0;
                numberobj_31_currentFormat = 6;
                numberobj_31_lastValue = 0;
                stackprotect_count = 0;
                _voiceIndex = 0;
                _noteNumber = 0;
                isMuted = 1;
                parameterOffset = 0;
            }
            
            // member variables
            
                number numberobj_28_value;
                number numberobj_29_value;
                number expr_15_in1;
                number expr_15_out1;
                list scale_09_input;
                number scale_09_inlow;
                number scale_09_inhigh;
                number scale_09_outlow;
                number scale_09_outhigh;
                number scale_09_power;
                list scale_09_out;
                number numberobj_30_value;
                list scale_10_input;
                number scale_10_inlow;
                number scale_10_inhigh;
                number scale_10_outlow;
                number scale_10_outhigh;
                number scale_10_power;
                list scale_10_out;
                number numberobj_31_value;
                number expr_16_in1;
                number expr_16_in2;
                number expr_16_out1;
                MillisecondTime _currentTime;
                UInt64 audioProcessSampleCount;
                SampleIndex sampleOffsetIntoNextAudioBuffer;
                signal zeroBuffer;
                signal dummyBuffer;
                bool didAllocateSignals;
                Index vs;
                Index maxvs;
                number sr;
                number invsr;
                Int numberobj_28_currentFormat;
                number numberobj_28_lastValue;
                Int numberobj_29_currentFormat;
                number numberobj_29_lastValue;
                Int numberobj_30_currentFormat;
                number numberobj_30_lastValue;
                Int numberobj_31_currentFormat;
                number numberobj_31_lastValue;
                number stackprotect_count;
                Index _voiceIndex;
                Int _noteNumber;
                Index isMuted;
                ParameterIndex parameterOffset;
            
    };
    
    RNBOSubpatcher_205()
    {
    }
    
    ~RNBOSubpatcher_205()
    {
        delete this->p_07;
    }
    
    virtual Grafik7* getPatcher() const {
        return static_cast<Grafik7 *>(_parentPatcher);
    }
    
    Grafik7* getTopLevelPatcher() {
        return this->getPatcher()->getTopLevelPatcher();
    }
    
    void cancelClockEvents()
    {
        getEngine()->flushClockEvents(this, -1621164530, false);
        getEngine()->flushClockEvents(this, 1114681293, false);
        getEngine()->flushClockEvents(this, -62043057, false);
        getEngine()->flushClockEvents(this, -1494586265, false);
    }
    
    SampleIndex currentsampletime() {
        return this->audioProcessSampleCount + this->sampleOffsetIntoNextAudioBuffer;
    }
    
    number mstosamps(MillisecondTime ms) {
        return ms * this->sr * 0.001;
    }
    
    inline number safesqrt(number num) {
        return (num > 0.0 ? rnbo_sqrt(num) : 0.0);
    }
    
    Index vectorsize() const {
        return this->vs;
    }
    
    Index getNumMidiInputPorts() const {
        return 0;
    }
    
    void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
    
    Index getNumMidiOutputPorts() const {
        return 0;
    }
    
    void process(
        const SampleValue * const* inputs,
        Index numInputs,
        SampleValue * const* outputs,
        Index numOutputs,
        Index n
    ) {
        this->vs = n;
        this->updateTime(this->getEngine()->getCurrentTime());
        SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
        SampleValue * out2 = (numOutputs >= 2 && outputs[1] ? outputs[1] : this->dummyBuffer);
        const SampleValue * in1 = (numInputs >= 1 && inputs[0] ? inputs[0] : this->zeroBuffer);
        const SampleValue * in2 = (numInputs >= 2 && inputs[1] ? inputs[1] : this->zeroBuffer);
        this->linetilde_12_perform(this->signals[0], n);
        this->linetilde_13_perform(this->signals[1], n);
        this->p_07_perform(n);
        this->linetilde_14_perform(this->signals[2], n);
        this->numbertilde_01_perform(this->signals[2], this->dummyBuffer, n);
    
        this->filtercoeff_06_perform(
            this->filtercoeff_06_frequency,
            this->signals[1],
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            n
        );
    
        this->biquad_tilde_12_perform(
            in2,
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            this->signals[2],
            n
        );
    
        this->biquad_tilde_11_perform(
            in1,
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            this->signals[1],
            n
        );
    
        this->gen_05_perform(
            this->signals[1],
            this->signals[2],
            this->gen_05_in3,
            this->gen_05_in4,
            this->gen_05_in5,
            this->signals[7],
            this->signals[6],
            n
        );
    
        this->dspexpr_17_perform(this->signals[1], this->signals[7], this->signals[0], out1, n);
        this->dspexpr_18_perform(this->signals[2], this->signals[6], this->signals[0], out2, n);
        this->stackprotect_perform(n);
        this->audioProcessSampleCount += this->vs;
    }
    
    void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
        if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
            Index i;
    
            for (i = 0; i < 8; i++) {
                this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
            }
    
            this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
            this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
            this->didAllocateSignals = true;
        }
    
        const bool sampleRateChanged = sampleRate != this->sr;
        const bool maxvsChanged = maxBlockSize != this->maxvs;
        const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
    
        if (sampleRateChanged || maxvsChanged) {
            this->vs = maxBlockSize;
            this->maxvs = maxBlockSize;
            this->sr = sampleRate;
            this->invsr = 1 / sampleRate;
        }
    
        this->numbertilde_01_dspsetup(forceDSPSetup);
        this->filtercoeff_06_dspsetup(forceDSPSetup);
        this->biquad_tilde_12_dspsetup(forceDSPSetup);
        this->biquad_tilde_11_dspsetup(forceDSPSetup);
        this->p_07->prepareToProcess(sampleRate, maxBlockSize, force);
    
        if (sampleRateChanged)
            this->onSampleRateChanged(sampleRate);
    }
    
    void setProbingTarget(MessageTag id) {
        switch (id) {
        default:
            {
            this->setProbingIndex(-1);
            break;
            }
        }
    }
    
    void setProbingIndex(ProbingIndex ) {}
    
    Index getProbingChannels(MessageTag outletId) const {
        RNBO_UNUSED(outletId);
        return 0;
    }
    
    Index getIsMuted()  {
        return this->isMuted;
    }
    
    void setIsMuted(Index v)  {
        this->isMuted = v;
    }
    
    void onSampleRateChanged(double ) {}
    
    Index getPatcherSerial() const {
        return 0;
    }
    
    void getState(PatcherStateInterface& ) {}
    
    void setState() {
        this->p_07 = new RNBOSubpatcher_196();
        this->p_07->setEngineAndPatcher(this->getEngine(), this);
        this->p_07->initialize();
        this->p_07->setParameterOffset(this->getParameterOffset(this->p_07));
    }
    
    void getPreset(PatcherStateInterface& preset) {
        this->p_07->getPreset(getSubState(getSubState(preset, "__sps"), "scale"));
    }
    
    void setParameterValue(ParameterIndex index, ParameterValue v, MillisecondTime time) {
        RNBO_UNUSED(v);
        this->updateTime(time);
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_07->getNumParameters())
                this->p_07->setParameterValue(index, v, time);
    
            break;
            }
        }
    }
    
    void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValue(index, value, time);
    }
    
    void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
        this->setParameterValue(index, this->getParameterValue(index), time);
    }
    
    void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValueNormalized(index, value, time);
    }
    
    ParameterValue getParameterValue(ParameterIndex index)  {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_07->getNumParameters())
                return this->p_07->getParameterValue(index);
    
            return 0;
            }
        }
    }
    
    ParameterIndex getNumSignalInParameters() const {
        return 0;
    }
    
    ParameterIndex getNumSignalOutParameters() const {
        return 0;
    }
    
    ParameterIndex getNumParameters() const {
        return 0 + this->p_07->getNumParameters();
    }
    
    ConstCharPointer getParameterName(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_07->getNumParameters())
                return this->p_07->getParameterName(index);
    
            return "bogus";
            }
        }
    }
    
    ConstCharPointer getParameterId(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_07->getNumParameters())
                return this->p_07->getParameterId(index);
    
            return "bogus";
            }
        }
    }
    
    void getParameterInfo(ParameterIndex index, ParameterInfo * info) const {
        {
            switch (index) {
            default:
                {
                index -= 0;
    
                if (index < this->p_07->getNumParameters())
                    this->p_07->getParameterInfo(index, info);
    
                break;
                }
            }
        }
    }
    
    void sendParameter(ParameterIndex index, bool ignoreValue) {
        this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
    }
    
    ParameterIndex getParameterOffset(BaseInterface* subpatcher) const {
        if (subpatcher == this->p_07)
            return 0;
    
        return 0;
    }
    
    void setParameterOffset(ParameterIndex offset) {
        this->parameterOffset = offset;
    }
    
    ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
        if (steps == 1) {
            if (normalizedValue > 0) {
                normalizedValue = 1.;
            }
        } else {
            ParameterValue oneStep = (number)1. / (steps - 1);
            ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
            normalizedValue = numberOfSteps * oneStep;
        }
    
        return normalizedValue;
    }
    
    ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_07->getNumParameters())
                return this->p_07->convertToNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        value = (value < 0 ? 0 : (value > 1 ? 1 : value));
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_07->getNumParameters())
                return this->p_07->convertFromNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_07->getNumParameters())
                return this->p_07->constrainParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    void scheduleParamInit(ParameterIndex index, Index order) {
        this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
    }
    
    void processClockEvent(MillisecondTime time, ClockId index, bool hasValue, ParameterValue value) {
        RNBO_UNUSED(hasValue);
        this->updateTime(time);
    
        switch (index) {
        case -1621164530:
            {
            this->linetilde_12_target_bang();
            break;
            }
        case 1114681293:
            {
            this->linetilde_13_target_bang();
            break;
            }
        case -62043057:
            {
            this->linetilde_14_target_bang();
            break;
            }
        case -1494586265:
            {
            this->numbertilde_01_value_set(value);
            break;
            }
        }
    }
    
    void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
    
    void processOutletEvent(
        EngineLink* sender,
        OutletIndex index,
        ParameterValue value,
        MillisecondTime time
    ) {
        this->updateTime(time);
        this->processOutletAtCurrentTime(sender, index, value);
    }
    
    void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
        this->updateTime(time);
    
        switch (tag) {
        case TAG("valin"):
            {
            if (TAG("1.6kHz~/number_obj-3") == objectId)
                this->numberobj_32_valin_set(payload);
    
            if (TAG("1.6kHz~/number_obj-4") == objectId)
                this->numberobj_33_valin_set(payload);
    
            if (TAG("1.6kHz~/number_obj-8") == objectId)
                this->numberobj_34_valin_set(payload);
    
            break;
            }
        case TAG("format"):
            {
            if (TAG("1.6kHz~/number_obj-3") == objectId)
                this->numberobj_32_format_set(payload);
    
            if (TAG("1.6kHz~/number_obj-4") == objectId)
                this->numberobj_33_format_set(payload);
    
            if (TAG("1.6kHz~/number_obj-8") == objectId)
                this->numberobj_34_format_set(payload);
    
            break;
            }
        case TAG("listin"):
            {
            if (TAG("1.6kHz~/message_obj-33") == objectId)
                this->message_03_listin_number_set(payload);
    
            if (TAG("1.6kHz~/message_obj-31") == objectId)
                this->message_04_listin_number_set(payload);
    
            break;
            }
        case TAG("sig"):
            {
            if (TAG("1.6kHz~/number~_obj-42") == objectId)
                this->numbertilde_01_sig_number_set(payload);
    
            break;
            }
        case TAG("mode"):
            {
            if (TAG("1.6kHz~/number~_obj-42") == objectId)
                this->numbertilde_01_mode_set(payload);
    
            break;
            }
        }
    
        this->p_07->processNumMessage(tag, objectId, time, payload);
    }
    
    void processListMessage(
        MessageTag tag,
        MessageTag objectId,
        MillisecondTime time,
        const list& payload
    ) {
        this->updateTime(time);
    
        switch (tag) {
        case TAG("listin"):
            {
            if (TAG("1.6kHz~/message_obj-33") == objectId)
                this->message_03_listin_list_set(payload);
    
            if (TAG("1.6kHz~/message_obj-31") == objectId)
                this->message_04_listin_list_set(payload);
    
            break;
            }
        case TAG("sig"):
            {
            if (TAG("1.6kHz~/number~_obj-42") == objectId)
                this->numbertilde_01_sig_list_set(payload);
    
            break;
            }
        }
    
        this->p_07->processListMessage(tag, objectId, time, payload);
    }
    
    void processBangMessage(MessageTag tag, MessageTag objectId, MillisecondTime time) {
        this->updateTime(time);
    
        switch (tag) {
        case TAG("listin"):
            {
            if (TAG("1.6kHz~/message_obj-33") == objectId)
                this->message_03_listin_bang_bang();
    
            if (TAG("1.6kHz~/message_obj-31") == objectId)
                this->message_04_listin_bang_bang();
    
            break;
            }
        }
    
        this->p_07->processBangMessage(tag, objectId, time);
    }
    
    MessageTagInfo resolveTag(MessageTag tag) const {
        switch (tag) {
        case TAG("valout"):
            {
            return "valout";
            }
        case TAG("1.6kHz~/number_obj-3"):
            {
            return "1.6kHz~/number_obj-3";
            }
        case TAG("setup"):
            {
            return "setup";
            }
        case TAG("1.6kHz~/number_obj-4"):
            {
            return "1.6kHz~/number_obj-4";
            }
        case TAG("listout"):
            {
            return "listout";
            }
        case TAG("1.6kHz~/message_obj-33"):
            {
            return "1.6kHz~/message_obj-33";
            }
        case TAG("1.6kHz~/number_obj-8"):
            {
            return "1.6kHz~/number_obj-8";
            }
        case TAG("monitor"):
            {
            return "monitor";
            }
        case TAG("1.6kHz~/number~_obj-42"):
            {
            return "1.6kHz~/number~_obj-42";
            }
        case TAG("assign"):
            {
            return "assign";
            }
        case TAG("1.6kHz~/message_obj-31"):
            {
            return "1.6kHz~/message_obj-31";
            }
        case TAG("valin"):
            {
            return "valin";
            }
        case TAG("format"):
            {
            return "format";
            }
        case TAG("listin"):
            {
            return "listin";
            }
        case TAG("sig"):
            {
            return "sig";
            }
        case TAG("mode"):
            {
            return "mode";
            }
        }
    
        auto subpatchResult_0 = this->p_07->resolveTag(tag);
    
        if (subpatchResult_0)
            return subpatchResult_0;
    
        return nullptr;
    }
    
    DataRef* getDataRef(DataRefIndex index)  {
        switch (index) {
        default:
            {
            return nullptr;
            }
        }
    }
    
    DataRefIndex getNumDataRefs() const {
        return 0;
    }
    
    void fillDataRef(DataRefIndex , DataRef& ) {}
    
    void processDataViewUpdate(DataRefIndex index, MillisecondTime time) {
        this->p_07->processDataViewUpdate(index, time);
    }
    
    void initialize() {
        this->assign_defaults();
        this->setState();
    }
    
    protected:
    
    void eventinlet_16_out1_bang_bang() {
        this->linetilde_12_segments_bang();
    }
    
    void eventinlet_16_out1_list_set(const list& v) {
        this->linetilde_12_segments_set(v);
    }
    
    void eventinlet_17_out1_bang_bang() {
        this->numberobj_33_value_bang();
    }
    
    void eventinlet_17_out1_list_set(const list& v) {
        {
            number converted = (v->length > 0 ? v[0] : 0);
            this->numberobj_33_value_set(converted);
        }
    }
    
    void numberobj_32_valin_set(number v) {
        this->numberobj_32_value_set(v);
    }
    
    void numberobj_32_format_set(number v) {
        this->numberobj_32_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void numberobj_33_valin_set(number v) {
        this->numberobj_33_value_set(v);
    }
    
    void numberobj_33_format_set(number v) {
        this->numberobj_33_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void message_03_listin_list_set(const list& v) {
        this->message_03_set_set(v);
    }
    
    void message_03_listin_number_set(number v) {
        this->message_03_set_set(v);
    }
    
    void message_03_listin_bang_bang() {
        this->message_03_trigger_bang();
    }
    
    void numberobj_34_valin_set(number v) {
        this->numberobj_34_value_set(v);
    }
    
    void numberobj_34_format_set(number v) {
        this->numberobj_34_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void numbertilde_01_sig_number_set(number v) {
        this->numbertilde_01_outValue = v;
    }
    
    void numbertilde_01_sig_list_set(const list& v) {
        this->numbertilde_01_outValue = v[0];
    }
    
    void numbertilde_01_mode_set(number v) {
        if (v == 1) {
            this->numbertilde_01_currentMode = 0;
        } else if (v == 2) {
            this->numbertilde_01_currentMode = 1;
        }
    }
    
    void message_04_listin_list_set(const list& v) {
        this->message_04_set_set(v);
    }
    
    void message_04_listin_number_set(number v) {
        this->message_04_set_set(v);
    }
    
    void message_04_listin_bang_bang() {
        this->message_04_trigger_bang();
    }
    
    void linetilde_12_target_bang() {}
    
    void linetilde_13_target_bang() {}
    
    void linetilde_14_target_bang() {}
    
    void numbertilde_01_value_set(number ) {}
    
    number msToSamps(MillisecondTime ms, number sampleRate) {
        return ms * sampleRate * 0.001;
    }
    
    MillisecondTime sampsToMs(SampleIndex samps) {
        return samps * (this->invsr * 1000);
    }
    
    Index getMaxBlockSize() const {
        return this->maxvs;
    }
    
    number getSampleRate() const {
        return this->sr;
    }
    
    bool hasFixedVectorSize() const {
        return false;
    }
    
    Index getNumInputChannels() const {
        return 2;
    }
    
    Index getNumOutputChannels() const {
        return 2;
    }
    
    void initializeObjects() {
        this->gen_05_x1_l_init();
        this->gen_05_y1_l_init();
        this->gen_05_x1_r_init();
        this->gen_05_y1_r_init();
        this->numberobj_32_init();
        this->numberobj_33_init();
        this->change_02_init();
        this->message_03_init();
        this->numberobj_34_init();
        this->numbertilde_01_init();
        this->message_04_init();
        this->p_07->initializeObjects();
    }
    
    void sendOutlet(OutletIndex index, ParameterValue value) {
        this->getEngine()->sendOutlet(this, index, value);
    }
    
    void startup() {
        this->updateTime(this->getEngine()->getCurrentTime());
        this->p_07->startup();
    }
    
    void allocateDataRefs() {
        this->p_07->allocateDataRefs();
    }
    
    void change_02_zero_set(number ) {}
    
    void change_02_nonzero_set(number ) {}
    
    void linetilde_14_time_set(number v) {
        this->linetilde_14_time = v;
    }
    
    void linetilde_14_segments_set(const list& v) {
        this->linetilde_14_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_14_time == 0) {
                this->linetilde_14_activeRamps->length = 0;
                this->linetilde_14_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_14_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_14_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_14_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_14_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_14_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_14_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_14_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_14_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_14_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_14_activeRamps->push(lastRampValue);
                    this->linetilde_14_activeRamps->push(0);
                    this->linetilde_14_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_14_keepramp)) {
                            this->linetilde_14_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_14_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_14_activeRamps->push(destinationValue);
                    this->linetilde_14_activeRamps->push(inc);
                    this->linetilde_14_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void message_03_out_set(const list& v) {
        this->linetilde_14_segments_set(v);
    }
    
    void message_03_trigger_bang() {
        this->message_03_out_set(this->message_03_set);
    }
    
    void select_02_match1_bang() {
        this->message_03_trigger_bang();
    }
    
    void message_04_out_set(const list& v) {
        this->linetilde_14_segments_set(v);
    }
    
    void message_04_trigger_bang() {
        this->message_04_out_set(this->message_04_set);
    }
    
    void select_02_match2_bang() {
        this->message_04_trigger_bang();
    }
    
    void select_02_nomatch_number_set(number ) {}
    
    void select_02_input_number_set(number v) {
        if (v == this->select_02_test1)
            this->select_02_match1_bang();
        else if (v == this->select_02_test2)
            this->select_02_match2_bang();
        else
            this->select_02_nomatch_number_set(v);
    }
    
    void change_02_out_set(number v) {
        this->change_02_out = v;
        this->select_02_input_number_set(v);
    }
    
    void change_02_input_set(number v) {
        this->change_02_input = v;
    
        if (v != this->change_02_prev) {
            number prev = this->change_02_prev;
            this->change_02_prev = v;
    
            if (v == 0) {
                this->change_02_zero_set(1);
            } else if (this->change_02_out == 0) {
                this->change_02_nonzero_set(1);
            }
    
            {
                this->change_02_out_set(v);
            }
        } else {
            this->change_02_prev = v;
        }
    }
    
    void numberobj_34_output_set(number v) {
        this->change_02_input_set(v);
    }
    
    void numberobj_34_value_set(number v) {
        this->numberobj_34_value_setter(v);
        v = this->numberobj_34_value;
        number localvalue = v;
    
        if (this->numberobj_34_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("1.6kHz~/number_obj-8"), localvalue, this->_currentTime);
        this->numberobj_34_output_set(localvalue);
    }
    
    void expr_18_out1_set(number v) {
        this->expr_18_out1 = v;
        this->numberobj_34_value_set(this->expr_18_out1);
    }
    
    void expr_18_in1_set(number in1) {
        this->expr_18_in1 = in1;
        this->expr_18_out1_set(this->expr_18_in1 > this->expr_18_in2);//#map:1.6kHz~/>_obj-2:1
    }
    
    void gen_05_in5_set(number v) {
        this->gen_05_in5 = v;
    }
    
    void p_07_out3_number_set(number v) {
        this->gen_05_in5_set(v);
    }
    
    void gen_05_in4_set(number v) {
        this->gen_05_in4 = v;
    }
    
    void p_07_out2_number_set(number v) {
        this->gen_05_in4_set(v);
    }
    
    void gen_05_in3_set(number v) {
        this->gen_05_in3 = v;
    }
    
    void p_07_out1_number_set(number v) {
        this->gen_05_in3_set(v);
    }
    
    void p_07_in1_number_set(number v) {
        this->p_07->updateTime(this->_currentTime);
        this->p_07->eventinlet_15_out1_number_set(v);
    }
    
    void linetilde_13_time_set(number v) {
        this->linetilde_13_time = v;
    }
    
    void linetilde_13_segments_set(const list& v) {
        this->linetilde_13_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_13_time == 0) {
                this->linetilde_13_activeRamps->length = 0;
                this->linetilde_13_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_13_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_13_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_13_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_13_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_13_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_13_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_13_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_13_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_13_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_13_activeRamps->push(lastRampValue);
                    this->linetilde_13_activeRamps->push(0);
                    this->linetilde_13_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_13_keepramp)) {
                            this->linetilde_13_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_13_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_13_activeRamps->push(destinationValue);
                    this->linetilde_13_activeRamps->push(inc);
                    this->linetilde_13_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_32_output_set(number v) {
        {
            list converted = {v};
            this->linetilde_13_segments_set(converted);
        }
    }
    
    void numberobj_32_value_set(number v) {
        this->numberobj_32_value_setter(v);
        v = this->numberobj_32_value;
        number localvalue = v;
    
        if (this->numberobj_32_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("1.6kHz~/number_obj-3"), localvalue, this->_currentTime);
        this->numberobj_32_output_set(localvalue);
    }
    
    void expr_17_out1_set(number v) {
        this->expr_17_out1 = v;
        this->numberobj_32_value_set(this->expr_17_out1);
    }
    
    void expr_17_in1_set(number in1) {
        this->expr_17_in1 = in1;
        this->expr_17_out1_set(rnbo_pow(10, this->expr_17_in1 * 0.05));//#map:1.6kHz~/dbtoa_obj-9:1
    }
    
    void numberobj_33_output_set(number v) {
        this->expr_18_in1_set(v);
        this->p_07_in1_number_set(v);
        this->expr_17_in1_set(v);
    }
    
    void numberobj_33_value_set(number v) {
        this->numberobj_33_value_setter(v);
        v = this->numberobj_33_value;
        number localvalue = v;
    
        if (this->numberobj_33_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("1.6kHz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_33_output_set(localvalue);
    }
    
    void eventinlet_17_out1_number_set(number v) {
        this->numberobj_33_value_set(v);
    }
    
    void linetilde_12_time_set(number v) {
        this->linetilde_12_time = v;
    }
    
    void linetilde_12_segments_set(const list& v) {
        this->linetilde_12_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_12_time == 0) {
                this->linetilde_12_activeRamps->length = 0;
                this->linetilde_12_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_12_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_12_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_12_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_12_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_12_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_12_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_12_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_12_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_12_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_12_activeRamps->push(lastRampValue);
                    this->linetilde_12_activeRamps->push(0);
                    this->linetilde_12_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_12_keepramp)) {
                            this->linetilde_12_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_12_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_12_activeRamps->push(destinationValue);
                    this->linetilde_12_activeRamps->push(inc);
                    this->linetilde_12_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void eventinlet_16_out1_number_set(number v) {
        {
            list converted = {v};
            this->linetilde_12_segments_set(converted);
        }
    }
    
    void linetilde_12_segments_bang() {
        list v = this->linetilde_12_segments;
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_12_time == 0) {
                this->linetilde_12_activeRamps->length = 0;
                this->linetilde_12_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_12_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_12_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_12_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_12_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_12_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_12_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_12_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_12_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_12_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_12_activeRamps->push(lastRampValue);
                    this->linetilde_12_activeRamps->push(0);
                    this->linetilde_12_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_12_keepramp)) {
                            this->linetilde_12_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_12_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_12_activeRamps->push(destinationValue);
                    this->linetilde_12_activeRamps->push(inc);
                    this->linetilde_12_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_33_value_bang() {
        number v = this->numberobj_33_value;
        number localvalue = v;
    
        if (this->numberobj_33_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("1.6kHz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_33_output_set(localvalue);
    }
    
    void message_03_set_set(const list& v) {
        this->message_03_set = jsCreateListCopy(v);
        this->getEngine()->sendListMessage(TAG("listout"), TAG("1.6kHz~/message_obj-33"), v, this->_currentTime);
    }
    
    void message_04_set_set(const list& v) {
        this->message_04_set = jsCreateListCopy(v);
        this->getEngine()->sendListMessage(TAG("listout"), TAG("1.6kHz~/message_obj-31"), v, this->_currentTime);
    }
    
    void linetilde_12_perform(SampleValue * out, Index n) {
        auto __linetilde_12_time = this->linetilde_12_time;
        auto __linetilde_12_keepramp = this->linetilde_12_keepramp;
        auto __linetilde_12_currentValue = this->linetilde_12_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_12_activeRamps->length)) {
            while ((bool)(this->linetilde_12_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_12_activeRamps[0];
                number inc = this->linetilde_12_activeRamps[1];
                number rampTimeInSamples = this->linetilde_12_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_12_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_12_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_12_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -1621164530,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_12_keepramp))) {
                            __linetilde_12_time = 0;
                        }
                    }
                }
    
                __linetilde_12_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_12_currentValue;
            i++;
        }
    
        this->linetilde_12_currentValue = __linetilde_12_currentValue;
        this->linetilde_12_time = __linetilde_12_time;
    }
    
    void linetilde_13_perform(SampleValue * out, Index n) {
        auto __linetilde_13_time = this->linetilde_13_time;
        auto __linetilde_13_keepramp = this->linetilde_13_keepramp;
        auto __linetilde_13_currentValue = this->linetilde_13_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_13_activeRamps->length)) {
            while ((bool)(this->linetilde_13_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_13_activeRamps[0];
                number inc = this->linetilde_13_activeRamps[1];
                number rampTimeInSamples = this->linetilde_13_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_13_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_13_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_13_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            1114681293,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_13_keepramp))) {
                            __linetilde_13_time = 0;
                        }
                    }
                }
    
                __linetilde_13_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_13_currentValue;
            i++;
        }
    
        this->linetilde_13_currentValue = __linetilde_13_currentValue;
        this->linetilde_13_time = __linetilde_13_time;
    }
    
    void p_07_perform(Index n) {
        // subpatcher: scale
        this->p_07->process(nullptr, 0, nullptr, 0, n);
    }
    
    void linetilde_14_perform(SampleValue * out, Index n) {
        auto __linetilde_14_time = this->linetilde_14_time;
        auto __linetilde_14_keepramp = this->linetilde_14_keepramp;
        auto __linetilde_14_currentValue = this->linetilde_14_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_14_activeRamps->length)) {
            while ((bool)(this->linetilde_14_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_14_activeRamps[0];
                number inc = this->linetilde_14_activeRamps[1];
                number rampTimeInSamples = this->linetilde_14_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_14_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_14_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_14_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -62043057,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_14_keepramp))) {
                            __linetilde_14_time = 0;
                        }
                    }
                }
    
                __linetilde_14_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_14_currentValue;
            i++;
        }
    
        this->linetilde_14_currentValue = __linetilde_14_currentValue;
        this->linetilde_14_time = __linetilde_14_time;
    }
    
    void numbertilde_01_perform(const SampleValue * input_signal, SampleValue * output, Index n) {
        auto __numbertilde_01_currentIntervalInSamples = this->numbertilde_01_currentIntervalInSamples;
        auto __numbertilde_01_lastValue = this->numbertilde_01_lastValue;
        auto __numbertilde_01_currentInterval = this->numbertilde_01_currentInterval;
        auto __numbertilde_01_rampInSamples = this->numbertilde_01_rampInSamples;
        auto __numbertilde_01_outValue = this->numbertilde_01_outValue;
        auto __numbertilde_01_currentMode = this->numbertilde_01_currentMode;
        number monitorvalue = input_signal[0];
    
        for (Index i = 0; i < n; i++) {
            if (__numbertilde_01_currentMode == 0) {
                output[(Index)i] = this->numbertilde_01_smooth_next(
                    __numbertilde_01_outValue,
                    __numbertilde_01_rampInSamples,
                    __numbertilde_01_rampInSamples
                );
            } else {
                output[(Index)i] = input_signal[(Index)i];
            }
        }
    
        __numbertilde_01_currentInterval -= n;
    
        if (monitorvalue != __numbertilde_01_lastValue && __numbertilde_01_currentInterval <= 0) {
            __numbertilde_01_currentInterval = __numbertilde_01_currentIntervalInSamples;
    
            this->getEngine()->scheduleClockEventWithValue(
                this,
                -1494586265,
                this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                monitorvalue
            );;
    
            __numbertilde_01_lastValue = monitorvalue;
    
            this->getEngine()->sendListMessage(
                TAG("monitor"),
                TAG("1.6kHz~/number~_obj-42"),
                {monitorvalue},
                this->_currentTime
            );;
        }
    
        this->numbertilde_01_currentInterval = __numbertilde_01_currentInterval;
        this->numbertilde_01_lastValue = __numbertilde_01_lastValue;
    }
    
    void filtercoeff_06_perform(
        number frequency,
        const Sample * gain,
        const Sample * q,
        SampleValue * a0,
        SampleValue * a1,
        SampleValue * a2,
        SampleValue * b1,
        SampleValue * b2,
        Index n
    ) {
        RNBO_UNUSED(frequency);
        auto __filtercoeff_06_activeResamp = this->filtercoeff_06_activeResamp;
        auto __filtercoeff_06_resamp_counter = this->filtercoeff_06_resamp_counter;
        auto __filtercoeff_06_K_EPSILON = this->filtercoeff_06_K_EPSILON;
    
        for (Index i = 0; i < n; i++) {
            number local_q = q[(Index)i];
            number local_gain = gain[(Index)i];
    
            if (local_gain < 0)
                local_gain = 0;
    
            number local_frequency = 1600;
    
            if (local_q < __filtercoeff_06_K_EPSILON)
                local_q = __filtercoeff_06_K_EPSILON;
    
            local_frequency = (local_frequency > this->sr * 0.5 ? this->sr * 0.5 : (local_frequency < 1 ? 1 : local_frequency));
            __filtercoeff_06_resamp_counter--;
    
            if (__filtercoeff_06_resamp_counter <= 0) {
                __filtercoeff_06_resamp_counter = __filtercoeff_06_activeResamp;
                this->filtercoeff_06_updateTerms(local_frequency, local_gain, local_q);
            }
    
            a0[(Index)i] = this->filtercoeff_06_la0;
            a1[(Index)i] = this->filtercoeff_06_la1;
            a2[(Index)i] = this->filtercoeff_06_la2;
            b1[(Index)i] = this->filtercoeff_06_lb1;
            b2[(Index)i] = this->filtercoeff_06_lb2;
        }
    
        this->filtercoeff_06_resamp_counter = __filtercoeff_06_resamp_counter;
    }
    
    void biquad_tilde_12_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_12_y2 = this->biquad_tilde_12_y2;
        auto __biquad_tilde_12_y1 = this->biquad_tilde_12_y1;
        auto __biquad_tilde_12_x2 = this->biquad_tilde_12_x2;
        auto __biquad_tilde_12_x1 = this->biquad_tilde_12_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_12_x1 * a1[(Index)i] + __biquad_tilde_12_x2 * a2[(Index)i] - (__biquad_tilde_12_y1 * b1[(Index)i] + __biquad_tilde_12_y2 * b2[(Index)i]);
            __biquad_tilde_12_x2 = __biquad_tilde_12_x1;
            __biquad_tilde_12_x1 = x[(Index)i];
            __biquad_tilde_12_y2 = __biquad_tilde_12_y1;
            __biquad_tilde_12_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_12_x1 = __biquad_tilde_12_x1;
        this->biquad_tilde_12_x2 = __biquad_tilde_12_x2;
        this->biquad_tilde_12_y1 = __biquad_tilde_12_y1;
        this->biquad_tilde_12_y2 = __biquad_tilde_12_y2;
    }
    
    void biquad_tilde_11_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_11_y2 = this->biquad_tilde_11_y2;
        auto __biquad_tilde_11_y1 = this->biquad_tilde_11_y1;
        auto __biquad_tilde_11_x2 = this->biquad_tilde_11_x2;
        auto __biquad_tilde_11_x1 = this->biquad_tilde_11_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_11_x1 * a1[(Index)i] + __biquad_tilde_11_x2 * a2[(Index)i] - (__biquad_tilde_11_y1 * b1[(Index)i] + __biquad_tilde_11_y2 * b2[(Index)i]);
            __biquad_tilde_11_x2 = __biquad_tilde_11_x1;
            __biquad_tilde_11_x1 = x[(Index)i];
            __biquad_tilde_11_y2 = __biquad_tilde_11_y1;
            __biquad_tilde_11_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_11_x1 = __biquad_tilde_11_x1;
        this->biquad_tilde_11_x2 = __biquad_tilde_11_x2;
        this->biquad_tilde_11_y1 = __biquad_tilde_11_y1;
        this->biquad_tilde_11_y2 = __biquad_tilde_11_y2;
    }
    
    void gen_05_perform(
        const Sample * in1,
        const Sample * in2,
        number in3,
        number in4,
        number in5,
        SampleValue * out1,
        SampleValue * out2,
        Index n
    ) {
        auto __gen_05_y1_r_value = this->gen_05_y1_r_value;
        auto __gen_05_x1_r_value = this->gen_05_x1_r_value;
        auto __gen_05_y1_l_value = this->gen_05_y1_l_value;
        auto __gen_05_x1_l_value = this->gen_05_x1_l_value;
        number drive_2 = in3;
        number asym_3 = in4;
        number is_cut_4 = in5;
        number morph_factor_5 = 0.25 + is_cut_4 * (0.6 - 0.25);
        number amount_6 = drive_2 * morph_factor_5;
        number bias_factor_7 = 0.08 + is_cut_4 * (0.12 - 0.08);
        number bias_8 = asym_3 * bias_factor_7;
        Index i;
    
        for (i = 0; i < n; i++) {
            number xin_l_0 = in1[(Index)i];
            number xin_r_1 = in2[(Index)i];
            number raw_l_9 = xin_l_0 + bias_8;
            number dirty_l_10 = rnbo_tanh(raw_l_9 * 0.6) * 1.6;
            number cubic_l_11 = dirty_l_10 * dirty_l_10 * dirty_l_10 / (number)3;
            number y_l_12 = xin_l_0 - amount_6 * cubic_l_11;
            number dc_l_13 = y_l_12 - __gen_05_x1_l_value + 0.9995 * __gen_05_y1_l_value;
            __gen_05_x1_l_value = y_l_12;
            __gen_05_y1_l_value = dc_l_13;
            number raw_r_14 = xin_r_1 + bias_8;
            number dirty_r_15 = rnbo_tanh(raw_r_14 * 0.6) * 1.6;
            number cubic_r_16 = dirty_r_15 * dirty_r_15 * dirty_r_15 / (number)3;
            number y_r_17 = xin_r_1 - amount_6 * cubic_r_16;
            number dc_r_18 = y_r_17 - __gen_05_x1_r_value + 0.9995 * __gen_05_y1_r_value;
            __gen_05_x1_r_value = y_r_17;
            __gen_05_y1_r_value = dc_r_18;
            number expr_1_19 = dc_l_13;
            number expr_2_20 = dc_r_18;
            out1[(Index)i] = expr_1_19;
            out2[(Index)i] = expr_2_20;
        }
    
        this->gen_05_x1_l_value = __gen_05_x1_l_value;
        this->gen_05_y1_l_value = __gen_05_y1_l_value;
        this->gen_05_x1_r_value = __gen_05_x1_r_value;
        this->gen_05_y1_r_value = __gen_05_y1_r_value;
    }
    
    void dspexpr_17_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void dspexpr_18_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void stackprotect_perform(Index n) {
        RNBO_UNUSED(n);
        auto __stackprotect_count = this->stackprotect_count;
        __stackprotect_count = 0;
        this->stackprotect_count = __stackprotect_count;
    }
    
    void numberobj_32_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_32_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_32_value = localvalue;
    }
    
    void numberobj_33_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_33_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_33_value = localvalue;
    }
    
    void numberobj_34_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_34_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_34_value = localvalue;
    }
    
    void biquad_tilde_11_reset() {
        this->biquad_tilde_11_x1 = 0;
        this->biquad_tilde_11_x2 = 0;
        this->biquad_tilde_11_y1 = 0;
        this->biquad_tilde_11_y2 = 0;
    }
    
    void biquad_tilde_11_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_11_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_11_reset();
        this->biquad_tilde_11_setupDone = true;
    }
    
    void biquad_tilde_12_reset() {
        this->biquad_tilde_12_x1 = 0;
        this->biquad_tilde_12_x2 = 0;
        this->biquad_tilde_12_y1 = 0;
        this->biquad_tilde_12_y2 = 0;
    }
    
    void biquad_tilde_12_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_12_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_12_reset();
        this->biquad_tilde_12_setupDone = true;
    }
    
    number gen_05_x1_l_getvalue() {
        return this->gen_05_x1_l_value;
    }
    
    void gen_05_x1_l_setvalue(number val) {
        this->gen_05_x1_l_value = val;
    }
    
    void gen_05_x1_l_reset() {
        this->gen_05_x1_l_value = 0;
    }
    
    void gen_05_x1_l_init() {
        this->gen_05_x1_l_value = 0;
    }
    
    number gen_05_y1_l_getvalue() {
        return this->gen_05_y1_l_value;
    }
    
    void gen_05_y1_l_setvalue(number val) {
        this->gen_05_y1_l_value = val;
    }
    
    void gen_05_y1_l_reset() {
        this->gen_05_y1_l_value = 0;
    }
    
    void gen_05_y1_l_init() {
        this->gen_05_y1_l_value = 0;
    }
    
    number gen_05_x1_r_getvalue() {
        return this->gen_05_x1_r_value;
    }
    
    void gen_05_x1_r_setvalue(number val) {
        this->gen_05_x1_r_value = val;
    }
    
    void gen_05_x1_r_reset() {
        this->gen_05_x1_r_value = 0;
    }
    
    void gen_05_x1_r_init() {
        this->gen_05_x1_r_value = 0;
    }
    
    number gen_05_y1_r_getvalue() {
        return this->gen_05_y1_r_value;
    }
    
    void gen_05_y1_r_setvalue(number val) {
        this->gen_05_y1_r_value = val;
    }
    
    void gen_05_y1_r_reset() {
        this->gen_05_y1_r_value = 0;
    }
    
    void gen_05_y1_r_init() {
        this->gen_05_y1_r_value = 0;
    }
    
    array<number, 5> filtercoeff_06_localop_next(number frequency, number q, number gain, number type) {
        number omega = frequency * this->filtercoeff_06_localop_twopi_over_sr;
        this->filtercoeff_06_localop_cs = rnbo_cos(omega);
        this->filtercoeff_06_localop_sn = rnbo_sin(omega);
        this->filtercoeff_06_localop_one_over_gain = (gain >= 0 ? (number)1 / gain : 0.0);
        this->filtercoeff_06_localop_one_over_q = (number)1 / q;
        this->filtercoeff_06_localop_alpha = this->filtercoeff_06_localop_sn * 0.5 * this->filtercoeff_06_localop_one_over_q;
    
        switch ((int)type) {
        case 5:
            {
            this->filtercoeff_06_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_06_localop_beta = this->safesqrt(
                (this->filtercoeff_06_localop_A * this->filtercoeff_06_localop_A + 1.) * this->filtercoeff_06_localop_one_over_q - (this->filtercoeff_06_localop_A - 1.) * (this->filtercoeff_06_localop_A - 1.)
            );
    
            this->filtercoeff_06_localop_b0 = (number)1 / (this->filtercoeff_06_localop_A + 1. + (this->filtercoeff_06_localop_A - 1.) * this->filtercoeff_06_localop_cs + this->filtercoeff_06_localop_beta * this->filtercoeff_06_localop_sn);
            break;
            }
        case 6:
            {
            this->filtercoeff_06_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_06_localop_beta = this->safesqrt(
                (this->filtercoeff_06_localop_A * this->filtercoeff_06_localop_A + 1.) * this->filtercoeff_06_localop_one_over_q - (this->filtercoeff_06_localop_A - 1.) * (this->filtercoeff_06_localop_A - 1.)
            );
    
            this->filtercoeff_06_localop_b0 = (number)1 / (this->filtercoeff_06_localop_A + 1. - (this->filtercoeff_06_localop_A - 1.) * this->filtercoeff_06_localop_cs + this->filtercoeff_06_localop_beta * this->filtercoeff_06_localop_sn);
            break;
            }
        case 4:
            {
            this->filtercoeff_06_localop_A = this->safesqrt(gain);
            this->filtercoeff_06_localop_one_over_a = (this->filtercoeff_06_localop_A == 0 ? 0 : (number)1 / this->filtercoeff_06_localop_A);
            this->filtercoeff_06_localop_b0 = (number)1 / (1. + this->filtercoeff_06_localop_alpha * this->filtercoeff_06_localop_one_over_a);
            break;
            }
        case 9:
        case 10:
        case 11:
        case 13:
        case 14:
            {
            this->filtercoeff_06_localop_b0 = (number)1 / (1. + this->filtercoeff_06_localop_alpha);
            this->filtercoeff_06_localop_b0g = (number)1 / (this->filtercoeff_06_localop_one_over_gain + this->filtercoeff_06_localop_alpha * this->filtercoeff_06_localop_one_over_gain);
            break;
            }
        default:
            {
            this->filtercoeff_06_localop_b0 = (number)1 / (1. + this->filtercoeff_06_localop_alpha);
            break;
            }
        }
    
        switch ((int)type) {
        case 0:
            {
            this->filtercoeff_06_localop_la0 = this->filtercoeff_06_localop_la2 = (1. - this->filtercoeff_06_localop_cs) * 0.5 * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la1 = (1. - this->filtercoeff_06_localop_cs) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0;
            break;
            }
        case 1:
            {
            this->filtercoeff_06_localop_la0 = this->filtercoeff_06_localop_la2 = (1. + this->filtercoeff_06_localop_cs) * 0.5 * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la1 = -(1. + this->filtercoeff_06_localop_cs) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0;
            break;
            }
        case 2:
            {
            this->filtercoeff_06_localop_la0 = this->filtercoeff_06_localop_alpha * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la1 = 0.;
            this->filtercoeff_06_localop_la2 = -this->filtercoeff_06_localop_alpha * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0;
            break;
            }
        case 7:
            {
            this->filtercoeff_06_localop_la0 = this->filtercoeff_06_localop_alpha * q * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la1 = 0.;
            this->filtercoeff_06_localop_la2 = -this->filtercoeff_06_localop_alpha * q * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0;
            break;
            }
        case 3:
            {
            this->filtercoeff_06_localop_la1 = this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la0 = this->filtercoeff_06_localop_la2 = this->filtercoeff_06_localop_b0;
            break;
            }
        case 8:
            {
            this->filtercoeff_06_localop_la1 = this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = this->filtercoeff_06_localop_la0 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la2 = 1.0;
            break;
            }
        case 4:
            {
            this->filtercoeff_06_localop_la0 = (1. + this->filtercoeff_06_localop_alpha * this->filtercoeff_06_localop_A) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la1 = this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la2 = (1. - this->filtercoeff_06_localop_alpha * this->filtercoeff_06_localop_A) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (1. - this->filtercoeff_06_localop_alpha * this->filtercoeff_06_localop_one_over_a) * this->filtercoeff_06_localop_b0;
            break;
            }
        case 5:
            {
            this->filtercoeff_06_localop_la0 = this->filtercoeff_06_localop_A * (this->filtercoeff_06_localop_A + 1. - (this->filtercoeff_06_localop_A - 1.) * this->filtercoeff_06_localop_cs + this->filtercoeff_06_localop_beta * this->filtercoeff_06_localop_sn) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la1 = 2. * this->filtercoeff_06_localop_A * (this->filtercoeff_06_localop_A - 1 - (this->filtercoeff_06_localop_A + 1) * this->filtercoeff_06_localop_cs) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la2 = this->filtercoeff_06_localop_A * (this->filtercoeff_06_localop_A + 1. - (this->filtercoeff_06_localop_A - 1.) * this->filtercoeff_06_localop_cs - this->filtercoeff_06_localop_beta * this->filtercoeff_06_localop_sn) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb1 = -2. * (this->filtercoeff_06_localop_A - 1. + (this->filtercoeff_06_localop_A + 1.) * this->filtercoeff_06_localop_cs) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (this->filtercoeff_06_localop_A + 1. + (this->filtercoeff_06_localop_A - 1.) * this->filtercoeff_06_localop_cs - this->filtercoeff_06_localop_beta * this->filtercoeff_06_localop_sn) * this->filtercoeff_06_localop_b0;
            break;
            }
        case 6:
            {
            this->filtercoeff_06_localop_la0 = this->filtercoeff_06_localop_A * (this->filtercoeff_06_localop_A + 1. + (this->filtercoeff_06_localop_A - 1.) * this->filtercoeff_06_localop_cs + this->filtercoeff_06_localop_beta * this->filtercoeff_06_localop_sn) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la1 = -2. * this->filtercoeff_06_localop_A * (this->filtercoeff_06_localop_A - 1. + (this->filtercoeff_06_localop_A + 1.) * this->filtercoeff_06_localop_cs) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la2 = this->filtercoeff_06_localop_A * (this->filtercoeff_06_localop_A + 1. + (this->filtercoeff_06_localop_A - 1.) * this->filtercoeff_06_localop_cs - this->filtercoeff_06_localop_beta * this->filtercoeff_06_localop_sn) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb1 = 2. * (this->filtercoeff_06_localop_A - 1. - (this->filtercoeff_06_localop_A + 1.) * this->filtercoeff_06_localop_cs) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (this->filtercoeff_06_localop_A + 1. - (this->filtercoeff_06_localop_A - 1.) * this->filtercoeff_06_localop_cs - this->filtercoeff_06_localop_beta * this->filtercoeff_06_localop_sn) * this->filtercoeff_06_localop_b0;
            break;
            }
        case 9:
            {
            this->filtercoeff_06_localop_b0g = (number)1 / (this->filtercoeff_06_localop_one_over_gain + this->filtercoeff_06_localop_alpha * this->filtercoeff_06_localop_one_over_gain);
            this->filtercoeff_06_localop_la0 = this->filtercoeff_06_localop_la2 = (1. - this->filtercoeff_06_localop_cs) * 0.5 * this->filtercoeff_06_localop_b0g;
            this->filtercoeff_06_localop_la1 = (1. - this->filtercoeff_06_localop_cs) * this->filtercoeff_06_localop_b0g;
            this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0;
            break;
            }
        case 10:
            {
            this->filtercoeff_06_localop_b0g = (number)1 / (this->filtercoeff_06_localop_one_over_gain + this->filtercoeff_06_localop_alpha * this->filtercoeff_06_localop_one_over_gain);
            this->filtercoeff_06_localop_la0 = this->filtercoeff_06_localop_la2 = (1. + this->filtercoeff_06_localop_cs) * 0.5 * this->filtercoeff_06_localop_b0g;
            this->filtercoeff_06_localop_la1 = -(1. + this->filtercoeff_06_localop_cs) * this->filtercoeff_06_localop_b0g;
            this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0;
            break;
            }
        case 11:
            {
            this->filtercoeff_06_localop_la0 = this->filtercoeff_06_localop_alpha * gain * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la1 = 0.;
            this->filtercoeff_06_localop_la2 = -this->filtercoeff_06_localop_alpha * gain * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0;
            break;
            }
        case 13:
            {
            this->filtercoeff_06_localop_la0 = this->filtercoeff_06_localop_alpha * gain * q * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la1 = 0.;
            this->filtercoeff_06_localop_la2 = -this->filtercoeff_06_localop_alpha * gain * q * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0;
            break;
            }
        case 12:
            {
            this->filtercoeff_06_localop_b0g = (number)1 / (this->filtercoeff_06_localop_one_over_gain + this->filtercoeff_06_localop_alpha * this->filtercoeff_06_localop_one_over_gain);
            this->filtercoeff_06_localop_la1 = this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs;
            this->filtercoeff_06_localop_lb2 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la1 *= this->filtercoeff_06_localop_b0g;
            this->filtercoeff_06_localop_lb1 *= this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_la0 = this->filtercoeff_06_localop_b0g;
            this->filtercoeff_06_localop_la2 = this->filtercoeff_06_localop_b0g;
            break;
            }
        case 14:
            {
            this->filtercoeff_06_localop_b0g = (number)1 / (this->filtercoeff_06_localop_one_over_gain + this->filtercoeff_06_localop_alpha * this->filtercoeff_06_localop_one_over_gain);
            this->filtercoeff_06_localop_la0 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0g;
            this->filtercoeff_06_localop_la1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0g;
            this->filtercoeff_06_localop_la2 = gain;
            this->filtercoeff_06_localop_lb1 = -2. * this->filtercoeff_06_localop_cs * this->filtercoeff_06_localop_b0;
            this->filtercoeff_06_localop_lb2 = (1. - this->filtercoeff_06_localop_alpha) * this->filtercoeff_06_localop_b0;
            break;
            }
        case 15:
            {
            this->filtercoeff_06_localop_la0 = 1;
            this->filtercoeff_06_localop_la1 = 0;
            this->filtercoeff_06_localop_la2 = 0;
            this->filtercoeff_06_localop_lb1 = 0;
            this->filtercoeff_06_localop_lb2 = 0;
            }
        default:
            {
            break;
            }
        }
    
        return {
            this->filtercoeff_06_localop_la0,
            this->filtercoeff_06_localop_la1,
            this->filtercoeff_06_localop_la2,
            this->filtercoeff_06_localop_lb1,
            this->filtercoeff_06_localop_lb2
        };
    }
    
    void filtercoeff_06_localop_dspsetup() {
        this->filtercoeff_06_localop_twopi_over_sr = (number)6.283185307179586 / this->sr;
    }
    
    void filtercoeff_06_localop_reset() {
        this->filtercoeff_06_localop_twopi_over_sr = 0;
        this->filtercoeff_06_localop_cs = 0;
        this->filtercoeff_06_localop_sn = 0;
        this->filtercoeff_06_localop_one_over_gain = 0;
        this->filtercoeff_06_localop_one_over_q = 0;
        this->filtercoeff_06_localop_alpha = 0;
        this->filtercoeff_06_localop_beta = 0;
        this->filtercoeff_06_localop_b0 = 0;
        this->filtercoeff_06_localop_b0g = 0;
        this->filtercoeff_06_localop_A = 0;
        this->filtercoeff_06_localop_one_over_a = 0;
        this->filtercoeff_06_localop_la0 = 0;
        this->filtercoeff_06_localop_la1 = 0;
        this->filtercoeff_06_localop_la2 = 0;
        this->filtercoeff_06_localop_lb1 = 0;
        this->filtercoeff_06_localop_lb2 = 0;
    }
    
    void filtercoeff_06_updateTerms(number local_frequency, number local_gain, number local_q) {
        if ((bool)(this->filtercoeff_06_force_update) || local_frequency != this->filtercoeff_06_last_frequency || local_q != this->filtercoeff_06_last_q || local_gain != this->filtercoeff_06_last_gain || this->filtercoeff_06_type != this->filtercoeff_06_last_type) {
            array<number, 5> tmp = this->filtercoeff_06_localop_next(local_frequency, local_q, local_gain, this->filtercoeff_06_type);
            this->filtercoeff_06_la0 = tmp[0];
            this->filtercoeff_06_la1 = tmp[1];
            this->filtercoeff_06_la2 = tmp[2];
            this->filtercoeff_06_lb1 = tmp[3];
            this->filtercoeff_06_lb2 = tmp[4];
            this->filtercoeff_06_last_frequency = local_frequency;
            this->filtercoeff_06_last_q = local_q;
            this->filtercoeff_06_last_gain = local_gain;
            this->filtercoeff_06_last_type = this->filtercoeff_06_type;
            this->filtercoeff_06_force_update = false;
        }
    }
    
    void filtercoeff_06_dspsetup(bool force) {
        if ((bool)(this->filtercoeff_06_setupDone) && (bool)(!(bool)(force)))
            return;
    
        {
            this->filtercoeff_06_activeResamp = this->vectorsize();
        }
    
        this->filtercoeff_06_resamp_counter = 0;
        this->filtercoeff_06_la0 = 0.;
        this->filtercoeff_06_la1 = 0.;
        this->filtercoeff_06_la2 = 0.;
        this->filtercoeff_06_lb1 = 0.;
        this->filtercoeff_06_lb2 = 0.;
        this->filtercoeff_06_last_frequency = -1.;
        this->filtercoeff_06_last_q = -1.;
        this->filtercoeff_06_last_gain = -1.;
        this->filtercoeff_06_last_type = this->filtercoeff_06_type;
        this->filtercoeff_06_force_update = true;
        this->filtercoeff_06_setupDone = true;
        this->filtercoeff_06_localop_dspsetup();
    }
    
    void numberobj_32_init() {
        this->numberobj_32_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("1.6kHz~/number_obj-3"), 1, this->_currentTime);
    }
    
    void numberobj_32_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_32_value;
    }
    
    void numberobj_32_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_32_value_set(preset["value"]);
    }
    
    void numberobj_33_init() {
        this->numberobj_33_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("1.6kHz~/number_obj-4"), 1, this->_currentTime);
    }
    
    void numberobj_33_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_33_value;
    }
    
    void numberobj_33_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_33_value_set(preset["value"]);
    }
    
    void change_02_init() {
        this->change_02_prev = this->change_02_input;
    }
    
    void message_03_init() {
        this->message_03_set_set({0.9});
    }
    
    void numberobj_34_init() {
        this->numberobj_34_currentFormat = 0;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("1.6kHz~/number_obj-8"), 1, this->_currentTime);
    }
    
    void numberobj_34_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_34_value;
    }
    
    void numberobj_34_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_34_value_set(preset["value"]);
    }
    
    number numbertilde_01_smooth_d_next(number x) {
        number temp = (number)(x - this->numbertilde_01_smooth_d_prev);
        this->numbertilde_01_smooth_d_prev = x;
        return temp;
    }
    
    void numbertilde_01_smooth_d_dspsetup() {
        this->numbertilde_01_smooth_d_reset();
    }
    
    void numbertilde_01_smooth_d_reset() {
        this->numbertilde_01_smooth_d_prev = 0;
    }
    
    number numbertilde_01_smooth_next(number x, number up, number down) {
        if (this->numbertilde_01_smooth_d_next(x) != 0.) {
            if (x > this->numbertilde_01_smooth_prev) {
                number _up = up;
    
                if (_up < 1)
                    _up = 1;
    
                this->numbertilde_01_smooth_index = _up;
                this->numbertilde_01_smooth_increment = (x - this->numbertilde_01_smooth_prev) / _up;
            } else if (x < this->numbertilde_01_smooth_prev) {
                number _down = down;
    
                if (_down < 1)
                    _down = 1;
    
                this->numbertilde_01_smooth_index = _down;
                this->numbertilde_01_smooth_increment = (x - this->numbertilde_01_smooth_prev) / _down;
            }
        }
    
        if (this->numbertilde_01_smooth_index > 0) {
            this->numbertilde_01_smooth_prev += this->numbertilde_01_smooth_increment;
            this->numbertilde_01_smooth_index -= 1;
        } else {
            this->numbertilde_01_smooth_prev = x;
        }
    
        return this->numbertilde_01_smooth_prev;
    }
    
    void numbertilde_01_smooth_reset() {
        this->numbertilde_01_smooth_prev = 0;
        this->numbertilde_01_smooth_index = 0;
        this->numbertilde_01_smooth_increment = 0;
        this->numbertilde_01_smooth_d_reset();
    }
    
    void numbertilde_01_init() {
        this->numbertilde_01_currentMode = 1;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("1.6kHz~/number~_obj-42"), 1, this->_currentTime);
    }
    
    void numbertilde_01_dspsetup(bool force) {
        if ((bool)(this->numbertilde_01_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->numbertilde_01_currentIntervalInSamples = this->mstosamps(100);
        this->numbertilde_01_currentInterval = this->numbertilde_01_currentIntervalInSamples;
        this->numbertilde_01_rampInSamples = this->mstosamps(this->numbertilde_01_ramp);
        this->numbertilde_01_setupDone = true;
        this->numbertilde_01_smooth_d_dspsetup();
    }
    
    void message_04_init() {
        this->message_04_set_set({1.2});
    }
    
    bool stackprotect_check() {
        this->stackprotect_count++;
    
        if (this->stackprotect_count > 128) {
            console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
            return true;
        }
    
        return false;
    }
    
    void updateTime(MillisecondTime time) {
        this->_currentTime = time;
        this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
    
        if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
            this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
    
        if (this->sampleOffsetIntoNextAudioBuffer < 0)
            this->sampleOffsetIntoNextAudioBuffer = 0;
    }
    
    void assign_defaults()
    {
        dspexpr_17_in1 = 0;
        dspexpr_17_in2 = 0;
        dspexpr_17_in3 = 0;
        biquad_tilde_11_x = 0;
        biquad_tilde_11_a0 = 0;
        biquad_tilde_11_a1 = 0;
        biquad_tilde_11_a2 = 0;
        biquad_tilde_11_b1 = 0;
        biquad_tilde_11_b2 = 0;
        linetilde_12_time = 10;
        linetilde_12_keepramp = 1;
        biquad_tilde_12_x = 0;
        biquad_tilde_12_a0 = 0;
        biquad_tilde_12_a1 = 0;
        biquad_tilde_12_a2 = 0;
        biquad_tilde_12_b1 = 0;
        biquad_tilde_12_b2 = 0;
        dspexpr_18_in1 = 0;
        dspexpr_18_in2 = 0;
        dspexpr_18_in3 = 0;
        gen_05_in1 = 0;
        gen_05_in2 = 0;
        gen_05_in3 = 0;
        gen_05_in4 = 0;
        gen_05_in5 = 0;
        filtercoeff_06_frequency = 1600;
        filtercoeff_06_gain = 1;
        filtercoeff_06_q = 1.2;
        filtercoeff_06_type = 4;
        numberobj_32_value = 0;
        numberobj_32_value_setter(numberobj_32_value);
        numberobj_33_value = 0;
        numberobj_33_value_setter(numberobj_33_value);
        expr_17_in1 = 0;
        expr_17_out1 = 0;
        linetilde_13_time = 10;
        linetilde_13_keepramp = 1;
        p_07_target = 0;
        change_02_input = 0;
        change_02_out = 0;
        select_02_test1 = 0;
        select_02_test2 = 1;
        numberobj_34_value = 0;
        numberobj_34_value_setter(numberobj_34_value);
        expr_18_in1 = 0;
        expr_18_in2 = 0;
        expr_18_out1 = 0;
        linetilde_14_time = 10;
        linetilde_14_keepramp = 1;
        numbertilde_01_input_number = 0;
        numbertilde_01_ramp = 0;
        _currentTime = 0;
        audioProcessSampleCount = 0;
        sampleOffsetIntoNextAudioBuffer = 0;
        zeroBuffer = nullptr;
        dummyBuffer = nullptr;
        signals[0] = nullptr;
        signals[1] = nullptr;
        signals[2] = nullptr;
        signals[3] = nullptr;
        signals[4] = nullptr;
        signals[5] = nullptr;
        signals[6] = nullptr;
        signals[7] = nullptr;
        didAllocateSignals = 0;
        vs = 0;
        maxvs = 0;
        sr = 44100;
        invsr = 0.00002267573696;
        biquad_tilde_11_x1 = 0;
        biquad_tilde_11_x2 = 0;
        biquad_tilde_11_y1 = 0;
        biquad_tilde_11_y2 = 0;
        biquad_tilde_11_setupDone = false;
        linetilde_12_currentValue = 0;
        biquad_tilde_12_x1 = 0;
        biquad_tilde_12_x2 = 0;
        biquad_tilde_12_y1 = 0;
        biquad_tilde_12_y2 = 0;
        biquad_tilde_12_setupDone = false;
        gen_05_x1_l_value = 0;
        gen_05_y1_l_value = 0;
        gen_05_x1_r_value = 0;
        gen_05_y1_r_value = 0;
        filtercoeff_06_K_EPSILON = 1e-9;
        filtercoeff_06_setupDone = false;
        numberobj_32_currentFormat = 6;
        numberobj_32_lastValue = 0;
        numberobj_33_currentFormat = 6;
        numberobj_33_lastValue = 0;
        linetilde_13_currentValue = 1;
        numberobj_34_currentFormat = 6;
        numberobj_34_lastValue = 0;
        linetilde_14_currentValue = 1;
        numbertilde_01_currentInterval = 0;
        numbertilde_01_currentIntervalInSamples = 0;
        numbertilde_01_lastValue = 0;
        numbertilde_01_outValue = 0;
        numbertilde_01_rampInSamples = 0;
        numbertilde_01_currentMode = 0;
        numbertilde_01_smooth_d_prev = 0;
        numbertilde_01_smooth_prev = 0;
        numbertilde_01_smooth_index = 0;
        numbertilde_01_smooth_increment = 0;
        numbertilde_01_setupDone = false;
        stackprotect_count = 0;
        _voiceIndex = 0;
        _noteNumber = 0;
        isMuted = 1;
        parameterOffset = 0;
    }
    
    // member variables
    
        number dspexpr_17_in1;
        number dspexpr_17_in2;
        number dspexpr_17_in3;
        number biquad_tilde_11_x;
        number biquad_tilde_11_a0;
        number biquad_tilde_11_a1;
        number biquad_tilde_11_a2;
        number biquad_tilde_11_b1;
        number biquad_tilde_11_b2;
        list linetilde_12_segments;
        number linetilde_12_time;
        number linetilde_12_keepramp;
        number biquad_tilde_12_x;
        number biquad_tilde_12_a0;
        number biquad_tilde_12_a1;
        number biquad_tilde_12_a2;
        number biquad_tilde_12_b1;
        number biquad_tilde_12_b2;
        number dspexpr_18_in1;
        number dspexpr_18_in2;
        number dspexpr_18_in3;
        number gen_05_in1;
        number gen_05_in2;
        number gen_05_in3;
        number gen_05_in4;
        number gen_05_in5;
        number filtercoeff_06_frequency;
        number filtercoeff_06_gain;
        number filtercoeff_06_q;
        Int filtercoeff_06_type;
        number numberobj_32_value;
        number numberobj_33_value;
        number expr_17_in1;
        number expr_17_out1;
        list linetilde_13_segments;
        number linetilde_13_time;
        number linetilde_13_keepramp;
        number p_07_target;
        number change_02_input;
        number change_02_out;
        list message_03_set;
        number select_02_test1;
        number select_02_test2;
        number numberobj_34_value;
        number expr_18_in1;
        number expr_18_in2;
        number expr_18_out1;
        list linetilde_14_segments;
        number linetilde_14_time;
        number linetilde_14_keepramp;
        number numbertilde_01_input_number;
        number numbertilde_01_ramp;
        list message_04_set;
        MillisecondTime _currentTime;
        UInt64 audioProcessSampleCount;
        SampleIndex sampleOffsetIntoNextAudioBuffer;
        signal zeroBuffer;
        signal dummyBuffer;
        SampleValue * signals[8];
        bool didAllocateSignals;
        Index vs;
        Index maxvs;
        number sr;
        number invsr;
        number biquad_tilde_11_x1;
        number biquad_tilde_11_x2;
        number biquad_tilde_11_y1;
        number biquad_tilde_11_y2;
        bool biquad_tilde_11_setupDone;
        list linetilde_12_activeRamps;
        number linetilde_12_currentValue;
        number biquad_tilde_12_x1;
        number biquad_tilde_12_x2;
        number biquad_tilde_12_y1;
        number biquad_tilde_12_y2;
        bool biquad_tilde_12_setupDone;
        number gen_05_x1_l_value;
        number gen_05_y1_l_value;
        number gen_05_x1_r_value;
        number gen_05_y1_r_value;
        number filtercoeff_06_resamp_counter;
        number filtercoeff_06_activeResamp;
        number filtercoeff_06_K_EPSILON;
        number filtercoeff_06_la0;
        number filtercoeff_06_la1;
        number filtercoeff_06_la2;
        number filtercoeff_06_lb1;
        number filtercoeff_06_lb2;
        number filtercoeff_06_last_frequency;
        number filtercoeff_06_last_q;
        number filtercoeff_06_last_gain;
        Int filtercoeff_06_last_type;
        bool filtercoeff_06_force_update;
        number filtercoeff_06_localop_twopi_over_sr;
        number filtercoeff_06_localop_cs;
        number filtercoeff_06_localop_sn;
        number filtercoeff_06_localop_one_over_gain;
        number filtercoeff_06_localop_one_over_q;
        number filtercoeff_06_localop_alpha;
        number filtercoeff_06_localop_beta;
        number filtercoeff_06_localop_b0;
        number filtercoeff_06_localop_b0g;
        number filtercoeff_06_localop_A;
        number filtercoeff_06_localop_one_over_a;
        number filtercoeff_06_localop_la0;
        number filtercoeff_06_localop_la1;
        number filtercoeff_06_localop_la2;
        number filtercoeff_06_localop_lb1;
        number filtercoeff_06_localop_lb2;
        bool filtercoeff_06_setupDone;
        Int numberobj_32_currentFormat;
        number numberobj_32_lastValue;
        Int numberobj_33_currentFormat;
        number numberobj_33_lastValue;
        list linetilde_13_activeRamps;
        number linetilde_13_currentValue;
        number change_02_prev;
        Int numberobj_34_currentFormat;
        number numberobj_34_lastValue;
        list linetilde_14_activeRamps;
        number linetilde_14_currentValue;
        SampleIndex numbertilde_01_currentInterval;
        SampleIndex numbertilde_01_currentIntervalInSamples;
        number numbertilde_01_lastValue;
        number numbertilde_01_outValue;
        number numbertilde_01_rampInSamples;
        Int numbertilde_01_currentMode;
        number numbertilde_01_smooth_d_prev;
        number numbertilde_01_smooth_prev;
        number numbertilde_01_smooth_index;
        number numbertilde_01_smooth_increment;
        bool numbertilde_01_setupDone;
        number stackprotect_count;
        Index _voiceIndex;
        Int _noteNumber;
        Index isMuted;
        ParameterIndex parameterOffset;
        RNBOSubpatcher_196* p_07;
    
};

class RNBOSubpatcher_206 : public PatcherInterfaceImpl {
    
    friend class Grafik7;
    
    public:
    
    class RNBOSubpatcher_197 : public PatcherInterfaceImpl {
            
            friend class RNBOSubpatcher_206;
            friend class Grafik7;
            
            public:
            
            RNBOSubpatcher_197()
            {
            }
            
            ~RNBOSubpatcher_197()
            {
            }
            
            virtual RNBOSubpatcher_206* getPatcher() const {
                return static_cast<RNBOSubpatcher_206 *>(_parentPatcher);
            }
            
            Grafik7* getTopLevelPatcher() {
                return this->getPatcher()->getTopLevelPatcher();
            }
            
            void cancelClockEvents()
            {
            }
            
            inline number safediv(number num, number denom) {
                return (denom == 0.0 ? 0.0 : num / denom);
            }
            
            number safepow(number base, number exponent) {
                return fixnan(rnbo_pow(base, exponent));
            }
            
            number scale(
                number x,
                number lowin,
                number hiin,
                number lowout,
                number highout,
                number pow
            ) {
                auto inscale = this->safediv(1., hiin - lowin);
                number outdiff = highout - lowout;
                number value = (x - lowin) * inscale;
            
                if (pow != 1) {
                    if (value > 0)
                        value = this->safepow(value, pow);
                    else
                        value = -this->safepow(-value, pow);
                }
            
                value = value * outdiff + lowout;
                return value;
            }
            
            Index getNumMidiInputPorts() const {
                return 0;
            }
            
            void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
            
            Index getNumMidiOutputPorts() const {
                return 0;
            }
            
            void process(
                const SampleValue * const* inputs,
                Index numInputs,
                SampleValue * const* outputs,
                Index numOutputs,
                Index n
            ) {
                RNBO_UNUSED(numOutputs);
                RNBO_UNUSED(outputs);
                RNBO_UNUSED(numInputs);
                RNBO_UNUSED(inputs);
                this->vs = n;
                this->updateTime(this->getEngine()->getCurrentTime());
                this->stackprotect_perform(n);
                this->audioProcessSampleCount += this->vs;
            }
            
            void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
                if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
                    this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
                    this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
                    this->didAllocateSignals = true;
                }
            
                const bool sampleRateChanged = sampleRate != this->sr;
                const bool maxvsChanged = maxBlockSize != this->maxvs;
                const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
            
                if (sampleRateChanged || maxvsChanged) {
                    this->vs = maxBlockSize;
                    this->maxvs = maxBlockSize;
                    this->sr = sampleRate;
                    this->invsr = 1 / sampleRate;
                }
            
                RNBO_UNUSED(forceDSPSetup);
            
                if (sampleRateChanged)
                    this->onSampleRateChanged(sampleRate);
            }
            
            void setProbingTarget(MessageTag id) {
                switch (id) {
                default:
                    {
                    this->setProbingIndex(-1);
                    break;
                    }
                }
            }
            
            void setProbingIndex(ProbingIndex ) {}
            
            Index getProbingChannels(MessageTag outletId) const {
                RNBO_UNUSED(outletId);
                return 0;
            }
            
            Index getIsMuted()  {
                return this->isMuted;
            }
            
            void setIsMuted(Index v)  {
                this->isMuted = v;
            }
            
            void onSampleRateChanged(double ) {}
            
            Index getPatcherSerial() const {
                return 0;
            }
            
            void getState(PatcherStateInterface& ) {}
            
            void setState() {}
            
            void getPreset(PatcherStateInterface& ) {}
            
            void setParameterValue(ParameterIndex , ParameterValue , MillisecondTime ) {}
            
            void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValue(index, value, time);
            }
            
            void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
                this->setParameterValue(index, this->getParameterValue(index), time);
            }
            
            void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValueNormalized(index, value, time);
            }
            
            ParameterValue getParameterValue(ParameterIndex index)  {
                switch (index) {
                default:
                    {
                    return 0;
                    }
                }
            }
            
            ParameterIndex getNumSignalInParameters() const {
                return 0;
            }
            
            ParameterIndex getNumSignalOutParameters() const {
                return 0;
            }
            
            ParameterIndex getNumParameters() const {
                return 0;
            }
            
            ConstCharPointer getParameterName(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            ConstCharPointer getParameterId(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            void getParameterInfo(ParameterIndex , ParameterInfo * ) const {}
            
            void sendParameter(ParameterIndex index, bool ignoreValue) {
                this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
            }
            
            void setParameterOffset(ParameterIndex offset) {
                this->parameterOffset = offset;
            }
            
            ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
                if (steps == 1) {
                    if (normalizedValue > 0) {
                        normalizedValue = 1.;
                    }
                } else {
                    ParameterValue oneStep = (number)1. / (steps - 1);
                    ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
                    normalizedValue = numberOfSteps * oneStep;
                }
            
                return normalizedValue;
            }
            
            ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                value = (value < 0 ? 0 : (value > 1 ? 1 : value));
            
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            void scheduleParamInit(ParameterIndex index, Index order) {
                this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
            }
            
            void processClockEvent(MillisecondTime , ClockId , bool , ParameterValue ) {}
            
            void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
            
            void processOutletEvent(
                EngineLink* sender,
                OutletIndex index,
                ParameterValue value,
                MillisecondTime time
            ) {
                this->updateTime(time);
                this->processOutletAtCurrentTime(sender, index, value);
            }
            
            void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
                this->updateTime(time);
            
                switch (tag) {
                case TAG("valin"):
                    {
                    if (TAG("800Hz~/scale/number_obj-34") == objectId)
                        this->numberobj_35_valin_set(payload);
            
                    if (TAG("800Hz~/scale/number_obj-32") == objectId)
                        this->numberobj_36_valin_set(payload);
            
                    if (TAG("800Hz~/scale/number_obj-38") == objectId)
                        this->numberobj_37_valin_set(payload);
            
                    if (TAG("800Hz~/scale/number_obj-55") == objectId)
                        this->numberobj_38_valin_set(payload);
            
                    break;
                    }
                case TAG("format"):
                    {
                    if (TAG("800Hz~/scale/number_obj-34") == objectId)
                        this->numberobj_35_format_set(payload);
            
                    if (TAG("800Hz~/scale/number_obj-32") == objectId)
                        this->numberobj_36_format_set(payload);
            
                    if (TAG("800Hz~/scale/number_obj-38") == objectId)
                        this->numberobj_37_format_set(payload);
            
                    if (TAG("800Hz~/scale/number_obj-55") == objectId)
                        this->numberobj_38_format_set(payload);
            
                    break;
                    }
                }
            }
            
            void processListMessage(MessageTag , MessageTag , MillisecondTime , const list& ) {}
            
            void processBangMessage(MessageTag , MessageTag , MillisecondTime ) {}
            
            MessageTagInfo resolveTag(MessageTag tag) const {
                switch (tag) {
                case TAG("valout"):
                    {
                    return "valout";
                    }
                case TAG("800Hz~/scale/number_obj-34"):
                    {
                    return "800Hz~/scale/number_obj-34";
                    }
                case TAG("setup"):
                    {
                    return "setup";
                    }
                case TAG("800Hz~/scale/number_obj-32"):
                    {
                    return "800Hz~/scale/number_obj-32";
                    }
                case TAG("800Hz~/scale/number_obj-38"):
                    {
                    return "800Hz~/scale/number_obj-38";
                    }
                case TAG("800Hz~/scale/number_obj-55"):
                    {
                    return "800Hz~/scale/number_obj-55";
                    }
                case TAG("valin"):
                    {
                    return "valin";
                    }
                case TAG("format"):
                    {
                    return "format";
                    }
                }
            
                return nullptr;
            }
            
            DataRef* getDataRef(DataRefIndex index)  {
                switch (index) {
                default:
                    {
                    return nullptr;
                    }
                }
            }
            
            DataRefIndex getNumDataRefs() const {
                return 0;
            }
            
            void fillDataRef(DataRefIndex , DataRef& ) {}
            
            void processDataViewUpdate(DataRefIndex , MillisecondTime ) {}
            
            void initialize() {
                this->assign_defaults();
                this->setState();
            }
            
            protected:
            
            void numberobj_35_valin_set(number v) {
                this->numberobj_35_value_set(v);
            }
            
            void numberobj_35_format_set(number v) {
                this->numberobj_35_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_36_valin_set(number v) {
                this->numberobj_36_value_set(v);
            }
            
            void numberobj_36_format_set(number v) {
                this->numberobj_36_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_37_valin_set(number v) {
                this->numberobj_37_value_set(v);
            }
            
            void numberobj_37_format_set(number v) {
                this->numberobj_37_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void eventinlet_18_out1_bang_bang() {
                this->expr_20_in1_bang();
                this->expr_19_in1_bang();
            }
            
            void eventinlet_18_out1_list_set(const list& v) {
                {
                    if (v->length > 1)
                        this->expr_20_in2_set(v[1]);
            
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_20_in1_set(converted);
                }
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_19_in1_set(converted);
                }
            }
            
            void numberobj_38_valin_set(number v) {
                this->numberobj_38_value_set(v);
            }
            
            void numberobj_38_format_set(number v) {
                this->numberobj_38_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            number msToSamps(MillisecondTime ms, number sampleRate) {
                return ms * sampleRate * 0.001;
            }
            
            MillisecondTime sampsToMs(SampleIndex samps) {
                return samps * (this->invsr * 1000);
            }
            
            Index getMaxBlockSize() const {
                return this->maxvs;
            }
            
            number getSampleRate() const {
                return this->sr;
            }
            
            bool hasFixedVectorSize() const {
                return false;
            }
            
            Index getNumInputChannels() const {
                return 0;
            }
            
            Index getNumOutputChannels() const {
                return 0;
            }
            
            void initializeObjects() {
                this->numberobj_35_init();
                this->numberobj_36_init();
                this->numberobj_37_init();
                this->numberobj_38_init();
            }
            
            void sendOutlet(OutletIndex index, ParameterValue value) {
                this->getEngine()->sendOutlet(this, index, value);
            }
            
            void startup() {}
            
            void allocateDataRefs() {}
            
            void eventoutlet_18_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_08_out3_number_set(v);
            }
            
            void numberobj_38_output_set(number v) {
                this->eventoutlet_18_in1_number_set(v);
            }
            
            void numberobj_38_value_set(number v) {
                this->numberobj_38_value_setter(v);
                v = this->numberobj_38_value;
                number localvalue = v;
            
                if (this->numberobj_38_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("800Hz~/scale/number_obj-55"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_38_output_set(localvalue);
            }
            
            void expr_20_out1_set(number v) {
                this->expr_20_out1 = v;
                this->numberobj_38_value_set(this->expr_20_out1);
            }
            
            void expr_20_in1_set(number in1) {
                this->expr_20_in1 = in1;
                this->expr_20_out1_set(this->expr_20_in1 < this->expr_20_in2);//#map:800Hz~/scale/<_obj-53:1
            }
            
            void eventoutlet_17_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_08_out2_number_set(v);
            }
            
            void numberobj_37_output_set(number v) {
                this->eventoutlet_17_in1_number_set(v);
            }
            
            void numberobj_37_value_set(number v) {
                this->numberobj_37_value_setter(v);
                v = this->numberobj_37_value;
                number localvalue = v;
            
                if (this->numberobj_37_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("800Hz~/scale/number_obj-38"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_37_output_set(localvalue);
            }
            
            void scale_12_out_set(const list& v) {
                this->scale_12_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_37_value_set(converted);
                }
            }
            
            void scale_12_input_set(const list& v) {
                this->scale_12_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_12_inlow,
                        this->scale_12_inhigh,
                        this->scale_12_outlow,
                        this->scale_12_outhigh,
                        this->scale_12_power
                    ));
                }
            
                this->scale_12_out_set(tmp);
            }
            
            void eventoutlet_16_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_08_out1_number_set(v);
            }
            
            void numberobj_35_output_set(number v) {
                this->eventoutlet_16_in1_number_set(v);
            }
            
            void numberobj_35_value_set(number v) {
                this->numberobj_35_value_setter(v);
                v = this->numberobj_35_value;
                number localvalue = v;
            
                if (this->numberobj_35_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("800Hz~/scale/number_obj-34"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_35_output_set(localvalue);
            }
            
            void scale_11_out_set(const list& v) {
                this->scale_11_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_35_value_set(converted);
                }
            }
            
            void scale_11_input_set(const list& v) {
                this->scale_11_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_11_inlow,
                        this->scale_11_inhigh,
                        this->scale_11_outlow,
                        this->scale_11_outhigh,
                        this->scale_11_power
                    ));
                }
            
                this->scale_11_out_set(tmp);
            }
            
            void numberobj_36_output_set(number v) {
                {
                    list converted = {v};
                    this->scale_12_input_set(converted);
                }
            
                {
                    list converted = {v};
                    this->scale_11_input_set(converted);
                }
            }
            
            void numberobj_36_value_set(number v) {
                this->numberobj_36_value_setter(v);
                v = this->numberobj_36_value;
                number localvalue = v;
            
                if (this->numberobj_36_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("800Hz~/scale/number_obj-32"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_36_output_set(localvalue);
            }
            
            void expr_19_out1_set(number v) {
                this->expr_19_out1 = v;
                this->numberobj_36_value_set(this->expr_19_out1);
            }
            
            void expr_19_in1_set(number in1) {
                this->expr_19_in1 = in1;
                this->expr_19_out1_set(rnbo_abs(this->expr_19_in1));//#map:800Hz~/scale/abs_obj-29:1
            }
            
            void eventinlet_18_out1_number_set(number v) {
                this->expr_20_in1_set(v);
                this->expr_19_in1_set(v);
            }
            
            void expr_20_in1_bang() {
                this->expr_20_out1_set(this->expr_20_in1 < this->expr_20_in2);//#map:800Hz~/scale/<_obj-53:1
            }
            
            void expr_19_in1_bang() {
                this->expr_19_out1_set(rnbo_abs(this->expr_19_in1));//#map:800Hz~/scale/abs_obj-29:1
            }
            
            void expr_20_in2_set(number v) {
                this->expr_20_in2 = v;
            }
            
            void stackprotect_perform(Index n) {
                RNBO_UNUSED(n);
                auto __stackprotect_count = this->stackprotect_count;
                __stackprotect_count = 0;
                this->stackprotect_count = __stackprotect_count;
            }
            
            void numberobj_35_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_35_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_35_value = localvalue;
            }
            
            void numberobj_36_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_36_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_36_value = localvalue;
            }
            
            void numberobj_37_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_37_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_37_value = localvalue;
            }
            
            void numberobj_38_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_38_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_38_value = localvalue;
            }
            
            void numberobj_35_init() {
                this->numberobj_35_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("800Hz~/scale/number_obj-34"), 1, this->_currentTime);
            }
            
            void numberobj_35_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_35_value;
            }
            
            void numberobj_35_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_35_value_set(preset["value"]);
            }
            
            void numberobj_36_init() {
                this->numberobj_36_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("800Hz~/scale/number_obj-32"), 1, this->_currentTime);
            }
            
            void numberobj_36_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_36_value;
            }
            
            void numberobj_36_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_36_value_set(preset["value"]);
            }
            
            void numberobj_37_init() {
                this->numberobj_37_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("800Hz~/scale/number_obj-38"), 1, this->_currentTime);
            }
            
            void numberobj_37_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_37_value;
            }
            
            void numberobj_37_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_37_value_set(preset["value"]);
            }
            
            void numberobj_38_init() {
                this->numberobj_38_currentFormat = 0;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("800Hz~/scale/number_obj-55"), 1, this->_currentTime);
            }
            
            void numberobj_38_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_38_value;
            }
            
            void numberobj_38_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_38_value_set(preset["value"]);
            }
            
            bool stackprotect_check() {
                this->stackprotect_count++;
            
                if (this->stackprotect_count > 128) {
                    console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
                    return true;
                }
            
                return false;
            }
            
            void updateTime(MillisecondTime time) {
                this->_currentTime = time;
                this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
            
                if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
                    this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
            
                if (this->sampleOffsetIntoNextAudioBuffer < 0)
                    this->sampleOffsetIntoNextAudioBuffer = 0;
            }
            
            void assign_defaults()
            {
                numberobj_35_value = 0;
                numberobj_35_value_setter(numberobj_35_value);
                numberobj_36_value = 0;
                numberobj_36_value_setter(numberobj_36_value);
                expr_19_in1 = 0;
                expr_19_out1 = 0;
                scale_11_inlow = 0;
                scale_11_inhigh = 12;
                scale_11_outlow = 0;
                scale_11_outhigh = 1;
                scale_11_power = 1;
                numberobj_37_value = 0;
                numberobj_37_value_setter(numberobj_37_value);
                scale_12_inlow = 0;
                scale_12_inhigh = 12;
                scale_12_outlow = 0;
                scale_12_outhigh = 1;
                scale_12_power = 0.5;
                numberobj_38_value = 0;
                numberobj_38_value_setter(numberobj_38_value);
                expr_20_in1 = 0;
                expr_20_in2 = 0;
                expr_20_out1 = 0;
                _currentTime = 0;
                audioProcessSampleCount = 0;
                sampleOffsetIntoNextAudioBuffer = 0;
                zeroBuffer = nullptr;
                dummyBuffer = nullptr;
                didAllocateSignals = 0;
                vs = 0;
                maxvs = 0;
                sr = 44100;
                invsr = 0.00002267573696;
                numberobj_35_currentFormat = 6;
                numberobj_35_lastValue = 0;
                numberobj_36_currentFormat = 6;
                numberobj_36_lastValue = 0;
                numberobj_37_currentFormat = 6;
                numberobj_37_lastValue = 0;
                numberobj_38_currentFormat = 6;
                numberobj_38_lastValue = 0;
                stackprotect_count = 0;
                _voiceIndex = 0;
                _noteNumber = 0;
                isMuted = 1;
                parameterOffset = 0;
            }
            
            // member variables
            
                number numberobj_35_value;
                number numberobj_36_value;
                number expr_19_in1;
                number expr_19_out1;
                list scale_11_input;
                number scale_11_inlow;
                number scale_11_inhigh;
                number scale_11_outlow;
                number scale_11_outhigh;
                number scale_11_power;
                list scale_11_out;
                number numberobj_37_value;
                list scale_12_input;
                number scale_12_inlow;
                number scale_12_inhigh;
                number scale_12_outlow;
                number scale_12_outhigh;
                number scale_12_power;
                list scale_12_out;
                number numberobj_38_value;
                number expr_20_in1;
                number expr_20_in2;
                number expr_20_out1;
                MillisecondTime _currentTime;
                UInt64 audioProcessSampleCount;
                SampleIndex sampleOffsetIntoNextAudioBuffer;
                signal zeroBuffer;
                signal dummyBuffer;
                bool didAllocateSignals;
                Index vs;
                Index maxvs;
                number sr;
                number invsr;
                Int numberobj_35_currentFormat;
                number numberobj_35_lastValue;
                Int numberobj_36_currentFormat;
                number numberobj_36_lastValue;
                Int numberobj_37_currentFormat;
                number numberobj_37_lastValue;
                Int numberobj_38_currentFormat;
                number numberobj_38_lastValue;
                number stackprotect_count;
                Index _voiceIndex;
                Int _noteNumber;
                Index isMuted;
                ParameterIndex parameterOffset;
            
    };
    
    RNBOSubpatcher_206()
    {
    }
    
    ~RNBOSubpatcher_206()
    {
        delete this->p_08;
    }
    
    virtual Grafik7* getPatcher() const {
        return static_cast<Grafik7 *>(_parentPatcher);
    }
    
    Grafik7* getTopLevelPatcher() {
        return this->getPatcher()->getTopLevelPatcher();
    }
    
    void cancelClockEvents()
    {
        getEngine()->flushClockEvents(this, -62043057, false);
        getEngine()->flushClockEvents(this, -1621164530, false);
    }
    
    SampleIndex currentsampletime() {
        return this->audioProcessSampleCount + this->sampleOffsetIntoNextAudioBuffer;
    }
    
    number mstosamps(MillisecondTime ms) {
        return ms * this->sr * 0.001;
    }
    
    inline number safesqrt(number num) {
        return (num > 0.0 ? rnbo_sqrt(num) : 0.0);
    }
    
    Index vectorsize() const {
        return this->vs;
    }
    
    Index getNumMidiInputPorts() const {
        return 0;
    }
    
    void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
    
    Index getNumMidiOutputPorts() const {
        return 0;
    }
    
    void process(
        const SampleValue * const* inputs,
        Index numInputs,
        SampleValue * const* outputs,
        Index numOutputs,
        Index n
    ) {
        this->vs = n;
        this->updateTime(this->getEngine()->getCurrentTime());
        SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
        SampleValue * out2 = (numOutputs >= 2 && outputs[1] ? outputs[1] : this->dummyBuffer);
        const SampleValue * in1 = (numInputs >= 1 && inputs[0] ? inputs[0] : this->zeroBuffer);
        const SampleValue * in2 = (numInputs >= 2 && inputs[1] ? inputs[1] : this->zeroBuffer);
        this->linetilde_15_perform(this->signals[0], n);
        this->linetilde_16_perform(this->signals[1], n);
    
        this->filtercoeff_07_perform(
            this->filtercoeff_07_frequency,
            this->signals[1],
            this->filtercoeff_07_q,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            n
        );
    
        this->biquad_tilde_14_perform(
            in2,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[1],
            n
        );
    
        this->biquad_tilde_13_perform(
            in1,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            n
        );
    
        this->gen_06_perform(
            this->signals[7],
            this->signals[1],
            this->gen_06_in3,
            this->gen_06_in4,
            this->gen_06_in5,
            this->signals[6],
            this->signals[5],
            n
        );
    
        this->dspexpr_19_perform(this->signals[7], this->signals[6], this->signals[0], out1, n);
        this->dspexpr_20_perform(this->signals[1], this->signals[5], this->signals[0], out2, n);
        this->p_08_perform(n);
        this->stackprotect_perform(n);
        this->audioProcessSampleCount += this->vs;
    }
    
    void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
        if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
            Index i;
    
            for (i = 0; i < 8; i++) {
                this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
            }
    
            this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
            this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
            this->didAllocateSignals = true;
        }
    
        const bool sampleRateChanged = sampleRate != this->sr;
        const bool maxvsChanged = maxBlockSize != this->maxvs;
        const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
    
        if (sampleRateChanged || maxvsChanged) {
            this->vs = maxBlockSize;
            this->maxvs = maxBlockSize;
            this->sr = sampleRate;
            this->invsr = 1 / sampleRate;
        }
    
        this->filtercoeff_07_dspsetup(forceDSPSetup);
        this->biquad_tilde_14_dspsetup(forceDSPSetup);
        this->biquad_tilde_13_dspsetup(forceDSPSetup);
        this->p_08->prepareToProcess(sampleRate, maxBlockSize, force);
    
        if (sampleRateChanged)
            this->onSampleRateChanged(sampleRate);
    }
    
    void setProbingTarget(MessageTag id) {
        switch (id) {
        default:
            {
            this->setProbingIndex(-1);
            break;
            }
        }
    }
    
    void setProbingIndex(ProbingIndex ) {}
    
    Index getProbingChannels(MessageTag outletId) const {
        RNBO_UNUSED(outletId);
        return 0;
    }
    
    Index getIsMuted()  {
        return this->isMuted;
    }
    
    void setIsMuted(Index v)  {
        this->isMuted = v;
    }
    
    void onSampleRateChanged(double ) {}
    
    Index getPatcherSerial() const {
        return 0;
    }
    
    void getState(PatcherStateInterface& ) {}
    
    void setState() {
        this->p_08 = new RNBOSubpatcher_197();
        this->p_08->setEngineAndPatcher(this->getEngine(), this);
        this->p_08->initialize();
        this->p_08->setParameterOffset(this->getParameterOffset(this->p_08));
    }
    
    void getPreset(PatcherStateInterface& preset) {
        this->p_08->getPreset(getSubState(getSubState(preset, "__sps"), "scale"));
    }
    
    void setParameterValue(ParameterIndex index, ParameterValue v, MillisecondTime time) {
        RNBO_UNUSED(v);
        this->updateTime(time);
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_08->getNumParameters())
                this->p_08->setParameterValue(index, v, time);
    
            break;
            }
        }
    }
    
    void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValue(index, value, time);
    }
    
    void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
        this->setParameterValue(index, this->getParameterValue(index), time);
    }
    
    void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValueNormalized(index, value, time);
    }
    
    ParameterValue getParameterValue(ParameterIndex index)  {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_08->getNumParameters())
                return this->p_08->getParameterValue(index);
    
            return 0;
            }
        }
    }
    
    ParameterIndex getNumSignalInParameters() const {
        return 0;
    }
    
    ParameterIndex getNumSignalOutParameters() const {
        return 0;
    }
    
    ParameterIndex getNumParameters() const {
        return 0 + this->p_08->getNumParameters();
    }
    
    ConstCharPointer getParameterName(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_08->getNumParameters())
                return this->p_08->getParameterName(index);
    
            return "bogus";
            }
        }
    }
    
    ConstCharPointer getParameterId(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_08->getNumParameters())
                return this->p_08->getParameterId(index);
    
            return "bogus";
            }
        }
    }
    
    void getParameterInfo(ParameterIndex index, ParameterInfo * info) const {
        {
            switch (index) {
            default:
                {
                index -= 0;
    
                if (index < this->p_08->getNumParameters())
                    this->p_08->getParameterInfo(index, info);
    
                break;
                }
            }
        }
    }
    
    void sendParameter(ParameterIndex index, bool ignoreValue) {
        this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
    }
    
    ParameterIndex getParameterOffset(BaseInterface* subpatcher) const {
        if (subpatcher == this->p_08)
            return 0;
    
        return 0;
    }
    
    void setParameterOffset(ParameterIndex offset) {
        this->parameterOffset = offset;
    }
    
    ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
        if (steps == 1) {
            if (normalizedValue > 0) {
                normalizedValue = 1.;
            }
        } else {
            ParameterValue oneStep = (number)1. / (steps - 1);
            ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
            normalizedValue = numberOfSteps * oneStep;
        }
    
        return normalizedValue;
    }
    
    ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_08->getNumParameters())
                return this->p_08->convertToNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        value = (value < 0 ? 0 : (value > 1 ? 1 : value));
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_08->getNumParameters())
                return this->p_08->convertFromNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_08->getNumParameters())
                return this->p_08->constrainParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    void scheduleParamInit(ParameterIndex index, Index order) {
        this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
    }
    
    void processClockEvent(MillisecondTime time, ClockId index, bool hasValue, ParameterValue value) {
        RNBO_UNUSED(value);
        RNBO_UNUSED(hasValue);
        this->updateTime(time);
    
        switch (index) {
        case -62043057:
            {
            this->linetilde_15_target_bang();
            break;
            }
        case -1621164530:
            {
            this->linetilde_16_target_bang();
            break;
            }
        }
    }
    
    void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
    
    void processOutletEvent(
        EngineLink* sender,
        OutletIndex index,
        ParameterValue value,
        MillisecondTime time
    ) {
        this->updateTime(time);
        this->processOutletAtCurrentTime(sender, index, value);
    }
    
    void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
        this->updateTime(time);
    
        switch (tag) {
        case TAG("valin"):
            {
            if (TAG("800Hz~/number_obj-3") == objectId)
                this->numberobj_39_valin_set(payload);
    
            if (TAG("800Hz~/number_obj-4") == objectId)
                this->numberobj_40_valin_set(payload);
    
            break;
            }
        case TAG("format"):
            {
            if (TAG("800Hz~/number_obj-3") == objectId)
                this->numberobj_39_format_set(payload);
    
            if (TAG("800Hz~/number_obj-4") == objectId)
                this->numberobj_40_format_set(payload);
    
            break;
            }
        }
    
        this->p_08->processNumMessage(tag, objectId, time, payload);
    }
    
    void processListMessage(
        MessageTag tag,
        MessageTag objectId,
        MillisecondTime time,
        const list& payload
    ) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_08->processListMessage(tag, objectId, time, payload);
    }
    
    void processBangMessage(MessageTag tag, MessageTag objectId, MillisecondTime time) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_08->processBangMessage(tag, objectId, time);
    }
    
    MessageTagInfo resolveTag(MessageTag tag) const {
        switch (tag) {
        case TAG("valout"):
            {
            return "valout";
            }
        case TAG("800Hz~/number_obj-3"):
            {
            return "800Hz~/number_obj-3";
            }
        case TAG("setup"):
            {
            return "setup";
            }
        case TAG("800Hz~/number_obj-4"):
            {
            return "800Hz~/number_obj-4";
            }
        case TAG("valin"):
            {
            return "valin";
            }
        case TAG("format"):
            {
            return "format";
            }
        }
    
        auto subpatchResult_0 = this->p_08->resolveTag(tag);
    
        if (subpatchResult_0)
            return subpatchResult_0;
    
        return nullptr;
    }
    
    DataRef* getDataRef(DataRefIndex index)  {
        switch (index) {
        default:
            {
            return nullptr;
            }
        }
    }
    
    DataRefIndex getNumDataRefs() const {
        return 0;
    }
    
    void fillDataRef(DataRefIndex , DataRef& ) {}
    
    void processDataViewUpdate(DataRefIndex index, MillisecondTime time) {
        this->p_08->processDataViewUpdate(index, time);
    }
    
    void initialize() {
        this->assign_defaults();
        this->setState();
    }
    
    protected:
    
    void eventinlet_19_out1_bang_bang() {
        this->linetilde_15_segments_bang();
    }
    
    void eventinlet_19_out1_list_set(const list& v) {
        this->linetilde_15_segments_set(v);
    }
    
    void eventinlet_20_out1_bang_bang() {
        this->numberobj_40_value_bang();
    }
    
    void eventinlet_20_out1_list_set(const list& v) {
        {
            number converted = (v->length > 0 ? v[0] : 0);
            this->numberobj_40_value_set(converted);
        }
    }
    
    void numberobj_39_valin_set(number v) {
        this->numberobj_39_value_set(v);
    }
    
    void numberobj_39_format_set(number v) {
        this->numberobj_39_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void numberobj_40_valin_set(number v) {
        this->numberobj_40_value_set(v);
    }
    
    void numberobj_40_format_set(number v) {
        this->numberobj_40_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void linetilde_15_target_bang() {}
    
    void linetilde_16_target_bang() {}
    
    number msToSamps(MillisecondTime ms, number sampleRate) {
        return ms * sampleRate * 0.001;
    }
    
    MillisecondTime sampsToMs(SampleIndex samps) {
        return samps * (this->invsr * 1000);
    }
    
    Index getMaxBlockSize() const {
        return this->maxvs;
    }
    
    number getSampleRate() const {
        return this->sr;
    }
    
    bool hasFixedVectorSize() const {
        return false;
    }
    
    Index getNumInputChannels() const {
        return 2;
    }
    
    Index getNumOutputChannels() const {
        return 2;
    }
    
    void initializeObjects() {
        this->gen_06_x1_l_init();
        this->gen_06_y1_l_init();
        this->gen_06_x1_r_init();
        this->gen_06_y1_r_init();
        this->numberobj_39_init();
        this->numberobj_40_init();
        this->p_08->initializeObjects();
    }
    
    void sendOutlet(OutletIndex index, ParameterValue value) {
        this->getEngine()->sendOutlet(this, index, value);
    }
    
    void startup() {
        this->updateTime(this->getEngine()->getCurrentTime());
        this->p_08->startup();
    }
    
    void allocateDataRefs() {
        this->p_08->allocateDataRefs();
    }
    
    void gen_06_in5_set(number v) {
        this->gen_06_in5 = v;
    }
    
    void p_08_out3_number_set(number v) {
        this->gen_06_in5_set(v);
    }
    
    void gen_06_in4_set(number v) {
        this->gen_06_in4 = v;
    }
    
    void p_08_out2_number_set(number v) {
        this->gen_06_in4_set(v);
    }
    
    void gen_06_in3_set(number v) {
        this->gen_06_in3 = v;
    }
    
    void p_08_out1_number_set(number v) {
        this->gen_06_in3_set(v);
    }
    
    void p_08_in1_number_set(number v) {
        this->p_08->updateTime(this->_currentTime);
        this->p_08->eventinlet_18_out1_number_set(v);
    }
    
    void linetilde_16_time_set(number v) {
        this->linetilde_16_time = v;
    }
    
    void linetilde_16_segments_set(const list& v) {
        this->linetilde_16_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_16_time == 0) {
                this->linetilde_16_activeRamps->length = 0;
                this->linetilde_16_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_16_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_16_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_16_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_16_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_16_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_16_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_16_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_16_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_16_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_16_activeRamps->push(lastRampValue);
                    this->linetilde_16_activeRamps->push(0);
                    this->linetilde_16_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_16_keepramp)) {
                            this->linetilde_16_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_16_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_16_activeRamps->push(destinationValue);
                    this->linetilde_16_activeRamps->push(inc);
                    this->linetilde_16_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_39_output_set(number v) {
        {
            list converted = {v};
            this->linetilde_16_segments_set(converted);
        }
    }
    
    void numberobj_39_value_set(number v) {
        this->numberobj_39_value_setter(v);
        v = this->numberobj_39_value;
        number localvalue = v;
    
        if (this->numberobj_39_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("800Hz~/number_obj-3"), localvalue, this->_currentTime);
        this->numberobj_39_output_set(localvalue);
    }
    
    void expr_21_out1_set(number v) {
        this->expr_21_out1 = v;
        this->numberobj_39_value_set(this->expr_21_out1);
    }
    
    void expr_21_in1_set(number in1) {
        this->expr_21_in1 = in1;
        this->expr_21_out1_set(rnbo_pow(10, this->expr_21_in1 * 0.05));//#map:800Hz~/dbtoa_obj-9:1
    }
    
    void numberobj_40_output_set(number v) {
        this->p_08_in1_number_set(v);
        this->expr_21_in1_set(v);
    }
    
    void numberobj_40_value_set(number v) {
        this->numberobj_40_value_setter(v);
        v = this->numberobj_40_value;
        number localvalue = v;
    
        if (this->numberobj_40_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("800Hz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_40_output_set(localvalue);
    }
    
    void eventinlet_20_out1_number_set(number v) {
        this->numberobj_40_value_set(v);
    }
    
    void linetilde_15_time_set(number v) {
        this->linetilde_15_time = v;
    }
    
    void linetilde_15_segments_set(const list& v) {
        this->linetilde_15_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_15_time == 0) {
                this->linetilde_15_activeRamps->length = 0;
                this->linetilde_15_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_15_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_15_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_15_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_15_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_15_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_15_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_15_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_15_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_15_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_15_activeRamps->push(lastRampValue);
                    this->linetilde_15_activeRamps->push(0);
                    this->linetilde_15_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_15_keepramp)) {
                            this->linetilde_15_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_15_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_15_activeRamps->push(destinationValue);
                    this->linetilde_15_activeRamps->push(inc);
                    this->linetilde_15_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void eventinlet_19_out1_number_set(number v) {
        {
            list converted = {v};
            this->linetilde_15_segments_set(converted);
        }
    }
    
    void linetilde_15_segments_bang() {
        list v = this->linetilde_15_segments;
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_15_time == 0) {
                this->linetilde_15_activeRamps->length = 0;
                this->linetilde_15_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_15_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_15_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_15_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_15_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_15_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_15_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_15_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_15_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_15_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_15_activeRamps->push(lastRampValue);
                    this->linetilde_15_activeRamps->push(0);
                    this->linetilde_15_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_15_keepramp)) {
                            this->linetilde_15_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_15_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_15_activeRamps->push(destinationValue);
                    this->linetilde_15_activeRamps->push(inc);
                    this->linetilde_15_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_40_value_bang() {
        number v = this->numberobj_40_value;
        number localvalue = v;
    
        if (this->numberobj_40_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("800Hz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_40_output_set(localvalue);
    }
    
    void linetilde_15_perform(SampleValue * out, Index n) {
        auto __linetilde_15_time = this->linetilde_15_time;
        auto __linetilde_15_keepramp = this->linetilde_15_keepramp;
        auto __linetilde_15_currentValue = this->linetilde_15_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_15_activeRamps->length)) {
            while ((bool)(this->linetilde_15_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_15_activeRamps[0];
                number inc = this->linetilde_15_activeRamps[1];
                number rampTimeInSamples = this->linetilde_15_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_15_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_15_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_15_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -62043057,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_15_keepramp))) {
                            __linetilde_15_time = 0;
                        }
                    }
                }
    
                __linetilde_15_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_15_currentValue;
            i++;
        }
    
        this->linetilde_15_currentValue = __linetilde_15_currentValue;
        this->linetilde_15_time = __linetilde_15_time;
    }
    
    void linetilde_16_perform(SampleValue * out, Index n) {
        auto __linetilde_16_time = this->linetilde_16_time;
        auto __linetilde_16_keepramp = this->linetilde_16_keepramp;
        auto __linetilde_16_currentValue = this->linetilde_16_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_16_activeRamps->length)) {
            while ((bool)(this->linetilde_16_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_16_activeRamps[0];
                number inc = this->linetilde_16_activeRamps[1];
                number rampTimeInSamples = this->linetilde_16_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_16_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_16_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_16_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -1621164530,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_16_keepramp))) {
                            __linetilde_16_time = 0;
                        }
                    }
                }
    
                __linetilde_16_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_16_currentValue;
            i++;
        }
    
        this->linetilde_16_currentValue = __linetilde_16_currentValue;
        this->linetilde_16_time = __linetilde_16_time;
    }
    
    void filtercoeff_07_perform(
        number frequency,
        const Sample * gain,
        number q,
        SampleValue * a0,
        SampleValue * a1,
        SampleValue * a2,
        SampleValue * b1,
        SampleValue * b2,
        Index n
    ) {
        RNBO_UNUSED(q);
        RNBO_UNUSED(frequency);
        auto __filtercoeff_07_activeResamp = this->filtercoeff_07_activeResamp;
        auto __filtercoeff_07_resamp_counter = this->filtercoeff_07_resamp_counter;
        auto __filtercoeff_07_K_EPSILON = this->filtercoeff_07_K_EPSILON;
    
        for (Index i = 0; i < n; i++) {
            number local_q = 1;
            number local_gain = gain[(Index)i];
    
            if (local_gain < 0)
                local_gain = 0;
    
            number local_frequency = 800;
    
            if (local_q < __filtercoeff_07_K_EPSILON)
                local_q = __filtercoeff_07_K_EPSILON;
    
            local_frequency = (local_frequency > this->sr * 0.5 ? this->sr * 0.5 : (local_frequency < 1 ? 1 : local_frequency));
            __filtercoeff_07_resamp_counter--;
    
            if (__filtercoeff_07_resamp_counter <= 0) {
                __filtercoeff_07_resamp_counter = __filtercoeff_07_activeResamp;
                this->filtercoeff_07_updateTerms(local_frequency, local_gain, local_q);
            }
    
            a0[(Index)i] = this->filtercoeff_07_la0;
            a1[(Index)i] = this->filtercoeff_07_la1;
            a2[(Index)i] = this->filtercoeff_07_la2;
            b1[(Index)i] = this->filtercoeff_07_lb1;
            b2[(Index)i] = this->filtercoeff_07_lb2;
        }
    
        this->filtercoeff_07_resamp_counter = __filtercoeff_07_resamp_counter;
    }
    
    void biquad_tilde_14_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_14_y2 = this->biquad_tilde_14_y2;
        auto __biquad_tilde_14_y1 = this->biquad_tilde_14_y1;
        auto __biquad_tilde_14_x2 = this->biquad_tilde_14_x2;
        auto __biquad_tilde_14_x1 = this->biquad_tilde_14_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_14_x1 * a1[(Index)i] + __biquad_tilde_14_x2 * a2[(Index)i] - (__biquad_tilde_14_y1 * b1[(Index)i] + __biquad_tilde_14_y2 * b2[(Index)i]);
            __biquad_tilde_14_x2 = __biquad_tilde_14_x1;
            __biquad_tilde_14_x1 = x[(Index)i];
            __biquad_tilde_14_y2 = __biquad_tilde_14_y1;
            __biquad_tilde_14_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_14_x1 = __biquad_tilde_14_x1;
        this->biquad_tilde_14_x2 = __biquad_tilde_14_x2;
        this->biquad_tilde_14_y1 = __biquad_tilde_14_y1;
        this->biquad_tilde_14_y2 = __biquad_tilde_14_y2;
    }
    
    void biquad_tilde_13_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_13_y2 = this->biquad_tilde_13_y2;
        auto __biquad_tilde_13_y1 = this->biquad_tilde_13_y1;
        auto __biquad_tilde_13_x2 = this->biquad_tilde_13_x2;
        auto __biquad_tilde_13_x1 = this->biquad_tilde_13_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_13_x1 * a1[(Index)i] + __biquad_tilde_13_x2 * a2[(Index)i] - (__biquad_tilde_13_y1 * b1[(Index)i] + __biquad_tilde_13_y2 * b2[(Index)i]);
            __biquad_tilde_13_x2 = __biquad_tilde_13_x1;
            __biquad_tilde_13_x1 = x[(Index)i];
            __biquad_tilde_13_y2 = __biquad_tilde_13_y1;
            __biquad_tilde_13_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_13_x1 = __biquad_tilde_13_x1;
        this->biquad_tilde_13_x2 = __biquad_tilde_13_x2;
        this->biquad_tilde_13_y1 = __biquad_tilde_13_y1;
        this->biquad_tilde_13_y2 = __biquad_tilde_13_y2;
    }
    
    void gen_06_perform(
        const Sample * in1,
        const Sample * in2,
        number in3,
        number in4,
        number in5,
        SampleValue * out1,
        SampleValue * out2,
        Index n
    ) {
        auto __gen_06_y1_r_value = this->gen_06_y1_r_value;
        auto __gen_06_x1_r_value = this->gen_06_x1_r_value;
        auto __gen_06_y1_l_value = this->gen_06_y1_l_value;
        auto __gen_06_x1_l_value = this->gen_06_x1_l_value;
        number drive_2 = in3;
        number asym_3 = in4;
        number is_cut_4 = in5;
        number morph_factor_5 = 0.2 + is_cut_4 * (0.45 - 0.2);
        number amount_6 = drive_2 * morph_factor_5;
        number bias_factor_7 = 0.06 + is_cut_4 * (0.1 - 0.06);
        number bias_8 = asym_3 * bias_factor_7;
        Index i;
    
        for (i = 0; i < n; i++) {
            number xin_l_0 = in1[(Index)i];
            number xin_r_1 = in2[(Index)i];
            number raw_l_9 = xin_l_0 + bias_8;
            number dirty_l_10 = rnbo_tanh(raw_l_9 * 0.6) * 1.6;
            number cubic_l_11 = dirty_l_10 * dirty_l_10 * dirty_l_10 / (number)3;
            number y_l_12 = xin_l_0 - amount_6 * cubic_l_11;
            number dc_l_13 = y_l_12 - __gen_06_x1_l_value + 0.9995 * __gen_06_y1_l_value;
            __gen_06_x1_l_value = y_l_12;
            __gen_06_y1_l_value = dc_l_13;
            number raw_r_14 = xin_r_1 + bias_8;
            number dirty_r_15 = rnbo_tanh(raw_r_14 * 0.6) * 1.6;
            number cubic_r_16 = dirty_r_15 * dirty_r_15 * dirty_r_15 / (number)3;
            number y_r_17 = xin_r_1 - amount_6 * cubic_r_16;
            number dc_r_18 = y_r_17 - __gen_06_x1_r_value + 0.9995 * __gen_06_y1_r_value;
            __gen_06_x1_r_value = y_r_17;
            __gen_06_y1_r_value = dc_r_18;
            number expr_1_19 = dc_l_13;
            number expr_2_20 = dc_r_18;
            out1[(Index)i] = expr_1_19;
            out2[(Index)i] = expr_2_20;
        }
    
        this->gen_06_x1_l_value = __gen_06_x1_l_value;
        this->gen_06_y1_l_value = __gen_06_y1_l_value;
        this->gen_06_x1_r_value = __gen_06_x1_r_value;
        this->gen_06_y1_r_value = __gen_06_y1_r_value;
    }
    
    void dspexpr_19_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void dspexpr_20_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void p_08_perform(Index n) {
        // subpatcher: scale
        this->p_08->process(nullptr, 0, nullptr, 0, n);
    }
    
    void stackprotect_perform(Index n) {
        RNBO_UNUSED(n);
        auto __stackprotect_count = this->stackprotect_count;
        __stackprotect_count = 0;
        this->stackprotect_count = __stackprotect_count;
    }
    
    void numberobj_39_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_39_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_39_value = localvalue;
    }
    
    void numberobj_40_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_40_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_40_value = localvalue;
    }
    
    void biquad_tilde_13_reset() {
        this->biquad_tilde_13_x1 = 0;
        this->biquad_tilde_13_x2 = 0;
        this->biquad_tilde_13_y1 = 0;
        this->biquad_tilde_13_y2 = 0;
    }
    
    void biquad_tilde_13_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_13_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_13_reset();
        this->biquad_tilde_13_setupDone = true;
    }
    
    void biquad_tilde_14_reset() {
        this->biquad_tilde_14_x1 = 0;
        this->biquad_tilde_14_x2 = 0;
        this->biquad_tilde_14_y1 = 0;
        this->biquad_tilde_14_y2 = 0;
    }
    
    void biquad_tilde_14_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_14_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_14_reset();
        this->biquad_tilde_14_setupDone = true;
    }
    
    number gen_06_x1_l_getvalue() {
        return this->gen_06_x1_l_value;
    }
    
    void gen_06_x1_l_setvalue(number val) {
        this->gen_06_x1_l_value = val;
    }
    
    void gen_06_x1_l_reset() {
        this->gen_06_x1_l_value = 0;
    }
    
    void gen_06_x1_l_init() {
        this->gen_06_x1_l_value = 0;
    }
    
    number gen_06_y1_l_getvalue() {
        return this->gen_06_y1_l_value;
    }
    
    void gen_06_y1_l_setvalue(number val) {
        this->gen_06_y1_l_value = val;
    }
    
    void gen_06_y1_l_reset() {
        this->gen_06_y1_l_value = 0;
    }
    
    void gen_06_y1_l_init() {
        this->gen_06_y1_l_value = 0;
    }
    
    number gen_06_x1_r_getvalue() {
        return this->gen_06_x1_r_value;
    }
    
    void gen_06_x1_r_setvalue(number val) {
        this->gen_06_x1_r_value = val;
    }
    
    void gen_06_x1_r_reset() {
        this->gen_06_x1_r_value = 0;
    }
    
    void gen_06_x1_r_init() {
        this->gen_06_x1_r_value = 0;
    }
    
    number gen_06_y1_r_getvalue() {
        return this->gen_06_y1_r_value;
    }
    
    void gen_06_y1_r_setvalue(number val) {
        this->gen_06_y1_r_value = val;
    }
    
    void gen_06_y1_r_reset() {
        this->gen_06_y1_r_value = 0;
    }
    
    void gen_06_y1_r_init() {
        this->gen_06_y1_r_value = 0;
    }
    
    array<number, 5> filtercoeff_07_localop_next(number frequency, number q, number gain, number type) {
        number omega = frequency * this->filtercoeff_07_localop_twopi_over_sr;
        this->filtercoeff_07_localop_cs = rnbo_cos(omega);
        this->filtercoeff_07_localop_sn = rnbo_sin(omega);
        this->filtercoeff_07_localop_one_over_gain = (gain >= 0 ? (number)1 / gain : 0.0);
        this->filtercoeff_07_localop_one_over_q = (number)1 / q;
        this->filtercoeff_07_localop_alpha = this->filtercoeff_07_localop_sn * 0.5 * this->filtercoeff_07_localop_one_over_q;
    
        switch ((int)type) {
        case 5:
            {
            this->filtercoeff_07_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_07_localop_beta = this->safesqrt(
                (this->filtercoeff_07_localop_A * this->filtercoeff_07_localop_A + 1.) * this->filtercoeff_07_localop_one_over_q - (this->filtercoeff_07_localop_A - 1.) * (this->filtercoeff_07_localop_A - 1.)
            );
    
            this->filtercoeff_07_localop_b0 = (number)1 / (this->filtercoeff_07_localop_A + 1. + (this->filtercoeff_07_localop_A - 1.) * this->filtercoeff_07_localop_cs + this->filtercoeff_07_localop_beta * this->filtercoeff_07_localop_sn);
            break;
            }
        case 6:
            {
            this->filtercoeff_07_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_07_localop_beta = this->safesqrt(
                (this->filtercoeff_07_localop_A * this->filtercoeff_07_localop_A + 1.) * this->filtercoeff_07_localop_one_over_q - (this->filtercoeff_07_localop_A - 1.) * (this->filtercoeff_07_localop_A - 1.)
            );
    
            this->filtercoeff_07_localop_b0 = (number)1 / (this->filtercoeff_07_localop_A + 1. - (this->filtercoeff_07_localop_A - 1.) * this->filtercoeff_07_localop_cs + this->filtercoeff_07_localop_beta * this->filtercoeff_07_localop_sn);
            break;
            }
        case 4:
            {
            this->filtercoeff_07_localop_A = this->safesqrt(gain);
            this->filtercoeff_07_localop_one_over_a = (this->filtercoeff_07_localop_A == 0 ? 0 : (number)1 / this->filtercoeff_07_localop_A);
            this->filtercoeff_07_localop_b0 = (number)1 / (1. + this->filtercoeff_07_localop_alpha * this->filtercoeff_07_localop_one_over_a);
            break;
            }
        case 9:
        case 10:
        case 11:
        case 13:
        case 14:
            {
            this->filtercoeff_07_localop_b0 = (number)1 / (1. + this->filtercoeff_07_localop_alpha);
            this->filtercoeff_07_localop_b0g = (number)1 / (this->filtercoeff_07_localop_one_over_gain + this->filtercoeff_07_localop_alpha * this->filtercoeff_07_localop_one_over_gain);
            break;
            }
        default:
            {
            this->filtercoeff_07_localop_b0 = (number)1 / (1. + this->filtercoeff_07_localop_alpha);
            break;
            }
        }
    
        switch ((int)type) {
        case 0:
            {
            this->filtercoeff_07_localop_la0 = this->filtercoeff_07_localop_la2 = (1. - this->filtercoeff_07_localop_cs) * 0.5 * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la1 = (1. - this->filtercoeff_07_localop_cs) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0;
            break;
            }
        case 1:
            {
            this->filtercoeff_07_localop_la0 = this->filtercoeff_07_localop_la2 = (1. + this->filtercoeff_07_localop_cs) * 0.5 * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la1 = -(1. + this->filtercoeff_07_localop_cs) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0;
            break;
            }
        case 2:
            {
            this->filtercoeff_07_localop_la0 = this->filtercoeff_07_localop_alpha * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la1 = 0.;
            this->filtercoeff_07_localop_la2 = -this->filtercoeff_07_localop_alpha * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0;
            break;
            }
        case 7:
            {
            this->filtercoeff_07_localop_la0 = this->filtercoeff_07_localop_alpha * q * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la1 = 0.;
            this->filtercoeff_07_localop_la2 = -this->filtercoeff_07_localop_alpha * q * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0;
            break;
            }
        case 3:
            {
            this->filtercoeff_07_localop_la1 = this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la0 = this->filtercoeff_07_localop_la2 = this->filtercoeff_07_localop_b0;
            break;
            }
        case 8:
            {
            this->filtercoeff_07_localop_la1 = this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = this->filtercoeff_07_localop_la0 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la2 = 1.0;
            break;
            }
        case 4:
            {
            this->filtercoeff_07_localop_la0 = (1. + this->filtercoeff_07_localop_alpha * this->filtercoeff_07_localop_A) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la1 = this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la2 = (1. - this->filtercoeff_07_localop_alpha * this->filtercoeff_07_localop_A) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (1. - this->filtercoeff_07_localop_alpha * this->filtercoeff_07_localop_one_over_a) * this->filtercoeff_07_localop_b0;
            break;
            }
        case 5:
            {
            this->filtercoeff_07_localop_la0 = this->filtercoeff_07_localop_A * (this->filtercoeff_07_localop_A + 1. - (this->filtercoeff_07_localop_A - 1.) * this->filtercoeff_07_localop_cs + this->filtercoeff_07_localop_beta * this->filtercoeff_07_localop_sn) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la1 = 2. * this->filtercoeff_07_localop_A * (this->filtercoeff_07_localop_A - 1 - (this->filtercoeff_07_localop_A + 1) * this->filtercoeff_07_localop_cs) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la2 = this->filtercoeff_07_localop_A * (this->filtercoeff_07_localop_A + 1. - (this->filtercoeff_07_localop_A - 1.) * this->filtercoeff_07_localop_cs - this->filtercoeff_07_localop_beta * this->filtercoeff_07_localop_sn) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb1 = -2. * (this->filtercoeff_07_localop_A - 1. + (this->filtercoeff_07_localop_A + 1.) * this->filtercoeff_07_localop_cs) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (this->filtercoeff_07_localop_A + 1. + (this->filtercoeff_07_localop_A - 1.) * this->filtercoeff_07_localop_cs - this->filtercoeff_07_localop_beta * this->filtercoeff_07_localop_sn) * this->filtercoeff_07_localop_b0;
            break;
            }
        case 6:
            {
            this->filtercoeff_07_localop_la0 = this->filtercoeff_07_localop_A * (this->filtercoeff_07_localop_A + 1. + (this->filtercoeff_07_localop_A - 1.) * this->filtercoeff_07_localop_cs + this->filtercoeff_07_localop_beta * this->filtercoeff_07_localop_sn) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la1 = -2. * this->filtercoeff_07_localop_A * (this->filtercoeff_07_localop_A - 1. + (this->filtercoeff_07_localop_A + 1.) * this->filtercoeff_07_localop_cs) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la2 = this->filtercoeff_07_localop_A * (this->filtercoeff_07_localop_A + 1. + (this->filtercoeff_07_localop_A - 1.) * this->filtercoeff_07_localop_cs - this->filtercoeff_07_localop_beta * this->filtercoeff_07_localop_sn) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb1 = 2. * (this->filtercoeff_07_localop_A - 1. - (this->filtercoeff_07_localop_A + 1.) * this->filtercoeff_07_localop_cs) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (this->filtercoeff_07_localop_A + 1. - (this->filtercoeff_07_localop_A - 1.) * this->filtercoeff_07_localop_cs - this->filtercoeff_07_localop_beta * this->filtercoeff_07_localop_sn) * this->filtercoeff_07_localop_b0;
            break;
            }
        case 9:
            {
            this->filtercoeff_07_localop_b0g = (number)1 / (this->filtercoeff_07_localop_one_over_gain + this->filtercoeff_07_localop_alpha * this->filtercoeff_07_localop_one_over_gain);
            this->filtercoeff_07_localop_la0 = this->filtercoeff_07_localop_la2 = (1. - this->filtercoeff_07_localop_cs) * 0.5 * this->filtercoeff_07_localop_b0g;
            this->filtercoeff_07_localop_la1 = (1. - this->filtercoeff_07_localop_cs) * this->filtercoeff_07_localop_b0g;
            this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0;
            break;
            }
        case 10:
            {
            this->filtercoeff_07_localop_b0g = (number)1 / (this->filtercoeff_07_localop_one_over_gain + this->filtercoeff_07_localop_alpha * this->filtercoeff_07_localop_one_over_gain);
            this->filtercoeff_07_localop_la0 = this->filtercoeff_07_localop_la2 = (1. + this->filtercoeff_07_localop_cs) * 0.5 * this->filtercoeff_07_localop_b0g;
            this->filtercoeff_07_localop_la1 = -(1. + this->filtercoeff_07_localop_cs) * this->filtercoeff_07_localop_b0g;
            this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0;
            break;
            }
        case 11:
            {
            this->filtercoeff_07_localop_la0 = this->filtercoeff_07_localop_alpha * gain * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la1 = 0.;
            this->filtercoeff_07_localop_la2 = -this->filtercoeff_07_localop_alpha * gain * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0;
            break;
            }
        case 13:
            {
            this->filtercoeff_07_localop_la0 = this->filtercoeff_07_localop_alpha * gain * q * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la1 = 0.;
            this->filtercoeff_07_localop_la2 = -this->filtercoeff_07_localop_alpha * gain * q * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0;
            break;
            }
        case 12:
            {
            this->filtercoeff_07_localop_b0g = (number)1 / (this->filtercoeff_07_localop_one_over_gain + this->filtercoeff_07_localop_alpha * this->filtercoeff_07_localop_one_over_gain);
            this->filtercoeff_07_localop_la1 = this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs;
            this->filtercoeff_07_localop_lb2 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la1 *= this->filtercoeff_07_localop_b0g;
            this->filtercoeff_07_localop_lb1 *= this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_la0 = this->filtercoeff_07_localop_b0g;
            this->filtercoeff_07_localop_la2 = this->filtercoeff_07_localop_b0g;
            break;
            }
        case 14:
            {
            this->filtercoeff_07_localop_b0g = (number)1 / (this->filtercoeff_07_localop_one_over_gain + this->filtercoeff_07_localop_alpha * this->filtercoeff_07_localop_one_over_gain);
            this->filtercoeff_07_localop_la0 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0g;
            this->filtercoeff_07_localop_la1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0g;
            this->filtercoeff_07_localop_la2 = gain;
            this->filtercoeff_07_localop_lb1 = -2. * this->filtercoeff_07_localop_cs * this->filtercoeff_07_localop_b0;
            this->filtercoeff_07_localop_lb2 = (1. - this->filtercoeff_07_localop_alpha) * this->filtercoeff_07_localop_b0;
            break;
            }
        case 15:
            {
            this->filtercoeff_07_localop_la0 = 1;
            this->filtercoeff_07_localop_la1 = 0;
            this->filtercoeff_07_localop_la2 = 0;
            this->filtercoeff_07_localop_lb1 = 0;
            this->filtercoeff_07_localop_lb2 = 0;
            }
        default:
            {
            break;
            }
        }
    
        return {
            this->filtercoeff_07_localop_la0,
            this->filtercoeff_07_localop_la1,
            this->filtercoeff_07_localop_la2,
            this->filtercoeff_07_localop_lb1,
            this->filtercoeff_07_localop_lb2
        };
    }
    
    void filtercoeff_07_localop_dspsetup() {
        this->filtercoeff_07_localop_twopi_over_sr = (number)6.283185307179586 / this->sr;
    }
    
    void filtercoeff_07_localop_reset() {
        this->filtercoeff_07_localop_twopi_over_sr = 0;
        this->filtercoeff_07_localop_cs = 0;
        this->filtercoeff_07_localop_sn = 0;
        this->filtercoeff_07_localop_one_over_gain = 0;
        this->filtercoeff_07_localop_one_over_q = 0;
        this->filtercoeff_07_localop_alpha = 0;
        this->filtercoeff_07_localop_beta = 0;
        this->filtercoeff_07_localop_b0 = 0;
        this->filtercoeff_07_localop_b0g = 0;
        this->filtercoeff_07_localop_A = 0;
        this->filtercoeff_07_localop_one_over_a = 0;
        this->filtercoeff_07_localop_la0 = 0;
        this->filtercoeff_07_localop_la1 = 0;
        this->filtercoeff_07_localop_la2 = 0;
        this->filtercoeff_07_localop_lb1 = 0;
        this->filtercoeff_07_localop_lb2 = 0;
    }
    
    void filtercoeff_07_updateTerms(number local_frequency, number local_gain, number local_q) {
        if ((bool)(this->filtercoeff_07_force_update) || local_frequency != this->filtercoeff_07_last_frequency || local_q != this->filtercoeff_07_last_q || local_gain != this->filtercoeff_07_last_gain || this->filtercoeff_07_type != this->filtercoeff_07_last_type) {
            array<number, 5> tmp = this->filtercoeff_07_localop_next(local_frequency, local_q, local_gain, this->filtercoeff_07_type);
            this->filtercoeff_07_la0 = tmp[0];
            this->filtercoeff_07_la1 = tmp[1];
            this->filtercoeff_07_la2 = tmp[2];
            this->filtercoeff_07_lb1 = tmp[3];
            this->filtercoeff_07_lb2 = tmp[4];
            this->filtercoeff_07_last_frequency = local_frequency;
            this->filtercoeff_07_last_q = local_q;
            this->filtercoeff_07_last_gain = local_gain;
            this->filtercoeff_07_last_type = this->filtercoeff_07_type;
            this->filtercoeff_07_force_update = false;
        }
    }
    
    void filtercoeff_07_dspsetup(bool force) {
        if ((bool)(this->filtercoeff_07_setupDone) && (bool)(!(bool)(force)))
            return;
    
        {
            this->filtercoeff_07_activeResamp = this->vectorsize();
        }
    
        this->filtercoeff_07_resamp_counter = 0;
        this->filtercoeff_07_la0 = 0.;
        this->filtercoeff_07_la1 = 0.;
        this->filtercoeff_07_la2 = 0.;
        this->filtercoeff_07_lb1 = 0.;
        this->filtercoeff_07_lb2 = 0.;
        this->filtercoeff_07_last_frequency = -1.;
        this->filtercoeff_07_last_q = -1.;
        this->filtercoeff_07_last_gain = -1.;
        this->filtercoeff_07_last_type = this->filtercoeff_07_type;
        this->filtercoeff_07_force_update = true;
        this->filtercoeff_07_setupDone = true;
        this->filtercoeff_07_localop_dspsetup();
    }
    
    void numberobj_39_init() {
        this->numberobj_39_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("800Hz~/number_obj-3"), 1, this->_currentTime);
    }
    
    void numberobj_39_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_39_value;
    }
    
    void numberobj_39_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_39_value_set(preset["value"]);
    }
    
    void numberobj_40_init() {
        this->numberobj_40_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("800Hz~/number_obj-4"), 1, this->_currentTime);
    }
    
    void numberobj_40_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_40_value;
    }
    
    void numberobj_40_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_40_value_set(preset["value"]);
    }
    
    bool stackprotect_check() {
        this->stackprotect_count++;
    
        if (this->stackprotect_count > 128) {
            console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
            return true;
        }
    
        return false;
    }
    
    void updateTime(MillisecondTime time) {
        this->_currentTime = time;
        this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
    
        if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
            this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
    
        if (this->sampleOffsetIntoNextAudioBuffer < 0)
            this->sampleOffsetIntoNextAudioBuffer = 0;
    }
    
    void assign_defaults()
    {
        dspexpr_19_in1 = 0;
        dspexpr_19_in2 = 0;
        dspexpr_19_in3 = 0;
        biquad_tilde_13_x = 0;
        biquad_tilde_13_a0 = 0;
        biquad_tilde_13_a1 = 0;
        biquad_tilde_13_a2 = 0;
        biquad_tilde_13_b1 = 0;
        biquad_tilde_13_b2 = 0;
        linetilde_15_time = 10;
        linetilde_15_keepramp = 1;
        biquad_tilde_14_x = 0;
        biquad_tilde_14_a0 = 0;
        biquad_tilde_14_a1 = 0;
        biquad_tilde_14_a2 = 0;
        biquad_tilde_14_b1 = 0;
        biquad_tilde_14_b2 = 0;
        dspexpr_20_in1 = 0;
        dspexpr_20_in2 = 0;
        dspexpr_20_in3 = 0;
        gen_06_in1 = 0;
        gen_06_in2 = 0;
        gen_06_in3 = 0;
        gen_06_in4 = 0;
        gen_06_in5 = 0;
        filtercoeff_07_frequency = 800;
        filtercoeff_07_gain = 1;
        filtercoeff_07_q = 1;
        filtercoeff_07_type = 4;
        numberobj_39_value = 0;
        numberobj_39_value_setter(numberobj_39_value);
        numberobj_40_value = 0;
        numberobj_40_value_setter(numberobj_40_value);
        expr_21_in1 = 0;
        expr_21_out1 = 0;
        linetilde_16_time = 10;
        linetilde_16_keepramp = 1;
        p_08_target = 0;
        _currentTime = 0;
        audioProcessSampleCount = 0;
        sampleOffsetIntoNextAudioBuffer = 0;
        zeroBuffer = nullptr;
        dummyBuffer = nullptr;
        signals[0] = nullptr;
        signals[1] = nullptr;
        signals[2] = nullptr;
        signals[3] = nullptr;
        signals[4] = nullptr;
        signals[5] = nullptr;
        signals[6] = nullptr;
        signals[7] = nullptr;
        didAllocateSignals = 0;
        vs = 0;
        maxvs = 0;
        sr = 44100;
        invsr = 0.00002267573696;
        biquad_tilde_13_x1 = 0;
        biquad_tilde_13_x2 = 0;
        biquad_tilde_13_y1 = 0;
        biquad_tilde_13_y2 = 0;
        biquad_tilde_13_setupDone = false;
        linetilde_15_currentValue = 0;
        biquad_tilde_14_x1 = 0;
        biquad_tilde_14_x2 = 0;
        biquad_tilde_14_y1 = 0;
        biquad_tilde_14_y2 = 0;
        biquad_tilde_14_setupDone = false;
        gen_06_x1_l_value = 0;
        gen_06_y1_l_value = 0;
        gen_06_x1_r_value = 0;
        gen_06_y1_r_value = 0;
        filtercoeff_07_K_EPSILON = 1e-9;
        filtercoeff_07_setupDone = false;
        numberobj_39_currentFormat = 6;
        numberobj_39_lastValue = 0;
        numberobj_40_currentFormat = 6;
        numberobj_40_lastValue = 0;
        linetilde_16_currentValue = 1;
        stackprotect_count = 0;
        _voiceIndex = 0;
        _noteNumber = 0;
        isMuted = 1;
        parameterOffset = 0;
    }
    
    // member variables
    
        number dspexpr_19_in1;
        number dspexpr_19_in2;
        number dspexpr_19_in3;
        number biquad_tilde_13_x;
        number biquad_tilde_13_a0;
        number biquad_tilde_13_a1;
        number biquad_tilde_13_a2;
        number biquad_tilde_13_b1;
        number biquad_tilde_13_b2;
        list linetilde_15_segments;
        number linetilde_15_time;
        number linetilde_15_keepramp;
        number biquad_tilde_14_x;
        number biquad_tilde_14_a0;
        number biquad_tilde_14_a1;
        number biquad_tilde_14_a2;
        number biquad_tilde_14_b1;
        number biquad_tilde_14_b2;
        number dspexpr_20_in1;
        number dspexpr_20_in2;
        number dspexpr_20_in3;
        number gen_06_in1;
        number gen_06_in2;
        number gen_06_in3;
        number gen_06_in4;
        number gen_06_in5;
        number filtercoeff_07_frequency;
        number filtercoeff_07_gain;
        number filtercoeff_07_q;
        Int filtercoeff_07_type;
        number numberobj_39_value;
        number numberobj_40_value;
        number expr_21_in1;
        number expr_21_out1;
        list linetilde_16_segments;
        number linetilde_16_time;
        number linetilde_16_keepramp;
        number p_08_target;
        MillisecondTime _currentTime;
        UInt64 audioProcessSampleCount;
        SampleIndex sampleOffsetIntoNextAudioBuffer;
        signal zeroBuffer;
        signal dummyBuffer;
        SampleValue * signals[8];
        bool didAllocateSignals;
        Index vs;
        Index maxvs;
        number sr;
        number invsr;
        number biquad_tilde_13_x1;
        number biquad_tilde_13_x2;
        number biquad_tilde_13_y1;
        number biquad_tilde_13_y2;
        bool biquad_tilde_13_setupDone;
        list linetilde_15_activeRamps;
        number linetilde_15_currentValue;
        number biquad_tilde_14_x1;
        number biquad_tilde_14_x2;
        number biquad_tilde_14_y1;
        number biquad_tilde_14_y2;
        bool biquad_tilde_14_setupDone;
        number gen_06_x1_l_value;
        number gen_06_y1_l_value;
        number gen_06_x1_r_value;
        number gen_06_y1_r_value;
        number filtercoeff_07_resamp_counter;
        number filtercoeff_07_activeResamp;
        number filtercoeff_07_K_EPSILON;
        number filtercoeff_07_la0;
        number filtercoeff_07_la1;
        number filtercoeff_07_la2;
        number filtercoeff_07_lb1;
        number filtercoeff_07_lb2;
        number filtercoeff_07_last_frequency;
        number filtercoeff_07_last_q;
        number filtercoeff_07_last_gain;
        Int filtercoeff_07_last_type;
        bool filtercoeff_07_force_update;
        number filtercoeff_07_localop_twopi_over_sr;
        number filtercoeff_07_localop_cs;
        number filtercoeff_07_localop_sn;
        number filtercoeff_07_localop_one_over_gain;
        number filtercoeff_07_localop_one_over_q;
        number filtercoeff_07_localop_alpha;
        number filtercoeff_07_localop_beta;
        number filtercoeff_07_localop_b0;
        number filtercoeff_07_localop_b0g;
        number filtercoeff_07_localop_A;
        number filtercoeff_07_localop_one_over_a;
        number filtercoeff_07_localop_la0;
        number filtercoeff_07_localop_la1;
        number filtercoeff_07_localop_la2;
        number filtercoeff_07_localop_lb1;
        number filtercoeff_07_localop_lb2;
        bool filtercoeff_07_setupDone;
        Int numberobj_39_currentFormat;
        number numberobj_39_lastValue;
        Int numberobj_40_currentFormat;
        number numberobj_40_lastValue;
        list linetilde_16_activeRamps;
        number linetilde_16_currentValue;
        number stackprotect_count;
        Index _voiceIndex;
        Int _noteNumber;
        Index isMuted;
        ParameterIndex parameterOffset;
        RNBOSubpatcher_197* p_08;
    
};

class RNBOSubpatcher_207 : public PatcherInterfaceImpl {
    
    friend class Grafik7;
    
    public:
    
    class RNBOSubpatcher_198 : public PatcherInterfaceImpl {
            
            friend class RNBOSubpatcher_207;
            friend class Grafik7;
            
            public:
            
            RNBOSubpatcher_198()
            {
            }
            
            ~RNBOSubpatcher_198()
            {
            }
            
            virtual RNBOSubpatcher_207* getPatcher() const {
                return static_cast<RNBOSubpatcher_207 *>(_parentPatcher);
            }
            
            Grafik7* getTopLevelPatcher() {
                return this->getPatcher()->getTopLevelPatcher();
            }
            
            void cancelClockEvents()
            {
            }
            
            inline number safediv(number num, number denom) {
                return (denom == 0.0 ? 0.0 : num / denom);
            }
            
            number safepow(number base, number exponent) {
                return fixnan(rnbo_pow(base, exponent));
            }
            
            number scale(
                number x,
                number lowin,
                number hiin,
                number lowout,
                number highout,
                number pow
            ) {
                auto inscale = this->safediv(1., hiin - lowin);
                number outdiff = highout - lowout;
                number value = (x - lowin) * inscale;
            
                if (pow != 1) {
                    if (value > 0)
                        value = this->safepow(value, pow);
                    else
                        value = -this->safepow(-value, pow);
                }
            
                value = value * outdiff + lowout;
                return value;
            }
            
            Index getNumMidiInputPorts() const {
                return 0;
            }
            
            void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
            
            Index getNumMidiOutputPorts() const {
                return 0;
            }
            
            void process(
                const SampleValue * const* inputs,
                Index numInputs,
                SampleValue * const* outputs,
                Index numOutputs,
                Index n
            ) {
                RNBO_UNUSED(numOutputs);
                RNBO_UNUSED(outputs);
                RNBO_UNUSED(numInputs);
                RNBO_UNUSED(inputs);
                this->vs = n;
                this->updateTime(this->getEngine()->getCurrentTime());
                this->stackprotect_perform(n);
                this->audioProcessSampleCount += this->vs;
            }
            
            void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
                if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
                    this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
                    this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
                    this->didAllocateSignals = true;
                }
            
                const bool sampleRateChanged = sampleRate != this->sr;
                const bool maxvsChanged = maxBlockSize != this->maxvs;
                const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
            
                if (sampleRateChanged || maxvsChanged) {
                    this->vs = maxBlockSize;
                    this->maxvs = maxBlockSize;
                    this->sr = sampleRate;
                    this->invsr = 1 / sampleRate;
                }
            
                RNBO_UNUSED(forceDSPSetup);
            
                if (sampleRateChanged)
                    this->onSampleRateChanged(sampleRate);
            }
            
            void setProbingTarget(MessageTag id) {
                switch (id) {
                default:
                    {
                    this->setProbingIndex(-1);
                    break;
                    }
                }
            }
            
            void setProbingIndex(ProbingIndex ) {}
            
            Index getProbingChannels(MessageTag outletId) const {
                RNBO_UNUSED(outletId);
                return 0;
            }
            
            Index getIsMuted()  {
                return this->isMuted;
            }
            
            void setIsMuted(Index v)  {
                this->isMuted = v;
            }
            
            void onSampleRateChanged(double ) {}
            
            Index getPatcherSerial() const {
                return 0;
            }
            
            void getState(PatcherStateInterface& ) {}
            
            void setState() {}
            
            void getPreset(PatcherStateInterface& ) {}
            
            void setParameterValue(ParameterIndex , ParameterValue , MillisecondTime ) {}
            
            void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValue(index, value, time);
            }
            
            void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
                this->setParameterValue(index, this->getParameterValue(index), time);
            }
            
            void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
                this->setParameterValueNormalized(index, value, time);
            }
            
            ParameterValue getParameterValue(ParameterIndex index)  {
                switch (index) {
                default:
                    {
                    return 0;
                    }
                }
            }
            
            ParameterIndex getNumSignalInParameters() const {
                return 0;
            }
            
            ParameterIndex getNumSignalOutParameters() const {
                return 0;
            }
            
            ParameterIndex getNumParameters() const {
                return 0;
            }
            
            ConstCharPointer getParameterName(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            ConstCharPointer getParameterId(ParameterIndex index) const {
                switch (index) {
                default:
                    {
                    return "bogus";
                    }
                }
            }
            
            void getParameterInfo(ParameterIndex , ParameterInfo * ) const {}
            
            void sendParameter(ParameterIndex index, bool ignoreValue) {
                this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
            }
            
            void setParameterOffset(ParameterIndex offset) {
                this->parameterOffset = offset;
            }
            
            ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
                if (steps == 1) {
                    if (normalizedValue > 0) {
                        normalizedValue = 1.;
                    }
                } else {
                    ParameterValue oneStep = (number)1. / (steps - 1);
                    ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
                    normalizedValue = numberOfSteps * oneStep;
                }
            
                return normalizedValue;
            }
            
            ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
                value = (value < 0 ? 0 : (value > 1 ? 1 : value));
            
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
                switch (index) {
                default:
                    {
                    return value;
                    }
                }
            }
            
            void scheduleParamInit(ParameterIndex index, Index order) {
                this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
            }
            
            void processClockEvent(MillisecondTime , ClockId , bool , ParameterValue ) {}
            
            void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
            
            void processOutletEvent(
                EngineLink* sender,
                OutletIndex index,
                ParameterValue value,
                MillisecondTime time
            ) {
                this->updateTime(time);
                this->processOutletAtCurrentTime(sender, index, value);
            }
            
            void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
                this->updateTime(time);
            
                switch (tag) {
                case TAG("valin"):
                    {
                    if (TAG("400Hz~/scale/number_obj-34") == objectId)
                        this->numberobj_41_valin_set(payload);
            
                    if (TAG("400Hz~/scale/number_obj-32") == objectId)
                        this->numberobj_42_valin_set(payload);
            
                    if (TAG("400Hz~/scale/number_obj-38") == objectId)
                        this->numberobj_43_valin_set(payload);
            
                    if (TAG("400Hz~/scale/number_obj-55") == objectId)
                        this->numberobj_44_valin_set(payload);
            
                    break;
                    }
                case TAG("format"):
                    {
                    if (TAG("400Hz~/scale/number_obj-34") == objectId)
                        this->numberobj_41_format_set(payload);
            
                    if (TAG("400Hz~/scale/number_obj-32") == objectId)
                        this->numberobj_42_format_set(payload);
            
                    if (TAG("400Hz~/scale/number_obj-38") == objectId)
                        this->numberobj_43_format_set(payload);
            
                    if (TAG("400Hz~/scale/number_obj-55") == objectId)
                        this->numberobj_44_format_set(payload);
            
                    break;
                    }
                }
            }
            
            void processListMessage(MessageTag , MessageTag , MillisecondTime , const list& ) {}
            
            void processBangMessage(MessageTag , MessageTag , MillisecondTime ) {}
            
            MessageTagInfo resolveTag(MessageTag tag) const {
                switch (tag) {
                case TAG("valout"):
                    {
                    return "valout";
                    }
                case TAG("400Hz~/scale/number_obj-34"):
                    {
                    return "400Hz~/scale/number_obj-34";
                    }
                case TAG("setup"):
                    {
                    return "setup";
                    }
                case TAG("400Hz~/scale/number_obj-32"):
                    {
                    return "400Hz~/scale/number_obj-32";
                    }
                case TAG("400Hz~/scale/number_obj-38"):
                    {
                    return "400Hz~/scale/number_obj-38";
                    }
                case TAG("400Hz~/scale/number_obj-55"):
                    {
                    return "400Hz~/scale/number_obj-55";
                    }
                case TAG("valin"):
                    {
                    return "valin";
                    }
                case TAG("format"):
                    {
                    return "format";
                    }
                }
            
                return nullptr;
            }
            
            DataRef* getDataRef(DataRefIndex index)  {
                switch (index) {
                default:
                    {
                    return nullptr;
                    }
                }
            }
            
            DataRefIndex getNumDataRefs() const {
                return 0;
            }
            
            void fillDataRef(DataRefIndex , DataRef& ) {}
            
            void processDataViewUpdate(DataRefIndex , MillisecondTime ) {}
            
            void initialize() {
                this->assign_defaults();
                this->setState();
            }
            
            protected:
            
            void numberobj_41_valin_set(number v) {
                this->numberobj_41_value_set(v);
            }
            
            void numberobj_41_format_set(number v) {
                this->numberobj_41_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_42_valin_set(number v) {
                this->numberobj_42_value_set(v);
            }
            
            void numberobj_42_format_set(number v) {
                this->numberobj_42_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void numberobj_43_valin_set(number v) {
                this->numberobj_43_value_set(v);
            }
            
            void numberobj_43_format_set(number v) {
                this->numberobj_43_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            void eventinlet_21_out1_bang_bang() {
                this->expr_23_in1_bang();
                this->expr_22_in1_bang();
            }
            
            void eventinlet_21_out1_list_set(const list& v) {
                {
                    if (v->length > 1)
                        this->expr_23_in2_set(v[1]);
            
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_23_in1_set(converted);
                }
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->expr_22_in1_set(converted);
                }
            }
            
            void numberobj_44_valin_set(number v) {
                this->numberobj_44_value_set(v);
            }
            
            void numberobj_44_format_set(number v) {
                this->numberobj_44_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
            }
            
            number msToSamps(MillisecondTime ms, number sampleRate) {
                return ms * sampleRate * 0.001;
            }
            
            MillisecondTime sampsToMs(SampleIndex samps) {
                return samps * (this->invsr * 1000);
            }
            
            Index getMaxBlockSize() const {
                return this->maxvs;
            }
            
            number getSampleRate() const {
                return this->sr;
            }
            
            bool hasFixedVectorSize() const {
                return false;
            }
            
            Index getNumInputChannels() const {
                return 0;
            }
            
            Index getNumOutputChannels() const {
                return 0;
            }
            
            void initializeObjects() {
                this->numberobj_41_init();
                this->numberobj_42_init();
                this->numberobj_43_init();
                this->numberobj_44_init();
            }
            
            void sendOutlet(OutletIndex index, ParameterValue value) {
                this->getEngine()->sendOutlet(this, index, value);
            }
            
            void startup() {}
            
            void allocateDataRefs() {}
            
            void eventoutlet_21_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_09_out3_number_set(v);
            }
            
            void numberobj_44_output_set(number v) {
                this->eventoutlet_21_in1_number_set(v);
            }
            
            void numberobj_44_value_set(number v) {
                this->numberobj_44_value_setter(v);
                v = this->numberobj_44_value;
                number localvalue = v;
            
                if (this->numberobj_44_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("400Hz~/scale/number_obj-55"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_44_output_set(localvalue);
            }
            
            void expr_23_out1_set(number v) {
                this->expr_23_out1 = v;
                this->numberobj_44_value_set(this->expr_23_out1);
            }
            
            void expr_23_in1_set(number in1) {
                this->expr_23_in1 = in1;
                this->expr_23_out1_set(this->expr_23_in1 < this->expr_23_in2);//#map:400Hz~/scale/<_obj-53:1
            }
            
            void eventoutlet_20_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_09_out2_number_set(v);
            }
            
            void numberobj_43_output_set(number v) {
                this->eventoutlet_20_in1_number_set(v);
            }
            
            void numberobj_43_value_set(number v) {
                this->numberobj_43_value_setter(v);
                v = this->numberobj_43_value;
                number localvalue = v;
            
                if (this->numberobj_43_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("400Hz~/scale/number_obj-38"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_43_output_set(localvalue);
            }
            
            void scale_14_out_set(const list& v) {
                this->scale_14_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_43_value_set(converted);
                }
            }
            
            void scale_14_input_set(const list& v) {
                this->scale_14_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_14_inlow,
                        this->scale_14_inhigh,
                        this->scale_14_outlow,
                        this->scale_14_outhigh,
                        this->scale_14_power
                    ));
                }
            
                this->scale_14_out_set(tmp);
            }
            
            void eventoutlet_19_in1_number_set(number v) {
                this->getPatcher()->updateTime(this->_currentTime);
                this->getPatcher()->p_09_out1_number_set(v);
            }
            
            void numberobj_41_output_set(number v) {
                this->eventoutlet_19_in1_number_set(v);
            }
            
            void numberobj_41_value_set(number v) {
                this->numberobj_41_value_setter(v);
                v = this->numberobj_41_value;
                number localvalue = v;
            
                if (this->numberobj_41_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("400Hz~/scale/number_obj-34"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_41_output_set(localvalue);
            }
            
            void scale_13_out_set(const list& v) {
                this->scale_13_out = jsCreateListCopy(v);
            
                {
                    number converted = (v->length > 0 ? v[0] : 0);
                    this->numberobj_41_value_set(converted);
                }
            }
            
            void scale_13_input_set(const list& v) {
                this->scale_13_input = jsCreateListCopy(v);
                list tmp = {};
            
                for (Index i = 0; i < v->length; i++) {
                    tmp->push(this->scale(
                        v[(Index)i],
                        this->scale_13_inlow,
                        this->scale_13_inhigh,
                        this->scale_13_outlow,
                        this->scale_13_outhigh,
                        this->scale_13_power
                    ));
                }
            
                this->scale_13_out_set(tmp);
            }
            
            void numberobj_42_output_set(number v) {
                {
                    list converted = {v};
                    this->scale_14_input_set(converted);
                }
            
                {
                    list converted = {v};
                    this->scale_13_input_set(converted);
                }
            }
            
            void numberobj_42_value_set(number v) {
                this->numberobj_42_value_setter(v);
                v = this->numberobj_42_value;
                number localvalue = v;
            
                if (this->numberobj_42_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->getEngine()->sendNumMessage(
                    TAG("valout"),
                    TAG("400Hz~/scale/number_obj-32"),
                    localvalue,
                    this->_currentTime
                );
            
                this->numberobj_42_output_set(localvalue);
            }
            
            void expr_22_out1_set(number v) {
                this->expr_22_out1 = v;
                this->numberobj_42_value_set(this->expr_22_out1);
            }
            
            void expr_22_in1_set(number in1) {
                this->expr_22_in1 = in1;
                this->expr_22_out1_set(rnbo_abs(this->expr_22_in1));//#map:400Hz~/scale/abs_obj-29:1
            }
            
            void eventinlet_21_out1_number_set(number v) {
                this->expr_23_in1_set(v);
                this->expr_22_in1_set(v);
            }
            
            void expr_23_in1_bang() {
                this->expr_23_out1_set(this->expr_23_in1 < this->expr_23_in2);//#map:400Hz~/scale/<_obj-53:1
            }
            
            void expr_22_in1_bang() {
                this->expr_22_out1_set(rnbo_abs(this->expr_22_in1));//#map:400Hz~/scale/abs_obj-29:1
            }
            
            void expr_23_in2_set(number v) {
                this->expr_23_in2 = v;
            }
            
            void stackprotect_perform(Index n) {
                RNBO_UNUSED(n);
                auto __stackprotect_count = this->stackprotect_count;
                __stackprotect_count = 0;
                this->stackprotect_count = __stackprotect_count;
            }
            
            void numberobj_41_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_41_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_41_value = localvalue;
            }
            
            void numberobj_42_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_42_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_42_value = localvalue;
            }
            
            void numberobj_43_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_43_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_43_value = localvalue;
            }
            
            void numberobj_44_value_setter(number v) {
                number localvalue = v;
            
                if (this->numberobj_44_currentFormat != 6) {
                    localvalue = trunc(localvalue);
                }
            
                this->numberobj_44_value = localvalue;
            }
            
            void numberobj_41_init() {
                this->numberobj_41_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("400Hz~/scale/number_obj-34"), 1, this->_currentTime);
            }
            
            void numberobj_41_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_41_value;
            }
            
            void numberobj_41_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_41_value_set(preset["value"]);
            }
            
            void numberobj_42_init() {
                this->numberobj_42_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("400Hz~/scale/number_obj-32"), 1, this->_currentTime);
            }
            
            void numberobj_42_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_42_value;
            }
            
            void numberobj_42_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_42_value_set(preset["value"]);
            }
            
            void numberobj_43_init() {
                this->numberobj_43_currentFormat = 6;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("400Hz~/scale/number_obj-38"), 1, this->_currentTime);
            }
            
            void numberobj_43_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_43_value;
            }
            
            void numberobj_43_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_43_value_set(preset["value"]);
            }
            
            void numberobj_44_init() {
                this->numberobj_44_currentFormat = 0;
                this->getEngine()->sendNumMessage(TAG("setup"), TAG("400Hz~/scale/number_obj-55"), 1, this->_currentTime);
            }
            
            void numberobj_44_getPresetValue(PatcherStateInterface& preset) {
                preset["value"] = this->numberobj_44_value;
            }
            
            void numberobj_44_setPresetValue(PatcherStateInterface& preset) {
                if ((bool)(stateIsEmpty(preset)))
                    return;
            
                this->numberobj_44_value_set(preset["value"]);
            }
            
            bool stackprotect_check() {
                this->stackprotect_count++;
            
                if (this->stackprotect_count > 128) {
                    console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
                    return true;
                }
            
                return false;
            }
            
            void updateTime(MillisecondTime time) {
                this->_currentTime = time;
                this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
            
                if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
                    this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
            
                if (this->sampleOffsetIntoNextAudioBuffer < 0)
                    this->sampleOffsetIntoNextAudioBuffer = 0;
            }
            
            void assign_defaults()
            {
                numberobj_41_value = 0;
                numberobj_41_value_setter(numberobj_41_value);
                numberobj_42_value = 0;
                numberobj_42_value_setter(numberobj_42_value);
                expr_22_in1 = 0;
                expr_22_out1 = 0;
                scale_13_inlow = 0;
                scale_13_inhigh = 12;
                scale_13_outlow = 0;
                scale_13_outhigh = 1;
                scale_13_power = 1;
                numberobj_43_value = 0;
                numberobj_43_value_setter(numberobj_43_value);
                scale_14_inlow = 0;
                scale_14_inhigh = 12;
                scale_14_outlow = 0;
                scale_14_outhigh = 1;
                scale_14_power = 0.5;
                numberobj_44_value = 0;
                numberobj_44_value_setter(numberobj_44_value);
                expr_23_in1 = 0;
                expr_23_in2 = 0;
                expr_23_out1 = 0;
                _currentTime = 0;
                audioProcessSampleCount = 0;
                sampleOffsetIntoNextAudioBuffer = 0;
                zeroBuffer = nullptr;
                dummyBuffer = nullptr;
                didAllocateSignals = 0;
                vs = 0;
                maxvs = 0;
                sr = 44100;
                invsr = 0.00002267573696;
                numberobj_41_currentFormat = 6;
                numberobj_41_lastValue = 0;
                numberobj_42_currentFormat = 6;
                numberobj_42_lastValue = 0;
                numberobj_43_currentFormat = 6;
                numberobj_43_lastValue = 0;
                numberobj_44_currentFormat = 6;
                numberobj_44_lastValue = 0;
                stackprotect_count = 0;
                _voiceIndex = 0;
                _noteNumber = 0;
                isMuted = 1;
                parameterOffset = 0;
            }
            
            // member variables
            
                number numberobj_41_value;
                number numberobj_42_value;
                number expr_22_in1;
                number expr_22_out1;
                list scale_13_input;
                number scale_13_inlow;
                number scale_13_inhigh;
                number scale_13_outlow;
                number scale_13_outhigh;
                number scale_13_power;
                list scale_13_out;
                number numberobj_43_value;
                list scale_14_input;
                number scale_14_inlow;
                number scale_14_inhigh;
                number scale_14_outlow;
                number scale_14_outhigh;
                number scale_14_power;
                list scale_14_out;
                number numberobj_44_value;
                number expr_23_in1;
                number expr_23_in2;
                number expr_23_out1;
                MillisecondTime _currentTime;
                UInt64 audioProcessSampleCount;
                SampleIndex sampleOffsetIntoNextAudioBuffer;
                signal zeroBuffer;
                signal dummyBuffer;
                bool didAllocateSignals;
                Index vs;
                Index maxvs;
                number sr;
                number invsr;
                Int numberobj_41_currentFormat;
                number numberobj_41_lastValue;
                Int numberobj_42_currentFormat;
                number numberobj_42_lastValue;
                Int numberobj_43_currentFormat;
                number numberobj_43_lastValue;
                Int numberobj_44_currentFormat;
                number numberobj_44_lastValue;
                number stackprotect_count;
                Index _voiceIndex;
                Int _noteNumber;
                Index isMuted;
                ParameterIndex parameterOffset;
            
    };
    
    RNBOSubpatcher_207()
    {
    }
    
    ~RNBOSubpatcher_207()
    {
        delete this->p_09;
    }
    
    virtual Grafik7* getPatcher() const {
        return static_cast<Grafik7 *>(_parentPatcher);
    }
    
    Grafik7* getTopLevelPatcher() {
        return this->getPatcher()->getTopLevelPatcher();
    }
    
    void cancelClockEvents()
    {
        getEngine()->flushClockEvents(this, -62043057, false);
        getEngine()->flushClockEvents(this, -1621164530, false);
    }
    
    SampleIndex currentsampletime() {
        return this->audioProcessSampleCount + this->sampleOffsetIntoNextAudioBuffer;
    }
    
    number mstosamps(MillisecondTime ms) {
        return ms * this->sr * 0.001;
    }
    
    inline number safesqrt(number num) {
        return (num > 0.0 ? rnbo_sqrt(num) : 0.0);
    }
    
    Index vectorsize() const {
        return this->vs;
    }
    
    Index getNumMidiInputPorts() const {
        return 0;
    }
    
    void processMidiEvent(MillisecondTime , int , ConstByteArray , Index ) {}
    
    Index getNumMidiOutputPorts() const {
        return 0;
    }
    
    void process(
        const SampleValue * const* inputs,
        Index numInputs,
        SampleValue * const* outputs,
        Index numOutputs,
        Index n
    ) {
        this->vs = n;
        this->updateTime(this->getEngine()->getCurrentTime());
        SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
        SampleValue * out2 = (numOutputs >= 2 && outputs[1] ? outputs[1] : this->dummyBuffer);
        const SampleValue * in1 = (numInputs >= 1 && inputs[0] ? inputs[0] : this->zeroBuffer);
        const SampleValue * in2 = (numInputs >= 2 && inputs[1] ? inputs[1] : this->zeroBuffer);
        this->linetilde_17_perform(this->signals[0], n);
        this->linetilde_18_perform(this->signals[1], n);
    
        this->filtercoeff_08_perform(
            this->filtercoeff_08_frequency,
            this->signals[1],
            this->filtercoeff_08_q,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            n
        );
    
        this->biquad_tilde_16_perform(
            in2,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[1],
            n
        );
    
        this->biquad_tilde_15_perform(
            in1,
            this->signals[2],
            this->signals[3],
            this->signals[4],
            this->signals[5],
            this->signals[6],
            this->signals[7],
            n
        );
    
        this->gen_07_perform(
            this->signals[7],
            this->signals[1],
            this->gen_07_in3,
            this->gen_07_in4,
            this->gen_07_in5,
            this->signals[6],
            this->signals[5],
            n
        );
    
        this->dspexpr_21_perform(this->signals[7], this->signals[6], this->signals[0], out1, n);
        this->dspexpr_22_perform(this->signals[1], this->signals[5], this->signals[0], out2, n);
        this->p_09_perform(n);
        this->stackprotect_perform(n);
        this->audioProcessSampleCount += this->vs;
    }
    
    void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
        if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
            Index i;
    
            for (i = 0; i < 8; i++) {
                this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
            }
    
            this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
            this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
            this->didAllocateSignals = true;
        }
    
        const bool sampleRateChanged = sampleRate != this->sr;
        const bool maxvsChanged = maxBlockSize != this->maxvs;
        const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;
    
        if (sampleRateChanged || maxvsChanged) {
            this->vs = maxBlockSize;
            this->maxvs = maxBlockSize;
            this->sr = sampleRate;
            this->invsr = 1 / sampleRate;
        }
    
        this->filtercoeff_08_dspsetup(forceDSPSetup);
        this->biquad_tilde_16_dspsetup(forceDSPSetup);
        this->biquad_tilde_15_dspsetup(forceDSPSetup);
        this->p_09->prepareToProcess(sampleRate, maxBlockSize, force);
    
        if (sampleRateChanged)
            this->onSampleRateChanged(sampleRate);
    }
    
    void setProbingTarget(MessageTag id) {
        switch (id) {
        default:
            {
            this->setProbingIndex(-1);
            break;
            }
        }
    }
    
    void setProbingIndex(ProbingIndex ) {}
    
    Index getProbingChannels(MessageTag outletId) const {
        RNBO_UNUSED(outletId);
        return 0;
    }
    
    Index getIsMuted()  {
        return this->isMuted;
    }
    
    void setIsMuted(Index v)  {
        this->isMuted = v;
    }
    
    void onSampleRateChanged(double ) {}
    
    Index getPatcherSerial() const {
        return 0;
    }
    
    void getState(PatcherStateInterface& ) {}
    
    void setState() {
        this->p_09 = new RNBOSubpatcher_198();
        this->p_09->setEngineAndPatcher(this->getEngine(), this);
        this->p_09->initialize();
        this->p_09->setParameterOffset(this->getParameterOffset(this->p_09));
    }
    
    void getPreset(PatcherStateInterface& preset) {
        this->p_09->getPreset(getSubState(getSubState(preset, "__sps"), "scale"));
    }
    
    void setParameterValue(ParameterIndex index, ParameterValue v, MillisecondTime time) {
        RNBO_UNUSED(v);
        this->updateTime(time);
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_09->getNumParameters())
                this->p_09->setParameterValue(index, v, time);
    
            break;
            }
        }
    }
    
    void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValue(index, value, time);
    }
    
    void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
        this->setParameterValue(index, this->getParameterValue(index), time);
    }
    
    void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
        this->setParameterValueNormalized(index, value, time);
    }
    
    ParameterValue getParameterValue(ParameterIndex index)  {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_09->getNumParameters())
                return this->p_09->getParameterValue(index);
    
            return 0;
            }
        }
    }
    
    ParameterIndex getNumSignalInParameters() const {
        return 0;
    }
    
    ParameterIndex getNumSignalOutParameters() const {
        return 0;
    }
    
    ParameterIndex getNumParameters() const {
        return 0 + this->p_09->getNumParameters();
    }
    
    ConstCharPointer getParameterName(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_09->getNumParameters())
                return this->p_09->getParameterName(index);
    
            return "bogus";
            }
        }
    }
    
    ConstCharPointer getParameterId(ParameterIndex index) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_09->getNumParameters())
                return this->p_09->getParameterId(index);
    
            return "bogus";
            }
        }
    }
    
    void getParameterInfo(ParameterIndex index, ParameterInfo * info) const {
        {
            switch (index) {
            default:
                {
                index -= 0;
    
                if (index < this->p_09->getNumParameters())
                    this->p_09->getParameterInfo(index, info);
    
                break;
                }
            }
        }
    }
    
    void sendParameter(ParameterIndex index, bool ignoreValue) {
        this->getPatcher()->sendParameter(index + this->parameterOffset, ignoreValue);
    }
    
    ParameterIndex getParameterOffset(BaseInterface* subpatcher) const {
        if (subpatcher == this->p_09)
            return 0;
    
        return 0;
    }
    
    void setParameterOffset(ParameterIndex offset) {
        this->parameterOffset = offset;
    }
    
    ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
        if (steps == 1) {
            if (normalizedValue > 0) {
                normalizedValue = 1.;
            }
        } else {
            ParameterValue oneStep = (number)1. / (steps - 1);
            ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
            normalizedValue = numberOfSteps * oneStep;
        }
    
        return normalizedValue;
    }
    
    ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_09->getNumParameters())
                return this->p_09->convertToNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
        value = (value < 0 ? 0 : (value > 1 ? 1 : value));
    
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_09->getNumParameters())
                return this->p_09->convertFromNormalizedParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
        switch (index) {
        default:
            {
            index -= 0;
    
            if (index < this->p_09->getNumParameters())
                return this->p_09->constrainParameterValue(index, value);
    
            return value;
            }
        }
    }
    
    void scheduleParamInit(ParameterIndex index, Index order) {
        this->getPatcher()->scheduleParamInit(index + this->parameterOffset, order);
    }
    
    void processClockEvent(MillisecondTime time, ClockId index, bool hasValue, ParameterValue value) {
        RNBO_UNUSED(value);
        RNBO_UNUSED(hasValue);
        this->updateTime(time);
    
        switch (index) {
        case -62043057:
            {
            this->linetilde_17_target_bang();
            break;
            }
        case -1621164530:
            {
            this->linetilde_18_target_bang();
            break;
            }
        }
    }
    
    void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}
    
    void processOutletEvent(
        EngineLink* sender,
        OutletIndex index,
        ParameterValue value,
        MillisecondTime time
    ) {
        this->updateTime(time);
        this->processOutletAtCurrentTime(sender, index, value);
    }
    
    void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
        this->updateTime(time);
    
        switch (tag) {
        case TAG("valin"):
            {
            if (TAG("400Hz~/number_obj-3") == objectId)
                this->numberobj_45_valin_set(payload);
    
            if (TAG("400Hz~/number_obj-4") == objectId)
                this->numberobj_46_valin_set(payload);
    
            break;
            }
        case TAG("format"):
            {
            if (TAG("400Hz~/number_obj-3") == objectId)
                this->numberobj_45_format_set(payload);
    
            if (TAG("400Hz~/number_obj-4") == objectId)
                this->numberobj_46_format_set(payload);
    
            break;
            }
        }
    
        this->p_09->processNumMessage(tag, objectId, time, payload);
    }
    
    void processListMessage(
        MessageTag tag,
        MessageTag objectId,
        MillisecondTime time,
        const list& payload
    ) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_09->processListMessage(tag, objectId, time, payload);
    }
    
    void processBangMessage(MessageTag tag, MessageTag objectId, MillisecondTime time) {
        RNBO_UNUSED(objectId);
        this->updateTime(time);
        this->p_09->processBangMessage(tag, objectId, time);
    }
    
    MessageTagInfo resolveTag(MessageTag tag) const {
        switch (tag) {
        case TAG("valout"):
            {
            return "valout";
            }
        case TAG("400Hz~/number_obj-3"):
            {
            return "400Hz~/number_obj-3";
            }
        case TAG("setup"):
            {
            return "setup";
            }
        case TAG("400Hz~/number_obj-4"):
            {
            return "400Hz~/number_obj-4";
            }
        case TAG("valin"):
            {
            return "valin";
            }
        case TAG("format"):
            {
            return "format";
            }
        }
    
        auto subpatchResult_0 = this->p_09->resolveTag(tag);
    
        if (subpatchResult_0)
            return subpatchResult_0;
    
        return nullptr;
    }
    
    DataRef* getDataRef(DataRefIndex index)  {
        switch (index) {
        default:
            {
            return nullptr;
            }
        }
    }
    
    DataRefIndex getNumDataRefs() const {
        return 0;
    }
    
    void fillDataRef(DataRefIndex , DataRef& ) {}
    
    void processDataViewUpdate(DataRefIndex index, MillisecondTime time) {
        this->p_09->processDataViewUpdate(index, time);
    }
    
    void initialize() {
        this->assign_defaults();
        this->setState();
    }
    
    protected:
    
    void eventinlet_22_out1_bang_bang() {
        this->linetilde_17_segments_bang();
    }
    
    void eventinlet_22_out1_list_set(const list& v) {
        this->linetilde_17_segments_set(v);
    }
    
    void eventinlet_23_out1_bang_bang() {
        this->numberobj_46_value_bang();
    }
    
    void eventinlet_23_out1_list_set(const list& v) {
        {
            number converted = (v->length > 0 ? v[0] : 0);
            this->numberobj_46_value_set(converted);
        }
    }
    
    void numberobj_45_valin_set(number v) {
        this->numberobj_45_value_set(v);
    }
    
    void numberobj_45_format_set(number v) {
        this->numberobj_45_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void numberobj_46_valin_set(number v) {
        this->numberobj_46_value_set(v);
    }
    
    void numberobj_46_format_set(number v) {
        this->numberobj_46_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
    }
    
    void linetilde_17_target_bang() {}
    
    void linetilde_18_target_bang() {}
    
    number msToSamps(MillisecondTime ms, number sampleRate) {
        return ms * sampleRate * 0.001;
    }
    
    MillisecondTime sampsToMs(SampleIndex samps) {
        return samps * (this->invsr * 1000);
    }
    
    Index getMaxBlockSize() const {
        return this->maxvs;
    }
    
    number getSampleRate() const {
        return this->sr;
    }
    
    bool hasFixedVectorSize() const {
        return false;
    }
    
    Index getNumInputChannels() const {
        return 2;
    }
    
    Index getNumOutputChannels() const {
        return 2;
    }
    
    void initializeObjects() {
        this->gen_07_x1_l_init();
        this->gen_07_y1_l_init();
        this->gen_07_x1_r_init();
        this->gen_07_y1_r_init();
        this->numberobj_45_init();
        this->numberobj_46_init();
        this->p_09->initializeObjects();
    }
    
    void sendOutlet(OutletIndex index, ParameterValue value) {
        this->getEngine()->sendOutlet(this, index, value);
    }
    
    void startup() {
        this->updateTime(this->getEngine()->getCurrentTime());
        this->p_09->startup();
    }
    
    void allocateDataRefs() {
        this->p_09->allocateDataRefs();
    }
    
    void gen_07_in5_set(number v) {
        this->gen_07_in5 = v;
    }
    
    void p_09_out3_number_set(number v) {
        this->gen_07_in5_set(v);
    }
    
    void gen_07_in4_set(number v) {
        this->gen_07_in4 = v;
    }
    
    void p_09_out2_number_set(number v) {
        this->gen_07_in4_set(v);
    }
    
    void gen_07_in3_set(number v) {
        this->gen_07_in3 = v;
    }
    
    void p_09_out1_number_set(number v) {
        this->gen_07_in3_set(v);
    }
    
    void p_09_in1_number_set(number v) {
        this->p_09->updateTime(this->_currentTime);
        this->p_09->eventinlet_21_out1_number_set(v);
    }
    
    void linetilde_18_time_set(number v) {
        this->linetilde_18_time = v;
    }
    
    void linetilde_18_segments_set(const list& v) {
        this->linetilde_18_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_18_time == 0) {
                this->linetilde_18_activeRamps->length = 0;
                this->linetilde_18_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_18_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_18_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_18_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_18_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_18_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_18_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_18_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_18_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_18_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_18_activeRamps->push(lastRampValue);
                    this->linetilde_18_activeRamps->push(0);
                    this->linetilde_18_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_18_keepramp)) {
                            this->linetilde_18_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_18_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_18_activeRamps->push(destinationValue);
                    this->linetilde_18_activeRamps->push(inc);
                    this->linetilde_18_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_45_output_set(number v) {
        {
            list converted = {v};
            this->linetilde_18_segments_set(converted);
        }
    }
    
    void numberobj_45_value_set(number v) {
        this->numberobj_45_value_setter(v);
        v = this->numberobj_45_value;
        number localvalue = v;
    
        if (this->numberobj_45_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("400Hz~/number_obj-3"), localvalue, this->_currentTime);
        this->numberobj_45_output_set(localvalue);
    }
    
    void expr_24_out1_set(number v) {
        this->expr_24_out1 = v;
        this->numberobj_45_value_set(this->expr_24_out1);
    }
    
    void expr_24_in1_set(number in1) {
        this->expr_24_in1 = in1;
        this->expr_24_out1_set(rnbo_pow(10, this->expr_24_in1 * 0.05));//#map:400Hz~/dbtoa_obj-9:1
    }
    
    void numberobj_46_output_set(number v) {
        this->p_09_in1_number_set(v);
        this->expr_24_in1_set(v);
    }
    
    void numberobj_46_value_set(number v) {
        this->numberobj_46_value_setter(v);
        v = this->numberobj_46_value;
        number localvalue = v;
    
        if (this->numberobj_46_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("400Hz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_46_output_set(localvalue);
    }
    
    void eventinlet_23_out1_number_set(number v) {
        this->numberobj_46_value_set(v);
    }
    
    void linetilde_17_time_set(number v) {
        this->linetilde_17_time = v;
    }
    
    void linetilde_17_segments_set(const list& v) {
        this->linetilde_17_segments = jsCreateListCopy(v);
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_17_time == 0) {
                this->linetilde_17_activeRamps->length = 0;
                this->linetilde_17_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_17_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_17_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_17_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_17_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_17_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_17_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_17_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_17_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_17_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_17_activeRamps->push(lastRampValue);
                    this->linetilde_17_activeRamps->push(0);
                    this->linetilde_17_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_17_keepramp)) {
                            this->linetilde_17_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_17_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_17_activeRamps->push(destinationValue);
                    this->linetilde_17_activeRamps->push(inc);
                    this->linetilde_17_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void eventinlet_22_out1_number_set(number v) {
        {
            list converted = {v};
            this->linetilde_17_segments_set(converted);
        }
    }
    
    void linetilde_17_segments_bang() {
        list v = this->linetilde_17_segments;
    
        if ((bool)(v->length)) {
            if (v->length == 1 && this->linetilde_17_time == 0) {
                this->linetilde_17_activeRamps->length = 0;
                this->linetilde_17_currentValue = v[0];
            } else {
                auto currentTime = this->currentsampletime();
                number lastRampValue = this->linetilde_17_currentValue;
                number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;
    
                for (Index i = 0; i < this->linetilde_17_activeRamps->length; i += 3) {
                    rampEnd = this->linetilde_17_activeRamps[(Index)(i + 2)];
    
                    if (rampEnd > currentTime) {
                        this->linetilde_17_activeRamps[(Index)(i + 2)] = currentTime;
                        number diff = rampEnd - currentTime;
                        number valueDiff = diff * this->linetilde_17_activeRamps[(Index)(i + 1)];
                        lastRampValue = this->linetilde_17_activeRamps[(Index)i] - valueDiff;
                        this->linetilde_17_activeRamps[(Index)i] = lastRampValue;
                        this->linetilde_17_activeRamps->length = i + 3;
                        rampEnd = currentTime;
                    } else {
                        lastRampValue = this->linetilde_17_activeRamps[(Index)i];
                    }
                }
    
                if (rampEnd < currentTime) {
                    this->linetilde_17_activeRamps->push(lastRampValue);
                    this->linetilde_17_activeRamps->push(0);
                    this->linetilde_17_activeRamps->push(currentTime);
                }
    
                number lastRampEnd = currentTime;
    
                for (Index i = 0; i < v->length; i += 2) {
                    number destinationValue = v[(Index)i];
                    number inc = 0;
                    number rampTimeInSamples;
    
                    if (v->length > i + 1) {
                        rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);
    
                        if ((bool)(this->linetilde_17_keepramp)) {
                            this->linetilde_17_time_set(v[(Index)(i + 1)]);
                        }
                    } else {
                        rampTimeInSamples = this->mstosamps(this->linetilde_17_time);
                    }
    
                    if (rampTimeInSamples <= 0) {
                        rampTimeInSamples = 1;
                    }
    
                    inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                    lastRampEnd += rampTimeInSamples;
                    this->linetilde_17_activeRamps->push(destinationValue);
                    this->linetilde_17_activeRamps->push(inc);
                    this->linetilde_17_activeRamps->push(lastRampEnd);
                    lastRampValue = destinationValue;
                }
            }
        }
    }
    
    void numberobj_46_value_bang() {
        number v = this->numberobj_46_value;
        number localvalue = v;
    
        if (this->numberobj_46_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->getEngine()->sendNumMessage(TAG("valout"), TAG("400Hz~/number_obj-4"), localvalue, this->_currentTime);
        this->numberobj_46_output_set(localvalue);
    }
    
    void linetilde_17_perform(SampleValue * out, Index n) {
        auto __linetilde_17_time = this->linetilde_17_time;
        auto __linetilde_17_keepramp = this->linetilde_17_keepramp;
        auto __linetilde_17_currentValue = this->linetilde_17_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_17_activeRamps->length)) {
            while ((bool)(this->linetilde_17_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_17_activeRamps[0];
                number inc = this->linetilde_17_activeRamps[1];
                number rampTimeInSamples = this->linetilde_17_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_17_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_17_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_17_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -62043057,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_17_keepramp))) {
                            __linetilde_17_time = 0;
                        }
                    }
                }
    
                __linetilde_17_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_17_currentValue;
            i++;
        }
    
        this->linetilde_17_currentValue = __linetilde_17_currentValue;
        this->linetilde_17_time = __linetilde_17_time;
    }
    
    void linetilde_18_perform(SampleValue * out, Index n) {
        auto __linetilde_18_time = this->linetilde_18_time;
        auto __linetilde_18_keepramp = this->linetilde_18_keepramp;
        auto __linetilde_18_currentValue = this->linetilde_18_currentValue;
        Index i = 0;
    
        if ((bool)(this->linetilde_18_activeRamps->length)) {
            while ((bool)(this->linetilde_18_activeRamps->length) && i < n) {
                number destinationValue = this->linetilde_18_activeRamps[0];
                number inc = this->linetilde_18_activeRamps[1];
                number rampTimeInSamples = this->linetilde_18_activeRamps[2] - this->audioProcessSampleCount - i;
                number val = __linetilde_18_currentValue;
    
                while (rampTimeInSamples > 0 && i < n) {
                    out[(Index)i] = val;
                    val += inc;
                    i++;
                    rampTimeInSamples--;
                }
    
                if (rampTimeInSamples <= 0) {
                    val = destinationValue;
                    this->linetilde_18_activeRamps->splice(0, 3);
    
                    if ((bool)(!(bool)(this->linetilde_18_activeRamps->length))) {
                        this->getEngine()->scheduleClockEventWithValue(
                            this,
                            -1621164530,
                            this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                            0
                        );;
    
                        if ((bool)(!(bool)(__linetilde_18_keepramp))) {
                            __linetilde_18_time = 0;
                        }
                    }
                }
    
                __linetilde_18_currentValue = val;
            }
        }
    
        while (i < n) {
            out[(Index)i] = __linetilde_18_currentValue;
            i++;
        }
    
        this->linetilde_18_currentValue = __linetilde_18_currentValue;
        this->linetilde_18_time = __linetilde_18_time;
    }
    
    void filtercoeff_08_perform(
        number frequency,
        const Sample * gain,
        number q,
        SampleValue * a0,
        SampleValue * a1,
        SampleValue * a2,
        SampleValue * b1,
        SampleValue * b2,
        Index n
    ) {
        RNBO_UNUSED(q);
        RNBO_UNUSED(frequency);
        auto __filtercoeff_08_activeResamp = this->filtercoeff_08_activeResamp;
        auto __filtercoeff_08_resamp_counter = this->filtercoeff_08_resamp_counter;
        auto __filtercoeff_08_K_EPSILON = this->filtercoeff_08_K_EPSILON;
    
        for (Index i = 0; i < n; i++) {
            number local_q = 1;
            number local_gain = gain[(Index)i];
    
            if (local_gain < 0)
                local_gain = 0;
    
            number local_frequency = 400;
    
            if (local_q < __filtercoeff_08_K_EPSILON)
                local_q = __filtercoeff_08_K_EPSILON;
    
            local_frequency = (local_frequency > this->sr * 0.5 ? this->sr * 0.5 : (local_frequency < 1 ? 1 : local_frequency));
            __filtercoeff_08_resamp_counter--;
    
            if (__filtercoeff_08_resamp_counter <= 0) {
                __filtercoeff_08_resamp_counter = __filtercoeff_08_activeResamp;
                this->filtercoeff_08_updateTerms(local_frequency, local_gain, local_q);
            }
    
            a0[(Index)i] = this->filtercoeff_08_la0;
            a1[(Index)i] = this->filtercoeff_08_la1;
            a2[(Index)i] = this->filtercoeff_08_la2;
            b1[(Index)i] = this->filtercoeff_08_lb1;
            b2[(Index)i] = this->filtercoeff_08_lb2;
        }
    
        this->filtercoeff_08_resamp_counter = __filtercoeff_08_resamp_counter;
    }
    
    void biquad_tilde_16_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_16_y2 = this->biquad_tilde_16_y2;
        auto __biquad_tilde_16_y1 = this->biquad_tilde_16_y1;
        auto __biquad_tilde_16_x2 = this->biquad_tilde_16_x2;
        auto __biquad_tilde_16_x1 = this->biquad_tilde_16_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_16_x1 * a1[(Index)i] + __biquad_tilde_16_x2 * a2[(Index)i] - (__biquad_tilde_16_y1 * b1[(Index)i] + __biquad_tilde_16_y2 * b2[(Index)i]);
            __biquad_tilde_16_x2 = __biquad_tilde_16_x1;
            __biquad_tilde_16_x1 = x[(Index)i];
            __biquad_tilde_16_y2 = __biquad_tilde_16_y1;
            __biquad_tilde_16_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_16_x1 = __biquad_tilde_16_x1;
        this->biquad_tilde_16_x2 = __biquad_tilde_16_x2;
        this->biquad_tilde_16_y1 = __biquad_tilde_16_y1;
        this->biquad_tilde_16_y2 = __biquad_tilde_16_y2;
    }
    
    void biquad_tilde_15_perform(
        const Sample * x,
        const Sample * a0,
        const Sample * a1,
        const Sample * a2,
        const Sample * b1,
        const Sample * b2,
        SampleValue * out1,
        Index n
    ) {
        auto __biquad_tilde_15_y2 = this->biquad_tilde_15_y2;
        auto __biquad_tilde_15_y1 = this->biquad_tilde_15_y1;
        auto __biquad_tilde_15_x2 = this->biquad_tilde_15_x2;
        auto __biquad_tilde_15_x1 = this->biquad_tilde_15_x1;
        Index i;
    
        for (i = 0; i < n; i++) {
            number tmp = x[(Index)i] * a0[(Index)i] + __biquad_tilde_15_x1 * a1[(Index)i] + __biquad_tilde_15_x2 * a2[(Index)i] - (__biquad_tilde_15_y1 * b1[(Index)i] + __biquad_tilde_15_y2 * b2[(Index)i]);
            __biquad_tilde_15_x2 = __biquad_tilde_15_x1;
            __biquad_tilde_15_x1 = x[(Index)i];
            __biquad_tilde_15_y2 = __biquad_tilde_15_y1;
            __biquad_tilde_15_y1 = tmp;
            out1[(Index)i] = tmp;
        }
    
        this->biquad_tilde_15_x1 = __biquad_tilde_15_x1;
        this->biquad_tilde_15_x2 = __biquad_tilde_15_x2;
        this->biquad_tilde_15_y1 = __biquad_tilde_15_y1;
        this->biquad_tilde_15_y2 = __biquad_tilde_15_y2;
    }
    
    void gen_07_perform(
        const Sample * in1,
        const Sample * in2,
        number in3,
        number in4,
        number in5,
        SampleValue * out1,
        SampleValue * out2,
        Index n
    ) {
        auto __gen_07_y1_r_value = this->gen_07_y1_r_value;
        auto __gen_07_x1_r_value = this->gen_07_x1_r_value;
        auto __gen_07_y1_l_value = this->gen_07_y1_l_value;
        auto __gen_07_x1_l_value = this->gen_07_x1_l_value;
        number drive_2 = in3;
        number asym_3 = in4;
        number is_cut_4 = in5;
        number morph_factor_5 = 0.2 + is_cut_4 * (0.45 - 0.2);
        number amount_6 = drive_2 * morph_factor_5;
        number bias_factor_7 = 0.06 + is_cut_4 * (0.1 - 0.06);
        number bias_8 = asym_3 * bias_factor_7;
        Index i;
    
        for (i = 0; i < n; i++) {
            number xin_l_0 = in1[(Index)i];
            number xin_r_1 = in2[(Index)i];
            number raw_l_9 = xin_l_0 + bias_8;
            number dirty_l_10 = rnbo_tanh(raw_l_9 * 0.6) * 1.6;
            number cubic_l_11 = dirty_l_10 * dirty_l_10 * dirty_l_10 / (number)3;
            number y_l_12 = xin_l_0 - amount_6 * cubic_l_11;
            number dc_l_13 = y_l_12 - __gen_07_x1_l_value + 0.9995 * __gen_07_y1_l_value;
            __gen_07_x1_l_value = y_l_12;
            __gen_07_y1_l_value = dc_l_13;
            number raw_r_14 = xin_r_1 + bias_8;
            number dirty_r_15 = rnbo_tanh(raw_r_14 * 0.6) * 1.6;
            number cubic_r_16 = dirty_r_15 * dirty_r_15 * dirty_r_15 / (number)3;
            number y_r_17 = xin_r_1 - amount_6 * cubic_r_16;
            number dc_r_18 = y_r_17 - __gen_07_x1_r_value + 0.9995 * __gen_07_y1_r_value;
            __gen_07_x1_r_value = y_r_17;
            __gen_07_y1_r_value = dc_r_18;
            number expr_1_19 = dc_l_13;
            number expr_2_20 = dc_r_18;
            out1[(Index)i] = expr_1_19;
            out2[(Index)i] = expr_2_20;
        }
    
        this->gen_07_x1_l_value = __gen_07_x1_l_value;
        this->gen_07_y1_l_value = __gen_07_y1_l_value;
        this->gen_07_x1_r_value = __gen_07_x1_r_value;
        this->gen_07_y1_r_value = __gen_07_y1_r_value;
    }
    
    void dspexpr_21_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void dspexpr_22_perform(
        const Sample * in1,
        const Sample * in2,
        const Sample * in3,
        SampleValue * out1,
        Index n
    ) {
        Index i;
    
        for (i = 0; i < n; i++) {
            out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
        }
    }
    
    void p_09_perform(Index n) {
        // subpatcher: scale
        this->p_09->process(nullptr, 0, nullptr, 0, n);
    }
    
    void stackprotect_perform(Index n) {
        RNBO_UNUSED(n);
        auto __stackprotect_count = this->stackprotect_count;
        __stackprotect_count = 0;
        this->stackprotect_count = __stackprotect_count;
    }
    
    void numberobj_45_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_45_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_45_value = localvalue;
    }
    
    void numberobj_46_value_setter(number v) {
        number localvalue = v;
    
        if (this->numberobj_46_currentFormat != 6) {
            localvalue = trunc(localvalue);
        }
    
        this->numberobj_46_value = localvalue;
    }
    
    void biquad_tilde_15_reset() {
        this->biquad_tilde_15_x1 = 0;
        this->biquad_tilde_15_x2 = 0;
        this->biquad_tilde_15_y1 = 0;
        this->biquad_tilde_15_y2 = 0;
    }
    
    void biquad_tilde_15_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_15_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_15_reset();
        this->biquad_tilde_15_setupDone = true;
    }
    
    void biquad_tilde_16_reset() {
        this->biquad_tilde_16_x1 = 0;
        this->biquad_tilde_16_x2 = 0;
        this->biquad_tilde_16_y1 = 0;
        this->biquad_tilde_16_y2 = 0;
    }
    
    void biquad_tilde_16_dspsetup(bool force) {
        if ((bool)(this->biquad_tilde_16_setupDone) && (bool)(!(bool)(force)))
            return;
    
        this->biquad_tilde_16_reset();
        this->biquad_tilde_16_setupDone = true;
    }
    
    number gen_07_x1_l_getvalue() {
        return this->gen_07_x1_l_value;
    }
    
    void gen_07_x1_l_setvalue(number val) {
        this->gen_07_x1_l_value = val;
    }
    
    void gen_07_x1_l_reset() {
        this->gen_07_x1_l_value = 0;
    }
    
    void gen_07_x1_l_init() {
        this->gen_07_x1_l_value = 0;
    }
    
    number gen_07_y1_l_getvalue() {
        return this->gen_07_y1_l_value;
    }
    
    void gen_07_y1_l_setvalue(number val) {
        this->gen_07_y1_l_value = val;
    }
    
    void gen_07_y1_l_reset() {
        this->gen_07_y1_l_value = 0;
    }
    
    void gen_07_y1_l_init() {
        this->gen_07_y1_l_value = 0;
    }
    
    number gen_07_x1_r_getvalue() {
        return this->gen_07_x1_r_value;
    }
    
    void gen_07_x1_r_setvalue(number val) {
        this->gen_07_x1_r_value = val;
    }
    
    void gen_07_x1_r_reset() {
        this->gen_07_x1_r_value = 0;
    }
    
    void gen_07_x1_r_init() {
        this->gen_07_x1_r_value = 0;
    }
    
    number gen_07_y1_r_getvalue() {
        return this->gen_07_y1_r_value;
    }
    
    void gen_07_y1_r_setvalue(number val) {
        this->gen_07_y1_r_value = val;
    }
    
    void gen_07_y1_r_reset() {
        this->gen_07_y1_r_value = 0;
    }
    
    void gen_07_y1_r_init() {
        this->gen_07_y1_r_value = 0;
    }
    
    array<number, 5> filtercoeff_08_localop_next(number frequency, number q, number gain, number type) {
        number omega = frequency * this->filtercoeff_08_localop_twopi_over_sr;
        this->filtercoeff_08_localop_cs = rnbo_cos(omega);
        this->filtercoeff_08_localop_sn = rnbo_sin(omega);
        this->filtercoeff_08_localop_one_over_gain = (gain >= 0 ? (number)1 / gain : 0.0);
        this->filtercoeff_08_localop_one_over_q = (number)1 / q;
        this->filtercoeff_08_localop_alpha = this->filtercoeff_08_localop_sn * 0.5 * this->filtercoeff_08_localop_one_over_q;
    
        switch ((int)type) {
        case 5:
            {
            this->filtercoeff_08_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_08_localop_beta = this->safesqrt(
                (this->filtercoeff_08_localop_A * this->filtercoeff_08_localop_A + 1.) * this->filtercoeff_08_localop_one_over_q - (this->filtercoeff_08_localop_A - 1.) * (this->filtercoeff_08_localop_A - 1.)
            );
    
            this->filtercoeff_08_localop_b0 = (number)1 / (this->filtercoeff_08_localop_A + 1. + (this->filtercoeff_08_localop_A - 1.) * this->filtercoeff_08_localop_cs + this->filtercoeff_08_localop_beta * this->filtercoeff_08_localop_sn);
            break;
            }
        case 6:
            {
            this->filtercoeff_08_localop_A = this->safesqrt(gain);
    
            this->filtercoeff_08_localop_beta = this->safesqrt(
                (this->filtercoeff_08_localop_A * this->filtercoeff_08_localop_A + 1.) * this->filtercoeff_08_localop_one_over_q - (this->filtercoeff_08_localop_A - 1.) * (this->filtercoeff_08_localop_A - 1.)
            );
    
            this->filtercoeff_08_localop_b0 = (number)1 / (this->filtercoeff_08_localop_A + 1. - (this->filtercoeff_08_localop_A - 1.) * this->filtercoeff_08_localop_cs + this->filtercoeff_08_localop_beta * this->filtercoeff_08_localop_sn);
            break;
            }
        case 4:
            {
            this->filtercoeff_08_localop_A = this->safesqrt(gain);
            this->filtercoeff_08_localop_one_over_a = (this->filtercoeff_08_localop_A == 0 ? 0 : (number)1 / this->filtercoeff_08_localop_A);
            this->filtercoeff_08_localop_b0 = (number)1 / (1. + this->filtercoeff_08_localop_alpha * this->filtercoeff_08_localop_one_over_a);
            break;
            }
        case 9:
        case 10:
        case 11:
        case 13:
        case 14:
            {
            this->filtercoeff_08_localop_b0 = (number)1 / (1. + this->filtercoeff_08_localop_alpha);
            this->filtercoeff_08_localop_b0g = (number)1 / (this->filtercoeff_08_localop_one_over_gain + this->filtercoeff_08_localop_alpha * this->filtercoeff_08_localop_one_over_gain);
            break;
            }
        default:
            {
            this->filtercoeff_08_localop_b0 = (number)1 / (1. + this->filtercoeff_08_localop_alpha);
            break;
            }
        }
    
        switch ((int)type) {
        case 0:
            {
            this->filtercoeff_08_localop_la0 = this->filtercoeff_08_localop_la2 = (1. - this->filtercoeff_08_localop_cs) * 0.5 * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la1 = (1. - this->filtercoeff_08_localop_cs) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0;
            break;
            }
        case 1:
            {
            this->filtercoeff_08_localop_la0 = this->filtercoeff_08_localop_la2 = (1. + this->filtercoeff_08_localop_cs) * 0.5 * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la1 = -(1. + this->filtercoeff_08_localop_cs) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0;
            break;
            }
        case 2:
            {
            this->filtercoeff_08_localop_la0 = this->filtercoeff_08_localop_alpha * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la1 = 0.;
            this->filtercoeff_08_localop_la2 = -this->filtercoeff_08_localop_alpha * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0;
            break;
            }
        case 7:
            {
            this->filtercoeff_08_localop_la0 = this->filtercoeff_08_localop_alpha * q * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la1 = 0.;
            this->filtercoeff_08_localop_la2 = -this->filtercoeff_08_localop_alpha * q * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0;
            break;
            }
        case 3:
            {
            this->filtercoeff_08_localop_la1 = this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la0 = this->filtercoeff_08_localop_la2 = this->filtercoeff_08_localop_b0;
            break;
            }
        case 8:
            {
            this->filtercoeff_08_localop_la1 = this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = this->filtercoeff_08_localop_la0 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la2 = 1.0;
            break;
            }
        case 4:
            {
            this->filtercoeff_08_localop_la0 = (1. + this->filtercoeff_08_localop_alpha * this->filtercoeff_08_localop_A) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la1 = this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la2 = (1. - this->filtercoeff_08_localop_alpha * this->filtercoeff_08_localop_A) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (1. - this->filtercoeff_08_localop_alpha * this->filtercoeff_08_localop_one_over_a) * this->filtercoeff_08_localop_b0;
            break;
            }
        case 5:
            {
            this->filtercoeff_08_localop_la0 = this->filtercoeff_08_localop_A * (this->filtercoeff_08_localop_A + 1. - (this->filtercoeff_08_localop_A - 1.) * this->filtercoeff_08_localop_cs + this->filtercoeff_08_localop_beta * this->filtercoeff_08_localop_sn) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la1 = 2. * this->filtercoeff_08_localop_A * (this->filtercoeff_08_localop_A - 1 - (this->filtercoeff_08_localop_A + 1) * this->filtercoeff_08_localop_cs) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la2 = this->filtercoeff_08_localop_A * (this->filtercoeff_08_localop_A + 1. - (this->filtercoeff_08_localop_A - 1.) * this->filtercoeff_08_localop_cs - this->filtercoeff_08_localop_beta * this->filtercoeff_08_localop_sn) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb1 = -2. * (this->filtercoeff_08_localop_A - 1. + (this->filtercoeff_08_localop_A + 1.) * this->filtercoeff_08_localop_cs) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (this->filtercoeff_08_localop_A + 1. + (this->filtercoeff_08_localop_A - 1.) * this->filtercoeff_08_localop_cs - this->filtercoeff_08_localop_beta * this->filtercoeff_08_localop_sn) * this->filtercoeff_08_localop_b0;
            break;
            }
        case 6:
            {
            this->filtercoeff_08_localop_la0 = this->filtercoeff_08_localop_A * (this->filtercoeff_08_localop_A + 1. + (this->filtercoeff_08_localop_A - 1.) * this->filtercoeff_08_localop_cs + this->filtercoeff_08_localop_beta * this->filtercoeff_08_localop_sn) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la1 = -2. * this->filtercoeff_08_localop_A * (this->filtercoeff_08_localop_A - 1. + (this->filtercoeff_08_localop_A + 1.) * this->filtercoeff_08_localop_cs) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la2 = this->filtercoeff_08_localop_A * (this->filtercoeff_08_localop_A + 1. + (this->filtercoeff_08_localop_A - 1.) * this->filtercoeff_08_localop_cs - this->filtercoeff_08_localop_beta * this->filtercoeff_08_localop_sn) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb1 = 2. * (this->filtercoeff_08_localop_A - 1. - (this->filtercoeff_08_localop_A + 1.) * this->filtercoeff_08_localop_cs) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (this->filtercoeff_08_localop_A + 1. - (this->filtercoeff_08_localop_A - 1.) * this->filtercoeff_08_localop_cs - this->filtercoeff_08_localop_beta * this->filtercoeff_08_localop_sn) * this->filtercoeff_08_localop_b0;
            break;
            }
        case 9:
            {
            this->filtercoeff_08_localop_b0g = (number)1 / (this->filtercoeff_08_localop_one_over_gain + this->filtercoeff_08_localop_alpha * this->filtercoeff_08_localop_one_over_gain);
            this->filtercoeff_08_localop_la0 = this->filtercoeff_08_localop_la2 = (1. - this->filtercoeff_08_localop_cs) * 0.5 * this->filtercoeff_08_localop_b0g;
            this->filtercoeff_08_localop_la1 = (1. - this->filtercoeff_08_localop_cs) * this->filtercoeff_08_localop_b0g;
            this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0;
            break;
            }
        case 10:
            {
            this->filtercoeff_08_localop_b0g = (number)1 / (this->filtercoeff_08_localop_one_over_gain + this->filtercoeff_08_localop_alpha * this->filtercoeff_08_localop_one_over_gain);
            this->filtercoeff_08_localop_la0 = this->filtercoeff_08_localop_la2 = (1. + this->filtercoeff_08_localop_cs) * 0.5 * this->filtercoeff_08_localop_b0g;
            this->filtercoeff_08_localop_la1 = -(1. + this->filtercoeff_08_localop_cs) * this->filtercoeff_08_localop_b0g;
            this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0;
            break;
            }
        case 11:
            {
            this->filtercoeff_08_localop_la0 = this->filtercoeff_08_localop_alpha * gain * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la1 = 0.;
            this->filtercoeff_08_localop_la2 = -this->filtercoeff_08_localop_alpha * gain * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0;
            break;
            }
        case 13:
            {
            this->filtercoeff_08_localop_la0 = this->filtercoeff_08_localop_alpha * gain * q * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la1 = 0.;
            this->filtercoeff_08_localop_la2 = -this->filtercoeff_08_localop_alpha * gain * q * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0;
            break;
            }
        case 12:
            {
            this->filtercoeff_08_localop_b0g = (number)1 / (this->filtercoeff_08_localop_one_over_gain + this->filtercoeff_08_localop_alpha * this->filtercoeff_08_localop_one_over_gain);
            this->filtercoeff_08_localop_la1 = this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs;
            this->filtercoeff_08_localop_lb2 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la1 *= this->filtercoeff_08_localop_b0g;
            this->filtercoeff_08_localop_lb1 *= this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_la0 = this->filtercoeff_08_localop_b0g;
            this->filtercoeff_08_localop_la2 = this->filtercoeff_08_localop_b0g;
            break;
            }
        case 14:
            {
            this->filtercoeff_08_localop_b0g = (number)1 / (this->filtercoeff_08_localop_one_over_gain + this->filtercoeff_08_localop_alpha * this->filtercoeff_08_localop_one_over_gain);
            this->filtercoeff_08_localop_la0 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0g;
            this->filtercoeff_08_localop_la1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0g;
            this->filtercoeff_08_localop_la2 = gain;
            this->filtercoeff_08_localop_lb1 = -2. * this->filtercoeff_08_localop_cs * this->filtercoeff_08_localop_b0;
            this->filtercoeff_08_localop_lb2 = (1. - this->filtercoeff_08_localop_alpha) * this->filtercoeff_08_localop_b0;
            break;
            }
        case 15:
            {
            this->filtercoeff_08_localop_la0 = 1;
            this->filtercoeff_08_localop_la1 = 0;
            this->filtercoeff_08_localop_la2 = 0;
            this->filtercoeff_08_localop_lb1 = 0;
            this->filtercoeff_08_localop_lb2 = 0;
            }
        default:
            {
            break;
            }
        }
    
        return {
            this->filtercoeff_08_localop_la0,
            this->filtercoeff_08_localop_la1,
            this->filtercoeff_08_localop_la2,
            this->filtercoeff_08_localop_lb1,
            this->filtercoeff_08_localop_lb2
        };
    }
    
    void filtercoeff_08_localop_dspsetup() {
        this->filtercoeff_08_localop_twopi_over_sr = (number)6.283185307179586 / this->sr;
    }
    
    void filtercoeff_08_localop_reset() {
        this->filtercoeff_08_localop_twopi_over_sr = 0;
        this->filtercoeff_08_localop_cs = 0;
        this->filtercoeff_08_localop_sn = 0;
        this->filtercoeff_08_localop_one_over_gain = 0;
        this->filtercoeff_08_localop_one_over_q = 0;
        this->filtercoeff_08_localop_alpha = 0;
        this->filtercoeff_08_localop_beta = 0;
        this->filtercoeff_08_localop_b0 = 0;
        this->filtercoeff_08_localop_b0g = 0;
        this->filtercoeff_08_localop_A = 0;
        this->filtercoeff_08_localop_one_over_a = 0;
        this->filtercoeff_08_localop_la0 = 0;
        this->filtercoeff_08_localop_la1 = 0;
        this->filtercoeff_08_localop_la2 = 0;
        this->filtercoeff_08_localop_lb1 = 0;
        this->filtercoeff_08_localop_lb2 = 0;
    }
    
    void filtercoeff_08_updateTerms(number local_frequency, number local_gain, number local_q) {
        if ((bool)(this->filtercoeff_08_force_update) || local_frequency != this->filtercoeff_08_last_frequency || local_q != this->filtercoeff_08_last_q || local_gain != this->filtercoeff_08_last_gain || this->filtercoeff_08_type != this->filtercoeff_08_last_type) {
            array<number, 5> tmp = this->filtercoeff_08_localop_next(local_frequency, local_q, local_gain, this->filtercoeff_08_type);
            this->filtercoeff_08_la0 = tmp[0];
            this->filtercoeff_08_la1 = tmp[1];
            this->filtercoeff_08_la2 = tmp[2];
            this->filtercoeff_08_lb1 = tmp[3];
            this->filtercoeff_08_lb2 = tmp[4];
            this->filtercoeff_08_last_frequency = local_frequency;
            this->filtercoeff_08_last_q = local_q;
            this->filtercoeff_08_last_gain = local_gain;
            this->filtercoeff_08_last_type = this->filtercoeff_08_type;
            this->filtercoeff_08_force_update = false;
        }
    }
    
    void filtercoeff_08_dspsetup(bool force) {
        if ((bool)(this->filtercoeff_08_setupDone) && (bool)(!(bool)(force)))
            return;
    
        {
            this->filtercoeff_08_activeResamp = this->vectorsize();
        }
    
        this->filtercoeff_08_resamp_counter = 0;
        this->filtercoeff_08_la0 = 0.;
        this->filtercoeff_08_la1 = 0.;
        this->filtercoeff_08_la2 = 0.;
        this->filtercoeff_08_lb1 = 0.;
        this->filtercoeff_08_lb2 = 0.;
        this->filtercoeff_08_last_frequency = -1.;
        this->filtercoeff_08_last_q = -1.;
        this->filtercoeff_08_last_gain = -1.;
        this->filtercoeff_08_last_type = this->filtercoeff_08_type;
        this->filtercoeff_08_force_update = true;
        this->filtercoeff_08_setupDone = true;
        this->filtercoeff_08_localop_dspsetup();
    }
    
    void numberobj_45_init() {
        this->numberobj_45_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("400Hz~/number_obj-3"), 1, this->_currentTime);
    }
    
    void numberobj_45_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_45_value;
    }
    
    void numberobj_45_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_45_value_set(preset["value"]);
    }
    
    void numberobj_46_init() {
        this->numberobj_46_currentFormat = 6;
        this->getEngine()->sendNumMessage(TAG("setup"), TAG("400Hz~/number_obj-4"), 1, this->_currentTime);
    }
    
    void numberobj_46_getPresetValue(PatcherStateInterface& preset) {
        preset["value"] = this->numberobj_46_value;
    }
    
    void numberobj_46_setPresetValue(PatcherStateInterface& preset) {
        if ((bool)(stateIsEmpty(preset)))
            return;
    
        this->numberobj_46_value_set(preset["value"]);
    }
    
    bool stackprotect_check() {
        this->stackprotect_count++;
    
        if (this->stackprotect_count > 128) {
            console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
            return true;
        }
    
        return false;
    }
    
    void updateTime(MillisecondTime time) {
        this->_currentTime = time;
        this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));
    
        if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
            this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;
    
        if (this->sampleOffsetIntoNextAudioBuffer < 0)
            this->sampleOffsetIntoNextAudioBuffer = 0;
    }
    
    void assign_defaults()
    {
        dspexpr_21_in1 = 0;
        dspexpr_21_in2 = 0;
        dspexpr_21_in3 = 0;
        biquad_tilde_15_x = 0;
        biquad_tilde_15_a0 = 0;
        biquad_tilde_15_a1 = 0;
        biquad_tilde_15_a2 = 0;
        biquad_tilde_15_b1 = 0;
        biquad_tilde_15_b2 = 0;
        linetilde_17_time = 10;
        linetilde_17_keepramp = 1;
        dspexpr_22_in1 = 0;
        dspexpr_22_in2 = 0;
        dspexpr_22_in3 = 0;
        biquad_tilde_16_x = 0;
        biquad_tilde_16_a0 = 0;
        biquad_tilde_16_a1 = 0;
        biquad_tilde_16_a2 = 0;
        biquad_tilde_16_b1 = 0;
        biquad_tilde_16_b2 = 0;
        gen_07_in1 = 0;
        gen_07_in2 = 0;
        gen_07_in3 = 0;
        gen_07_in4 = 0;
        gen_07_in5 = 0;
        filtercoeff_08_frequency = 400;
        filtercoeff_08_gain = 1;
        filtercoeff_08_q = 1;
        filtercoeff_08_type = 4;
        numberobj_45_value = 0;
        numberobj_45_value_setter(numberobj_45_value);
        numberobj_46_value = 0;
        numberobj_46_value_setter(numberobj_46_value);
        expr_24_in1 = 0;
        expr_24_out1 = 0;
        linetilde_18_time = 10;
        linetilde_18_keepramp = 1;
        p_09_target = 0;
        _currentTime = 0;
        audioProcessSampleCount = 0;
        sampleOffsetIntoNextAudioBuffer = 0;
        zeroBuffer = nullptr;
        dummyBuffer = nullptr;
        signals[0] = nullptr;
        signals[1] = nullptr;
        signals[2] = nullptr;
        signals[3] = nullptr;
        signals[4] = nullptr;
        signals[5] = nullptr;
        signals[6] = nullptr;
        signals[7] = nullptr;
        didAllocateSignals = 0;
        vs = 0;
        maxvs = 0;
        sr = 44100;
        invsr = 0.00002267573696;
        biquad_tilde_15_x1 = 0;
        biquad_tilde_15_x2 = 0;
        biquad_tilde_15_y1 = 0;
        biquad_tilde_15_y2 = 0;
        biquad_tilde_15_setupDone = false;
        linetilde_17_currentValue = 0;
        biquad_tilde_16_x1 = 0;
        biquad_tilde_16_x2 = 0;
        biquad_tilde_16_y1 = 0;
        biquad_tilde_16_y2 = 0;
        biquad_tilde_16_setupDone = false;
        gen_07_x1_l_value = 0;
        gen_07_y1_l_value = 0;
        gen_07_x1_r_value = 0;
        gen_07_y1_r_value = 0;
        filtercoeff_08_K_EPSILON = 1e-9;
        filtercoeff_08_setupDone = false;
        numberobj_45_currentFormat = 6;
        numberobj_45_lastValue = 0;
        numberobj_46_currentFormat = 6;
        numberobj_46_lastValue = 0;
        linetilde_18_currentValue = 1;
        stackprotect_count = 0;
        _voiceIndex = 0;
        _noteNumber = 0;
        isMuted = 1;
        parameterOffset = 0;
    }
    
    // member variables
    
        number dspexpr_21_in1;
        number dspexpr_21_in2;
        number dspexpr_21_in3;
        number biquad_tilde_15_x;
        number biquad_tilde_15_a0;
        number biquad_tilde_15_a1;
        number biquad_tilde_15_a2;
        number biquad_tilde_15_b1;
        number biquad_tilde_15_b2;
        list linetilde_17_segments;
        number linetilde_17_time;
        number linetilde_17_keepramp;
        number dspexpr_22_in1;
        number dspexpr_22_in2;
        number dspexpr_22_in3;
        number biquad_tilde_16_x;
        number biquad_tilde_16_a0;
        number biquad_tilde_16_a1;
        number biquad_tilde_16_a2;
        number biquad_tilde_16_b1;
        number biquad_tilde_16_b2;
        number gen_07_in1;
        number gen_07_in2;
        number gen_07_in3;
        number gen_07_in4;
        number gen_07_in5;
        number filtercoeff_08_frequency;
        number filtercoeff_08_gain;
        number filtercoeff_08_q;
        Int filtercoeff_08_type;
        number numberobj_45_value;
        number numberobj_46_value;
        number expr_24_in1;
        number expr_24_out1;
        list linetilde_18_segments;
        number linetilde_18_time;
        number linetilde_18_keepramp;
        number p_09_target;
        MillisecondTime _currentTime;
        UInt64 audioProcessSampleCount;
        SampleIndex sampleOffsetIntoNextAudioBuffer;
        signal zeroBuffer;
        signal dummyBuffer;
        SampleValue * signals[8];
        bool didAllocateSignals;
        Index vs;
        Index maxvs;
        number sr;
        number invsr;
        number biquad_tilde_15_x1;
        number biquad_tilde_15_x2;
        number biquad_tilde_15_y1;
        number biquad_tilde_15_y2;
        bool biquad_tilde_15_setupDone;
        list linetilde_17_activeRamps;
        number linetilde_17_currentValue;
        number biquad_tilde_16_x1;
        number biquad_tilde_16_x2;
        number biquad_tilde_16_y1;
        number biquad_tilde_16_y2;
        bool biquad_tilde_16_setupDone;
        number gen_07_x1_l_value;
        number gen_07_y1_l_value;
        number gen_07_x1_r_value;
        number gen_07_y1_r_value;
        number filtercoeff_08_resamp_counter;
        number filtercoeff_08_activeResamp;
        number filtercoeff_08_K_EPSILON;
        number filtercoeff_08_la0;
        number filtercoeff_08_la1;
        number filtercoeff_08_la2;
        number filtercoeff_08_lb1;
        number filtercoeff_08_lb2;
        number filtercoeff_08_last_frequency;
        number filtercoeff_08_last_q;
        number filtercoeff_08_last_gain;
        Int filtercoeff_08_last_type;
        bool filtercoeff_08_force_update;
        number filtercoeff_08_localop_twopi_over_sr;
        number filtercoeff_08_localop_cs;
        number filtercoeff_08_localop_sn;
        number filtercoeff_08_localop_one_over_gain;
        number filtercoeff_08_localop_one_over_q;
        number filtercoeff_08_localop_alpha;
        number filtercoeff_08_localop_beta;
        number filtercoeff_08_localop_b0;
        number filtercoeff_08_localop_b0g;
        number filtercoeff_08_localop_A;
        number filtercoeff_08_localop_one_over_a;
        number filtercoeff_08_localop_la0;
        number filtercoeff_08_localop_la1;
        number filtercoeff_08_localop_la2;
        number filtercoeff_08_localop_lb1;
        number filtercoeff_08_localop_lb2;
        bool filtercoeff_08_setupDone;
        Int numberobj_45_currentFormat;
        number numberobj_45_lastValue;
        Int numberobj_46_currentFormat;
        number numberobj_46_lastValue;
        list linetilde_18_activeRamps;
        number linetilde_18_currentValue;
        number stackprotect_count;
        Index _voiceIndex;
        Int _noteNumber;
        Index isMuted;
        ParameterIndex parameterOffset;
        RNBOSubpatcher_198* p_09;
    
};

Grafik7()
{
}

~Grafik7()
{
    delete this->p_10;
    delete this->p_11;
    delete this->p_12;
    delete this->p_13;
    delete this->p_14;
    delete this->p_15;
    delete this->p_16;
    delete this->p_17;
    delete this->p_18;
}

Grafik7* getTopLevelPatcher() {
    return this;
}

void cancelClockEvents()
{
    getEngine()->flushClockEvents(this, 892732297, false);
    getEngine()->flushClockEvents(this, -62043057, false);
    getEngine()->flushClockEvents(this, -1621164530, false);
    getEngine()->flushClockEvents(this, 1114681293, false);
}

template <typename T> void listquicksort(T& arr, T& sortindices, Int l, Int h, bool ascending) {
    if (l < h) {
        Int p = (Int)(this->listpartition(arr, sortindices, l, h, ascending));
        this->listquicksort(arr, sortindices, l, p - 1, ascending);
        this->listquicksort(arr, sortindices, p + 1, h, ascending);
    }
}

template <typename T> Int listpartition(T& arr, T& sortindices, Int l, Int h, bool ascending) {
    number x = arr[(Index)h];
    Int i = (Int)(l - 1);

    for (Int j = (Int)(l); j <= h - 1; j++) {
        bool asc = (bool)((bool)(ascending) && arr[(Index)j] <= x);
        bool desc = (bool)((bool)(!(bool)(ascending)) && arr[(Index)j] >= x);

        if ((bool)(asc) || (bool)(desc)) {
            i++;
            this->listswapelements(arr, i, j);
            this->listswapelements(sortindices, i, j);
        }
    }

    i++;
    this->listswapelements(arr, i, h);
    this->listswapelements(sortindices, i, h);
    return i;
}

template <typename T> void listswapelements(T& arr, Int a, Int b) {
    auto tmp = arr[(Index)a];
    arr[(Index)a] = arr[(Index)b];
    arr[(Index)b] = tmp;
}

SampleIndex currentsampletime() {
    return this->audioProcessSampleCount + this->sampleOffsetIntoNextAudioBuffer;
}

number mstosamps(MillisecondTime ms) {
    return ms * this->sr * 0.001;
}

Index voice() {
    return this->_voiceIndex;
}

number random(number low, number high) {
    number range = high - low;
    return globalrandom() * range + low;
}

ParameterValue fromnormalized(ParameterIndex index, ParameterValue normalizedValue) {
    return this->convertFromNormalizedParameterValue(index, normalizedValue);
}

number maximum(number x, number y) {
    return (x < y ? y : x);
}

MillisecondTime sampstoms(number samps) {
    return samps * 1000 / this->sr;
}

Index getNumMidiInputPorts() const {
    return 1;
}

void processMidiEvent(MillisecondTime time, int port, ConstByteArray data, Index length) {
    this->updateTime(time);
    this->ctlin_01_midihandler(data[0] & 240, (data[0] & 15) + 1, port, data, length);
    this->ctlin_02_midihandler(data[0] & 240, (data[0] & 15) + 1, port, data, length);
    this->ctlin_03_midihandler(data[0] & 240, (data[0] & 15) + 1, port, data, length);
    this->ctlin_04_midihandler(data[0] & 240, (data[0] & 15) + 1, port, data, length);
    this->ctlin_05_midihandler(data[0] & 240, (data[0] & 15) + 1, port, data, length);
    this->ctlin_06_midihandler(data[0] & 240, (data[0] & 15) + 1, port, data, length);
    this->ctlin_07_midihandler(data[0] & 240, (data[0] & 15) + 1, port, data, length);
    this->ctlin_08_midihandler(data[0] & 240, (data[0] & 15) + 1, port, data, length);
    this->ctlin_09_midihandler(data[0] & 240, (data[0] & 15) + 1, port, data, length);
    this->ctlin_10_midihandler(data[0] & 240, (data[0] & 15) + 1, port, data, length);
}

Index getNumMidiOutputPorts() const {
    return 0;
}

void process(
    const SampleValue * const* inputs,
    Index numInputs,
    SampleValue * const* outputs,
    Index numOutputs,
    Index n
) {
    this->vs = n;
    this->updateTime(this->getEngine()->getCurrentTime());
    SampleValue * out1 = (numOutputs >= 1 && outputs[0] ? outputs[0] : this->dummyBuffer);
    SampleValue * out2 = (numOutputs >= 2 && outputs[1] ? outputs[1] : this->dummyBuffer);
    const SampleValue * in1 = (numInputs >= 1 && inputs[0] ? inputs[0] : this->zeroBuffer);
    const SampleValue * in2 = (numInputs >= 2 && inputs[1] ? inputs[1] : this->zeroBuffer);
    this->linetilde_19_perform(this->signals[0], n);
    this->p_10_perform(in1, in2, this->signals[1], this->signals[2], n);
    this->p_12_perform(this->signals[1], this->signals[2], this->signals[3], this->signals[4], n);
    this->p_13_perform(this->signals[3], this->signals[4], this->signals[2], this->signals[1], n);
    this->p_18_perform(this->signals[2], this->signals[1], this->signals[4], this->signals[3], n);
    this->p_17_perform(this->signals[4], this->signals[3], this->signals[1], this->signals[2], n);
    this->p_16_perform(this->signals[1], this->signals[2], this->signals[3], this->signals[4], n);
    this->p_15_perform(this->signals[3], this->signals[4], this->signals[2], this->signals[1], n);
    this->p_14_perform(this->signals[2], this->signals[1], this->signals[4], this->signals[3], n);
    this->p_11_perform(this->signals[4], this->signals[3], this->signals[1], this->signals[2], n);
    this->linetilde_20_perform(this->signals[3], n);
    this->dspexpr_26_perform(this->signals[2], this->signals[3], this->signals[4], n);
    this->dspexpr_24_perform(this->signals[1], this->signals[4], this->signals[5], n);
    this->dspexpr_30_perform(this->signals[1], this->signals[3], this->signals[4], n);
    this->dspexpr_29_perform(this->signals[2], this->signals[4], this->signals[3], n);
    this->noise_tilde_01_perform(this->signals[4], n);
    this->onepole_tilde_03_perform(this->signals[4], this->onepole_tilde_03_freqInHz, this->signals[2], n);
    this->noise_tilde_02_perform(this->signals[4], n);
    this->onepole_tilde_04_perform(this->signals[4], this->onepole_tilde_04_freqInHz, this->signals[1], n);
    this->linetilde_21_perform(this->signals[4], n);
    this->dspexpr_32_perform(this->signals[1], this->signals[4], this->signals[6], n);
    this->dspexpr_28_perform(this->signals[3], this->signals[6], this->signals[1], n);
    this->dspexpr_27_perform(this->signals[1], in2, this->signals[0], this->signals[6], n);
    this->dspexpr_31_perform(this->signals[2], this->signals[4], this->signals[1], n);
    this->dspexpr_25_perform(this->signals[5], this->signals[1], this->signals[4], n);
    this->dspexpr_23_perform(this->signals[4], in1, this->signals[0], this->signals[1], n);
    this->gen_08_perform(this->signals[1], this->signals[6], out1, out2, n);
    this->stackprotect_perform(n);
    this->globaltransport_advance();
    this->audioProcessSampleCount += this->vs;
}

void prepareToProcess(number sampleRate, Index maxBlockSize, bool force) {
    if (this->maxvs < maxBlockSize || !this->didAllocateSignals) {
        Index i;

        for (i = 0; i < 7; i++) {
            this->signals[i] = resizeSignal(this->signals[i], this->maxvs, maxBlockSize);
        }

        this->globaltransport_tempo = resizeSignal(this->globaltransport_tempo, this->maxvs, maxBlockSize);
        this->globaltransport_state = resizeSignal(this->globaltransport_state, this->maxvs, maxBlockSize);
        this->zeroBuffer = resizeSignal(this->zeroBuffer, this->maxvs, maxBlockSize);
        this->dummyBuffer = resizeSignal(this->dummyBuffer, this->maxvs, maxBlockSize);
        this->didAllocateSignals = true;
    }

    const bool sampleRateChanged = sampleRate != this->sr;
    const bool maxvsChanged = maxBlockSize != this->maxvs;
    const bool forceDSPSetup = sampleRateChanged || maxvsChanged || force;

    if (sampleRateChanged || maxvsChanged) {
        this->vs = maxBlockSize;
        this->maxvs = maxBlockSize;
        this->sr = sampleRate;
        this->invsr = 1 / sampleRate;
    }

    this->onepole_tilde_03_dspsetup(forceDSPSetup);
    this->onepole_tilde_04_dspsetup(forceDSPSetup);
    this->globaltransport_dspsetup(forceDSPSetup);
    this->p_10->prepareToProcess(sampleRate, maxBlockSize, force);
    this->p_11->prepareToProcess(sampleRate, maxBlockSize, force);
    this->p_12->prepareToProcess(sampleRate, maxBlockSize, force);
    this->p_13->prepareToProcess(sampleRate, maxBlockSize, force);
    this->p_14->prepareToProcess(sampleRate, maxBlockSize, force);
    this->p_15->prepareToProcess(sampleRate, maxBlockSize, force);
    this->p_16->prepareToProcess(sampleRate, maxBlockSize, force);
    this->p_17->prepareToProcess(sampleRate, maxBlockSize, force);
    this->p_18->prepareToProcess(sampleRate, maxBlockSize, force);

    if (sampleRateChanged)
        this->onSampleRateChanged(sampleRate);
}

void setProbingTarget(MessageTag id) {
    switch (id) {
    default:
        {
        this->setProbingIndex(-1);
        break;
        }
    }
}

void setProbingIndex(ProbingIndex ) {}

Index getProbingChannels(MessageTag outletId) const {
    RNBO_UNUSED(outletId);
    return 0;
}

DataRef* getDataRef(DataRefIndex index)  {
    switch (index) {
    default:
        {
        return nullptr;
        }
    }
}

DataRefIndex getNumDataRefs() const {
    return 0;
}

void fillDataRef(DataRefIndex , DataRef& ) {}

void processDataViewUpdate(DataRefIndex index, MillisecondTime time) {
    this->p_10->processDataViewUpdate(index, time);
    this->p_11->processDataViewUpdate(index, time);
    this->p_12->processDataViewUpdate(index, time);
    this->p_13->processDataViewUpdate(index, time);
    this->p_14->processDataViewUpdate(index, time);
    this->p_15->processDataViewUpdate(index, time);
    this->p_16->processDataViewUpdate(index, time);
    this->p_17->processDataViewUpdate(index, time);
    this->p_18->processDataViewUpdate(index, time);
}

void initialize() {
    this->assign_defaults();
    this->setState();
    this->initializeObjects();
    this->allocateDataRefs();
    this->startup();
}

Index getIsMuted()  {
    return this->isMuted;
}

void setIsMuted(Index v)  {
    this->isMuted = v;
}

void onSampleRateChanged(double ) {}

Index getPatcherSerial() const {
    return 0;
}

void getState(PatcherStateInterface& ) {}

void setState() {
    this->p_10 = new RNBOSubpatcher_199();
    this->p_10->setEngineAndPatcher(this->getEngine(), this);
    this->p_10->initialize();
    this->p_10->setParameterOffset(this->getParameterOffset(this->p_10));
    this->p_11 = new RNBOSubpatcher_200();
    this->p_11->setEngineAndPatcher(this->getEngine(), this);
    this->p_11->initialize();
    this->p_11->setParameterOffset(this->getParameterOffset(this->p_11));
    this->p_12 = new RNBOSubpatcher_201();
    this->p_12->setEngineAndPatcher(this->getEngine(), this);
    this->p_12->initialize();
    this->p_12->setParameterOffset(this->getParameterOffset(this->p_12));
    this->p_13 = new RNBOSubpatcher_202();
    this->p_13->setEngineAndPatcher(this->getEngine(), this);
    this->p_13->initialize();
    this->p_13->setParameterOffset(this->getParameterOffset(this->p_13));
    this->p_14 = new RNBOSubpatcher_203();
    this->p_14->setEngineAndPatcher(this->getEngine(), this);
    this->p_14->initialize();
    this->p_14->setParameterOffset(this->getParameterOffset(this->p_14));
    this->p_15 = new RNBOSubpatcher_204();
    this->p_15->setEngineAndPatcher(this->getEngine(), this);
    this->p_15->initialize();
    this->p_15->setParameterOffset(this->getParameterOffset(this->p_15));
    this->p_16 = new RNBOSubpatcher_205();
    this->p_16->setEngineAndPatcher(this->getEngine(), this);
    this->p_16->initialize();
    this->p_16->setParameterOffset(this->getParameterOffset(this->p_16));
    this->p_17 = new RNBOSubpatcher_206();
    this->p_17->setEngineAndPatcher(this->getEngine(), this);
    this->p_17->initialize();
    this->p_17->setParameterOffset(this->getParameterOffset(this->p_17));
    this->p_18 = new RNBOSubpatcher_207();
    this->p_18->setEngineAndPatcher(this->getEngine(), this);
    this->p_18->initialize();
    this->p_18->setParameterOffset(this->getParameterOffset(this->p_18));
}

void getPreset(PatcherStateInterface& preset) {
    preset["__presetid"] = "rnbo";
    this->param_01_getPresetValue(getSubState(preset, "6.4kHz"));
    this->param_02_getPresetValue(getSubState(preset, "3.2kHz"));
    this->param_03_getPresetValue(getSubState(preset, "1.6kHz"));
    this->param_04_getPresetValue(getSubState(preset, "level"));
    this->param_05_getPresetValue(getSubState(preset, "800Hz"));
    this->param_06_getPresetValue(getSubState(preset, "400Hz"));
    this->param_07_getPresetValue(getSubState(preset, "200Hz"));
    this->param_08_getPresetValue(getSubState(preset, "100Hz"));
    this->param_09_getPresetValue(getSubState(preset, "Bypass7"));
    this->param_10_getPresetValue(getSubState(preset, "EQVersion"));
    this->param_11_getPresetValue(getSubState(preset, "Analog"));
    this->p_10->getPreset(getSubState(getSubState(preset, "__sps"), "Head-Bump"));
    this->p_11->getPreset(getSubState(getSubState(preset, "__sps"), "Level~"));
    this->p_12->getPreset(getSubState(getSubState(preset, "__sps"), "100Hz~"));
    this->p_13->getPreset(getSubState(getSubState(preset, "__sps"), "200Hz~"));
    this->p_14->getPreset(getSubState(getSubState(preset, "__sps"), "6.4kHz~"));
    this->p_15->getPreset(getSubState(getSubState(preset, "__sps"), "3.2kHz~"));
    this->p_16->getPreset(getSubState(getSubState(preset, "__sps"), "1.6kHz~"));
    this->p_17->getPreset(getSubState(getSubState(preset, "__sps"), "800Hz~"));
    this->p_18->getPreset(getSubState(getSubState(preset, "__sps"), "400Hz~"));
}

void setPreset(MillisecondTime time, PatcherStateInterface& preset) {
    this->updateTime(time);
    this->param_09_setPresetValue(getSubState(preset, "Bypass7"));
    this->param_10_setPresetValue(getSubState(preset, "EQVersion"));
    this->param_11_setPresetValue(getSubState(preset, "Analog"));
    this->param_08_setPresetValue(getSubState(preset, "100Hz"));
    this->param_07_setPresetValue(getSubState(preset, "200Hz"));
    this->param_06_setPresetValue(getSubState(preset, "400Hz"));
    this->param_05_setPresetValue(getSubState(preset, "800Hz"));
    this->param_03_setPresetValue(getSubState(preset, "1.6kHz"));
    this->param_02_setPresetValue(getSubState(preset, "3.2kHz"));
    this->param_01_setPresetValue(getSubState(preset, "6.4kHz"));
    this->param_04_setPresetValue(getSubState(preset, "level"));
}

void setParameterValue(ParameterIndex index, ParameterValue v, MillisecondTime time) {
    this->updateTime(time);

    switch (index) {
    case 0:
        {
        this->param_01_value_set(v);
        break;
        }
    case 1:
        {
        this->param_02_value_set(v);
        break;
        }
    case 2:
        {
        this->param_03_value_set(v);
        break;
        }
    case 3:
        {
        this->param_04_value_set(v);
        break;
        }
    case 4:
        {
        this->param_05_value_set(v);
        break;
        }
    case 5:
        {
        this->param_06_value_set(v);
        break;
        }
    case 6:
        {
        this->param_07_value_set(v);
        break;
        }
    case 7:
        {
        this->param_08_value_set(v);
        break;
        }
    case 8:
        {
        this->param_09_value_set(v);
        break;
        }
    case 9:
        {
        this->param_10_value_set(v);
        break;
        }
    case 10:
        {
        this->param_11_value_set(v);
        break;
        }
    default:
        {
        index -= 11;

        if (index < this->p_10->getNumParameters())
            this->p_10->setParameterValue(index, v, time);

        index -= this->p_10->getNumParameters();

        if (index < this->p_11->getNumParameters())
            this->p_11->setParameterValue(index, v, time);

        index -= this->p_11->getNumParameters();

        if (index < this->p_12->getNumParameters())
            this->p_12->setParameterValue(index, v, time);

        index -= this->p_12->getNumParameters();

        if (index < this->p_13->getNumParameters())
            this->p_13->setParameterValue(index, v, time);

        index -= this->p_13->getNumParameters();

        if (index < this->p_14->getNumParameters())
            this->p_14->setParameterValue(index, v, time);

        index -= this->p_14->getNumParameters();

        if (index < this->p_15->getNumParameters())
            this->p_15->setParameterValue(index, v, time);

        index -= this->p_15->getNumParameters();

        if (index < this->p_16->getNumParameters())
            this->p_16->setParameterValue(index, v, time);

        index -= this->p_16->getNumParameters();

        if (index < this->p_17->getNumParameters())
            this->p_17->setParameterValue(index, v, time);

        index -= this->p_17->getNumParameters();

        if (index < this->p_18->getNumParameters())
            this->p_18->setParameterValue(index, v, time);

        break;
        }
    }
}

void processParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
    this->setParameterValue(index, value, time);
}

void processParameterBangEvent(ParameterIndex index, MillisecondTime time) {
    this->setParameterValue(index, this->getParameterValue(index), time);
}

void processNormalizedParameterEvent(ParameterIndex index, ParameterValue value, MillisecondTime time) {
    this->setParameterValueNormalized(index, value, time);
}

ParameterValue getParameterValue(ParameterIndex index)  {
    switch (index) {
    case 0:
        {
        return this->param_01_value;
        }
    case 1:
        {
        return this->param_02_value;
        }
    case 2:
        {
        return this->param_03_value;
        }
    case 3:
        {
        return this->param_04_value;
        }
    case 4:
        {
        return this->param_05_value;
        }
    case 5:
        {
        return this->param_06_value;
        }
    case 6:
        {
        return this->param_07_value;
        }
    case 7:
        {
        return this->param_08_value;
        }
    case 8:
        {
        return this->param_09_value;
        }
    case 9:
        {
        return this->param_10_value;
        }
    case 10:
        {
        return this->param_11_value;
        }
    default:
        {
        index -= 11;

        if (index < this->p_10->getNumParameters())
            return this->p_10->getParameterValue(index);

        index -= this->p_10->getNumParameters();

        if (index < this->p_11->getNumParameters())
            return this->p_11->getParameterValue(index);

        index -= this->p_11->getNumParameters();

        if (index < this->p_12->getNumParameters())
            return this->p_12->getParameterValue(index);

        index -= this->p_12->getNumParameters();

        if (index < this->p_13->getNumParameters())
            return this->p_13->getParameterValue(index);

        index -= this->p_13->getNumParameters();

        if (index < this->p_14->getNumParameters())
            return this->p_14->getParameterValue(index);

        index -= this->p_14->getNumParameters();

        if (index < this->p_15->getNumParameters())
            return this->p_15->getParameterValue(index);

        index -= this->p_15->getNumParameters();

        if (index < this->p_16->getNumParameters())
            return this->p_16->getParameterValue(index);

        index -= this->p_16->getNumParameters();

        if (index < this->p_17->getNumParameters())
            return this->p_17->getParameterValue(index);

        index -= this->p_17->getNumParameters();

        if (index < this->p_18->getNumParameters())
            return this->p_18->getParameterValue(index);

        return 0;
        }
    }
}

ParameterIndex getNumSignalInParameters() const {
    return 0;
}

ParameterIndex getNumSignalOutParameters() const {
    return 0;
}

ParameterIndex getNumParameters() const {
    return 11 + this->p_10->getNumParameters() + this->p_11->getNumParameters() + this->p_12->getNumParameters() + this->p_13->getNumParameters() + this->p_14->getNumParameters() + this->p_15->getNumParameters() + this->p_16->getNumParameters() + this->p_17->getNumParameters() + this->p_18->getNumParameters();
}

ConstCharPointer getParameterName(ParameterIndex index) const {
    switch (index) {
    case 0:
        {
        return "6.4kHz";
        }
    case 1:
        {
        return "3.2kHz";
        }
    case 2:
        {
        return "1.6kHz";
        }
    case 3:
        {
        return "level";
        }
    case 4:
        {
        return "800Hz";
        }
    case 5:
        {
        return "400Hz";
        }
    case 6:
        {
        return "200Hz";
        }
    case 7:
        {
        return "100Hz";
        }
    case 8:
        {
        return "Bypass7";
        }
    case 9:
        {
        return "EQVersion";
        }
    case 10:
        {
        return "Analog";
        }
    default:
        {
        index -= 11;

        if (index < this->p_10->getNumParameters())
            return this->p_10->getParameterName(index);

        index -= this->p_10->getNumParameters();

        if (index < this->p_11->getNumParameters())
            return this->p_11->getParameterName(index);

        index -= this->p_11->getNumParameters();

        if (index < this->p_12->getNumParameters())
            return this->p_12->getParameterName(index);

        index -= this->p_12->getNumParameters();

        if (index < this->p_13->getNumParameters())
            return this->p_13->getParameterName(index);

        index -= this->p_13->getNumParameters();

        if (index < this->p_14->getNumParameters())
            return this->p_14->getParameterName(index);

        index -= this->p_14->getNumParameters();

        if (index < this->p_15->getNumParameters())
            return this->p_15->getParameterName(index);

        index -= this->p_15->getNumParameters();

        if (index < this->p_16->getNumParameters())
            return this->p_16->getParameterName(index);

        index -= this->p_16->getNumParameters();

        if (index < this->p_17->getNumParameters())
            return this->p_17->getParameterName(index);

        index -= this->p_17->getNumParameters();

        if (index < this->p_18->getNumParameters())
            return this->p_18->getParameterName(index);

        return "bogus";
        }
    }
}

ConstCharPointer getParameterId(ParameterIndex index) const {
    switch (index) {
    case 0:
        {
        return "6.4kHz";
        }
    case 1:
        {
        return "3.2kHz";
        }
    case 2:
        {
        return "1.6kHz";
        }
    case 3:
        {
        return "level";
        }
    case 4:
        {
        return "800Hz";
        }
    case 5:
        {
        return "400Hz";
        }
    case 6:
        {
        return "200Hz";
        }
    case 7:
        {
        return "100Hz";
        }
    case 8:
        {
        return "Bypass7";
        }
    case 9:
        {
        return "EQVersion";
        }
    case 10:
        {
        return "Analog";
        }
    default:
        {
        index -= 11;

        if (index < this->p_10->getNumParameters())
            return this->p_10->getParameterId(index);

        index -= this->p_10->getNumParameters();

        if (index < this->p_11->getNumParameters())
            return this->p_11->getParameterId(index);

        index -= this->p_11->getNumParameters();

        if (index < this->p_12->getNumParameters())
            return this->p_12->getParameterId(index);

        index -= this->p_12->getNumParameters();

        if (index < this->p_13->getNumParameters())
            return this->p_13->getParameterId(index);

        index -= this->p_13->getNumParameters();

        if (index < this->p_14->getNumParameters())
            return this->p_14->getParameterId(index);

        index -= this->p_14->getNumParameters();

        if (index < this->p_15->getNumParameters())
            return this->p_15->getParameterId(index);

        index -= this->p_15->getNumParameters();

        if (index < this->p_16->getNumParameters())
            return this->p_16->getParameterId(index);

        index -= this->p_16->getNumParameters();

        if (index < this->p_17->getNumParameters())
            return this->p_17->getParameterId(index);

        index -= this->p_17->getNumParameters();

        if (index < this->p_18->getNumParameters())
            return this->p_18->getParameterId(index);

        return "bogus";
        }
    }
}

void getParameterInfo(ParameterIndex index, ParameterInfo * info) const {
    {
        switch (index) {
        case 0:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = -12;
            info->max = 12;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "6.4kHz";
            info->unit = "%";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 1:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = -12;
            info->max = 12;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "3.2kHz";
            info->unit = "%";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 2:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = -12;
            info->max = 12;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "1.6kHz";
            info->unit = "%";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 3:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = -12;
            info->max = 12;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "Level";
            info->unit = "%";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 4:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = -12;
            info->max = 12;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "800Hz";
            info->unit = "%";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 5:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = -12;
            info->max = 12;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = " 400Hz";
            info->unit = "%";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 6:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = -12;
            info->max = 12;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "200Hz";
            info->unit = "%";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 7:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = -12;
            info->max = 12;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "100Hz";
            info->unit = "%";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 8:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = 0;
            info->max = 1;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "";
            info->unit = "";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 9:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 1.01;
            info->min = 1;
            info->max = 2;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "";
            info->unit = "";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        case 10:
            {
            info->type = ParameterTypeNumber;
            info->initialValue = 0;
            info->min = 0;
            info->max = 1;
            info->exponent = 1;
            info->steps = 0;
            info->debug = false;
            info->saveable = true;
            info->transmittable = true;
            info->initialized = true;
            info->visible = true;
            info->displayName = "";
            info->unit = "";
            info->ioType = IOTypeUndefined;
            info->signalIndex = INVALID_INDEX;
            break;
            }
        default:
            {
            index -= 11;

            if (index < this->p_10->getNumParameters())
                this->p_10->getParameterInfo(index, info);

            index -= this->p_10->getNumParameters();

            if (index < this->p_11->getNumParameters())
                this->p_11->getParameterInfo(index, info);

            index -= this->p_11->getNumParameters();

            if (index < this->p_12->getNumParameters())
                this->p_12->getParameterInfo(index, info);

            index -= this->p_12->getNumParameters();

            if (index < this->p_13->getNumParameters())
                this->p_13->getParameterInfo(index, info);

            index -= this->p_13->getNumParameters();

            if (index < this->p_14->getNumParameters())
                this->p_14->getParameterInfo(index, info);

            index -= this->p_14->getNumParameters();

            if (index < this->p_15->getNumParameters())
                this->p_15->getParameterInfo(index, info);

            index -= this->p_15->getNumParameters();

            if (index < this->p_16->getNumParameters())
                this->p_16->getParameterInfo(index, info);

            index -= this->p_16->getNumParameters();

            if (index < this->p_17->getNumParameters())
                this->p_17->getParameterInfo(index, info);

            index -= this->p_17->getNumParameters();

            if (index < this->p_18->getNumParameters())
                this->p_18->getParameterInfo(index, info);

            break;
            }
        }
    }
}

void sendParameter(ParameterIndex index, bool ignoreValue) {
    this->getEngine()->notifyParameterValueChanged(index, (ignoreValue ? 0 : this->getParameterValue(index)), ignoreValue);
}

ParameterIndex getParameterOffset(BaseInterface* subpatcher) const {
    if (subpatcher == this->p_10)
        return 11;

    if (subpatcher == this->p_11)
        return 11 + this->p_10->getNumParameters();

    if (subpatcher == this->p_12)
        return 11 + this->p_10->getNumParameters() + this->p_11->getNumParameters();

    if (subpatcher == this->p_13)
        return 11 + this->p_10->getNumParameters() + this->p_11->getNumParameters() + this->p_12->getNumParameters();

    if (subpatcher == this->p_14)
        return 11 + this->p_10->getNumParameters() + this->p_11->getNumParameters() + this->p_12->getNumParameters() + this->p_13->getNumParameters();

    if (subpatcher == this->p_15)
        return 11 + this->p_10->getNumParameters() + this->p_11->getNumParameters() + this->p_12->getNumParameters() + this->p_13->getNumParameters() + this->p_14->getNumParameters();

    if (subpatcher == this->p_16)
        return 11 + this->p_10->getNumParameters() + this->p_11->getNumParameters() + this->p_12->getNumParameters() + this->p_13->getNumParameters() + this->p_14->getNumParameters() + this->p_15->getNumParameters();

    if (subpatcher == this->p_17)
        return 11 + this->p_10->getNumParameters() + this->p_11->getNumParameters() + this->p_12->getNumParameters() + this->p_13->getNumParameters() + this->p_14->getNumParameters() + this->p_15->getNumParameters() + this->p_16->getNumParameters();

    if (subpatcher == this->p_18)
        return 11 + this->p_10->getNumParameters() + this->p_11->getNumParameters() + this->p_12->getNumParameters() + this->p_13->getNumParameters() + this->p_14->getNumParameters() + this->p_15->getNumParameters() + this->p_16->getNumParameters() + this->p_17->getNumParameters();

    return 0;
}

ParameterValue applyStepsToNormalizedParameterValue(ParameterValue normalizedValue, int steps) const {
    if (steps == 1) {
        if (normalizedValue > 0) {
            normalizedValue = 1.;
        }
    } else {
        ParameterValue oneStep = (number)1. / (steps - 1);
        ParameterValue numberOfSteps = rnbo_fround(normalizedValue / oneStep * 1 / (number)1) * (number)1;
        normalizedValue = numberOfSteps * oneStep;
    }

    return normalizedValue;
}

ParameterValue convertToNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
    switch (index) {
    case 8:
    case 10:
        {
        {
            value = (value < 0 ? 0 : (value > 1 ? 1 : value));
            ParameterValue normalizedValue = (value - 0) / (1 - 0);
            return normalizedValue;
        }
        }
    case 9:
        {
        {
            value = (value < 1 ? 1 : (value > 2 ? 2 : value));
            ParameterValue normalizedValue = (value - 1) / (2 - 1);
            return normalizedValue;
        }
        }
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
        {
        {
            value = (value < -12 ? -12 : (value > 12 ? 12 : value));
            ParameterValue normalizedValue = (value - -12) / (12 - -12);
            return normalizedValue;
        }
        }
    default:
        {
        index -= 11;

        if (index < this->p_10->getNumParameters())
            return this->p_10->convertToNormalizedParameterValue(index, value);

        index -= this->p_10->getNumParameters();

        if (index < this->p_11->getNumParameters())
            return this->p_11->convertToNormalizedParameterValue(index, value);

        index -= this->p_11->getNumParameters();

        if (index < this->p_12->getNumParameters())
            return this->p_12->convertToNormalizedParameterValue(index, value);

        index -= this->p_12->getNumParameters();

        if (index < this->p_13->getNumParameters())
            return this->p_13->convertToNormalizedParameterValue(index, value);

        index -= this->p_13->getNumParameters();

        if (index < this->p_14->getNumParameters())
            return this->p_14->convertToNormalizedParameterValue(index, value);

        index -= this->p_14->getNumParameters();

        if (index < this->p_15->getNumParameters())
            return this->p_15->convertToNormalizedParameterValue(index, value);

        index -= this->p_15->getNumParameters();

        if (index < this->p_16->getNumParameters())
            return this->p_16->convertToNormalizedParameterValue(index, value);

        index -= this->p_16->getNumParameters();

        if (index < this->p_17->getNumParameters())
            return this->p_17->convertToNormalizedParameterValue(index, value);

        index -= this->p_17->getNumParameters();

        if (index < this->p_18->getNumParameters())
            return this->p_18->convertToNormalizedParameterValue(index, value);

        return value;
        }
    }
}

ParameterValue convertFromNormalizedParameterValue(ParameterIndex index, ParameterValue value) const {
    value = (value < 0 ? 0 : (value > 1 ? 1 : value));

    switch (index) {
    case 8:
    case 10:
        {
        {
            {
                return 0 + value * (1 - 0);
            }
        }
        }
    case 9:
        {
        {
            {
                return 1 + value * (2 - 1);
            }
        }
        }
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
        {
        {
            {
                return -12 + value * (12 - -12);
            }
        }
        }
    default:
        {
        index -= 11;

        if (index < this->p_10->getNumParameters())
            return this->p_10->convertFromNormalizedParameterValue(index, value);

        index -= this->p_10->getNumParameters();

        if (index < this->p_11->getNumParameters())
            return this->p_11->convertFromNormalizedParameterValue(index, value);

        index -= this->p_11->getNumParameters();

        if (index < this->p_12->getNumParameters())
            return this->p_12->convertFromNormalizedParameterValue(index, value);

        index -= this->p_12->getNumParameters();

        if (index < this->p_13->getNumParameters())
            return this->p_13->convertFromNormalizedParameterValue(index, value);

        index -= this->p_13->getNumParameters();

        if (index < this->p_14->getNumParameters())
            return this->p_14->convertFromNormalizedParameterValue(index, value);

        index -= this->p_14->getNumParameters();

        if (index < this->p_15->getNumParameters())
            return this->p_15->convertFromNormalizedParameterValue(index, value);

        index -= this->p_15->getNumParameters();

        if (index < this->p_16->getNumParameters())
            return this->p_16->convertFromNormalizedParameterValue(index, value);

        index -= this->p_16->getNumParameters();

        if (index < this->p_17->getNumParameters())
            return this->p_17->convertFromNormalizedParameterValue(index, value);

        index -= this->p_17->getNumParameters();

        if (index < this->p_18->getNumParameters())
            return this->p_18->convertFromNormalizedParameterValue(index, value);

        return value;
        }
    }
}

ParameterValue constrainParameterValue(ParameterIndex index, ParameterValue value) const {
    switch (index) {
    case 0:
        {
        return this->param_01_value_constrain(value);
        }
    case 1:
        {
        return this->param_02_value_constrain(value);
        }
    case 2:
        {
        return this->param_03_value_constrain(value);
        }
    case 3:
        {
        return this->param_04_value_constrain(value);
        }
    case 4:
        {
        return this->param_05_value_constrain(value);
        }
    case 5:
        {
        return this->param_06_value_constrain(value);
        }
    case 6:
        {
        return this->param_07_value_constrain(value);
        }
    case 7:
        {
        return this->param_08_value_constrain(value);
        }
    case 8:
        {
        return this->param_09_value_constrain(value);
        }
    case 9:
        {
        return this->param_10_value_constrain(value);
        }
    case 10:
        {
        return this->param_11_value_constrain(value);
        }
    default:
        {
        index -= 11;

        if (index < this->p_10->getNumParameters())
            return this->p_10->constrainParameterValue(index, value);

        index -= this->p_10->getNumParameters();

        if (index < this->p_11->getNumParameters())
            return this->p_11->constrainParameterValue(index, value);

        index -= this->p_11->getNumParameters();

        if (index < this->p_12->getNumParameters())
            return this->p_12->constrainParameterValue(index, value);

        index -= this->p_12->getNumParameters();

        if (index < this->p_13->getNumParameters())
            return this->p_13->constrainParameterValue(index, value);

        index -= this->p_13->getNumParameters();

        if (index < this->p_14->getNumParameters())
            return this->p_14->constrainParameterValue(index, value);

        index -= this->p_14->getNumParameters();

        if (index < this->p_15->getNumParameters())
            return this->p_15->constrainParameterValue(index, value);

        index -= this->p_15->getNumParameters();

        if (index < this->p_16->getNumParameters())
            return this->p_16->constrainParameterValue(index, value);

        index -= this->p_16->getNumParameters();

        if (index < this->p_17->getNumParameters())
            return this->p_17->constrainParameterValue(index, value);

        index -= this->p_17->getNumParameters();

        if (index < this->p_18->getNumParameters())
            return this->p_18->constrainParameterValue(index, value);

        return value;
        }
    }
}

void scheduleParamInit(ParameterIndex index, Index order) {
    this->paramInitIndices->push(index);
    this->paramInitOrder->push(order);
}

void processParamInitEvents() {
    this->listquicksort(
        this->paramInitOrder,
        this->paramInitIndices,
        0,
        (int)(this->paramInitOrder->length - 1),
        true
    );

    for (Index i = 0; i < this->paramInitOrder->length; i++) {
        this->getEngine()->scheduleParameterBang(this->paramInitIndices[i], 0);
    }
}

void processClockEvent(MillisecondTime time, ClockId index, bool hasValue, ParameterValue value) {
    RNBO_UNUSED(value);
    RNBO_UNUSED(hasValue);
    this->updateTime(time);

    switch (index) {
    case 892732297:
        {
        this->loadmess_01_startupbang_bang();
        break;
        }
    case -62043057:
        {
        this->linetilde_19_target_bang();
        break;
        }
    case -1621164530:
        {
        this->linetilde_20_target_bang();
        break;
        }
    case 1114681293:
        {
        this->linetilde_21_target_bang();
        break;
        }
    }
}

void processOutletAtCurrentTime(EngineLink* , OutletIndex , ParameterValue ) {}

void processOutletEvent(
    EngineLink* sender,
    OutletIndex index,
    ParameterValue value,
    MillisecondTime time
) {
    this->updateTime(time);
    this->processOutletAtCurrentTime(sender, index, value);
}

void processNumMessage(MessageTag tag, MessageTag objectId, MillisecondTime time, number payload) {
    this->updateTime(time);

    switch (tag) {
    case TAG("valin"):
        {
        if (TAG("number_obj-52") == objectId)
            this->numberobj_47_valin_set(payload);

        if (TAG("number_obj-47") == objectId)
            this->numberobj_48_valin_set(payload);

        break;
        }
    case TAG("format"):
        {
        if (TAG("number_obj-52") == objectId)
            this->numberobj_47_format_set(payload);

        if (TAG("number_obj-47") == objectId)
            this->numberobj_48_format_set(payload);

        break;
        }
    }

    this->p_10->processNumMessage(tag, objectId, time, payload);
    this->p_11->processNumMessage(tag, objectId, time, payload);
    this->p_12->processNumMessage(tag, objectId, time, payload);
    this->p_13->processNumMessage(tag, objectId, time, payload);
    this->p_14->processNumMessage(tag, objectId, time, payload);
    this->p_15->processNumMessage(tag, objectId, time, payload);
    this->p_16->processNumMessage(tag, objectId, time, payload);
    this->p_17->processNumMessage(tag, objectId, time, payload);
    this->p_18->processNumMessage(tag, objectId, time, payload);
}

void processListMessage(
    MessageTag tag,
    MessageTag objectId,
    MillisecondTime time,
    const list& payload
) {
    RNBO_UNUSED(objectId);
    this->updateTime(time);
    this->p_10->processListMessage(tag, objectId, time, payload);
    this->p_11->processListMessage(tag, objectId, time, payload);
    this->p_12->processListMessage(tag, objectId, time, payload);
    this->p_13->processListMessage(tag, objectId, time, payload);
    this->p_14->processListMessage(tag, objectId, time, payload);
    this->p_15->processListMessage(tag, objectId, time, payload);
    this->p_16->processListMessage(tag, objectId, time, payload);
    this->p_17->processListMessage(tag, objectId, time, payload);
    this->p_18->processListMessage(tag, objectId, time, payload);
}

void processBangMessage(MessageTag tag, MessageTag objectId, MillisecondTime time) {
    this->updateTime(time);

    switch (tag) {
    case TAG("startupbang"):
        {
        if (TAG("loadmess_obj-53") == objectId)
            this->loadmess_01_startupbang_bang();

        break;
        }
    }

    this->p_10->processBangMessage(tag, objectId, time);
    this->p_11->processBangMessage(tag, objectId, time);
    this->p_12->processBangMessage(tag, objectId, time);
    this->p_13->processBangMessage(tag, objectId, time);
    this->p_14->processBangMessage(tag, objectId, time);
    this->p_15->processBangMessage(tag, objectId, time);
    this->p_16->processBangMessage(tag, objectId, time);
    this->p_17->processBangMessage(tag, objectId, time);
    this->p_18->processBangMessage(tag, objectId, time);
}

MessageTagInfo resolveTag(MessageTag tag) const {
    switch (tag) {
    case TAG("valout"):
        {
        return "valout";
        }
    case TAG("number_obj-52"):
        {
        return "number_obj-52";
        }
    case TAG("setup"):
        {
        return "setup";
        }
    case TAG("number_obj-47"):
        {
        return "number_obj-47";
        }
    case TAG("startupbang"):
        {
        return "startupbang";
        }
    case TAG("loadmess_obj-53"):
        {
        return "loadmess_obj-53";
        }
    case TAG("valin"):
        {
        return "valin";
        }
    case TAG("format"):
        {
        return "format";
        }
    }

    auto subpatchResult_0 = this->p_10->resolveTag(tag);

    if (subpatchResult_0)
        return subpatchResult_0;

    auto subpatchResult_1 = this->p_11->resolveTag(tag);

    if (subpatchResult_1)
        return subpatchResult_1;

    auto subpatchResult_2 = this->p_12->resolveTag(tag);

    if (subpatchResult_2)
        return subpatchResult_2;

    auto subpatchResult_3 = this->p_13->resolveTag(tag);

    if (subpatchResult_3)
        return subpatchResult_3;

    auto subpatchResult_4 = this->p_14->resolveTag(tag);

    if (subpatchResult_4)
        return subpatchResult_4;

    auto subpatchResult_5 = this->p_15->resolveTag(tag);

    if (subpatchResult_5)
        return subpatchResult_5;

    auto subpatchResult_6 = this->p_16->resolveTag(tag);

    if (subpatchResult_6)
        return subpatchResult_6;

    auto subpatchResult_7 = this->p_17->resolveTag(tag);

    if (subpatchResult_7)
        return subpatchResult_7;

    auto subpatchResult_8 = this->p_18->resolveTag(tag);

    if (subpatchResult_8)
        return subpatchResult_8;

    return "";
}

MessageIndex getNumMessages() const {
    return 0;
}

const MessageInfo& getMessageInfo(MessageIndex index) const {
    switch (index) {

    }

    return NullMessageInfo;
}

protected:

void param_01_value_set(number v) {
    v = this->param_01_value_constrain(v);
    this->param_01_value = v;
    this->sendParameter(0, false);

    if (this->param_01_value != this->param_01_lastValue) {
        this->getEngine()->presetTouched();
        this->param_01_lastValue = this->param_01_value;
    }

    this->p_14_in3_number_set(v);
}

void param_02_value_set(number v) {
    v = this->param_02_value_constrain(v);
    this->param_02_value = v;
    this->sendParameter(1, false);

    if (this->param_02_value != this->param_02_lastValue) {
        this->getEngine()->presetTouched();
        this->param_02_lastValue = this->param_02_value;
    }

    this->p_15_in3_number_set(v);
}

void param_03_value_set(number v) {
    v = this->param_03_value_constrain(v);
    this->param_03_value = v;
    this->sendParameter(2, false);

    if (this->param_03_value != this->param_03_lastValue) {
        this->getEngine()->presetTouched();
        this->param_03_lastValue = this->param_03_value;
    }

    this->p_16_in3_number_set(v);
}

void param_04_value_set(number v) {
    v = this->param_04_value_constrain(v);
    this->param_04_value = v;
    this->sendParameter(3, false);

    if (this->param_04_value != this->param_04_lastValue) {
        this->getEngine()->presetTouched();
        this->param_04_lastValue = this->param_04_value;
    }

    this->p_11_in3_number_set(v);
}

void param_05_value_set(number v) {
    v = this->param_05_value_constrain(v);
    this->param_05_value = v;
    this->sendParameter(4, false);

    if (this->param_05_value != this->param_05_lastValue) {
        this->getEngine()->presetTouched();
        this->param_05_lastValue = this->param_05_value;
    }

    this->p_17_in3_number_set(v);
}

void param_06_value_set(number v) {
    v = this->param_06_value_constrain(v);
    this->param_06_value = v;
    this->sendParameter(5, false);

    if (this->param_06_value != this->param_06_lastValue) {
        this->getEngine()->presetTouched();
        this->param_06_lastValue = this->param_06_value;
    }

    this->p_18_in3_number_set(v);
}

void param_07_value_set(number v) {
    v = this->param_07_value_constrain(v);
    this->param_07_value = v;
    this->sendParameter(6, false);

    if (this->param_07_value != this->param_07_lastValue) {
        this->getEngine()->presetTouched();
        this->param_07_lastValue = this->param_07_value;
    }

    this->p_13_in3_number_set(v);
}

void param_08_value_set(number v) {
    v = this->param_08_value_constrain(v);
    this->param_08_value = v;
    this->sendParameter(7, false);

    if (this->param_08_value != this->param_08_lastValue) {
        this->getEngine()->presetTouched();
        this->param_08_lastValue = this->param_08_value;
    }

    this->p_12_in3_number_set(v);
}

void param_09_value_set(number v) {
    v = this->param_09_value_constrain(v);
    this->param_09_value = v;
    this->sendParameter(8, false);

    if (this->param_09_value != this->param_09_lastValue) {
        this->getEngine()->presetTouched();
        this->param_09_lastValue = this->param_09_value;
    }

    {
        list converted = {v};
        this->linetilde_19_segments_set(converted);
    }
}

void param_10_value_set(number v) {
    v = this->param_10_value_constrain(v);
    this->param_10_value = v;
    this->sendParameter(9, false);

    if (this->param_10_value != this->param_10_lastValue) {
        this->getEngine()->presetTouched();
        this->param_10_lastValue = this->param_10_value;
    }

    this->numberobj_47_value_set(v);
}

void param_11_value_set(number v) {
    v = this->param_11_value_constrain(v);
    this->param_11_value = v;
    this->sendParameter(10, false);

    if (this->param_11_value != this->param_11_lastValue) {
        this->getEngine()->presetTouched();
        this->param_11_lastValue = this->param_11_value;
    }

    this->numberobj_48_value_set(v);
    this->p_18_in4_number_set(v);
    this->p_13_in4_number_set(v);
    this->p_12_in4_number_set(v);
    this->p_14_in4_number_set(v);
    this->p_15_in4_number_set(v);
    this->p_16_in4_number_set(v);
    this->p_17_in4_number_set(v);
    this->p_10_in4_number_set(v);
}

void loadmess_01_startupbang_bang() {
    this->loadmess_01_message_bang();
}

void numberobj_47_valin_set(number v) {
    this->numberobj_47_value_set(v);
}

void numberobj_47_format_set(number v) {
    this->numberobj_47_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
}

void numberobj_48_valin_set(number v) {
    this->numberobj_48_value_set(v);
}

void numberobj_48_format_set(number v) {
    this->numberobj_48_currentFormat = trunc((v > 6 ? 6 : (v < 0 ? 0 : v)));
}

void linetilde_19_target_bang() {}

void linetilde_20_target_bang() {}

void linetilde_21_target_bang() {}

number msToSamps(MillisecondTime ms, number sampleRate) {
    return ms * sampleRate * 0.001;
}

MillisecondTime sampsToMs(SampleIndex samps) {
    return samps * (this->invsr * 1000);
}

Index getMaxBlockSize() const {
    return this->maxvs;
}

number getSampleRate() const {
    return this->sr;
}

bool hasFixedVectorSize() const {
    return false;
}

Index getNumInputChannels() const {
    return 2;
}

Index getNumOutputChannels() const {
    return 2;
}

void allocateDataRefs() {
    this->p_10->allocateDataRefs();
    this->p_11->allocateDataRefs();
    this->p_12->allocateDataRefs();
    this->p_13->allocateDataRefs();
    this->p_14->allocateDataRefs();
    this->p_15->allocateDataRefs();
    this->p_16->allocateDataRefs();
    this->p_17->allocateDataRefs();
    this->p_18->allocateDataRefs();
}

void initializeObjects() {
    this->gen_08_dc_l_init();
    this->gen_08_dc_r_init();
    this->noise_tilde_01_init();
    this->numberobj_47_init();
    this->noise_tilde_02_init();
    this->numberobj_48_init();
    this->p_10->initializeObjects();
    this->p_11->initializeObjects();
    this->p_12->initializeObjects();
    this->p_13->initializeObjects();
    this->p_14->initializeObjects();
    this->p_15->initializeObjects();
    this->p_16->initializeObjects();
    this->p_17->initializeObjects();
    this->p_18->initializeObjects();
}

void sendOutlet(OutletIndex index, ParameterValue value) {
    this->getEngine()->sendOutlet(this, index, value);
}

void startup() {
    this->updateTime(this->getEngine()->getCurrentTime());
    this->p_10->startup();
    this->p_11->startup();
    this->p_12->startup();
    this->p_13->startup();
    this->p_14->startup();
    this->p_15->startup();
    this->p_16->startup();
    this->p_17->startup();
    this->p_18->startup();
    this->getEngine()->scheduleClockEvent(this, 892732297, 0 + this->_currentTime);;

    {
        this->scheduleParamInit(0, 7);
    }

    {
        this->scheduleParamInit(1, 6);
    }

    {
        this->scheduleParamInit(2, 5);
    }

    {
        this->scheduleParamInit(3, 8);
    }

    {
        this->scheduleParamInit(4, 4);
    }

    {
        this->scheduleParamInit(5, 3);
    }

    {
        this->scheduleParamInit(6, 2);
    }

    {
        this->scheduleParamInit(7, 1);
    }

    {
        this->scheduleParamInit(8, 0);
    }

    {
        this->scheduleParamInit(9, 0);
    }

    {
        this->scheduleParamInit(10, 0);
    }

    this->processParamInitEvents();
}

number param_01_value_constrain(number v) const {
    v = (v > 12 ? 12 : (v < -12 ? -12 : v));
    return v;
}

void p_14_in3_number_set(number v) {
    this->p_14->updateTime(this->_currentTime);
    this->p_14->eventinlet_11_out1_number_set(v);
}

number param_02_value_constrain(number v) const {
    v = (v > 12 ? 12 : (v < -12 ? -12 : v));
    return v;
}

void p_15_in3_number_set(number v) {
    this->p_15->updateTime(this->_currentTime);
    this->p_15->eventinlet_14_out1_number_set(v);
}

number param_03_value_constrain(number v) const {
    v = (v > 12 ? 12 : (v < -12 ? -12 : v));
    return v;
}

void p_16_in3_number_set(number v) {
    this->p_16->updateTime(this->_currentTime);
    this->p_16->eventinlet_17_out1_number_set(v);
}

number param_04_value_constrain(number v) const {
    v = (v > 12 ? 12 : (v < -12 ? -12 : v));
    return v;
}

void p_11_in3_number_set(number v) {
    this->p_11->updateTime(this->_currentTime);
    this->p_11->eventinlet_02_out1_number_set(v);
}

number param_05_value_constrain(number v) const {
    v = (v > 12 ? 12 : (v < -12 ? -12 : v));
    return v;
}

void p_17_in3_number_set(number v) {
    this->p_17->updateTime(this->_currentTime);
    this->p_17->eventinlet_20_out1_number_set(v);
}

number param_06_value_constrain(number v) const {
    v = (v > 12 ? 12 : (v < -12 ? -12 : v));
    return v;
}

void p_18_in3_number_set(number v) {
    this->p_18->updateTime(this->_currentTime);
    this->p_18->eventinlet_23_out1_number_set(v);
}

number param_07_value_constrain(number v) const {
    v = (v > 12 ? 12 : (v < -12 ? -12 : v));
    return v;
}

void p_13_in3_number_set(number v) {
    this->p_13->updateTime(this->_currentTime);
    this->p_13->eventinlet_08_out1_number_set(v);
}

number param_08_value_constrain(number v) const {
    v = (v > 12 ? 12 : (v < -12 ? -12 : v));
    return v;
}

void p_12_in3_number_set(number v) {
    this->p_12->updateTime(this->_currentTime);
    this->p_12->eventinlet_05_out1_number_set(v);
}

number param_09_value_constrain(number v) const {
    v = (v > 1 ? 1 : (v < 0 ? 0 : v));
    return v;
}

void linetilde_19_time_set(number v) {
    this->linetilde_19_time = v;
}

void linetilde_19_segments_set(const list& v) {
    this->linetilde_19_segments = jsCreateListCopy(v);

    if ((bool)(v->length)) {
        if (v->length == 1 && this->linetilde_19_time == 0) {
            this->linetilde_19_activeRamps->length = 0;
            this->linetilde_19_currentValue = v[0];
        } else {
            auto currentTime = this->currentsampletime();
            number lastRampValue = this->linetilde_19_currentValue;
            number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;

            for (Index i = 0; i < this->linetilde_19_activeRamps->length; i += 3) {
                rampEnd = this->linetilde_19_activeRamps[(Index)(i + 2)];

                if (rampEnd > currentTime) {
                    this->linetilde_19_activeRamps[(Index)(i + 2)] = currentTime;
                    number diff = rampEnd - currentTime;
                    number valueDiff = diff * this->linetilde_19_activeRamps[(Index)(i + 1)];
                    lastRampValue = this->linetilde_19_activeRamps[(Index)i] - valueDiff;
                    this->linetilde_19_activeRamps[(Index)i] = lastRampValue;
                    this->linetilde_19_activeRamps->length = i + 3;
                    rampEnd = currentTime;
                } else {
                    lastRampValue = this->linetilde_19_activeRamps[(Index)i];
                }
            }

            if (rampEnd < currentTime) {
                this->linetilde_19_activeRamps->push(lastRampValue);
                this->linetilde_19_activeRamps->push(0);
                this->linetilde_19_activeRamps->push(currentTime);
            }

            number lastRampEnd = currentTime;

            for (Index i = 0; i < v->length; i += 2) {
                number destinationValue = v[(Index)i];
                number inc = 0;
                number rampTimeInSamples;

                if (v->length > i + 1) {
                    rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);

                    if ((bool)(this->linetilde_19_keepramp)) {
                        this->linetilde_19_time_set(v[(Index)(i + 1)]);
                    }
                } else {
                    rampTimeInSamples = this->mstosamps(this->linetilde_19_time);
                }

                if (rampTimeInSamples <= 0) {
                    rampTimeInSamples = 1;
                }

                inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                lastRampEnd += rampTimeInSamples;
                this->linetilde_19_activeRamps->push(destinationValue);
                this->linetilde_19_activeRamps->push(inc);
                this->linetilde_19_activeRamps->push(lastRampEnd);
                lastRampValue = destinationValue;
            }
        }
    }
}

number param_10_value_constrain(number v) const {
    v = (v > 2 ? 2 : (v < 1 ? 1 : v));
    return v;
}

void numberobj_47_output_set(number ) {}

void numberobj_47_value_set(number v) {
    this->numberobj_47_value_setter(v);
    v = this->numberobj_47_value;
    number localvalue = v;

    if (this->numberobj_47_currentFormat != 6) {
        localvalue = trunc(localvalue);
    }

    this->getEngine()->sendNumMessage(TAG("valout"), TAG("number_obj-52"), localvalue, this->_currentTime);
    this->numberobj_47_output_set(localvalue);
}

number param_11_value_constrain(number v) const {
    v = (v > 1 ? 1 : (v < 0 ? 0 : v));
    return v;
}

void linetilde_21_time_set(number v) {
    this->linetilde_21_time = v;
}

void linetilde_21_segments_set(const list& v) {
    this->linetilde_21_segments = jsCreateListCopy(v);

    if ((bool)(v->length)) {
        if (v->length == 1 && this->linetilde_21_time == 0) {
            this->linetilde_21_activeRamps->length = 0;
            this->linetilde_21_currentValue = v[0];
        } else {
            auto currentTime = this->currentsampletime();
            number lastRampValue = this->linetilde_21_currentValue;
            number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;

            for (Index i = 0; i < this->linetilde_21_activeRamps->length; i += 3) {
                rampEnd = this->linetilde_21_activeRamps[(Index)(i + 2)];

                if (rampEnd > currentTime) {
                    this->linetilde_21_activeRamps[(Index)(i + 2)] = currentTime;
                    number diff = rampEnd - currentTime;
                    number valueDiff = diff * this->linetilde_21_activeRamps[(Index)(i + 1)];
                    lastRampValue = this->linetilde_21_activeRamps[(Index)i] - valueDiff;
                    this->linetilde_21_activeRamps[(Index)i] = lastRampValue;
                    this->linetilde_21_activeRamps->length = i + 3;
                    rampEnd = currentTime;
                } else {
                    lastRampValue = this->linetilde_21_activeRamps[(Index)i];
                }
            }

            if (rampEnd < currentTime) {
                this->linetilde_21_activeRamps->push(lastRampValue);
                this->linetilde_21_activeRamps->push(0);
                this->linetilde_21_activeRamps->push(currentTime);
            }

            number lastRampEnd = currentTime;

            for (Index i = 0; i < v->length; i += 2) {
                number destinationValue = v[(Index)i];
                number inc = 0;
                number rampTimeInSamples;

                if (v->length > i + 1) {
                    rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);

                    if ((bool)(this->linetilde_21_keepramp)) {
                        this->linetilde_21_time_set(v[(Index)(i + 1)]);
                    }
                } else {
                    rampTimeInSamples = this->mstosamps(this->linetilde_21_time);
                }

                if (rampTimeInSamples <= 0) {
                    rampTimeInSamples = 1;
                }

                inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                lastRampEnd += rampTimeInSamples;
                this->linetilde_21_activeRamps->push(destinationValue);
                this->linetilde_21_activeRamps->push(inc);
                this->linetilde_21_activeRamps->push(lastRampEnd);
                lastRampValue = destinationValue;
            }
        }
    }
}

void expr_36_out1_set(number v) {
    this->expr_36_out1 = v;

    {
        list converted = {this->expr_36_out1};
        this->linetilde_21_segments_set(converted);
    }
}

void expr_36_in1_set(number in1) {
    this->expr_36_in1 = in1;
    this->expr_36_out1_set(this->expr_36_in1 * this->expr_36_in2);//#map:*_obj-45:1
}

void linetilde_20_time_set(number v) {
    this->linetilde_20_time = v;
}

void linetilde_20_segments_set(const list& v) {
    this->linetilde_20_segments = jsCreateListCopy(v);

    if ((bool)(v->length)) {
        if (v->length == 1 && this->linetilde_20_time == 0) {
            this->linetilde_20_activeRamps->length = 0;
            this->linetilde_20_currentValue = v[0];
        } else {
            auto currentTime = this->currentsampletime();
            number lastRampValue = this->linetilde_20_currentValue;
            number rampEnd = currentTime - this->sampleOffsetIntoNextAudioBuffer;

            for (Index i = 0; i < this->linetilde_20_activeRamps->length; i += 3) {
                rampEnd = this->linetilde_20_activeRamps[(Index)(i + 2)];

                if (rampEnd > currentTime) {
                    this->linetilde_20_activeRamps[(Index)(i + 2)] = currentTime;
                    number diff = rampEnd - currentTime;
                    number valueDiff = diff * this->linetilde_20_activeRamps[(Index)(i + 1)];
                    lastRampValue = this->linetilde_20_activeRamps[(Index)i] - valueDiff;
                    this->linetilde_20_activeRamps[(Index)i] = lastRampValue;
                    this->linetilde_20_activeRamps->length = i + 3;
                    rampEnd = currentTime;
                } else {
                    lastRampValue = this->linetilde_20_activeRamps[(Index)i];
                }
            }

            if (rampEnd < currentTime) {
                this->linetilde_20_activeRamps->push(lastRampValue);
                this->linetilde_20_activeRamps->push(0);
                this->linetilde_20_activeRamps->push(currentTime);
            }

            number lastRampEnd = currentTime;

            for (Index i = 0; i < v->length; i += 2) {
                number destinationValue = v[(Index)i];
                number inc = 0;
                number rampTimeInSamples;

                if (v->length > i + 1) {
                    rampTimeInSamples = this->mstosamps(v[(Index)(i + 1)]);

                    if ((bool)(this->linetilde_20_keepramp)) {
                        this->linetilde_20_time_set(v[(Index)(i + 1)]);
                    }
                } else {
                    rampTimeInSamples = this->mstosamps(this->linetilde_20_time);
                }

                if (rampTimeInSamples <= 0) {
                    rampTimeInSamples = 1;
                }

                inc = (destinationValue - lastRampValue) / rampTimeInSamples;
                lastRampEnd += rampTimeInSamples;
                this->linetilde_20_activeRamps->push(destinationValue);
                this->linetilde_20_activeRamps->push(inc);
                this->linetilde_20_activeRamps->push(lastRampEnd);
                lastRampValue = destinationValue;
            }
        }
    }
}

void expr_33_out1_set(number v) {
    this->expr_33_out1 = v;

    {
        list converted = {this->expr_33_out1};
        this->linetilde_20_segments_set(converted);
    }
}

void expr_33_in1_set(number in1) {
    this->expr_33_in1 = in1;
    this->expr_33_out1_set(this->expr_33_in1 * this->expr_33_in2);//#map:*_obj-32:1
}

void numberobj_48_output_set(number v) {
    this->expr_36_in1_set(v);
    this->expr_33_in1_set(v);
}

void numberobj_48_value_set(number v) {
    this->numberobj_48_value_setter(v);
    v = this->numberobj_48_value;
    number localvalue = v;

    if (this->numberobj_48_currentFormat != 6) {
        localvalue = trunc(localvalue);
    }

    this->getEngine()->sendNumMessage(TAG("valout"), TAG("number_obj-47"), localvalue, this->_currentTime);
    this->numberobj_48_output_set(localvalue);
}

void p_18_in4_number_set(number v) {
    this->p_18->updateTime(this->_currentTime);
    this->p_18->eventinlet_22_out1_number_set(v);
}

void p_13_in4_number_set(number v) {
    this->p_13->updateTime(this->_currentTime);
    this->p_13->eventinlet_07_out1_number_set(v);
}

void p_12_in4_number_set(number v) {
    this->p_12->updateTime(this->_currentTime);
    this->p_12->eventinlet_04_out1_number_set(v);
}

void p_14_in4_number_set(number v) {
    this->p_14->updateTime(this->_currentTime);
    this->p_14->eventinlet_10_out1_number_set(v);
}

void p_15_in4_number_set(number v) {
    this->p_15->updateTime(this->_currentTime);
    this->p_15->eventinlet_13_out1_number_set(v);
}

void p_16_in4_number_set(number v) {
    this->p_16->updateTime(this->_currentTime);
    this->p_16->eventinlet_16_out1_number_set(v);
}

void p_17_in4_number_set(number v) {
    this->p_17->updateTime(this->_currentTime);
    this->p_17->eventinlet_19_out1_number_set(v);
}

void p_10_in4_number_set(number v) {
    this->p_10->updateTime(this->_currentTime);
    this->p_10->eventinlet_01_out1_number_set(v);
}

void param_10_normalizedvalue_set(number v) {
    this->param_10_value_set(this->fromnormalized(9, v));
}

void loadmess_01_message_bang() {
    list v = this->loadmess_01_message;

    {
        if (v->length > 1)
            this->param_10_normalizedvalue_set(v[1]);

        number converted = (v->length > 0 ? v[0] : 0);
        this->param_10_value_set(converted);
    }
}

void ctlin_01_outchannel_set(number ) {}

void ctlin_01_outcontroller_set(number ) {}

void fromnormalized_01_output_set(number v) {
    this->param_01_value_set(v);
}

void fromnormalized_01_input_set(number v) {
    this->fromnormalized_01_output_set(this->fromnormalized(0, v));
}

void expr_25_out1_set(number v) {
    this->expr_25_out1 = v;
    this->fromnormalized_01_input_set(this->expr_25_out1);
}

void expr_25_in1_set(number in1) {
    this->expr_25_in1 = in1;
    this->expr_25_out1_set(this->expr_25_in1 * this->expr_25_in2);//#map:expr_25:1
}

void ctlin_01_value_set(number v) {
    this->expr_25_in1_set(v);
}

void ctlin_01_midihandler(int status, int channel, int port, ConstByteArray data, Index length) {
    RNBO_UNUSED(length);
    RNBO_UNUSED(port);

    if (status == 0xB0 && (channel == this->ctlin_01_channel || this->ctlin_01_channel == -1) && (data[1] == this->ctlin_01_controller || this->ctlin_01_controller == -1)) {
        this->ctlin_01_outchannel_set(channel);
        this->ctlin_01_outcontroller_set(data[1]);
        this->ctlin_01_value_set(data[2]);
        this->ctlin_01_status = 0;
    }
}

void ctlin_02_outchannel_set(number ) {}

void ctlin_02_outcontroller_set(number ) {}

void fromnormalized_02_output_set(number v) {
    this->param_02_value_set(v);
}

void fromnormalized_02_input_set(number v) {
    this->fromnormalized_02_output_set(this->fromnormalized(1, v));
}

void expr_26_out1_set(number v) {
    this->expr_26_out1 = v;
    this->fromnormalized_02_input_set(this->expr_26_out1);
}

void expr_26_in1_set(number in1) {
    this->expr_26_in1 = in1;
    this->expr_26_out1_set(this->expr_26_in1 * this->expr_26_in2);//#map:expr_26:1
}

void ctlin_02_value_set(number v) {
    this->expr_26_in1_set(v);
}

void ctlin_02_midihandler(int status, int channel, int port, ConstByteArray data, Index length) {
    RNBO_UNUSED(length);
    RNBO_UNUSED(port);

    if (status == 0xB0 && (channel == this->ctlin_02_channel || this->ctlin_02_channel == -1) && (data[1] == this->ctlin_02_controller || this->ctlin_02_controller == -1)) {
        this->ctlin_02_outchannel_set(channel);
        this->ctlin_02_outcontroller_set(data[1]);
        this->ctlin_02_value_set(data[2]);
        this->ctlin_02_status = 0;
    }
}

void ctlin_03_outchannel_set(number ) {}

void ctlin_03_outcontroller_set(number ) {}

void fromnormalized_03_output_set(number v) {
    this->param_03_value_set(v);
}

void fromnormalized_03_input_set(number v) {
    this->fromnormalized_03_output_set(this->fromnormalized(2, v));
}

void expr_27_out1_set(number v) {
    this->expr_27_out1 = v;
    this->fromnormalized_03_input_set(this->expr_27_out1);
}

void expr_27_in1_set(number in1) {
    this->expr_27_in1 = in1;
    this->expr_27_out1_set(this->expr_27_in1 * this->expr_27_in2);//#map:expr_27:1
}

void ctlin_03_value_set(number v) {
    this->expr_27_in1_set(v);
}

void ctlin_03_midihandler(int status, int channel, int port, ConstByteArray data, Index length) {
    RNBO_UNUSED(length);
    RNBO_UNUSED(port);

    if (status == 0xB0 && (channel == this->ctlin_03_channel || this->ctlin_03_channel == -1) && (data[1] == this->ctlin_03_controller || this->ctlin_03_controller == -1)) {
        this->ctlin_03_outchannel_set(channel);
        this->ctlin_03_outcontroller_set(data[1]);
        this->ctlin_03_value_set(data[2]);
        this->ctlin_03_status = 0;
    }
}

void ctlin_04_outchannel_set(number ) {}

void ctlin_04_outcontroller_set(number ) {}

void fromnormalized_04_output_set(number v) {
    this->param_04_value_set(v);
}

void fromnormalized_04_input_set(number v) {
    this->fromnormalized_04_output_set(this->fromnormalized(3, v));
}

void expr_28_out1_set(number v) {
    this->expr_28_out1 = v;
    this->fromnormalized_04_input_set(this->expr_28_out1);
}

void expr_28_in1_set(number in1) {
    this->expr_28_in1 = in1;
    this->expr_28_out1_set(this->expr_28_in1 * this->expr_28_in2);//#map:expr_28:1
}

void ctlin_04_value_set(number v) {
    this->expr_28_in1_set(v);
}

void ctlin_04_midihandler(int status, int channel, int port, ConstByteArray data, Index length) {
    RNBO_UNUSED(length);
    RNBO_UNUSED(port);

    if (status == 0xB0 && (channel == this->ctlin_04_channel || this->ctlin_04_channel == -1) && (data[1] == this->ctlin_04_controller || this->ctlin_04_controller == -1)) {
        this->ctlin_04_outchannel_set(channel);
        this->ctlin_04_outcontroller_set(data[1]);
        this->ctlin_04_value_set(data[2]);
        this->ctlin_04_status = 0;
    }
}

void ctlin_05_outchannel_set(number ) {}

void ctlin_05_outcontroller_set(number ) {}

void fromnormalized_05_output_set(number v) {
    this->param_05_value_set(v);
}

void fromnormalized_05_input_set(number v) {
    this->fromnormalized_05_output_set(this->fromnormalized(4, v));
}

void expr_29_out1_set(number v) {
    this->expr_29_out1 = v;
    this->fromnormalized_05_input_set(this->expr_29_out1);
}

void expr_29_in1_set(number in1) {
    this->expr_29_in1 = in1;
    this->expr_29_out1_set(this->expr_29_in1 * this->expr_29_in2);//#map:expr_29:1
}

void ctlin_05_value_set(number v) {
    this->expr_29_in1_set(v);
}

void ctlin_05_midihandler(int status, int channel, int port, ConstByteArray data, Index length) {
    RNBO_UNUSED(length);
    RNBO_UNUSED(port);

    if (status == 0xB0 && (channel == this->ctlin_05_channel || this->ctlin_05_channel == -1) && (data[1] == this->ctlin_05_controller || this->ctlin_05_controller == -1)) {
        this->ctlin_05_outchannel_set(channel);
        this->ctlin_05_outcontroller_set(data[1]);
        this->ctlin_05_value_set(data[2]);
        this->ctlin_05_status = 0;
    }
}

void ctlin_06_outchannel_set(number ) {}

void ctlin_06_outcontroller_set(number ) {}

void fromnormalized_06_output_set(number v) {
    this->param_06_value_set(v);
}

void fromnormalized_06_input_set(number v) {
    this->fromnormalized_06_output_set(this->fromnormalized(5, v));
}

void expr_30_out1_set(number v) {
    this->expr_30_out1 = v;
    this->fromnormalized_06_input_set(this->expr_30_out1);
}

void expr_30_in1_set(number in1) {
    this->expr_30_in1 = in1;
    this->expr_30_out1_set(this->expr_30_in1 * this->expr_30_in2);//#map:expr_30:1
}

void ctlin_06_value_set(number v) {
    this->expr_30_in1_set(v);
}

void ctlin_06_midihandler(int status, int channel, int port, ConstByteArray data, Index length) {
    RNBO_UNUSED(length);
    RNBO_UNUSED(port);

    if (status == 0xB0 && (channel == this->ctlin_06_channel || this->ctlin_06_channel == -1) && (data[1] == this->ctlin_06_controller || this->ctlin_06_controller == -1)) {
        this->ctlin_06_outchannel_set(channel);
        this->ctlin_06_outcontroller_set(data[1]);
        this->ctlin_06_value_set(data[2]);
        this->ctlin_06_status = 0;
    }
}

void ctlin_07_outchannel_set(number ) {}

void ctlin_07_outcontroller_set(number ) {}

void fromnormalized_07_output_set(number v) {
    this->param_07_value_set(v);
}

void fromnormalized_07_input_set(number v) {
    this->fromnormalized_07_output_set(this->fromnormalized(6, v));
}

void expr_31_out1_set(number v) {
    this->expr_31_out1 = v;
    this->fromnormalized_07_input_set(this->expr_31_out1);
}

void expr_31_in1_set(number in1) {
    this->expr_31_in1 = in1;
    this->expr_31_out1_set(this->expr_31_in1 * this->expr_31_in2);//#map:expr_31:1
}

void ctlin_07_value_set(number v) {
    this->expr_31_in1_set(v);
}

void ctlin_07_midihandler(int status, int channel, int port, ConstByteArray data, Index length) {
    RNBO_UNUSED(length);
    RNBO_UNUSED(port);

    if (status == 0xB0 && (channel == this->ctlin_07_channel || this->ctlin_07_channel == -1) && (data[1] == this->ctlin_07_controller || this->ctlin_07_controller == -1)) {
        this->ctlin_07_outchannel_set(channel);
        this->ctlin_07_outcontroller_set(data[1]);
        this->ctlin_07_value_set(data[2]);
        this->ctlin_07_status = 0;
    }
}

void ctlin_08_outchannel_set(number ) {}

void ctlin_08_outcontroller_set(number ) {}

void fromnormalized_08_output_set(number v) {
    this->param_08_value_set(v);
}

void fromnormalized_08_input_set(number v) {
    this->fromnormalized_08_output_set(this->fromnormalized(7, v));
}

void expr_32_out1_set(number v) {
    this->expr_32_out1 = v;
    this->fromnormalized_08_input_set(this->expr_32_out1);
}

void expr_32_in1_set(number in1) {
    this->expr_32_in1 = in1;
    this->expr_32_out1_set(this->expr_32_in1 * this->expr_32_in2);//#map:expr_32:1
}

void ctlin_08_value_set(number v) {
    this->expr_32_in1_set(v);
}

void ctlin_08_midihandler(int status, int channel, int port, ConstByteArray data, Index length) {
    RNBO_UNUSED(length);
    RNBO_UNUSED(port);

    if (status == 0xB0 && (channel == this->ctlin_08_channel || this->ctlin_08_channel == -1) && (data[1] == this->ctlin_08_controller || this->ctlin_08_controller == -1)) {
        this->ctlin_08_outchannel_set(channel);
        this->ctlin_08_outcontroller_set(data[1]);
        this->ctlin_08_value_set(data[2]);
        this->ctlin_08_status = 0;
    }
}

void ctlin_09_outchannel_set(number ) {}

void ctlin_09_outcontroller_set(number ) {}

void fromnormalized_09_output_set(number v) {
    this->param_09_value_set(v);
}

void fromnormalized_09_input_set(number v) {
    this->fromnormalized_09_output_set(this->fromnormalized(8, v));
}

void expr_34_out1_set(number v) {
    this->expr_34_out1 = v;
    this->fromnormalized_09_input_set(this->expr_34_out1);
}

void expr_34_in1_set(number in1) {
    this->expr_34_in1 = in1;
    this->expr_34_out1_set(this->expr_34_in1 * this->expr_34_in2);//#map:expr_34:1
}

void ctlin_09_value_set(number v) {
    this->expr_34_in1_set(v);
}

void ctlin_09_midihandler(int status, int channel, int port, ConstByteArray data, Index length) {
    RNBO_UNUSED(length);
    RNBO_UNUSED(port);

    if (status == 0xB0 && (channel == this->ctlin_09_channel || this->ctlin_09_channel == -1) && (data[1] == this->ctlin_09_controller || this->ctlin_09_controller == -1)) {
        this->ctlin_09_outchannel_set(channel);
        this->ctlin_09_outcontroller_set(data[1]);
        this->ctlin_09_value_set(data[2]);
        this->ctlin_09_status = 0;
    }
}

void ctlin_10_outchannel_set(number ) {}

void ctlin_10_outcontroller_set(number ) {}

void fromnormalized_10_output_set(number v) {
    this->param_11_value_set(v);
}

void fromnormalized_10_input_set(number v) {
    this->fromnormalized_10_output_set(this->fromnormalized(10, v));
}

void expr_35_out1_set(number v) {
    this->expr_35_out1 = v;
    this->fromnormalized_10_input_set(this->expr_35_out1);
}

void expr_35_in1_set(number in1) {
    this->expr_35_in1 = in1;
    this->expr_35_out1_set(this->expr_35_in1 * this->expr_35_in2);//#map:expr_35:1
}

void ctlin_10_value_set(number v) {
    this->expr_35_in1_set(v);
}

void ctlin_10_midihandler(int status, int channel, int port, ConstByteArray data, Index length) {
    RNBO_UNUSED(length);
    RNBO_UNUSED(port);

    if (status == 0xB0 && (channel == this->ctlin_10_channel || this->ctlin_10_channel == -1) && (data[1] == this->ctlin_10_controller || this->ctlin_10_controller == -1)) {
        this->ctlin_10_outchannel_set(channel);
        this->ctlin_10_outcontroller_set(data[1]);
        this->ctlin_10_value_set(data[2]);
        this->ctlin_10_status = 0;
    }
}

void linetilde_19_perform(SampleValue * out, Index n) {
    auto __linetilde_19_time = this->linetilde_19_time;
    auto __linetilde_19_keepramp = this->linetilde_19_keepramp;
    auto __linetilde_19_currentValue = this->linetilde_19_currentValue;
    Index i = 0;

    if ((bool)(this->linetilde_19_activeRamps->length)) {
        while ((bool)(this->linetilde_19_activeRamps->length) && i < n) {
            number destinationValue = this->linetilde_19_activeRamps[0];
            number inc = this->linetilde_19_activeRamps[1];
            number rampTimeInSamples = this->linetilde_19_activeRamps[2] - this->audioProcessSampleCount - i;
            number val = __linetilde_19_currentValue;

            while (rampTimeInSamples > 0 && i < n) {
                out[(Index)i] = val;
                val += inc;
                i++;
                rampTimeInSamples--;
            }

            if (rampTimeInSamples <= 0) {
                val = destinationValue;
                this->linetilde_19_activeRamps->splice(0, 3);

                if ((bool)(!(bool)(this->linetilde_19_activeRamps->length))) {
                    this->getEngine()->scheduleClockEventWithValue(
                        this,
                        -62043057,
                        this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                        0
                    );;

                    if ((bool)(!(bool)(__linetilde_19_keepramp))) {
                        __linetilde_19_time = 0;
                    }
                }
            }

            __linetilde_19_currentValue = val;
        }
    }

    while (i < n) {
        out[(Index)i] = __linetilde_19_currentValue;
        i++;
    }

    this->linetilde_19_currentValue = __linetilde_19_currentValue;
    this->linetilde_19_time = __linetilde_19_time;
}

void p_10_perform(
    const SampleValue * in1,
    const SampleValue * in2,
    SampleValue * out1,
    SampleValue * out2,
    Index n
) {
    // subpatcher: Head-Bump
    ConstSampleArray<2> ins = {in1, in2};

    SampleArray<2> outs = {out1, out2};
    this->p_10->process(ins, 2, outs, 2, n);
}

void p_12_perform(
    const SampleValue * in1,
    const SampleValue * in2,
    SampleValue * out1,
    SampleValue * out2,
    Index n
) {
    // subpatcher: 100Hz~
    ConstSampleArray<2> ins = {in1, in2};

    SampleArray<2> outs = {out1, out2};
    this->p_12->process(ins, 2, outs, 2, n);
}

void p_13_perform(
    const SampleValue * in1,
    const SampleValue * in2,
    SampleValue * out1,
    SampleValue * out2,
    Index n
) {
    // subpatcher: 200Hz~
    ConstSampleArray<2> ins = {in1, in2};

    SampleArray<2> outs = {out1, out2};
    this->p_13->process(ins, 2, outs, 2, n);
}

void p_18_perform(
    const SampleValue * in1,
    const SampleValue * in2,
    SampleValue * out1,
    SampleValue * out2,
    Index n
) {
    // subpatcher: 400Hz~
    ConstSampleArray<2> ins = {in1, in2};

    SampleArray<2> outs = {out1, out2};
    this->p_18->process(ins, 2, outs, 2, n);
}

void p_17_perform(
    const SampleValue * in1,
    const SampleValue * in2,
    SampleValue * out1,
    SampleValue * out2,
    Index n
) {
    // subpatcher: 800Hz~
    ConstSampleArray<2> ins = {in1, in2};

    SampleArray<2> outs = {out1, out2};
    this->p_17->process(ins, 2, outs, 2, n);
}

void p_16_perform(
    const SampleValue * in1,
    const SampleValue * in2,
    SampleValue * out1,
    SampleValue * out2,
    Index n
) {
    // subpatcher: 1.6kHz~
    ConstSampleArray<2> ins = {in1, in2};

    SampleArray<2> outs = {out1, out2};
    this->p_16->process(ins, 2, outs, 2, n);
}

void p_15_perform(
    const SampleValue * in1,
    const SampleValue * in2,
    SampleValue * out1,
    SampleValue * out2,
    Index n
) {
    // subpatcher: 3.2kHz~
    ConstSampleArray<2> ins = {in1, in2};

    SampleArray<2> outs = {out1, out2};
    this->p_15->process(ins, 2, outs, 2, n);
}

void p_14_perform(
    const SampleValue * in1,
    const SampleValue * in2,
    SampleValue * out1,
    SampleValue * out2,
    Index n
) {
    // subpatcher: 6.4kHz~
    ConstSampleArray<2> ins = {in1, in2};

    SampleArray<2> outs = {out1, out2};
    this->p_14->process(ins, 2, outs, 2, n);
}

void p_11_perform(
    const SampleValue * in1,
    const SampleValue * in2,
    SampleValue * out1,
    SampleValue * out2,
    Index n
) {
    // subpatcher: Level~
    ConstSampleArray<2> ins = {in1, in2};

    SampleArray<2> outs = {out1, out2};
    this->p_11->process(ins, 2, outs, 2, n);
}

void linetilde_20_perform(SampleValue * out, Index n) {
    auto __linetilde_20_time = this->linetilde_20_time;
    auto __linetilde_20_keepramp = this->linetilde_20_keepramp;
    auto __linetilde_20_currentValue = this->linetilde_20_currentValue;
    Index i = 0;

    if ((bool)(this->linetilde_20_activeRamps->length)) {
        while ((bool)(this->linetilde_20_activeRamps->length) && i < n) {
            number destinationValue = this->linetilde_20_activeRamps[0];
            number inc = this->linetilde_20_activeRamps[1];
            number rampTimeInSamples = this->linetilde_20_activeRamps[2] - this->audioProcessSampleCount - i;
            number val = __linetilde_20_currentValue;

            while (rampTimeInSamples > 0 && i < n) {
                out[(Index)i] = val;
                val += inc;
                i++;
                rampTimeInSamples--;
            }

            if (rampTimeInSamples <= 0) {
                val = destinationValue;
                this->linetilde_20_activeRamps->splice(0, 3);

                if ((bool)(!(bool)(this->linetilde_20_activeRamps->length))) {
                    this->getEngine()->scheduleClockEventWithValue(
                        this,
                        -1621164530,
                        this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                        0
                    );;

                    if ((bool)(!(bool)(__linetilde_20_keepramp))) {
                        __linetilde_20_time = 0;
                    }
                }
            }

            __linetilde_20_currentValue = val;
        }
    }

    while (i < n) {
        out[(Index)i] = __linetilde_20_currentValue;
        i++;
    }

    this->linetilde_20_currentValue = __linetilde_20_currentValue;
    this->linetilde_20_time = __linetilde_20_time;
}

void dspexpr_26_perform(const Sample * in1, const Sample * in2, SampleValue * out1, Index n) {
    Index i;

    for (i = 0; i < n; i++) {
        out1[(Index)i] = in1[(Index)i] * in2[(Index)i];//#map:_###_obj_###_:1
    }
}

void dspexpr_24_perform(const Sample * in1, const Sample * in2, SampleValue * out1, Index n) {
    Index i;

    for (i = 0; i < n; i++) {
        out1[(Index)i] = in1[(Index)i] + in2[(Index)i];//#map:_###_obj_###_:1
    }
}

void dspexpr_30_perform(const Sample * in1, const Sample * in2, SampleValue * out1, Index n) {
    Index i;

    for (i = 0; i < n; i++) {
        out1[(Index)i] = in1[(Index)i] * in2[(Index)i];//#map:_###_obj_###_:1
    }
}

void dspexpr_29_perform(const Sample * in1, const Sample * in2, SampleValue * out1, Index n) {
    Index i;

    for (i = 0; i < n; i++) {
        out1[(Index)i] = in1[(Index)i] + in2[(Index)i];//#map:_###_obj_###_:1
    }
}

void noise_tilde_01_perform(SampleValue * out1, Index n) {
    auto __noise_tilde_01_state = this->noise_tilde_01_state;
    Index i;

    for (i = 0; i < n; i++) {
        out1[(Index)i] = xoshiro_next(__noise_tilde_01_state);
    }
}

void onepole_tilde_03_perform(const Sample * x, number freqInHz, SampleValue * out1, Index n) {
    RNBO_UNUSED(freqInHz);
    auto __onepole_tilde_03_lastY = this->onepole_tilde_03_lastY;
    auto __onepole_tilde_03_b1 = this->onepole_tilde_03_b1;
    auto __onepole_tilde_03_a0 = this->onepole_tilde_03_a0;
    auto __onepole_tilde_03_needsUpdate = this->onepole_tilde_03_needsUpdate;
    auto __onepole_tilde_03_freq = this->onepole_tilde_03_freq;
    Index i;

    for (i = 0; i < n; i++) {
        if (__onepole_tilde_03_freq != 790 || (bool)(__onepole_tilde_03_needsUpdate)) {
            __onepole_tilde_03_freq = 790;
            __onepole_tilde_03_a0 = 1 - rnbo_exp(-4963.716392671873 / this->sr);
            __onepole_tilde_03_a0 = (__onepole_tilde_03_a0 > 0.99999 ? 0.99999 : (__onepole_tilde_03_a0 < 0.00001 ? 0.00001 : __onepole_tilde_03_a0));
            __onepole_tilde_03_b1 = 1 - __onepole_tilde_03_a0;
            __onepole_tilde_03_needsUpdate = false;
        }

        __onepole_tilde_03_lastY = __onepole_tilde_03_a0 * x[(Index)i] + __onepole_tilde_03_b1 * __onepole_tilde_03_lastY;
        out1[(Index)i] = __onepole_tilde_03_lastY;
    }

    this->onepole_tilde_03_freq = __onepole_tilde_03_freq;
    this->onepole_tilde_03_needsUpdate = __onepole_tilde_03_needsUpdate;
    this->onepole_tilde_03_a0 = __onepole_tilde_03_a0;
    this->onepole_tilde_03_b1 = __onepole_tilde_03_b1;
    this->onepole_tilde_03_lastY = __onepole_tilde_03_lastY;
}

void noise_tilde_02_perform(SampleValue * out1, Index n) {
    auto __noise_tilde_02_state = this->noise_tilde_02_state;
    Index i;

    for (i = 0; i < n; i++) {
        out1[(Index)i] = xoshiro_next(__noise_tilde_02_state);
    }
}

void onepole_tilde_04_perform(const Sample * x, number freqInHz, SampleValue * out1, Index n) {
    RNBO_UNUSED(freqInHz);
    auto __onepole_tilde_04_lastY = this->onepole_tilde_04_lastY;
    auto __onepole_tilde_04_b1 = this->onepole_tilde_04_b1;
    auto __onepole_tilde_04_a0 = this->onepole_tilde_04_a0;
    auto __onepole_tilde_04_needsUpdate = this->onepole_tilde_04_needsUpdate;
    auto __onepole_tilde_04_freq = this->onepole_tilde_04_freq;
    Index i;

    for (i = 0; i < n; i++) {
        if (__onepole_tilde_04_freq != 810 || (bool)(__onepole_tilde_04_needsUpdate)) {
            __onepole_tilde_04_freq = 810;
            __onepole_tilde_04_a0 = 1 - rnbo_exp(-5089.380098815464 / this->sr);
            __onepole_tilde_04_a0 = (__onepole_tilde_04_a0 > 0.99999 ? 0.99999 : (__onepole_tilde_04_a0 < 0.00001 ? 0.00001 : __onepole_tilde_04_a0));
            __onepole_tilde_04_b1 = 1 - __onepole_tilde_04_a0;
            __onepole_tilde_04_needsUpdate = false;
        }

        __onepole_tilde_04_lastY = __onepole_tilde_04_a0 * x[(Index)i] + __onepole_tilde_04_b1 * __onepole_tilde_04_lastY;
        out1[(Index)i] = __onepole_tilde_04_lastY;
    }

    this->onepole_tilde_04_freq = __onepole_tilde_04_freq;
    this->onepole_tilde_04_needsUpdate = __onepole_tilde_04_needsUpdate;
    this->onepole_tilde_04_a0 = __onepole_tilde_04_a0;
    this->onepole_tilde_04_b1 = __onepole_tilde_04_b1;
    this->onepole_tilde_04_lastY = __onepole_tilde_04_lastY;
}

void linetilde_21_perform(SampleValue * out, Index n) {
    auto __linetilde_21_time = this->linetilde_21_time;
    auto __linetilde_21_keepramp = this->linetilde_21_keepramp;
    auto __linetilde_21_currentValue = this->linetilde_21_currentValue;
    Index i = 0;

    if ((bool)(this->linetilde_21_activeRamps->length)) {
        while ((bool)(this->linetilde_21_activeRamps->length) && i < n) {
            number destinationValue = this->linetilde_21_activeRamps[0];
            number inc = this->linetilde_21_activeRamps[1];
            number rampTimeInSamples = this->linetilde_21_activeRamps[2] - this->audioProcessSampleCount - i;
            number val = __linetilde_21_currentValue;

            while (rampTimeInSamples > 0 && i < n) {
                out[(Index)i] = val;
                val += inc;
                i++;
                rampTimeInSamples--;
            }

            if (rampTimeInSamples <= 0) {
                val = destinationValue;
                this->linetilde_21_activeRamps->splice(0, 3);

                if ((bool)(!(bool)(this->linetilde_21_activeRamps->length))) {
                    this->getEngine()->scheduleClockEventWithValue(
                        this,
                        1114681293,
                        this->sampsToMs((SampleIndex)(this->vs)) + this->_currentTime,
                        0
                    );;

                    if ((bool)(!(bool)(__linetilde_21_keepramp))) {
                        __linetilde_21_time = 0;
                    }
                }
            }

            __linetilde_21_currentValue = val;
        }
    }

    while (i < n) {
        out[(Index)i] = __linetilde_21_currentValue;
        i++;
    }

    this->linetilde_21_currentValue = __linetilde_21_currentValue;
    this->linetilde_21_time = __linetilde_21_time;
}

void dspexpr_32_perform(const Sample * in1, const Sample * in2, SampleValue * out1, Index n) {
    Index i;

    for (i = 0; i < n; i++) {
        out1[(Index)i] = in1[(Index)i] * in2[(Index)i];//#map:_###_obj_###_:1
    }
}

void dspexpr_28_perform(const Sample * in1, const Sample * in2, SampleValue * out1, Index n) {
    Index i;

    for (i = 0; i < n; i++) {
        out1[(Index)i] = in1[(Index)i] + in2[(Index)i];//#map:_###_obj_###_:1
    }
}

void dspexpr_27_perform(
    const Sample * in1,
    const Sample * in2,
    const Sample * in3,
    SampleValue * out1,
    Index n
) {
    Index i;

    for (i = 0; i < n; i++) {
        out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
    }
}

void dspexpr_31_perform(const Sample * in1, const Sample * in2, SampleValue * out1, Index n) {
    Index i;

    for (i = 0; i < n; i++) {
        out1[(Index)i] = in1[(Index)i] * in2[(Index)i];//#map:_###_obj_###_:1
    }
}

void dspexpr_25_perform(const Sample * in1, const Sample * in2, SampleValue * out1, Index n) {
    Index i;

    for (i = 0; i < n; i++) {
        out1[(Index)i] = in1[(Index)i] + in2[(Index)i];//#map:_###_obj_###_:1
    }
}

void dspexpr_23_perform(
    const Sample * in1,
    const Sample * in2,
    const Sample * in3,
    SampleValue * out1,
    Index n
) {
    Index i;

    for (i = 0; i < n; i++) {
        out1[(Index)i] = in1[(Index)i] + in3[(Index)i] * (in2[(Index)i] - in1[(Index)i]);//#map:_###_obj_###_:1
    }
}

void gen_08_perform(
    const Sample * in1,
    const Sample * in2,
    SampleValue * out1,
    SampleValue * out2,
    Index n
) {
    auto __gen_08_dc_r_value = this->gen_08_dc_r_value;
    auto __gen_08_dc_l_value = this->gen_08_dc_l_value;
    Index i;

    for (i = 0; i < n; i++) {
        number in_l_0 = in1[(Index)i];
        number in_r_1 = in2[(Index)i];
        number out_l_2 = rnbo_tanh(in_l_0);
        number out_r_3 = rnbo_tanh(in_r_1);
        number final_l_4 = out_l_2 - __gen_08_dc_l_value + 0.999 * __gen_08_dc_l_value;
        __gen_08_dc_l_value = final_l_4;
        number final_r_5 = out_r_3 - __gen_08_dc_r_value + 0.999 * __gen_08_dc_r_value;
        __gen_08_dc_r_value = final_r_5;
        number expr_1_6 = final_l_4;
        number expr_2_7 = final_r_5;
        out2[(Index)i] = expr_2_7;
        out1[(Index)i] = expr_1_6;
    }

    this->gen_08_dc_l_value = __gen_08_dc_l_value;
    this->gen_08_dc_r_value = __gen_08_dc_r_value;
}

void stackprotect_perform(Index n) {
    RNBO_UNUSED(n);
    auto __stackprotect_count = this->stackprotect_count;
    __stackprotect_count = 0;
    this->stackprotect_count = __stackprotect_count;
}

void numberobj_47_value_setter(number v) {
    number localvalue = v;

    if (this->numberobj_47_currentFormat != 6) {
        localvalue = trunc(localvalue);
    }

    this->numberobj_47_value = localvalue;
}

void numberobj_48_value_setter(number v) {
    number localvalue = v;

    if (this->numberobj_48_currentFormat != 6) {
        localvalue = trunc(localvalue);
    }

    this->numberobj_48_value = localvalue;
}

number gen_08_dc_l_getvalue() {
    return this->gen_08_dc_l_value;
}

void gen_08_dc_l_setvalue(number val) {
    this->gen_08_dc_l_value = val;
}

void gen_08_dc_l_reset() {
    this->gen_08_dc_l_value = 0;
}

void gen_08_dc_l_init() {
    this->gen_08_dc_l_value = 0;
}

number gen_08_dc_r_getvalue() {
    return this->gen_08_dc_r_value;
}

void gen_08_dc_r_setvalue(number val) {
    this->gen_08_dc_r_value = val;
}

void gen_08_dc_r_reset() {
    this->gen_08_dc_r_value = 0;
}

void gen_08_dc_r_init() {
    this->gen_08_dc_r_value = 0;
}

void param_01_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_01_value;
}

void param_01_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_01_value_set(preset["value"]);
}

void param_02_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_02_value;
}

void param_02_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_02_value_set(preset["value"]);
}

void param_03_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_03_value;
}

void param_03_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_03_value_set(preset["value"]);
}

void param_04_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_04_value;
}

void param_04_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_04_value_set(preset["value"]);
}

void param_05_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_05_value;
}

void param_05_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_05_value_set(preset["value"]);
}

void param_06_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_06_value;
}

void param_06_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_06_value_set(preset["value"]);
}

void param_07_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_07_value;
}

void param_07_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_07_value_set(preset["value"]);
}

void param_08_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_08_value;
}

void param_08_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_08_value_set(preset["value"]);
}

void param_09_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_09_value;
}

void param_09_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_09_value_set(preset["value"]);
}

void onepole_tilde_03_reset() {
    this->onepole_tilde_03_lastY = 0;
    this->onepole_tilde_03_a0 = 0;
    this->onepole_tilde_03_b1 = 0;
}

void onepole_tilde_03_dspsetup(bool force) {
    if ((bool)(this->onepole_tilde_03_setupDone) && (bool)(!(bool)(force)))
        return;

    this->onepole_tilde_03_needsUpdate = true;
    this->onepole_tilde_03_reset();
    this->onepole_tilde_03_setupDone = true;
}

void noise_tilde_01_init() {
    this->noise_tilde_01_reset();
}

void noise_tilde_01_reset() {
    xoshiro_reset(
        systemticks() + this->voice() + this->random(0, 10000),
        this->noise_tilde_01_state
    );
}

void numberobj_47_init() {
    this->numberobj_47_currentFormat = 6;
    this->getEngine()->sendNumMessage(TAG("setup"), TAG("number_obj-52"), 1, this->_currentTime);
}

void numberobj_47_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->numberobj_47_value;
}

void numberobj_47_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->numberobj_47_value_set(preset["value"]);
}

void param_10_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_10_value;
}

void param_10_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_10_value_set(preset["value"]);
}

void param_11_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->param_11_value;
}

void param_11_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->param_11_value_set(preset["value"]);
}

void onepole_tilde_04_reset() {
    this->onepole_tilde_04_lastY = 0;
    this->onepole_tilde_04_a0 = 0;
    this->onepole_tilde_04_b1 = 0;
}

void onepole_tilde_04_dspsetup(bool force) {
    if ((bool)(this->onepole_tilde_04_setupDone) && (bool)(!(bool)(force)))
        return;

    this->onepole_tilde_04_needsUpdate = true;
    this->onepole_tilde_04_reset();
    this->onepole_tilde_04_setupDone = true;
}

void noise_tilde_02_init() {
    this->noise_tilde_02_reset();
}

void noise_tilde_02_reset() {
    xoshiro_reset(
        systemticks() + this->voice() + this->random(0, 10000),
        this->noise_tilde_02_state
    );
}

void numberobj_48_init() {
    this->numberobj_48_currentFormat = 6;
    this->getEngine()->sendNumMessage(TAG("setup"), TAG("number_obj-47"), 1, this->_currentTime);
}

void numberobj_48_getPresetValue(PatcherStateInterface& preset) {
    preset["value"] = this->numberobj_48_value;
}

void numberobj_48_setPresetValue(PatcherStateInterface& preset) {
    if ((bool)(stateIsEmpty(preset)))
        return;

    this->numberobj_48_value_set(preset["value"]);
}

void globaltransport_advance() {}

void globaltransport_dspsetup(bool ) {}

bool stackprotect_check() {
    this->stackprotect_count++;

    if (this->stackprotect_count > 128) {
        console->log("STACK OVERFLOW DETECTED - stopped processing branch !");
        return true;
    }

    return false;
}

void updateTime(MillisecondTime time) {
    this->_currentTime = time;
    this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(rnbo_fround(this->msToSamps(time - this->getEngine()->getCurrentTime(), this->sr)));

    if (this->sampleOffsetIntoNextAudioBuffer >= (SampleIndex)(this->vs))
        this->sampleOffsetIntoNextAudioBuffer = (SampleIndex)(this->vs) - 1;

    if (this->sampleOffsetIntoNextAudioBuffer < 0)
        this->sampleOffsetIntoNextAudioBuffer = 0;
}

void assign_defaults()
{
    gen_08_in1 = 0;
    gen_08_in2 = 0;
    dspexpr_23_in1 = 0;
    dspexpr_23_in2 = 0;
    dspexpr_23_in3 = 0;
    dspexpr_24_in1 = 0;
    dspexpr_24_in2 = 0;
    p_10_target = 0;
    dspexpr_25_in1 = 0;
    dspexpr_25_in2 = 0;
    p_11_target = 0;
    p_12_target = 0;
    p_13_target = 0;
    p_14_target = 0;
    p_15_target = 0;
    p_16_target = 0;
    p_17_target = 0;
    p_18_target = 0;
    dspexpr_26_in1 = 0;
    dspexpr_26_in2 = 0;
    linetilde_19_time = 10;
    linetilde_19_keepramp = 1;
    dspexpr_27_in1 = 0;
    dspexpr_27_in2 = 0;
    dspexpr_27_in3 = 0;
    dspexpr_28_in1 = 0;
    dspexpr_28_in2 = 0;
    dspexpr_29_in1 = 0;
    dspexpr_29_in2 = 0;
    dspexpr_30_in1 = 0;
    dspexpr_30_in2 = 0;
    param_01_value = 0;
    param_02_value = 0;
    param_03_value = 0;
    param_04_value = 0;
    param_05_value = 0;
    param_06_value = 0;
    param_07_value = 0;
    param_08_value = 0;
    linetilde_20_time = 10;
    linetilde_20_keepramp = 1;
    expr_33_in1 = 0;
    expr_33_in2 = 0.001;
    expr_33_out1 = 0;
    param_09_value = 0;
    dspexpr_31_in1 = 0;
    dspexpr_31_in2 = 0;
    onepole_tilde_03_x = 0;
    onepole_tilde_03_freqInHz = 790;
    loadmess_01_message = { 1.01 };
    numberobj_47_value = 0;
    numberobj_47_value_setter(numberobj_47_value);
    param_10_value = 1.01;
    param_11_value = 0;
    dspexpr_32_in1 = 0;
    dspexpr_32_in2 = 0;
    onepole_tilde_04_x = 0;
    onepole_tilde_04_freqInHz = 810;
    linetilde_21_time = 10;
    linetilde_21_keepramp = 1;
    numberobj_48_value = 0;
    numberobj_48_value_setter(numberobj_48_value);
    expr_36_in1 = 0;
    expr_36_in2 = 0.00005;
    expr_36_out1 = 0;
    ctlin_01_input = 0;
    ctlin_01_controller = 7;
    ctlin_01_channel = -1;
    expr_25_in1 = 0;
    expr_25_in2 = 0.007874015748;
    expr_25_out1 = 0;
    ctlin_02_input = 0;
    ctlin_02_controller = 6;
    ctlin_02_channel = -1;
    expr_26_in1 = 0;
    expr_26_in2 = 0.007874015748;
    expr_26_out1 = 0;
    ctlin_03_input = 0;
    ctlin_03_controller = 5;
    ctlin_03_channel = -1;
    expr_27_in1 = 0;
    expr_27_in2 = 0.007874015748;
    expr_27_out1 = 0;
    ctlin_04_input = 0;
    ctlin_04_controller = 8;
    ctlin_04_channel = -1;
    expr_28_in1 = 0;
    expr_28_in2 = 0.007874015748;
    expr_28_out1 = 0;
    ctlin_05_input = 0;
    ctlin_05_controller = 4;
    ctlin_05_channel = -1;
    expr_29_in1 = 0;
    expr_29_in2 = 0.007874015748;
    expr_29_out1 = 0;
    ctlin_06_input = 0;
    ctlin_06_controller = 3;
    ctlin_06_channel = -1;
    expr_30_in1 = 0;
    expr_30_in2 = 0.007874015748;
    expr_30_out1 = 0;
    ctlin_07_input = 0;
    ctlin_07_controller = 2;
    ctlin_07_channel = -1;
    expr_31_in1 = 0;
    expr_31_in2 = 0.007874015748;
    expr_31_out1 = 0;
    ctlin_08_input = 0;
    ctlin_08_controller = 1;
    ctlin_08_channel = -1;
    expr_32_in1 = 0;
    expr_32_in2 = 0.007874015748;
    expr_32_out1 = 0;
    ctlin_09_input = 0;
    ctlin_09_controller = -1;
    ctlin_09_channel = -1;
    expr_34_in1 = 0;
    expr_34_in2 = 0.007874015748;
    expr_34_out1 = 0;
    ctlin_10_input = 0;
    ctlin_10_controller = -1;
    ctlin_10_channel = -1;
    expr_35_in1 = 0;
    expr_35_in2 = 0.007874015748;
    expr_35_out1 = 0;
    _currentTime = 0;
    audioProcessSampleCount = 0;
    sampleOffsetIntoNextAudioBuffer = 0;
    zeroBuffer = nullptr;
    dummyBuffer = nullptr;
    signals[0] = nullptr;
    signals[1] = nullptr;
    signals[2] = nullptr;
    signals[3] = nullptr;
    signals[4] = nullptr;
    signals[5] = nullptr;
    signals[6] = nullptr;
    didAllocateSignals = 0;
    vs = 0;
    maxvs = 0;
    sr = 44100;
    invsr = 0.00002267573696;
    gen_08_dc_l_value = 0;
    gen_08_dc_r_value = 0;
    linetilde_19_currentValue = 0;
    param_01_lastValue = 0;
    param_02_lastValue = 0;
    param_03_lastValue = 0;
    param_04_lastValue = 0;
    param_05_lastValue = 0;
    param_06_lastValue = 0;
    param_07_lastValue = 0;
    param_08_lastValue = 0;
    linetilde_20_currentValue = 0;
    param_09_lastValue = 0;
    onepole_tilde_03_freq = 0;
    onepole_tilde_03_needsUpdate = false;
    onepole_tilde_03_lastY = 0;
    onepole_tilde_03_a0 = 0;
    onepole_tilde_03_b1 = 0;
    onepole_tilde_03_setupDone = false;
    numberobj_47_currentFormat = 6;
    numberobj_47_lastValue = 0;
    param_10_lastValue = 0;
    param_11_lastValue = 0;
    onepole_tilde_04_freq = 0;
    onepole_tilde_04_needsUpdate = false;
    onepole_tilde_04_lastY = 0;
    onepole_tilde_04_a0 = 0;
    onepole_tilde_04_b1 = 0;
    onepole_tilde_04_setupDone = false;
    linetilde_21_currentValue = 0;
    numberobj_48_currentFormat = 6;
    numberobj_48_lastValue = 0;
    ctlin_01_status = 0;
    ctlin_01_byte1 = -1;
    ctlin_01_inchan = 0;
    ctlin_02_status = 0;
    ctlin_02_byte1 = -1;
    ctlin_02_inchan = 0;
    ctlin_03_status = 0;
    ctlin_03_byte1 = -1;
    ctlin_03_inchan = 0;
    ctlin_04_status = 0;
    ctlin_04_byte1 = -1;
    ctlin_04_inchan = 0;
    ctlin_05_status = 0;
    ctlin_05_byte1 = -1;
    ctlin_05_inchan = 0;
    ctlin_06_status = 0;
    ctlin_06_byte1 = -1;
    ctlin_06_inchan = 0;
    ctlin_07_status = 0;
    ctlin_07_byte1 = -1;
    ctlin_07_inchan = 0;
    ctlin_08_status = 0;
    ctlin_08_byte1 = -1;
    ctlin_08_inchan = 0;
    ctlin_09_status = 0;
    ctlin_09_byte1 = -1;
    ctlin_09_inchan = 0;
    ctlin_10_status = 0;
    ctlin_10_byte1 = -1;
    ctlin_10_inchan = 0;
    globaltransport_tempo = nullptr;
    globaltransport_state = nullptr;
    stackprotect_count = 0;
    _voiceIndex = 0;
    _noteNumber = 0;
    isMuted = 1;
}

// member variables

    number gen_08_in1;
    number gen_08_in2;
    number dspexpr_23_in1;
    number dspexpr_23_in2;
    number dspexpr_23_in3;
    number dspexpr_24_in1;
    number dspexpr_24_in2;
    number p_10_target;
    number dspexpr_25_in1;
    number dspexpr_25_in2;
    number p_11_target;
    number p_12_target;
    number p_13_target;
    number p_14_target;
    number p_15_target;
    number p_16_target;
    number p_17_target;
    number p_18_target;
    number dspexpr_26_in1;
    number dspexpr_26_in2;
    list linetilde_19_segments;
    number linetilde_19_time;
    number linetilde_19_keepramp;
    number dspexpr_27_in1;
    number dspexpr_27_in2;
    number dspexpr_27_in3;
    number dspexpr_28_in1;
    number dspexpr_28_in2;
    number dspexpr_29_in1;
    number dspexpr_29_in2;
    number dspexpr_30_in1;
    number dspexpr_30_in2;
    number param_01_value;
    number param_02_value;
    number param_03_value;
    number param_04_value;
    number param_05_value;
    number param_06_value;
    number param_07_value;
    number param_08_value;
    list linetilde_20_segments;
    number linetilde_20_time;
    number linetilde_20_keepramp;
    number expr_33_in1;
    number expr_33_in2;
    number expr_33_out1;
    number param_09_value;
    number dspexpr_31_in1;
    number dspexpr_31_in2;
    number onepole_tilde_03_x;
    number onepole_tilde_03_freqInHz;
    list loadmess_01_message;
    number numberobj_47_value;
    number param_10_value;
    number param_11_value;
    number dspexpr_32_in1;
    number dspexpr_32_in2;
    number onepole_tilde_04_x;
    number onepole_tilde_04_freqInHz;
    list linetilde_21_segments;
    number linetilde_21_time;
    number linetilde_21_keepramp;
    number numberobj_48_value;
    number expr_36_in1;
    number expr_36_in2;
    number expr_36_out1;
    number ctlin_01_input;
    number ctlin_01_controller;
    number ctlin_01_channel;
    number expr_25_in1;
    number expr_25_in2;
    number expr_25_out1;
    number ctlin_02_input;
    number ctlin_02_controller;
    number ctlin_02_channel;
    number expr_26_in1;
    number expr_26_in2;
    number expr_26_out1;
    number ctlin_03_input;
    number ctlin_03_controller;
    number ctlin_03_channel;
    number expr_27_in1;
    number expr_27_in2;
    number expr_27_out1;
    number ctlin_04_input;
    number ctlin_04_controller;
    number ctlin_04_channel;
    number expr_28_in1;
    number expr_28_in2;
    number expr_28_out1;
    number ctlin_05_input;
    number ctlin_05_controller;
    number ctlin_05_channel;
    number expr_29_in1;
    number expr_29_in2;
    number expr_29_out1;
    number ctlin_06_input;
    number ctlin_06_controller;
    number ctlin_06_channel;
    number expr_30_in1;
    number expr_30_in2;
    number expr_30_out1;
    number ctlin_07_input;
    number ctlin_07_controller;
    number ctlin_07_channel;
    number expr_31_in1;
    number expr_31_in2;
    number expr_31_out1;
    number ctlin_08_input;
    number ctlin_08_controller;
    number ctlin_08_channel;
    number expr_32_in1;
    number expr_32_in2;
    number expr_32_out1;
    number ctlin_09_input;
    number ctlin_09_controller;
    number ctlin_09_channel;
    number expr_34_in1;
    number expr_34_in2;
    number expr_34_out1;
    number ctlin_10_input;
    number ctlin_10_controller;
    number ctlin_10_channel;
    number expr_35_in1;
    number expr_35_in2;
    number expr_35_out1;
    MillisecondTime _currentTime;
    UInt64 audioProcessSampleCount;
    SampleIndex sampleOffsetIntoNextAudioBuffer;
    signal zeroBuffer;
    signal dummyBuffer;
    SampleValue * signals[7];
    bool didAllocateSignals;
    Index vs;
    Index maxvs;
    number sr;
    number invsr;
    number gen_08_dc_l_value;
    number gen_08_dc_r_value;
    list linetilde_19_activeRamps;
    number linetilde_19_currentValue;
    number param_01_lastValue;
    number param_02_lastValue;
    number param_03_lastValue;
    number param_04_lastValue;
    number param_05_lastValue;
    number param_06_lastValue;
    number param_07_lastValue;
    number param_08_lastValue;
    list linetilde_20_activeRamps;
    number linetilde_20_currentValue;
    number param_09_lastValue;
    number onepole_tilde_03_freq;
    bool onepole_tilde_03_needsUpdate;
    number onepole_tilde_03_lastY;
    number onepole_tilde_03_a0;
    number onepole_tilde_03_b1;
    bool onepole_tilde_03_setupDone;
    UInt noise_tilde_01_state[4] = { };
    Int numberobj_47_currentFormat;
    number numberobj_47_lastValue;
    number param_10_lastValue;
    number param_11_lastValue;
    number onepole_tilde_04_freq;
    bool onepole_tilde_04_needsUpdate;
    number onepole_tilde_04_lastY;
    number onepole_tilde_04_a0;
    number onepole_tilde_04_b1;
    bool onepole_tilde_04_setupDone;
    UInt noise_tilde_02_state[4] = { };
    list linetilde_21_activeRamps;
    number linetilde_21_currentValue;
    Int numberobj_48_currentFormat;
    number numberobj_48_lastValue;
    int ctlin_01_status;
    int ctlin_01_byte1;
    int ctlin_01_inchan;
    int ctlin_02_status;
    int ctlin_02_byte1;
    int ctlin_02_inchan;
    int ctlin_03_status;
    int ctlin_03_byte1;
    int ctlin_03_inchan;
    int ctlin_04_status;
    int ctlin_04_byte1;
    int ctlin_04_inchan;
    int ctlin_05_status;
    int ctlin_05_byte1;
    int ctlin_05_inchan;
    int ctlin_06_status;
    int ctlin_06_byte1;
    int ctlin_06_inchan;
    int ctlin_07_status;
    int ctlin_07_byte1;
    int ctlin_07_inchan;
    int ctlin_08_status;
    int ctlin_08_byte1;
    int ctlin_08_inchan;
    int ctlin_09_status;
    int ctlin_09_byte1;
    int ctlin_09_inchan;
    int ctlin_10_status;
    int ctlin_10_byte1;
    int ctlin_10_inchan;
    signal globaltransport_tempo;
    signal globaltransport_state;
    number stackprotect_count;
    Index _voiceIndex;
    Int _noteNumber;
    Index isMuted;
    indexlist paramInitIndices;
    indexlist paramInitOrder;
    RNBOSubpatcher_199* p_10;
    RNBOSubpatcher_200* p_11;
    RNBOSubpatcher_201* p_12;
    RNBOSubpatcher_202* p_13;
    RNBOSubpatcher_203* p_14;
    RNBOSubpatcher_204* p_15;
    RNBOSubpatcher_205* p_16;
    RNBOSubpatcher_206* p_17;
    RNBOSubpatcher_207* p_18;

};

PatcherInterface* createGrafik7()
{
    return new Grafik7();
}

#ifndef RNBO_NO_PATCHERFACTORY

extern "C" PatcherFactoryFunctionPtr GetPatcherFactoryFunction(PlatformInterface* platformInterface)
#else

extern "C" PatcherFactoryFunctionPtr Grafik7FactoryFunction(PlatformInterface* platformInterface)
#endif

{
    Platform::set(platformInterface);
    return createGrafik7;
}

} // end RNBO namespace

